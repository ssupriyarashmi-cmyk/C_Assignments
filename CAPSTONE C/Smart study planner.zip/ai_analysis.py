"""
AI Student Performance Analysis Module
Analyzes quiz attempts at the topic and difficulty level.
Computes performance trends (Improving, Declining, Strong, Moderate, Weak),
identifies learning gaps, and produces class-level analytics for teachers.
"""

from database import get_db

class PerformanceAnalyzer:
    @staticmethod
    def analyze_attempt(attempt_id):
        """
        Calculates detailed topic-wise and difficulty-wise breakdown for a single quiz attempt.
        """
        conn = get_db()
        attempt = conn.execute("""
            SELECT qa.*, q.title as quiz_title, q.topic as quiz_topic, q.quiz_type, q.difficulty,
                   s.name as subject_name, s.code as subject_code
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.id = ?
        """, (attempt_id,)).fetchone()

        if not attempt:
            conn.close()
            return None

        # Fetch individual question responses
        answers = conn.execute("""
            SELECT qaa.*, qq.difficulty, qq.question_text, qq.explanation
            FROM quiz_attempt_answers qaa
            JOIN quiz_questions qq ON qaa.question_id = qq.id
            WHERE qaa.attempt_id = ?
        """, (attempt_id,)).fetchall()

        conn.close()

        # 1. Topic-wise breakdown
        topic_map = {}
        for a in answers:
            t = a['topic']
            if t not in topic_map:
                topic_map[t] = {'topic': t, 'total': 0, 'correct': 0, 'incorrect': 0}
            topic_map[t]['total'] += 1
            if a['is_correct']:
                topic_map[t]['correct'] += 1
            else:
                topic_map[t]['incorrect'] += 1

        topic_stats = []
        for t, data in topic_map.items():
            pct = round((data['correct'] / data['total']) * 100.0, 1) if data['total'] > 0 else 0.0
            status = PerformanceAnalyzer._classify_score(pct)
            is_definitive = data['total'] >= 2
            topic_stats.append({
                'topic': t,
                'total': data['total'],
                'correct': data['correct'],
                'incorrect': data['incorrect'],
                'percentage': pct,
                'status': status,
                'is_definitive': is_definitive,
                'evidence_note': f"Definitive ({data['total']} questions)" if is_definitive else "Preliminary (1 question)"
            })

        # 2. Difficulty-wise breakdown
        diff_map = {'Easy': {'total': 0, 'correct': 0}, 'Medium': {'total': 0, 'correct': 0}, 'Hard': {'total': 0, 'correct': 0}}
        for a in answers:
            d = a['difficulty'] or 'Medium'
            d = d.capitalize()
            if d not in diff_map:
                diff_map[d] = {'total': 0, 'correct': 0}
            diff_map[d]['total'] += 1
            if a['is_correct']:
                diff_map[d]['correct'] += 1

        difficulty_stats = {}
        for d, data in diff_map.items():
            if data['total'] > 0:
                difficulty_stats[d] = {
                    'total': data['total'],
                    'correct': data['correct'],
                    'percentage': round((data['correct'] / data['total']) * 100.0, 1)
                }

        incorrect_count = attempt['total_questions'] - attempt['correct_answers']

        return {
            'attempt': dict(attempt),
            'total_questions': attempt['total_questions'],
            'correct_answers': attempt['correct_answers'],
            'incorrect_answers': incorrect_count,
            'score_percentage': attempt['score_percentage'],
            'topic_stats': topic_stats,
            'difficulty_stats': difficulty_stats,
            'time_taken_seconds': attempt['time_taken_seconds'] or 0
        }

    @staticmethod
    def _classify_score(score_pct):
        if score_pct >= 80.0:
            return "Strong"
        elif score_pct >= 60.0:
            return "Moderate"
        else:
            return "Weak"

    @staticmethod
    def analyze_student(student_id):
        """
        Analyzes the full quiz history for a student across all subjects and topics.
        Calculates:
        - Overall metrics & subject scores
        - Topic-wise accuracy and attempt history
        - Strong, Moderate, Weak, Improving, Declining topic classifications
        - Chronological progress line data
        """
        conn = get_db()
        
        # 1. Fetch all attempts ordered chronologically
        attempts = conn.execute("""
            SELECT qa.id, qa.quiz_id, qa.score_percentage, qa.total_questions, qa.correct_answers,
                   qa.attempted_at, q.title as quiz_title, q.topic as quiz_topic,
                   s.id as subject_id, s.name as subject_name, s.code as subject_code
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ?
            ORDER BY qa.attempted_at ASC
        """, (student_id,)).fetchall()

        if not attempts:
            conn.close()
            return {
                'has_data': False,
                'overall_average': 0.0,
                'total_attempts': 0,
                'total_questions_attempted': 0,
                'all_topics': [],
                'subject_scores': {},
                'topic_analysis': {},
                'strong_topics': [],
                'moderate_topics': [],
                'weak_topics': [],
                'improving_topics': [],
                'declining_topics': [],
                'recent_history': [],
                'chart_data': {
                    'dates': [],
                    'scores': [],
                    'subject_labels': [],
                    'subject_scores': [],
                    'topic_labels': [],
                    'topic_scores': []
                }
            }

        # 2. Fetch all individual answers with topic attribution and attempt_id
        answers = conn.execute("""
            SELECT qaa.attempt_id, qaa.topic, qaa.is_correct, qa.attempted_at, qa.score_percentage,
                   s.name as subject_name, s.id as subject_id
            FROM quiz_attempt_answers qaa
            JOIN quiz_attempts qa ON qaa.attempt_id = qa.id
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ?
            ORDER BY qa.attempted_at ASC, qaa.attempt_id ASC
        """, (student_id,)).fetchall()

        conn.close()

        # Group by topic and attempt to get accurate chronological scores per topic
        topic_data = {}
        for a in answers:
            t = a['topic']
            att_id = a['attempt_id']
            if t not in topic_data:
                topic_data[t] = {
                    'topic': t,
                    'subject_name': a['subject_name'],
                    'subject_id': a['subject_id'],
                    'total_questions': 0,
                    'correct_answers': 0,
                    'attempts_dict': {}
                }
            topic_data[t]['total_questions'] += 1
            if a['is_correct']:
                topic_data[t]['correct_answers'] += 1

            if att_id not in topic_data[t]['attempts_dict']:
                topic_data[t]['attempts_dict'][att_id] = {'correct': 0, 'total': 0, 'date': a['attempted_at']}
            topic_data[t]['attempts_dict'][att_id]['total'] += 1
            if a['is_correct']:
                topic_data[t]['attempts_dict'][att_id]['correct'] += 1

        for t, d in topic_data.items():
            scores_history = []
            for att_id, att_stat in d['attempts_dict'].items():
                att_pct = round((att_stat['correct'] / att_stat['total']) * 100.0, 1) if att_stat['total'] > 0 else 0.0
                scores_history.append(att_pct)
            d['scores_history'] = scores_history

        # Classify each topic
        strong_topics = []
        moderate_topics = []
        weak_topics = []
        improving_topics = []
        declining_topics = []

        processed_topics = []
        for t, d in topic_data.items():
            acc = round((d['correct_answers'] / d['total_questions']) * 100.0, 1) if d['total_questions'] > 0 else 0.0
            history = d['scores_history']
            is_definitive = d['total_questions'] >= 2
            
            # Base classification
            base_status = PerformanceAnalyzer._classify_score(acc)
            if len(history) < 2:
                trend = "Insufficient History"
            else:
                trend = "Stable"
            
            # Trend calculation when multiple attempts exist
            if len(history) >= 2:
                first_score = history[0]
                latest_score = history[-1]
                delta = latest_score - first_score
                
                # Check consecutive trend
                is_consistently_rising = all(history[i] <= history[i+1] for i in range(len(history)-1)) and (latest_score > first_score)
                is_consistently_falling = all(history[i] >= history[i+1] for i in range(len(history)-1)) and (latest_score < first_score)
                
                if (delta >= 10.0) or is_consistently_rising:
                    trend = "Improving"
                    improving_topics.append({
                        'topic': t,
                        'subject': d['subject_name'],
                        'current_score': latest_score,
                        'first_score': first_score,
                        'delta': round(delta, 1),
                        'history': history,
                        'base_status': base_status,
                        'trend': 'Improving',
                        'is_definitive': is_definitive
                    })
                elif (delta <= -10.0) or is_consistently_falling:
                    trend = "Declining"
                    declining_topics.append({
                        'topic': t,
                        'subject': d['subject_name'],
                        'current_score': latest_score,
                        'first_score': first_score,
                        'delta': round(delta, 1),
                        'history': history,
                        'base_status': base_status,
                        'trend': 'Declining',
                        'is_definitive': is_definitive
                    })

            # Populate category lists
            topic_entry = {
                'topic': t,
                'subject': d['subject_name'],
                'subject_id': d['subject_id'],
                'accuracy': acc,
                'total_questions': d['total_questions'],
                'correct_answers': d['correct_answers'],
                'attempts_count': len(history) or 1,
                'scores_history': history,
                'trend': trend,
                'status': base_status,
                'is_definitive': is_definitive,
                'evidence_note': f"Definitive ({d['total_questions']} questions attempted)" if is_definitive else f"Preliminary (Only {d['total_questions']} question attempted)"
            }

            if base_status == 'Strong':
                strong_topics.append(topic_entry)
            elif base_status == 'Moderate':
                moderate_topics.append(topic_entry)
            else:
                weak_topics.append(topic_entry)

            processed_topics.append(topic_entry)

        # Subject-wise analysis
        subject_map = {}
        for att in attempts:
            sname = att['subject_name']
            if sname not in subject_map:
                subject_map[sname] = {'total_score': 0, 'count': 0, 'code': att['subject_code']}
            subject_map[sname]['total_score'] += att['score_percentage']
            subject_map[sname]['count'] += 1

        subject_averages = {
            s: round(data['total_score'] / data['count'], 1)
            for s, data in subject_map.items()
        }

        # Overall average
        total_att = len(attempts)
        overall_avg = round(sum(a['score_percentage'] for a in attempts) / total_att, 1) if total_att > 0 else 0.0
        total_q = sum(a['total_questions'] for a in attempts)

        # Chart.js formatting
        progress_dates = [a['attempted_at'][:10] for a in attempts]
        progress_scores = [round(a['score_percentage'], 1) for a in attempts]

        subj_labels = list(subject_averages.keys())
        subj_scores = list(subject_averages.values())

        top_topics_sorted = sorted(processed_topics, key=lambda x: x['accuracy'])
        topic_labels = [item['topic'] for item in top_topics_sorted[:8]]
        topic_scores = [item['accuracy'] for item in top_topics_sorted[:8]]

        return {
            'has_data': True,
            'overall_average': overall_avg,
            'total_attempts': total_att,
            'total_questions_attempted': total_q,
            'subject_scores': subject_averages,
            'all_topics': processed_topics,
            'strong_topics': strong_topics,
            'moderate_topics': moderate_topics,
            'weak_topics': weak_topics,
            'improving_topics': improving_topics,
            'declining_topics': declining_topics,
            'recent_history': list(reversed(attempts))[:6],
            'chart_data': {
                'dates': progress_dates,
                'scores': progress_scores,
                'subject_labels': subj_labels,
                'subject_scores': subj_scores,
                'topic_labels': topic_labels,
                'topic_scores': topic_scores
            }
        }

    @staticmethod
    def analyze_teacher_class(teacher_id, subject_id=None):
        """
        Computes class-level analytics for all students enrolled in a teacher's subjects.
        Identifies class average, struggling students, and the most challenging topics.
        """
        conn = get_db()
        cursor = conn.cursor()

        # Enrolled students query
        query_params = [teacher_id]
        subj_filter = ""
        if subject_id:
            subj_filter = "AND s.id = ?"
            query_params.append(subject_id)

        students = cursor.execute(f"""
            SELECT DISTINCT u.id, u.name, u.identifier, u.department
            FROM enrolments e
            JOIN subjects s ON e.subject_id = s.id
            JOIN users u ON e.student_id = u.id
            WHERE s.teacher_id = ? {subj_filter}
            ORDER BY u.name ASC
        """, query_params).fetchall()

        if not students:
            conn.close()
            return {
                'student_count': 0,
                'class_average': 0.0,
                'challenging_topics': [],
                'students_needing_support': [],
                'student_rankings': []
            }

        student_ids = [s['id'] for s in students]
        placeholders = ','.join('?' for _ in student_ids)

        # Get all attempts from these students
        attempts = cursor.execute(f"""
            SELECT qa.student_id, qa.score_percentage, qa.attempted_at, q.topic as quiz_topic,
                   s.name as subject_name
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id IN ({placeholders}) AND s.teacher_id = ?
        """, student_ids + [teacher_id]).fetchall()

        # Answers for topic analysis
        answers = cursor.execute(f"""
            SELECT qaa.topic, qaa.is_correct, qa.student_id
            FROM quiz_attempt_answers qaa
            JOIN quiz_attempts qa ON qaa.attempt_id = qa.id
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id IN ({placeholders}) AND s.teacher_id = ?
        """, student_ids + [teacher_id]).fetchall()

        conn.close()

        # Student averages
        student_scores = {s['id']: [] for s in students}
        for a in attempts:
            student_scores[a['student_id']].append(a['score_percentage'])

        student_rankings = []
        students_needing_support = []

        for s in students:
            scores = student_scores.get(s['id'], [])
            avg_s = round(sum(scores) / len(scores), 1) if scores else 0.0
            
            # Check trend
            if len(scores) < 2:
                trend = "Insufficient History"
            elif scores[-1] > scores[0]:
                trend = "Improving"
            elif scores[-1] < scores[0]:
                trend = "Declining"
            else:
                trend = "Stable"

            info = {
                'student_id': s['id'],
                'name': s['name'],
                'identifier': s['identifier'],
                'department': s['department'],
                'attempts_count': len(scores),
                'average_score': avg_s,
                'trend': trend
            }
            student_rankings.append(info)

            # Flag if low score or declining
            if (len(scores) > 0 and avg_s < 60.0) or (trend == 'Declining'):
                reason = "Low average score (<60%)" if avg_s < 60.0 else "Declining performance trend"
                students_needing_support.append({
                    **info,
                    'reason': reason
                })

        # Sort rankings by score descending
        student_rankings.sort(key=lambda x: x['average_score'], reverse=True)

        # Topic breakdown across entire class
        topic_totals = {}
        for ans in answers:
            t = ans['topic']
            if t not in topic_totals:
                topic_totals[t] = {'total': 0, 'correct': 0, 'students': set()}
            topic_totals[t]['total'] += 1
            if ans['is_correct']:
                topic_totals[t]['correct'] += 1
            topic_totals[t]['students'].add(ans['student_id'])

        challenging_topics = []
        for t, data in topic_totals.items():
            pct = round((data['correct'] / data['total']) * 100.0, 1) if data['total'] > 0 else 0.0
            challenging_topics.append({
                'topic': t,
                'accuracy': pct,
                'total_attempts': data['total'],
                'students_attempted': len(data['students']),
                'struggling_pct': round(100.0 - pct, 1)
            })

        # Sort by lowest accuracy first (most challenging)
        challenging_topics.sort(key=lambda x: x['accuracy'])

        all_scores = [a['score_percentage'] for a in attempts]
        class_avg = round(sum(all_scores) / len(all_scores), 1) if all_scores else 0.0

        return {
            'student_count': len(students),
            'enrolled_count': len(students),
            'class_average': class_avg,
            'total_attempts': len(attempts),
            'challenging_topics': challenging_topics[:6],
            'students_needing_support': students_needing_support,
            'student_rankings': student_rankings
        }
