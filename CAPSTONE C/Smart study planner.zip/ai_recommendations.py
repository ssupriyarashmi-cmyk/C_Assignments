"""
Personalized Study Recommendations Module
Generates personalized study guidance based on topic-level quiz performance.
Links weak and moderate topics with relevant teacher-uploaded study materials
and suggests structured revision durations.
"""

from database import get_db

class RecommendationEngine:
    @staticmethod
    def generate_recommendations(student_id, student_analysis=None):
        """
        Generates action-oriented recommendations based on recent topic performance
        and saves them to the study_recommendations table.
        """
        from ai_analysis import PerformanceAnalyzer
        if not student_analysis:
            student_analysis = PerformanceAnalyzer.analyze_student(student_id)

        if not student_analysis.get('has_data'):
            return []

        conn = get_db()
        cursor = conn.cursor()

        # Fetch all available materials for this student
        materials = cursor.execute("""
            SELECT m.id, m.title, m.topic, m.material_type, m.file_path, m.external_link,
                   s.id as subject_id, s.name as subject_name
            FROM study_materials m
            JOIN subjects s ON m.subject_id = s.id
            JOIN enrolments e ON s.id = e.subject_id
            WHERE e.student_id = ?
        """, (student_id,)).fetchall()

        # Build map of topic -> materials
        topic_materials = {}
        for m in materials:
            t_key = m['topic'].strip().lower()
            if t_key not in topic_materials:
                topic_materials[t_key] = []
            topic_materials[t_key].append(m)

        recommendations = []

        # 1. Process Weak Topics (High Priority)
        for w in student_analysis.get('weak_topics', []):
            t_name = w['topic']
            t_key = t_name.strip().lower()
            matching_mat = topic_materials.get(t_key, [None])[0]
            mat_id = matching_mat['id'] if matching_mat else None
            mat_title = matching_mat['title'] if matching_mat else None

            action = f"Review foundational concepts in '{t_name}'. Focus on basic principles before re-attempting practice quizzes."
            if mat_title:
                action += f" Refer to teacher resource: '{mat_title}'."
            else:
                action += " Attempt an AI Easy Practice quiz to build confidence."

            duration = 50  # minutes

            rec = {
                'student_id': student_id,
                'subject_id': w.get('subject_id'),
                'subject_name': w.get('subject', 'Core Subject'),
                'topic': t_name,
                'score_percentage': w['accuracy'],
                'status': 'Weak',
                'trend': w.get('trend', 'Stable'),
                'recommended_action': action,
                'suggested_duration_mins': duration,
                'material_id': mat_id,
                'material_title': mat_title
            }
            recommendations.append(rec)

        # 2. Process Declining Topics (Urgent Intervention)
        for d in student_analysis.get('declining_topics', []):
            t_name = d['topic']
            # Avoid duplicate if already added
            if any(r['topic'] == t_name for r in recommendations):
                continue

            t_key = t_name.strip().lower()
            matching_mat = topic_materials.get(t_key, [None])[0]
            mat_id = matching_mat['id'] if matching_mat else None

            action = f"Performance in '{t_name}' has decreased from {d['first_score']}% to {d['current_score']}%. Schedule an immediate revision session."
            rec = {
                'student_id': student_id,
                'subject_id': None,
                'subject_name': d.get('subject', 'Core Subject'),
                'topic': t_name,
                'score_percentage': d['current_score'],
                'status': 'Declining',
                'trend': 'Declining',
                'recommended_action': action,
                'suggested_duration_mins': 45,
                'material_id': mat_id,
                'material_title': matching_mat['title'] if matching_mat else None
            }
            recommendations.append(rec)

        # 3. Process Moderate Topics (Improving / Consolidating)
        for m in student_analysis.get('moderate_topics', [])[:3]:
            t_name = m['topic']
            action = f"Solid understanding in '{t_name}'. Solve 5-10 additional Medium/Hard practice problems to advance to Strong mastery."
            rec = {
                'student_id': student_id,
                'subject_id': m.get('subject_id'),
                'subject_name': m.get('subject', 'Core Subject'),
                'topic': t_name,
                'score_percentage': m['accuracy'],
                'status': 'Moderate',
                'trend': m.get('trend', 'Stable'),
                'recommended_action': action,
                'suggested_duration_mins': 35,
                'material_id': None,
                'material_title': None
            }
            recommendations.append(rec)

        # 4. Process Strong Topics (Maintenance)
        for s in student_analysis.get('strong_topics', [])[:2]:
            t_name = s['topic']
            action = f"Excellent mastery ({s['accuracy']}%) in '{t_name}'! Maintain retention with a quick 15-minute weekly flashcard check."
            rec = {
                'student_id': student_id,
                'subject_id': s.get('subject_id'),
                'subject_name': s.get('subject', 'Core Subject'),
                'topic': t_name,
                'score_percentage': s['accuracy'],
                'status': 'Strong',
                'trend': s.get('trend', 'Stable'),
                'recommended_action': action,
                'suggested_duration_mins': 20,
                'material_id': None,
                'material_title': None
            }
            recommendations.append(rec)

        # Save to database (refresh recommendations)
        cursor.execute("DELETE FROM study_recommendations WHERE student_id = ?", (student_id,))
        for r in recommendations:
            cursor.execute("""
                INSERT INTO study_recommendations 
                (student_id, subject_id, subject_name, topic, score_percentage, status, recommended_action, suggested_duration_mins, material_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                r['student_id'], r['subject_id'], r['subject_name'], r['topic'],
                r['score_percentage'], r['status'], r['recommended_action'],
                r['suggested_duration_mins'], r['material_id']
            ))

        conn.commit()
        conn.close()

        return recommendations

    @staticmethod
    def get_latest_recommendations(student_id):
        """Retrieves stored recommendations or generates fresh ones if empty."""
        conn = get_db()
        recs = conn.execute("""
            SELECT sr.*, sm.title as material_title, sm.material_type, sm.file_path, sm.external_link
            FROM study_recommendations sr
            LEFT JOIN study_materials sm ON sr.material_id = sm.id
            WHERE sr.student_id = ?
            ORDER BY 
                CASE sr.status
                    WHEN 'Weak' THEN 1
                    WHEN 'Declining' THEN 2
                    WHEN 'Moderate' THEN 3
                    WHEN 'Strong' THEN 4
                    ELSE 5
                END ASC,
                sr.score_percentage ASC
        """, (student_id,)).fetchall()
        conn.close()

        if not recs:
            return RecommendationEngine.generate_recommendations(student_id)
        return [dict(r) for r in recs]
