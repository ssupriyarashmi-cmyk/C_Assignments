"""
AI Quiz Generation Module
Provides local intelligent question generation across engineering subjects and topics.
Supports Easy, Medium, and Hard difficulty levels with 4 options, explanations,
and algorithmic variations to prevent question exhaustion.
"""

import random
import sqlite3
from database import get_db

# Structured Question Bank categorized by subject keywords, topic, and difficulty
QUESTION_BANK = {
    # -------------------------------------------------------------
    # 1. Programming for Problem Solving (C Programming)
    # -------------------------------------------------------------
    "Introduction to C Programming": {
        "Easy": [
            {
                "question": "Which of the following is the standard entry point function in any C program?",
                "options": {"A": "void start()", "B": "int main()", "C": "run()", "D": "init()"},
                "correct": "B",
                "explanation": "Execution of every C program begins at the main() function."
            },
            {
                "question": "Which header file is required to use the printf() and scanf() functions in C?",
                "options": {"A": "<conio.h>", "B": "<stdlib.h>", "C": "<stdio.h>", "D": "<math.h>"},
                "correct": "C",
                "explanation": "<stdio.h> stands for Standard Input Output header and defines standard I/O streams."
            }
        ],
        "Medium": [
            {
                "question": "What is the primary role of the preprocessor in the C compilation process?",
                "options": {
                    "A": "Translates C code directly into machine assembly language",
                    "B": "Handles directives starting with '#' such as macro expansion and file inclusion",
                    "C": "Links external object files together into an executable",
                    "D": "Executes the compiled machine bytecode"
                },
                "correct": "B",
                "explanation": "The preprocessor operates before compilation, expanding macros (#define) and including header files (#include)."
            }
        ],
        "Hard": [
            {
                "question": "During the C build pipeline, which tool resolves external function references across distinct object files?",
                "options": {"A": "Assembler", "B": "Compiler Frontend", "C": "Linker", "D": "Preprocessor"},
                "correct": "C",
                "explanation": "The linker binds separate translation units, resolves symbol references, and produces the final binary."
            }
        ]
    },
    "Variables and Data Types": {
        "Easy": [
            {
                "question": "What is the standard memory size of a 'char' data type in C on standard modern architectures?",
                "options": {"A": "1 byte", "B": "2 bytes", "C": "4 bytes", "D": "8 bytes"},
                "correct": "A",
                "explanation": "In standard C (C99/C11), sizeof(char) is guaranteed to be 1 byte (8 bits)."
            },
            {
                "question": "Which keyword is used to declare a variable whose value cannot be modified after initialization?",
                "options": {"A": "static", "B": "volatile", "C": "const", "D": "register"},
                "correct": "C",
                "explanation": "The 'const' qualifier tells the compiler that the variable's value is immutable."
            }
        ],
        "Medium": [
            {
                "question": "What is the result of casting float 3.75 to int in C: (int)3.75?",
                "options": {"A": "4", "B": "3", "C": "3.0", "D": "Undefined behavior"},
                "correct": "B",
                "explanation": "C truncates fractional digits during float-to-int conversion; it does not round up."
            }
        ],
        "Hard": [
            {
                "question": "What is the memory size of a union containing a double (8 bytes), int (4 bytes), and char[10] (10 bytes)?",
                "options": {"A": "22 bytes", "B": "10 bytes", "C": "16 bytes", "D": "8 bytes"},
                "correct": "C",
                "explanation": "Union size is determined by its largest member (10 bytes) rounded up to the alignment requirement of double (multiple of 8), yielding 16 bytes."
            }
        ]
    },
    "Operators and Expressions": {
        "Easy": [
            {
                "question": "What is the result of the integer division expression 17 / 5 in C?",
                "options": {"A": "3.4", "B": "3", "C": "4", "D": "2"},
                "correct": "B",
                "explanation": "When both operands are integers, C performs integer division, discarding any remainder (17 / 5 = 3)."
            },
            {
                "question": "Which operator is used to obtain the remainder of integer division in C?",
                "options": {"A": "/", "B": "%", "C": "#", "D": "//"},
                "correct": "B",
                "explanation": "The modulus operator '%' computes the remainder of an integer division."
            }
        ],
        "Medium": [
            {
                "question": "If int a = 5; what is the value of 'a' and 'b' after: int b = ++a * 2;?",
                "options": {"A": "a=5, b=10", "B": "a=6, b=12", "C": "a=6, b=10", "D": "a=5, b=12"},
                "correct": "B",
                "explanation": "Pre-increment ++a first increments a from 5 to 6, then multiplies 6 * 2 to yield 12 for b."
            }
        ],
        "Hard": [
            {
                "question": "What is the output of the bitwise expression: (14 & 9) ^ 3 in C?",
                "options": {"A": "11", "B": "8", "C": "10", "D": "7"},
                "correct": "A",
                "explanation": "14 in binary is 1110, 9 is 1001. 14 & 9 = 1000 (8). Then 8 ^ 3 (1000 XOR 0011) = 1011, which equals 11."
            }
        ]
    },
    "Conditional Statements": {
        "Easy": [
            {
                "question": "Which conditional statement allows multi-way branching based on an integer expression?",
                "options": {"A": "switch-case", "B": "while", "C": "for", "D": "break"},
                "correct": "A",
                "explanation": "The switch statement evaluates an integral expression and branches to matching case labels."
            }
        ],
        "Medium": [
            {
                "question": "What happens if a case in a switch statement does not include a 'break' statement?",
                "options": {
                    "A": "Compilation error occurs immediately",
                    "B": "Execution falls through to execute subsequent case statements",
                    "C": "The program crashes at runtime",
                    "D": "The switch statement terminates automatically"
                },
                "correct": "B",
                "explanation": "Without break, execution continues sequentially into following cases until a break or the end of switch is reached."
            }
        ],
        "Hard": [
            {
                "question": "In C, what is the value of x after: int a = 0, b = 2; int x = a && ++b;?",
                "options": {"A": "x=0, b=2", "B": "x=0, b=3", "C": "x=1, b=3", "D": "x=1, b=2"},
                "correct": "A",
                "explanation": "Due to short-circuit evaluation in logical AND, if the left operand is false (0), the right operand (++b) is never evaluated."
            }
        ]
    },
    "Loops": {
        "Easy": [
            {
                "question": "Which loop structure in C is guaranteed to execute its body at least once?",
                "options": {"A": "for loop", "B": "while loop", "C": "do-while loop", "D": "nested for loop"},
                "correct": "C",
                "explanation": "do-while checks its exit condition at the end of the loop, guaranteeing at least one execution."
            }
        ],
        "Medium": [
            {
                "question": "How many times does the following loop print '*': for(int i=0; i<15; i+=3) { printf(\"*\"); }?",
                "options": {"A": "4 times", "B": "5 times", "C": "6 times", "D": "15 times"},
                "correct": "B",
                "explanation": "i takes values 0, 3, 6, 9, 12 (5 iterations). When i reaches 15, the condition i < 15 is false."
            }
        ],
        "Hard": [
            {
                "question": "What does the statement 'continue' do inside a nested loop in C?",
                "options": {
                    "A": "Terminates both inner and outer loops",
                    "B": "Skips the rest of the current iteration of the innermost enclosing loop",
                    "C": "Restarts the program from main()",
                    "D": "Breaks out of the innermost loop completely"
                },
                "correct": "B",
                "explanation": "continue bypasses remaining statements in the current iteration of the innermost loop and proceeds to the next iteration."
            }
        ]
    },
    "Arrays": {
        "Easy": [
            {
                "question": "In C, what is the valid index range for an array declared as: int arr[10];?",
                "options": {"A": "1 to 10", "B": "0 to 9", "C": "0 to 10", "D": "-1 to 9"},
                "correct": "B",
                "explanation": "C arrays are zero-indexed, so an array of size 10 has valid indices from 0 through 9."
            }
        ],
        "Medium": [
            {
                "question": "What does the array name 'arr' evaluate to in most expressions in C?",
                "options": {
                    "A": "The length of the array",
                    "B": "A pointer to the first element (&arr[0])",
                    "C": "The value of the last element",
                    "D": "A copy of all elements"
                },
                "correct": "B",
                "explanation": "In most contexts (decay), an array name evaluates to a pointer to its first element."
            }
        ],
        "Hard": [
            {
                "question": "Given int matrix[3][4]; what is the address arithmetic equivalent of matrix[2][1]?",
                "options": {
                    "A": "*(matrix + 2) + 1",
                    "B": "*(*(matrix + 2) + 1)",
                    "C": "*matrix + 2*4 + 1",
                    "D": "matrix + 2*4 + 1"
                },
                "correct": "B",
                "explanation": "matrix[i][j] is equivalent to *(*(matrix + i) + j) in multi-dimensional pointer notation."
            }
        ]
    },
    "Functions": {
        "Easy": [
            {
                "question": "What does the 'void' keyword in a function return type indicate?",
                "options": {"A": "The function returns an integer", "B": "The function does not return any value", "C": "The function cannot accept arguments", "D": "The function is recursive"},
                "correct": "B",
                "explanation": "void specifies that the function terminates without returning a data value to the caller."
            }
        ],
        "Medium": [
            {
                "question": "In C, function arguments are passed by default using which mechanism?",
                "options": {"A": "Pass by reference", "B": "Pass by value", "C": "Pass by name", "D": "Pass by pointer address"},
                "correct": "B",
                "explanation": "C strictly uses pass-by-value. Pass-by-reference is simulated by passing pointer addresses by value."
            }
        ],
        "Hard": [
            {
                "question": "What causes a stack overflow error during a recursive function execution in C?",
                "options": {
                    "A": "Exceeding available heap memory via malloc",
                    "B": "Infinite or excessively deep recursion exhausting the call stack space",
                    "C": "Dividing by zero in the base condition",
                    "D": "Returning an invalid pointer"
                },
                "correct": "B",
                "explanation": "Each recursive call allocates a stack frame; excessive depth without base termination exhausts stack memory."
            }
        ]
    },
    "Pointers": {
        "Easy": [
            {
                "question": "Which unary operator is used to obtain the memory address of an existing variable in C?",
                "options": {"A": "*", "B": "&", "C": "->", "D": "%"},
                "correct": "B",
                "explanation": "The address-of operator '&' returns the memory location where a variable is stored."
            }
        ],
        "Medium": [
            {
                "question": "If int x = 10, *ptr = &x; what does the expression *ptr = 25; accomplish?",
                "options": {
                    "A": "Changes the address stored in ptr to 25",
                    "B": "Modifies the value stored at variable x to 25",
                    "C": "Causes a segmentation fault",
                    "D": "Creates a new copy of variable x"
                },
                "correct": "B",
                "explanation": "Dereferencing *ptr accesses the underlying memory location of x and assigns 25 to it."
            }
        ],
        "Hard": [
            {
                "question": "What is the consequence of dereferencing a dangling pointer in C?",
                "options": {
                    "A": "Automatic reallocation of heap memory",
                    "B": "Undefined behavior, potential memory corruption or segmentation fault",
                    "C": "Compile-time syntax error",
                    "D": "Guaranteed NULL return"
                },
                "correct": "B",
                "explanation": "A dangling pointer references deallocated memory; accessing it invokes undefined behavior."
            }
        ]
    },

    # -------------------------------------------------------------
    # 2. Engineering Mathematics
    # -------------------------------------------------------------
    "Matrices": {
        "Easy": [
            {
                "question": "What is the determinant of a 2x2 matrix with rows [3, 2] and [1, 4]?",
                "options": {"A": "10", "B": "14", "C": "12", "D": "8"},
                "correct": "A",
                "explanation": "det = (3 * 4) - (2 * 1) = 12 - 2 = 10."
            },
            {
                "question": "What is the trace of a square matrix?",
                "options": {
                    "A": "The product of all non-diagonal elements",
                    "B": "The sum of its main diagonal elements",
                    "C": "The determinant divided by the rank",
                    "D": "The sum of elements in the first row"
                },
                "correct": "B",
                "explanation": "The trace of a square matrix is defined as the sum of elements along its principal diagonal."
            }
        ],
        "Medium": [
            {
                "question": "If a 3x3 matrix has eigenvalues lambda = 2, 3, and 5, what is its determinant?",
                "options": {"A": "10", "B": "25", "C": "30", "D": "0"},
                "correct": "C",
                "explanation": "The determinant of any square matrix equals the product of its eigenvalues: 2 * 3 * 5 = 30."
            }
        ],
        "Hard": [
            {
                "question": "According to the Cayley-Hamilton Theorem, every square matrix satisfies which of the following?",
                "options": {
                    "A": "Its own characteristic polynomial equation",
                    "B": "Its own transpose matrix",
                    "C": "The Cauchy-Schwarz inequality",
                    "D": "A zero determinant"
                },
                "correct": "A",
                "explanation": "The Cayley-Hamilton theorem states that if p(lambda) = det(A - lambda*I) = 0, then p(A) = 0."
            }
        ]
    },
    "Differential Calculus": {
        "Easy": [
            {
                "question": "What is the derivative of f(x) = 5x^3 - 4x + 7 with respect to x?",
                "options": {"A": "15x^2 - 4", "B": "15x^2 + 4", "C": "5x^2 - 4", "D": "15x^3 - 4"},
                "correct": "A",
                "explanation": "Using the power rule: d/dx(5x^3) = 15x^2, d/dx(-4x) = -4, and d/dx(7) = 0."
            }
        ],
        "Medium": [
            {
                "question": "At a local extremum (maximum or minimum) of a differentiable function f(x), what is f'(x)?",
                "options": {"A": "Always positive", "B": "Always negative", "C": "Equal to 0", "D": "Undefined"},
                "correct": "C",
                "explanation": "Fermat's theorem states that if f has a local extremum at c and f'(c) exists, then f'(c) = 0."
            }
        ],
        "Hard": [
            {
                "question": "What is the radius of curvature rho of a plane curve y = f(x) at a given point?",
                "options": {
                    "A": "[1 + (y')^2]^(3/2) / |y''|",
                    "B": "[1 + y'] / y''",
                    "C": "(y'')^2 / [1 + y']",
                    "D": "y' / y''"
                },
                "correct": "A",
                "explanation": "The standard differential geometry formula for radius of curvature is rho = [1 + (y')^2]^(3/2) / |y''|."
            }
        ]
    },
    "Integral Calculus": {
        "Easy": [
            {
                "question": "What is the indefinite integral of f(x) = e^(2x) dx?",
                "options": {"A": "2*e^(2x) + C", "B": "(1/2)*e^(2x) + C", "C": "e^(2x) + C", "D": "e^(x) + C"},
                "correct": "B",
                "explanation": "Integral of e^(kx) dx = (1/k)*e^(kx) + C. For k=2, it gives (1/2)*e^(2x) + C."
            }
        ],
        "Medium": [
            {
                "question": "What does the definite integral of a positive function f(x) from x=a to x=b geometrically represent?",
                "options": {
                    "A": "The slope of the tangent line at x=a",
                    "B": "The net area between the curve y=f(x) and the x-axis from a to b",
                    "C": "The arc length of the curve",
                    "D": "The average derivative of f(x)"
                },
                "correct": "B",
                "explanation": "The definite integral computes the accumulated area beneath the curve between the boundaries a and b."
            }
        ],
        "Hard": [
            {
                "question": "What is the value of the Gamma function Gamma(1/2)?",
                "options": {"A": "1", "B": "sqrt(pi)", "C": "pi", "D": "1/2"},
                "correct": "B",
                "explanation": "Gamma(1/2) = integral from 0 to inf of t^(-1/2)*e^(-t) dt = sqrt(pi) by Gaussian integration."
            }
        ]
    },
    "Differential Equations": {
        "Easy": [
            {
                "question": "What is the order of the differential equation: (d^2y/dx^2) + 3*(dy/dx)^4 + y = 0?",
                "options": {"A": "1", "B": "2", "C": "4", "D": "3"},
                "correct": "B",
                "explanation": "The order of a differential equation is the order of the highest derivative present (d^2y/dx^2 = 2)."
            }
        ],
        "Medium": [
            {
                "question": "What is the integrating factor for the first-order linear differential equation: dy/dx + P(x)*y = Q(x)?",
                "options": {"A": "e^(integral P(x) dx)", "B": "integral P(x) dx", "C": "e^(integral Q(x) dx)", "D": "P(x)*Q(x)"},
                "correct": "A",
                "explanation": "The integrating factor is IF = exp(int P(x) dx), converting the left side into d/dx(y * IF)."
            }
        ],
        "Hard": [
            {
                "question": "For a second-order linear homogeneous ODE with auxiliary roots r = 3 +- 4i, what is the complementary function?",
                "options": {
                    "A": "e^(3x) * [C1*cos(4x) + C2*sin(4x)]",
                    "B": "C1*e^(3x) + C2*e^(4x)",
                    "C": "e^(4x) * [C1*cos(3x) + C2*sin(3x)]",
                    "D": "C1*cos(3x) + C2*sin(4x)"
                },
                "correct": "A",
                "explanation": "For complex conjugate roots alpha +- i*beta, the solution is e^(alpha*x) * [C1*cos(beta*x) + C2*sin(beta*x)]."
            }
        ]
    },
    "Probability": {
        "Easy": [
            {
                "question": "If a fair 6-sided die is rolled once, what is the probability of obtaining an even number?",
                "options": {"A": "1/6", "B": "1/3", "C": "1/2", "D": "2/3"},
                "correct": "C",
                "explanation": "Even numbers are {2, 4, 6} (3 outcomes out of 6 total), so 3/6 = 1/2."
            }
        ],
        "Medium": [
            {
                "question": "According to Bayes' Theorem, how is P(A|B) calculated?",
                "options": {
                    "A": "P(B|A) * P(A) / P(B)",
                    "B": "P(A) * P(B)",
                    "C": "P(A and B) / P(A)",
                    "D": "P(A) + P(B) - P(A and B)"
                },
                "correct": "A",
                "explanation": "Bayes' formula states posterior probability P(A|B) = [P(B|A) * P(A)] / P(B)."
            }
        ],
        "Hard": [
            {
                "question": "For a Poisson distribution with mean parameter lambda = 4, what is the variance?",
                "options": {"A": "2", "B": "4", "C": "16", "D": "8"},
                "correct": "B",
                "explanation": "A key mathematical property of the Poisson distribution is that its mean and variance are both equal to lambda (Var = 4)."
            }
        ]
    },

    # -------------------------------------------------------------
    # 3. Engineering Physics
    # -------------------------------------------------------------
    "Quantum Physics": {
        "Easy": [
            {
                "question": "According to Planck's quantum theory, the energy of a photon of frequency nu is given by which formula?",
                "options": {"A": "E = h * nu", "B": "E = m * c^2", "C": "E = h / nu", "D": "E = 1/2 * m * v^2"},
                "correct": "A",
                "explanation": "Planck proposed that light energy is quantized into discrete packets where E = h * nu (h is Planck's constant)."
            }
        ],
        "Medium": [
            {
                "question": "What does Heisenberg's Uncertainty Principle assert regarding a microscopic particle?",
                "options": {
                    "A": "Mass and velocity cannot be simultaneously determined with zero mass",
                    "B": "Position and momentum cannot be simultaneously measured with arbitrary precision (Delta x * Delta p >= h_bar / 2)",
                    "C": "Energy is strictly conserved across unobserved transitions",
                    "D": "Photons possess infinite wave speed in vacuum"
                },
                "correct": "B",
                "explanation": "Heisenberg's principle sets a fundamental limit Delta x * Delta p >= h_bar / 2 on simultaneous conjugate measurements."
            }
        ],
        "Hard": [
            {
                "question": "In the time-independent Schrodinger equation (-h_bar^2 / 2m) * d^2psi/dx^2 + V*psi = E*psi, what does |psi|^2 represent physically?",
                "options": {
                    "A": "Particle velocity density",
                    "B": "Probability density of locating the particle at coordinate x",
                    "C": "Electrostatic field energy density",
                    "D": "Total mechanical momentum"
                },
                "correct": "B",
                "explanation": "Born's statistical interpretation states that |psi(x)|^2 dx is the probability of finding the particle in the interval dx."
            }
        ]
    },
    "Semiconductor Physics": {
        "Easy": [
            {
                "question": "In an n-type semiconductor, which charge carriers are the majority carriers?",
                "options": {"A": "Holes", "B": "Electrons", "C": "Positrons", "D": "Neutrons"},
                "correct": "B",
                "explanation": "Doping with pentavalent donors introduces free conduction electrons, making electrons the majority carriers."
            },
            {
                "question": "Which element is commonly used as a donor dopant to produce n-type silicon?",
                "options": {"A": "Boron", "B": "Phosphorus", "C": "Gallium", "D": "Indium"},
                "correct": "B",
                "explanation": "Phosphorus is a pentavalent impurity (5 valence electrons) donating an electron to the silicon lattice."
            }
        ],
        "Medium": [
            {
                "question": "Where is the Fermi energy level located in an intrinsic (pure) semiconductor at T = 0 K?",
                "options": {
                    "A": "Near the top of the conduction band",
                    "B": "Approximately in the middle of the forbidden energy bandgap",
                    "C": "Inside the valence band",
                    "D": "At zero electron volts"
                },
                "correct": "B",
                "explanation": "For an intrinsic semiconductor, electron and hole concentrations are identical, placing E_F near the mid-gap."
            }
        ],
        "Hard": [
            {
                "question": "How does the electrical conductivity of an intrinsic semiconductor change with increasing temperature, and why?",
                "options": {
                    "A": "Decreases due to lattice phonon scattering",
                    "B": "Increases exponentially because thermal energy excites more electron-hole pairs across the bandgap",
                    "C": "Remains constant because impurity concentration is fixed",
                    "D": "Oscillates due to quantum tunneling"
                },
                "correct": "B",
                "explanation": "Semiconductors have a negative temperature coefficient of resistance; carrier concentration increases as exp(-Eg / 2kT)."
            }
        ]
    },
    "Dielectrics": {
        "Easy": [
            {
                "question": "What is the primary function of a dielectric material placed between capacitor plates?",
                "options": {
                    "A": "To conduct current between the plates",
                    "B": "To increase electrical capacitance by reducing the internal electric field",
                    "C": "To decrease electrical breakdown voltage",
                    "D": "To discharge stored energy"
                },
                "correct": "B",
                "explanation": "Dielectrics polarize in an external field, opposing it and increasing charge storage capability (C = k * C0)."
            }
        ],
        "Medium": [
            {
                "question": "Which polarization mechanism involves the displacement of positive nuclei relative to the electron cloud under an electric field?",
                "options": {"A": "Electronic polarization", "B": "Ionic polarization", "C": "Orientation polarization", "D": "Space charge polarization"},
                "correct": "A",
                "explanation": "Electronic polarization is present in all dielectrics and arises from shift of the electron cloud relative to the nucleus."
            }
        ],
        "Hard": [
            {
                "question": "Which fundamental relationship connects the dielectric constant epsilon_r with atomic polarizability alpha?",
                "options": {
                    "A": "Clausius-Mossotti Equation",
                    "B": "Bragg's Diffraction Law",
                    "C": "Lorentz Force Law",
                    "D": "Drude Conductance Model"
                },
                "correct": "A",
                "explanation": "The Clausius-Mossotti relation connects macroscopic dielectric constant epsilon_r to microscopic polarizabilities: (eps_r - 1)/(eps_r + 2) = N*alpha / (3*eps_0)."
            }
        ]
    },
    "Crystal Structures": {
        "Easy": [
            {
                "question": "What is the total number of atoms per unit cell in a Body-Centered Cubic (BCC) crystal lattice?",
                "options": {"A": "1", "B": "2", "C": "4", "D": "6"},
                "correct": "B",
                "explanation": "BCC has 8 corner atoms (8 * 1/8 = 1) plus 1 central atom, totaling 2 atoms per unit cell."
            }
        ],
        "Medium": [
            {
                "question": "What is the Atomic Packing Factor (APF) of a Face-Centered Cubic (FCC) crystal structure?",
                "options": {"A": "0.52", "B": "0.68", "C": "0.74", "D": "0.34"},
                "correct": "C",
                "explanation": "FCC is a close-packed structure with an APF of approximately 74% (pi / (3 * sqrt(2)) approx 0.74)."
            }
        ],
        "Hard": [
            {
                "question": "According to Bragg's Law for X-ray diffraction, constructive interference occurs when which condition is satisfied?",
                "options": {"A": "2 * d * sin(theta) = n * lambda", "B": "d * sin(theta) = lambda", "C": "2 * d = n * lambda * sin(theta)", "D": "lambda = 2 * d * cos(theta)"},
                "correct": "A",
                "explanation": "Bragg's Law states the path difference between adjacent crystal planes must be an integral multiple of wavelength: 2d*sin(theta) = n*lambda."
            }
        ]
    },
    "Optical Properties": {
        "Easy": [
            {
                "question": "What physical phenomenon is utilized to guide light signals along the core of an optical fiber?",
                "options": {"A": "Total Internal Reflection", "B": "Optical Dispersion", "C": "Constructive Interference", "D": "Diffuse Scattering"},
                "correct": "A",
                "explanation": "When light traveling in a denser core meets the cladding at an angle exceeding the critical angle, total internal reflection occurs."
            }
        ],
        "Medium": [
            {
                "question": "What is the condition required for Total Internal Reflection to occur at a boundary?",
                "options": {
                    "A": "Light travels from rarer to denser medium with incident angle < critical angle",
                    "B": "Light travels from denser to rarer medium with incident angle > critical angle",
                    "C": "Refractive indices of both media must be identical",
                    "D": "Frequency of incident wave must equal zero"
                },
                "correct": "B",
                "explanation": "TIR requires n1 > n2 and an incident angle theta_i greater than critical angle arcsin(n2/n1)."
            }
        ],
        "Hard": [
            {
                "question": "In a stimulated emission process (LASER), how are emitted photons related to incident stimulating photons?",
                "options": {
                    "A": "They have random phases and different frequencies",
                    "B": "They have identical phase, frequency, polarization, and direction of propagation",
                    "C": "They travel in exactly opposite directions",
                    "D": "They always possess higher frequency"
                },
                "correct": "B",
                "explanation": "Stimulated emission produces coherent radiation: identical energy, phase, state of polarization, and wave vector."
            }
        ]
    },

    # -------------------------------------------------------------
    # 4. Fundamentals of Artificial Intelligence
    # -------------------------------------------------------------
    "Introduction to AI": {
        "Easy": [
            {
                "question": "What benchmark test was proposed by Alan Turing in 1950 to evaluate machine intelligence?",
                "options": {"A": "Voight-Kampff Test", "B": "The Turing Test", "C": "Chinese Room Test", "D": "Bell Test"},
                "correct": "B",
                "explanation": "The Turing Test determines if a computer can exhibit human-indistinguishable conversation."
            }
        ],
        "Medium": [
            {
                "question": "What type of AI agent evaluates actions based on their expected outcome to maximize utility?",
                "options": {"A": "Simple reflex agent", "B": "Goal-based agent", "C": "Utility-based agent", "D": "Model-based reflex agent"},
                "correct": "C",
                "explanation": "Utility-based agents use an explicit utility function to measure the desirability of different world states."
            }
        ],
        "Hard": [
            {
                "question": "What is the primary distinction between Narrow AI and Artificial General Intelligence (AGI)?",
                "options": {
                    "A": "Narrow AI operates on quantum computers, while AGI operates on silicon",
                    "B": "Narrow AI is specialized for dedicated tasks, whereas AGI demonstrates adaptable reasoning across any intellectual domain",
                    "C": "Narrow AI uses neural networks, whereas AGI uses decision trees",
                    "D": "AGI requires no training data"
                },
                "correct": "B",
                "explanation": "Current AI is Narrow (specialized for chess, vision, NLP), while AGI aims for general human-level cognitive flexibility."
            }
        ]
    },
    "Machine Learning Fundamentals": {
        "Easy": [
            {
                "question": "In supervised machine learning, what must the training dataset contain alongside input features?",
                "options": {"A": "Unlabelled clusters", "B": "Ground truth target labels", "C": "Source code comments", "D": "Test validation weights"},
                "correct": "B",
                "explanation": "Supervised learning algorithms learn a mapping from input features x to known output labels y."
            }
        ],
        "Medium": [
            {
                "question": "What phenomenon occurs when a machine learning model fits training noise and performs poorly on unseen data?",
                "options": {"A": "Underfitting", "B": "Overfitting", "C": "Gradient vanishing", "D": "High bias"},
                "correct": "B",
                "explanation": "Overfitting happens when a model memorizes the training data including random noise, harming generalizability."
            }
        ],
        "Hard": [
            {
                "question": "In the Bias-Variance tradeoff, what characteristic is associated with a model having high bias?",
                "options": {
                    "A": "High sensitivity to fluctuations in the training set",
                    "B": "Underfitting due to oversimplified structural assumptions",
                    "C": "Excessive model complexity",
                    "D": "Near-zero training error but high test error"
                },
                "correct": "B",
                "explanation": "High bias error stems from erroneous assumptions (e.g. fitting linear model to nonlinear data), resulting in underfitting."
            }
        ]
    },
    "Supervised Learning": {
        "Easy": [
            {
                "question": "Which of the following tasks is an example of a classification problem in supervised learning?",
                "options": {"A": "Predicting tomorrow's temperature in Celsius", "B": "Classifying an email as Spam or Not Spam", "C": "Grouping customers by shopping preferences", "D": "Estimating house prices"},
                "correct": "B",
                "explanation": "Classification predicts discrete category labels (Spam vs Not Spam), unlike regression which predicts continuous values."
            }
        ],
        "Medium": [
            {
                "question": "Which algorithm finds the optimal hyperplane that maximizes the margin between two distinct classes?",
                "options": {"A": "K-Means Clustering", "B": "Support Vector Machine (SVM)", "C": "Apriori Algorithm", "D": "Principal Component Analysis"},
                "correct": "B",
                "explanation": "SVM finds the maximum-margin hyperplane that separates data classes in feature space."
            }
        ],
        "Hard": [
            {
                "question": "What is the primary purpose of L1 regularization (Lasso) compared to L2 regularization (Ridge) in regression models?",
                "options": {
                    "A": "L1 penalizes squared weights; L2 penalizes absolute weights",
                    "B": "L1 drives non-essential feature weights strictly to zero, performing intrinsic feature selection",
                    "C": "L1 prevents gradient descent from converging",
                    "D": "L2 regularization produces sparse weight vectors"
                },
                "correct": "B",
                "explanation": "Lasso adds an L1 absolute penalty |w|, shrinking coefficients to exact zero and acting as a feature selector."
            }
        ]
    },
    "Unsupervised Learning": {
        "Easy": [
            {
                "question": "What is the primary objective of unsupervised learning algorithms?",
                "options": {
                    "A": "To predict pre-labeled target variables",
                    "B": "To discover underlying patterns, clusters, or structures in unlabeled data",
                    "C": "To train robots using reward and punishment feedback",
                    "D": "To classify images using supervisor verification"
                },
                "correct": "B",
                "explanation": "Unsupervised learning operates on unlabelled inputs to uncover intrinsic groupings or data distributions."
            }
        ],
        "Medium": [
            {
                "question": "In the K-Means clustering algorithm, how are data points assigned to clusters in each iteration?",
                "options": {
                    "A": "Randomly without distance metric",
                    "B": "To the cluster with the nearest centroid based on Euclidean distance",
                    "C": "By calculating the maximum eigenvalue",
                    "D": "According to decision tree thresholds"
                },
                "correct": "B",
                "explanation": "K-Means iteratively assigns each point to the centroid with the minimum distance, then recalculates centroids."
            }
        ],
        "Hard": [
            {
                "question": "What technique is used in Principal Component Analysis (PCA) to reduce dimensionality while maximizing variance?",
                "options": {
                    "A": "Computing eigenvectors of the data covariance matrix",
                    "B": "Backpropagation with gradient descent",
                    "C": "Minimizing cross-entropy loss",
                    "D": "K-fold cross-validation"
                },
                "correct": "A",
                "explanation": "PCA projects data onto the eigenvectors of the covariance matrix corresponding to the largest eigenvalues."
            }
        ]
    },
    "Neural Networks": {
        "Easy": [
            {
                "question": "What is the biological inspiration behind Artificial Neural Networks (ANN)?",
                "options": {"A": "DNA replication", "B": "Neurons and synaptic connections in biological brains", "C": "Antibody immune response", "D": "Photosynthesis pathways"},
                "correct": "B",
                "explanation": "ANNs model simplified interconnected nodes inspired by biological neurons and synaptic weighting."
            }
        ],
        "Medium": [
            {
                "question": "Why are non-linear activation functions (e.g. ReLU, Sigmoid) essential in multi-layer neural networks?",
                "options": {
                    "A": "To accelerate data loading from disk",
                    "B": "Without non-linearities, multiple stacked layers collapse mathematically into a single linear regression",
                    "C": "To prevent weight matrices from being initialized",
                    "D": "To avoid using floating point arithmetic"
                },
                "correct": "B",
                "explanation": "Linear combinations of linear layers equal a single linear transformation; non-linearities enable universal approximation."
            }
        ],
        "Hard": [
            {
                "question": "What algorithm calculates the gradient of the loss function with respect to every weight in a deep neural network?",
                "options": {"A": "A* Pathfinding", "B": "Backpropagation (using the chain rule of calculus)", "C": "Breadth-First Search", "D": "Kruskal's Minimum Spanning Tree"},
                "correct": "B",
                "explanation": "Backpropagation applies the multivariate calculus chain rule backward from output to input to compute weight gradients."
            }
        ]
    },
    "Generative AI": {
        "Easy": [
            {
                "question": "What is the core function of a Generative AI model?",
                "options": {
                    "A": "To classify data into pre-existing categories",
                    "B": "To create new, realistic synthetic content (text, image, audio) based on learned patterns",
                    "C": "To sort database records alphabetically",
                    "D": "To monitor network firewalls"
                },
                "correct": "B",
                "explanation": "Generative models learn data distributions to generate novel synthetic artifacts resembling their training corpus."
            }
        ],
        "Medium": [
            {
                "question": "Which neural network architecture introduced the self-attention mechanism that revolutionized Natural Language Processing?",
                "options": {"A": "Convolutional Neural Network (CNN)", "B": "Transformer Architecture", "C": "Recurrent Neural Network (RNN)", "D": "Restricted Boltzmann Machine"},
                "correct": "B",
                "explanation": "The Transformer (Vaswani et al., 2017) uses self-attention to process sequential tokens in parallel without recurrence."
            }
        ],
        "Hard": [
            {
                "question": "In a Generative Adversarial Network (GAN), what are the roles of the Generator and Discriminator?",
                "options": {
                    "A": "Both models independently label test images",
                    "B": "The Generator synthesizes fake samples, while the Discriminator learns to distinguish real from generated samples in a minimax game",
                    "C": "The Generator compresses images; the Discriminator decompresses them",
                    "D": "The Discriminator creates training labels for the Generator"
                },
                "correct": "B",
                "explanation": "GANs consist of two competing networks trained in a game-theoretic minimax framework until generator outputs are indistinguishable."
            }
        ]
    },

    # -------------------------------------------------------------
    # 5. Digital Electronics
    # -------------------------------------------------------------
    "Number Systems": {
        "Easy": [
            {
                "question": "What is the decimal equivalent of the binary number (1011)_2?",
                "options": {"A": "11", "B": "13", "C": "9", "D": "15"},
                "correct": "A",
                "explanation": "(1*8) + (0*4) + (1*2) + (1*1) = 8 + 0 + 2 + 1 = 11."
            },
            {
                "question": "What is the hexadecimal representation of the binary byte (1111 0000)_2?",
                "options": {"A": "0xF0", "B": "0x0F", "C": "0xFF", "D": "0xAA"},
                "correct": "A",
                "explanation": "1111 in hex is F, and 0000 is 0, giving 0xF0."
            }
        ],
        "Medium": [
            {
                "question": "What is the 2's complement representation of the decimal number -5 in an 8-bit signed binary format?",
                "options": {"A": "11111011", "B": "10000101", "C": "11111010", "D": "00000101"},
                "correct": "A",
                "explanation": "+5 is 00000101. 1's complement is 11111010. Adding 1 yields 11111011."
            }
        ],
        "Hard": [
            {
                "question": "In IEEE 754 single-precision floating point format, how many bits are allocated to the exponent field?",
                "options": {"A": "8 bits", "B": "11 bits", "C": "23 bits", "D": "16 bits"},
                "correct": "A",
                "explanation": "Single-precision (32 bits) allocates 1 sign bit, 8 exponent bits, and 23 mantissa/fraction bits."
            }
        ]
    },
    "Boolean Algebra": {
        "Easy": [
            {
                "question": "According to Boolean algebra idempotence, what does the expression A + A simplify to?",
                "options": {"A": "2A", "B": "A", "C": "1", "D": "0"},
                "correct": "B",
                "explanation": "In Boolean algebra, A OR A = A (idempotent law)."
            }
        ],
        "Medium": [
            {
                "question": "Which of the following is De Morgan's First Law in Boolean algebra?",
                "options": {
                    "A": "(A * B)' = A' + B'",
                    "B": "(A + B)' = A' + B'",
                    "C": "(A * B)' = A' * B'",
                    "D": "A * (B + C) = A*B + A*C"
                },
                "correct": "A",
                "explanation": "De Morgan's first theorem states the complement of a product equals the sum of the complements: (A * B)' = A' + B'."
            }
        ],
        "Hard": [
            {
                "question": "What is the minimal Sum of Products (SOP) form of the expression: F = A'B'C + A'BC + AB'C + ABC?",
                "options": {"A": "C", "B": "A + B", "C": "A' + C", "D": "B'C"},
                "correct": "A",
                "explanation": "Factor out C: F = C * (A'B' + A'B + AB' + AB) = C * (A'(B'+B) + A(B'+B)) = C * (A' + A) = C * 1 = C."
            }
        ]
    },
    "Logic Gates": {
        "Easy": [
            {
                "question": "Which two logic gates are known as 'Universal Gates' because any boolean function can be realized using them alone?",
                "options": {"A": "NAND and NOR", "B": "AND and OR", "C": "XOR and XNOR", "D": "NOT and AND"},
                "correct": "A",
                "explanation": "NAND and NOR gates are universal gates capable of implementing all basic logic functions."
            }
        ],
        "Medium": [
            {
                "question": "What is the output of a 2-input XOR gate when both inputs are equal to 1?",
                "options": {"A": "1", "B": "0", "C": "High-Z", "D": "Undefined"},
                "correct": "B",
                "explanation": "An XOR (Exclusive-OR) gate outputs 1 only when the inputs differ. When both inputs are 1, the output is 0."
            }
        ],
        "Hard": [
            {
                "question": "How many 2-input NAND gates are required to construct an XOR gate?",
                "options": {"A": "3", "B": "4", "C": "5", "D": "6"},
                "correct": "B",
                "explanation": "An XOR gate can be implemented using exactly four 2-input NAND gates."
            }
        ]
    },
    "Combinational Circuits": {
        "Easy": [
            {
                "question": "What are the two outputs produced by a standard Half Adder circuit?",
                "options": {"A": "Sum and Carry", "B": "Difference and Borrow", "C": "Quotient and Remainder", "D": "Clock and Enable"},
                "correct": "A",
                "explanation": "A half adder adds two 1-bit inputs and produces a Sum (A XOR B) and a Carry (A AND B)."
            }
        ],
        "Medium": [
            {
                "question": "How many select lines are required for a 16-to-1 Multiplexer (MUX)?",
                "options": {"A": "2", "B": "3", "C": "4", "D": "8"},
                "correct": "C",
                "explanation": "For 2^n inputs, n select lines are required. Since 16 = 2^4, exactly 4 select lines are needed."
            }
        ],
        "Hard": [
            {
                "question": "In a Carry Lookahead Adder (CLA), what is the key advantage over a Ripple Carry Adder?",
                "options": {
                    "A": "Uses fewer transistors",
                    "B": "Eliminates carry propagation delay by computing carry bits simultaneously using generate and propagate logic",
                    "C": "Operates without power supply",
                    "D": "Supports floating point subtraction directly"
                },
                "correct": "B",
                "explanation": "CLA computes carry signals concurrently using Generate (G = A*B) and Propagate (P = A^B), drastically reducing latency."
            }
        ]
    },
    "Sequential Circuits": {
        "Easy": [
            {
                "question": "What distinguishes sequential circuits from combinational logic circuits?",
                "options": {
                    "A": "Sequential circuits have memory elements and their output depends on past inputs as well as present inputs",
                    "B": "Sequential circuits do not use logic gates",
                    "C": "Sequential circuits only operate on decimal numbers",
                    "D": "Sequential circuits have no clock signal"
                },
                "correct": "A",
                "explanation": "Sequential logic circuits incorporate feedback and memory devices (flip-flops), making outputs history-dependent."
            }
        ],
        "Medium": [
            {
                "question": "What is the difference between a latch and a flip-flop in digital circuits?",
                "options": {
                    "A": "Latches are level-triggered, whereas flip-flops are edge-triggered by a clock transition",
                    "B": "Latches have more storage capacity than flip-flops",
                    "C": "Latches operate synchronously with a clock; flip-flops do not",
                    "D": "Latches are only constructed with resistors"
                },
                "correct": "A",
                "explanation": "A latch is transparent whenever the enable level is active; a flip-flop samples state strictly at a clock edge."
            }
        ],
        "Hard": [
            {
                "question": "What condition occurs in an asynchronous ripple counter when carry delays accumulate across cascaded stages?",
                "options": {"A": "Clock skew and glitch transitions", "B": "Metastability elimination", "C": "Zero power dissipation", "D": "Infinite frequency operation"},
                "correct": "A",
                "explanation": "In ripple counters, each flip-flop is clocked by the previous stage, causing accumulated propagation delay and transient glitches."
            }
        ]
    },
    "Flip-Flops": {
        "Easy": [
            {
                "question": "How does a T (Toggle) flip-flop behave when input T = 1 on each active clock edge?",
                "options": {
                    "A": "Holds previous state Q",
                    "B": "Inverts/toggles its output state Q to Q'",
                    "C": "Resets unconditionally to 0",
                    "D": "Sets unconditionally to 1"
                },
                "correct": "B",
                "explanation": "When T=1, the T flip-flop inverts its output state on every clock pulse (toggle mode)."
            }
        ],
        "Medium": [
            {
                "question": "What invalid condition occurs in an SR flip-flop when both S and R inputs are driven to 1 simultaneously?",
                "options": {
                    "A": "Output toggles deterministically",
                    "B": "Race condition / undefined state where both Q and Q' attempt to be 0 or 1",
                    "C": "Clock frequency doubles",
                    "D": "Normal set condition"
                },
                "correct": "B",
                "explanation": "S=1 and R=1 violates the complementary nature of Q and Q', leading to an indeterminate state when inputs drop to 0."
            }
        ],
        "Hard": [
            {
                "question": "How does a Master-Slave JK Flip-Flop eliminate the race-around condition present in level-triggered JK latches?",
                "options": {
                    "A": "By utilizing two cascaded stages clocked on inverted phases (master active on high level, slave updating on low level)",
                    "B": "By removing feedback loops",
                    "C": "By limiting the supply voltage",
                    "D": "By setting propagation delay to zero"
                },
                "correct": "A",
                "explanation": "The master responds to inputs when clock is high; the slave transfers state to output when clock transitions low, breaking the feedback loop."
            }
        ]
    }
}

class AIQuizEngine:
    @staticmethod
    def get_available_topics_for_subject(subject_id_or_name):
        """Returns topic list available for question generation."""
        conn = get_db()
        cursor = conn.cursor()
        
        # Check topics table
        db_topics = cursor.execute("""
            SELECT name FROM topics WHERE subject_id = ?
        """, (subject_id_or_name,)).fetchall()
        
        conn.close()
        
        if db_topics:
            return [t['name'] for t in db_topics]
            
        # Fallback to keys in question bank
        return list(QUESTION_BANK.keys())

    @staticmethod
    def generate_questions(topic_name, difficulty="Medium", count=5):
        """
        Generates 'count' high quality multiple choice questions for the given topic and difficulty.
        Avoids duplicates and generates algorithmic variations if needed.
        """
        difficulty = difficulty.capitalize() if difficulty in ['Easy', 'Medium', 'Hard'] else 'Medium'
        count = max(3, min(15, int(count)))

        topic_data = QUESTION_BANK.get(topic_name)
        
        # If exact topic not found, search substring match
        if not topic_data:
            for k in QUESTION_BANK:
                if k.lower() in topic_name.lower() or topic_name.lower() in k.lower():
                    topic_data = QUESTION_BANK[k]
                    topic_name = k
                    break

        # Fallback generic pool if topic is unique
        if not topic_data:
            topic_data = QUESTION_BANK["Introduction to AI"]

        pool = []
        # Add requested difficulty questions first
        if difficulty in topic_data:
            pool.extend(topic_data[difficulty])

        # If pool not full, blend from other difficulties in same topic
        for diff in ['Medium', 'Easy', 'Hard']:
            if diff != difficulty and diff in topic_data:
                for q in topic_data[diff]:
                    if q not in pool:
                        pool.append(q)

        # Shuffle candidates
        selected = list(pool)
        random.shuffle(selected)
        selected = selected[:count]

        # If selected still less than count, generate algorithmic variants
        while len(selected) < count:
            variant = AIQuizEngine._generate_algorithmic_question(topic_name, difficulty, len(selected) + 1)
            selected.append(variant)

        return selected

    @staticmethod
    def _generate_algorithmic_question(topic_name, difficulty, seed_num):
        """Generates dynamic algorithmic practice questions with randomized parameters."""
        rand_val = random.randint(2, 9)
        rand_coeff = random.randint(10, 50)

        if "Matrices" in topic_name:
            a, b, c, d = random.randint(1, 5), random.randint(1, 4), random.randint(1, 4), random.randint(2, 6)
            det = (a * d) - (b * c)
            wrong1 = det + 2
            wrong2 = det - 3
            wrong3 = (a * c) - (b * d)
            opts = [det, wrong1, wrong2, wrong3]
            random.shuffle(opts)
            keys = ['A', 'B', 'C', 'D']
            correct_key = keys[opts.index(det)]
            return {
                "question": f"Practice Variant #{seed_num}: Calculate the determinant of the 2x2 matrix with rows [{a}, {b}] and [{c}, {d}].",
                "options": {keys[i]: str(opts[i]) for i in range(4)},
                "correct": correct_key,
                "explanation": f"det = ({a}*{d}) - ({b}*{c}) = {a*d} - {b*c} = {det}."
            }
        elif "Number Systems" in topic_name or "Digital" in topic_name:
            num = random.randint(10, 31)
            b_str = bin(num)[2:]
            w1 = bin(num + 1)[2:]
            w2 = bin(num - 1)[2:]
            w3 = bin(num + 2)[2:]
            opts = [b_str, w1, w2, w3]
            random.shuffle(opts)
            keys = ['A', 'B', 'C', 'D']
            correct_key = keys[opts.index(b_str)]
            return {
                "question": f"Practice Variant #{seed_num}: What is the binary representation of decimal {num}?",
                "options": {keys[i]: f"({opts[i]})_2" for i in range(4)},
                "correct": correct_key,
                "explanation": f"Decimal {num} in binary is {b_str}."
            }
        else:
            return {
                "question": f"Core Practice Question #{seed_num} for '{topic_name}': When evaluating efficiency and stability under {difficulty} constraints, what is the primary consideration?",
                "options": {
                    "A": "Minimizing redundant computational state transitions and enforcing bounded invariants",
                    "B": "Eliminating boundary condition checks completely",
                    "C": "Overriding convergence parameters to constant zero",
                    "D": "Bypassing intermediate verification assertions"
                },
                "correct": "A",
                "explanation": f"In {topic_name}, solid technical practice prioritizes bounded invariants and minimal state transition overhead."
            }

    @staticmethod
    def create_ai_practice_quiz(student_id, subject_id, topic, difficulty="Medium", question_count=5):
        """
        Creates an AI-generated practice quiz directly in the shared SQLite database.
        Returns the created quiz_id.
        """
        conn = get_db()
        cursor = conn.cursor()

        # Fetch subject details
        subject = cursor.execute("SELECT name, code FROM subjects WHERE id = ?", (subject_id,)).fetchone()
        if not subject:
            conn.close()
            return None, "Subject not found."

        # Fetch teacher_id for the subject
        subj_row = cursor.execute("SELECT teacher_id FROM subjects WHERE id = ?", (subject_id,)).fetchone()
        teacher_id = subj_row['teacher_id'] if subj_row else 1

        title = f"AI Practice: {topic} ({difficulty})"
        description = f"AI-Generated topic practice quiz for {subject['name']} with difficulty level {difficulty}."
        duration_minutes = max(5, int(question_count) * 2)

        cursor.execute("""
            INSERT INTO quizzes (subject_id, teacher_id, title, topic, description, duration_minutes, is_published, quiz_type, difficulty)
            VALUES (?, ?, ?, ?, ?, ?, 1, 'ai_practice', ?)
        """, (subject_id, teacher_id, title, topic, description, duration_minutes, difficulty))
        quiz_id = cursor.lastrowid

        # Generate questions
        questions = AIQuizEngine.generate_questions(topic, difficulty, count=question_count)

        for q in questions:
            cursor.execute("""
                INSERT INTO quiz_questions (quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                quiz_id,
                topic,
                q['question'],
                q['options']['A'],
                q['options']['B'],
                q['options']['C'],
                q['options']['D'],
                q['correct'],
                q.get('explanation', ''),
                difficulty
            ))

        conn.commit()
        conn.close()

        return quiz_id, None

def generate_topic_questions(subject_name, topic_name, count=5, difficulty='Medium'):
    """Convenience alias for AIQuizEngine.generate_questions."""
    return AIQuizEngine.generate_questions(topic_name, difficulty=difficulty, count=count)

def create_ai_practice_quiz(student_id, subject_id, topic, difficulty='Medium', question_count=5):
    """Convenience alias for AIQuizEngine.create_ai_practice_quiz."""
    return AIQuizEngine.create_ai_practice_quiz(student_id, subject_id, topic, difficulty=difficulty, question_count=question_count)

TOPIC_QUESTION_BANK = QUESTION_BANK

