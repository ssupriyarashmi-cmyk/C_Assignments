// AI-Powered Smart Study Planner - Client Script

document.addEventListener('DOMContentLoaded', function () {
    // 1. Mobile Sidebar Toggle
    const toggleBtn = document.querySelector('.sidebar-toggle-btn');
    const sidebar = document.querySelector('.sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });

        // Close when clicking outside
        document.addEventListener('click', function (e) {
            if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    // 2. Modal Handlers
    document.querySelectorAll('[data-modal-target]').forEach(button => {
        button.addEventListener('click', function () {
            const targetId = this.getAttribute('data-modal-target');
            const modal = document.querySelector(targetId);
            if (modal) {
                modal.classList.add('active');
            }
        });
    });

    document.querySelectorAll('.modal-close, .modal-cancel').forEach(button => {
        button.addEventListener('click', function () {
            const modal = this.closest('.modal-overlay');
            if (modal) {
                modal.classList.remove('active');
            }
        });
    });

    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', function (e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });

    // 3. Copy to Clipboard
    document.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const textToCopy = this.getAttribute('data-copy-text');
            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy).then(() => {
                    const originalText = this.innerHTML;
                    this.innerHTML = '<span>✓ Copied!</span>';
                    this.style.borderColor = 'var(--success)';
                    this.style.color = 'var(--success)';
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.style.borderColor = '';
                        this.style.color = '';
                    }, 2000);
                }).catch(err => {
                    console.error('Copy failed', err);
                });
            }
        });
    });

    // 4. Alert auto-dismiss
    document.querySelectorAll('.alert-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function () {
            const alert = this.closest('.alert');
            if (alert) {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            }
        });
    });

    // 5. Quiz Timer Countdown
    const timerElement = document.getElementById('quizCountdown');
    const quizForm = document.getElementById('quizForm');
    if (timerElement && quizForm) {
        let durationMinutes = parseInt(timerElement.getAttribute('data-duration') || '15', 10);
        let timeRemaining = durationMinutes * 60; // in seconds

        function updateDisplay() {
            const minutes = Math.floor(timeRemaining / 60);
            const seconds = timeRemaining % 60;
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            if (timeRemaining <= 60) {
                timerElement.style.color = '#EF4444';
            }
        }

        updateDisplay();

        const timerInterval = setInterval(function () {
            timeRemaining--;
            if (timeRemaining <= 0) {
                clearInterval(timerInterval);
                timerElement.textContent = "00:00";
                alert("Time has expired! Submitting your answers automatically now.");
                quizForm.submit();
            } else {
                updateDisplay();
            }
        }, 1000);
    }

    // 6. Password Visibility Toggle
    document.querySelectorAll('.password-toggle-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const targetInput = document.getElementById(targetId);
            if (targetInput) {
                if (targetInput.type === 'password') {
                    targetInput.type = 'text';
                    this.textContent = '🙈';
                    this.setAttribute('title', 'Hide password');
                } else {
                    targetInput.type = 'password';
                    this.textContent = '👁️';
                    this.setAttribute('title', 'Show password');
                }
            }
        });
    });
});
