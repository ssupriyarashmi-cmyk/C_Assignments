// Chart.js helper scripts for Teacher & Student Dashboards

function initStudentPerformanceCharts(data) {
    if (!data) return;

    // 1. History Trend Line Chart
    const historyCtx = document.getElementById('quizHistoryChart');
    if (historyCtx && data.history) {
        new Chart(historyCtx, {
            type: 'line',
            data: {
                labels: data.history.labels,
                datasets: [{
                    label: 'Score Percentage (%)',
                    data: data.history.data,
                    borderColor: '#7C3AED',
                    backgroundColor: 'rgba(124, 58, 237, 0.1)',
                    tension: 0.3,
                    fill: true,
                    pointBackgroundColor: '#7C3AED',
                    pointRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { callback: v => v + '%' }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    // 2. Subject-wise Performance Bar Chart
    const subjectCtx = document.getElementById('subjectPerfChart');
    if (subjectCtx && data.subjects) {
        new Chart(subjectCtx, {
            type: 'bar',
            data: {
                labels: data.subjects.labels,
                datasets: [{
                    label: 'Average Score (%)',
                    data: data.subjects.data,
                    backgroundColor: '#3B82F6',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { callback: v => v + '%' }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    // 3. Topic-wise Accuracy Chart
    const topicCtx = document.getElementById('topicPerfChart');
    if (topicCtx && data.topics) {
        new Chart(topicCtx, {
            type: 'bar',
            data: {
                labels: data.topics.labels,
                datasets: [{
                    label: 'Topic Accuracy (%)',
                    data: data.topics.data,
                    backgroundColor: data.topics.data.map(v => v < 50 ? '#EF4444' : (v < 75 ? '#F59E0B' : '#10B981')),
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { callback: v => v + '%' }
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return ` Accuracy: ${context.raw}%`;
                            }
                        }
                    }
                }
            }
        });
    }
}
