@echo off
title SmartCart - Grocery Price Comparison System
echo ===================================================
echo SMARTCART: Grocery Price Comparison System
echo Starting server on http://127.0.0.1:5000/ ...
echo ===================================================
cd /d "%~dp0"

echo Opening Google Chrome to http://127.0.0.1:5000/
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "http://127.0.0.1:5000/" 2>nul || start "" "http://127.0.0.1:5000/"

echo Running Flask Server (Press Ctrl+C to stop)...
python app.py
pause
