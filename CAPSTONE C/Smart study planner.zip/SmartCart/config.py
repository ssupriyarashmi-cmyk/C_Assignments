import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'smartcart-capstone-secret-key-2026-secure')
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATABASE_PATH = os.path.join(BASE_DIR, 'database', 'database.db')
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'images')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload
