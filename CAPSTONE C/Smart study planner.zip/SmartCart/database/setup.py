import os
import sqlite3
import hashlib
import secrets
from datetime import datetime, date

DATABASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(DATABASE_DIR, 'database.db')

def generate_hash(password):
    """Generate PBKDF2-SHA256 password hash compatible with standard and werkzeug formats."""
    salt = secrets.token_hex(8)
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
    return f"pbkdf2:sha256:100000${salt}${key.hex()}"

def get_db_connection(db_path=None):
    """Establish and return SQLite database connection with row factory and foreign keys enabled."""
    path = db_path or DATABASE_PATH
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db(db_path=None):
    """Create all required tables with constraints."""
    path = db_path or DATABASE_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = get_db_connection(path)
    cursor = conn.cursor()

    # Table 1: PRODUCTS
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            brand TEXT NOT NULL,
            category TEXT NOT NULL,
            quantity REAL NOT NULL CHECK(quantity > 0),
            unit TEXT NOT NULL,
            image TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    # Table 2: STORES
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS stores (
            store_id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_name TEXT NOT NULL UNIQUE,
            location TEXT NOT NULL,
            website TEXT,
            logo_color TEXT DEFAULT '#2e7d32',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    # Table 3: STORE_PRICES
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS store_prices (
            price_id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            store_id INTEGER NOT NULL,
            price REAL NOT NULL CHECK(price > 0),
            product_url TEXT,
            source_name TEXT,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
            FOREIGN KEY (store_id) REFERENCES stores(store_id) ON DELETE CASCADE,
            UNIQUE(product_id, store_id)
        );
    """)

    # Table 4: ADMINS
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    conn.commit()
    conn.close()
    print("Database tables initialized successfully.")

def seed_data(db_path=None):
    """Seed initial sample data for demonstration."""
    path = db_path or DATABASE_PATH
    conn = get_db_connection(path)
    cursor = conn.cursor()

    # Check if admin exists
    cursor.execute("SELECT COUNT(*) as count FROM admins")
    if cursor.fetchone()['count'] == 0:
        cursor.execute(
            "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
            ('admin', generate_hash('admin123'))
        )
        print("Default admin created (username: admin, password: admin123)")

    # Sample Stores
    stores_data = [
        ("BigBasket", "Pan-India Online Supermarket", "https://www.bigbasket.com", "#689f38"),
        ("JioMart", "Reliance Retail Online Hub", "https://www.jiomart.com", "#0083ca"),
        ("Amazon Fresh", "Amazon India Prime Grocery", "https://www.amazon.in/fresh", "#ff9900"),
        ("DMart Ready", "Avenue Supermarts Pick-up Points & Delivery", "https://www.dmart.in", "#1b5e20"),
        ("Flipkart Grocery", "Flipkart Supermart Delivery Network", "https://www.flipkart.com/grocery", "#2874f0")
    ]

    for name, location, website, color in stores_data:
        cursor.execute("""
            INSERT OR IGNORE INTO stores (store_name, location, website, logo_color)
            VALUES (?, ?, ?, ?)
        """, (name, location, website, color))

    # Sample Products across 7 core grocery categories
    products_data = [
        # Rice & Grains
        ("Daawat Rozana Super Basmati Rice", "Daawat", "Rice and Grains", 1.0, "kg", 
         "/static/images/daawat_rice.svg", "Premium aromatic aged long grain basmati rice suitable for everyday biryanis and pulao."),
        ("India Gate Feast Rozana Basmati Rice", "India Gate", "Rice and Grains", 1.0, "kg", 
         "/static/images/india_gate_rice.svg", "Finest quality everyday basmati rice with slender grains and authentic aroma."),
        ("Aashirvaad Superior MP Whole Wheat Atta", "Aashirvaad", "Rice and Grains", 5.0, "kg", 
         "/static/images/aashirvaad_atta.svg", "100% pure whole wheat flour processed with 4-step advantage for soft rotis."),
        ("Fortune Chakki Fresh Whole Wheat Atta", "Fortune", "Rice and Grains", 5.0, "kg", 
         "/static/images/fortune_atta.svg", "Traditional chakki ground wheat flour enriched with dietary fibre."),

        # Cooking Oil
        ("Fortune Sunlite Refined Sunflower Oil", "Fortune", "Cooking Oil", 1.0, "L", 
         "/static/images/fortune_oil.svg", "Light, healthy and refined sunflower cooking oil with Vitamin A & D."),
        ("Saffola Gold Pro Healthy Lifestyle Oil", "Saffola", "Cooking Oil", 1.0, "L", 
         "/static/images/saffola_oil.svg", "Dual seed blend of rice bran and sunflower oil with natural antioxidants."),
        ("Amul Pure Ghee Pouch", "Amul", "Cooking Oil", 1.0, "L", 
         "/static/images/amul_ghee.svg", "Traditional rich aroma pure cow and buffalo milk clarified butter."),

        # Dairy Products
        ("Amul Butter Pasteurized", "Amul", "Dairy Products", 500.0, "g", 
         "/static/images/amul_butter.svg", "Utterly butterly delicious creamy pasteurized table butter made from pure milk."),
        ("Britannia Cheese Slices", "Britannia", "Dairy Products", 200.0, "g", 
         "/static/images/britannia_cheese.svg", "Nutritious processed cheese slices packed with calcium and protein."),
        ("Amul Taaza Homogenised Toned Milk", "Amul", "Dairy Products", 1.0, "L", 
         "/static/images/amul_milk.svg", "Fresh pasteurised toned milk with 3.0% fat and 8.5% SNF."),

        # Snacks
        ("Maggi 2-Minute Masala Instant Noodles", "Maggi", "Snacks", 840.0, "g", 
         "/static/images/maggi_noodles.svg", "Classic pack of 12 instant noodles enriched with iron and 10 signature spices."),
        ("Parle-G Original Glucose Biscuits", "Parle", "Snacks", 800.0, "g", 
         "/static/images/parle_g.svg", "India's beloved glucose biscuit with nourishment of wheat and milk."),
        ("Britannia Good Day Cashew Cookies", "Britannia", "Snacks", 600.0, "g", 
         "/static/images/good_day.svg", "Rich and crispy butter cookies loaded with crunchy cashew nut chunks."),

        # Beverages
        ("Tata Tea Gold Premium Black Tea", "Tata Tea", "Beverages", 500.0, "g", 
         "/static/images/tata_tea.svg", "Exquisite blend of 85% fine Assam CTC tea leaves with 15% gently rolled long leaves."),
        ("Red Label Natural Care Tea", "Brooke Bond", "Beverages", 1.0, "kg", 
         "/static/images/red_label.svg", "Cardamom, ginger, tulsi, ashwagandha and mulethi infused health tea."),
        ("Nescafe Classic Instant Coffee Glass Jar", "Nescafe", "Beverages", 200.0, "g", 
         "/static/images/nescafe_coffee.svg", "100% pure Robusta coffee beans roasted to perfection for rich aroma."),

        # Pulses and Dal
        ("Tata Sampann Unpolished Toor Dal", "Tata Sampann", "Pulses and Dal", 1.0, "kg", 
         "/static/images/toor_dal.svg", "Pristine unpolished arhar dal with natural protein and no artificial polish."),
        ("Tata Sampann High Protein Moong Dal", "Tata Sampann", "Pulses and Dal", 1.0, "kg", 
         "/static/images/moong_dal.svg", "Unpolished split yellow moong lentils rich in dietary fibre and protein."),

        # Personal Care
        ("Dettol Original Germ Protection Soap", "Dettol", "Personal Care", 625.0, "g", 
         "/static/images/dettol_soap.svg", "Multipack of 5 x 125g antibacterial bath bars with iconic pine fragrance."),
        ("Colgate Strong Teeth Dental Toothpaste", "Colgate", "Personal Care", 500.0, "g", 
         "/static/images/colgate.svg", "Calcium Boost technology toothpaste that repairs enamel and provides cavity protection.")
    ]

    for name, brand, category, quantity, unit, image, desc in products_data:
        cursor.execute("""
            INSERT OR IGNORE INTO products (product_name, brand, category, quantity, unit, image, description)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (name, brand, category, quantity, unit, image, desc))

    conn.commit()

    # Retrieve store IDs
    cursor.execute("SELECT store_id, store_name FROM stores")
    stores_dict = {row['store_name']: row['store_id'] for row in cursor.fetchall()}

    # Retrieve product IDs
    cursor.execute("SELECT product_id, product_name FROM products")
    products_dict = {row['product_name']: row['product_id'] for row in cursor.fetchall()}

    # Current date for realistic price freshness
    today_str = date.today().strftime("%d-%m-%Y")

    # Store prices data with genuine retailer product page URLs
    # Format: (product_name, store_name, price, product_url, source_name)
    store_prices_data = [
        # Daawat Rozana Super Basmati Rice (1 kg)
        ("Daawat Rozana Super Basmati Rice", "BigBasket", 88.00, 
         "https://www.bigbasket.com/pd/40072498/daawat-rozana-super-basmati-rice-1-kg/", "BigBasket Grocery"),
        ("Daawat Rozana Super Basmati Rice", "JioMart", 84.00, 
         "https://www.jiomart.com/p/groceries/daawat-rozana-super-basmati-rice-1-kg/490000000", "JioMart Retail"),
        ("Daawat Rozana Super Basmati Rice", "Amazon Fresh", 89.00, 
         "https://www.amazon.in/dp/B00TS8AE8E", "Amazon Fresh India"),
        ("Daawat Rozana Super Basmati Rice", "DMart Ready", 78.00, 
         "https://www.dmart.in/product/daawat-rozana-super-basmati-rice-1-kg", "DMart Store"),
        ("Daawat Rozana Super Basmati Rice", "Flipkart Grocery", 85.00, 
         "https://www.flipkart.com/daawat-rozana-super-basmati-rice-1-kg/p/itm123456", "Flipkart Supermart"),

        # India Gate Feast Rozana Basmati Rice (1 kg)
        ("India Gate Feast Rozana Basmati Rice", "BigBasket", 96.00, 
         "https://www.bigbasket.com/pd/266120/india-gate-basmati-rice-feast-rozana-1-kg-pouch/", "BigBasket Grocery"),
        ("India Gate Feast Rozana Basmati Rice", "JioMart", 92.00, 
         "https://www.jiomart.com/p/groceries/india-gate-feast-rozana-basmati-rice-1-kg/490000001", "JioMart Retail"),
        ("India Gate Feast Rozana Basmati Rice", "Amazon Fresh", 98.00, 
         "https://www.amazon.in/dp/B00MNAG8O2", "Amazon Fresh India"),
        ("India Gate Feast Rozana Basmati Rice", "DMart Ready", 88.00, 
         "https://www.dmart.in/product/india-gate-feast-rozana-basmati-rice-1-kg", "DMart Store"),

        # Aashirvaad Superior MP Whole Wheat Atta (5 kg)
        ("Aashirvaad Superior MP Whole Wheat Atta", "BigBasket", 248.00, 
         "https://www.bigbasket.com/pd/126906/aashirvaad-atta-whole-wheat-5-kg-pouch/", "BigBasket Grocery"),
        ("Aashirvaad Superior MP Whole Wheat Atta", "JioMart", 239.00, 
         "https://www.jiomart.com/p/groceries/aashirvaad-superior-mp-atta-5-kg/490000100", "JioMart Retail"),
        ("Aashirvaad Superior MP Whole Wheat Atta", "Amazon Fresh", 245.00, 
         "https://www.amazon.in/dp/B010GGD16A", "Amazon Fresh India"),
        ("Aashirvaad Superior MP Whole Wheat Atta", "DMart Ready", 228.00, 
         "https://www.dmart.in/product/aashirvaad-superior-mp-atta-5-kg", "DMart Store"),
        ("Aashirvaad Superior MP Whole Wheat Atta", "Flipkart Grocery", 242.00, 
         "https://www.flipkart.com/aashirvaad-superior-mp-atta-5-kg/p/itmf3x", "Flipkart Supermart"),

        # Fortune Chakki Fresh Whole Wheat Atta (5 kg)
        ("Fortune Chakki Fresh Whole Wheat Atta", "BigBasket", 215.00, 
         "https://www.bigbasket.com/pd/40018888/fortune-chakki-fresh-atta-5-kg/", "BigBasket Grocery"),
        ("Fortune Chakki Fresh Whole Wheat Atta", "JioMart", 209.00, 
         "https://www.jiomart.com/p/groceries/fortune-chakki-fresh-atta-5-kg/490000105", "JioMart Retail"),
        ("Fortune Chakki Fresh Whole Wheat Atta", "Amazon Fresh", 219.00, 
         "https://www.amazon.in/dp/B07P8MBLN2", "Amazon Fresh India"),
        ("Fortune Chakki Fresh Whole Wheat Atta", "DMart Ready", 199.00, 
         "https://www.dmart.in/product/fortune-chakki-fresh-atta-5-kg", "DMart Store"),

        # Fortune Sunlite Refined Sunflower Oil (1 L)
        ("Fortune Sunlite Refined Sunflower Oil", "BigBasket", 138.00, 
         "https://www.bigbasket.com/pd/274145/fortune-sunlite-refined-sunflower-oil-1-l-pouch/", "BigBasket Grocery"),
        ("Fortune Sunlite Refined Sunflower Oil", "JioMart", 132.00, 
         "https://www.jiomart.com/p/groceries/fortune-sunlite-refined-sunflower-oil-1-l/490001234", "JioMart Retail"),
        ("Fortune Sunlite Refined Sunflower Oil", "Amazon Fresh", 140.00, 
         "https://www.amazon.in/dp/B07PBF819S", "Amazon Fresh India"),
        ("Fortune Sunlite Refined Sunflower Oil", "DMart Ready", 125.00, 
         "https://www.dmart.in/product/fortune-sunlite-sunflower-oil-1-l", "DMart Store"),
        ("Fortune Sunlite Refined Sunflower Oil", "Flipkart Grocery", 135.00, 
         "https://www.flipkart.com/fortune-sunlite-refined-sunflower-oil-pouch/p/itmf456", "Flipkart Supermart"),

        # Saffola Gold Pro Healthy Lifestyle Oil (1 L)
        ("Saffola Gold Pro Healthy Lifestyle Oil", "BigBasket", 168.00, 
         "https://www.bigbasket.com/pd/147491/saffola-gold-refined-cooking-oil-1-l-pouch/", "BigBasket Grocery"),
        ("Saffola Gold Pro Healthy Lifestyle Oil", "JioMart", 162.00, 
         "https://www.jiomart.com/p/groceries/saffola-gold-multisource-edible-oil-1-l/490001235", "JioMart Retail"),
        ("Saffola Gold Pro Healthy Lifestyle Oil", "Amazon Fresh", 170.00, 
         "https://www.amazon.in/dp/B07G3N9Z6G", "Amazon Fresh India"),
        ("Saffola Gold Pro Healthy Lifestyle Oil", "DMart Ready", 154.00, 
         "https://www.dmart.in/product/saffola-gold-edible-oil-1-l", "DMart Store"),

        # Amul Pure Ghee Pouch (1 L)
        ("Amul Pure Ghee Pouch", "BigBasket", 610.00, 
         "https://www.bigbasket.com/pd/104808/amul-pure-ghee-1-l-pouch/", "BigBasket Grocery"),
        ("Amul Pure Ghee Pouch", "JioMart", 595.00, 
         "https://www.jiomart.com/p/groceries/amul-pure-ghee-1-l-pouch/490002100", "JioMart Retail"),
        ("Amul Pure Ghee Pouch", "Amazon Fresh", 620.00, 
         "https://www.amazon.in/dp/B01HBG96F2", "Amazon Fresh India"),
        ("Amul Pure Ghee Pouch", "DMart Ready", 585.00, 
         "https://www.dmart.in/product/amul-pure-ghee-1-l-pouch", "DMart Store"),

        # Amul Butter Pasteurized (500 g)
        ("Amul Butter Pasteurized", "BigBasket", 275.00, 
         "https://www.bigbasket.com/pd/242671/amul-butter-pasteurised-500-g-carton/", "BigBasket Grocery"),
        ("Amul Butter Pasteurized", "JioMart", 270.00, 
         "https://www.jiomart.com/p/groceries/amul-butter-500-g/490003200", "JioMart Retail"),
        ("Amul Butter Pasteurized", "Amazon Fresh", 278.00, 
         "https://www.amazon.in/dp/B073XQLC76", "Amazon Fresh India"),
        ("Amul Butter Pasteurized", "DMart Ready", 262.00, 
         "https://www.dmart.in/product/amul-butter-500-g", "DMart Store"),

        # Britannia Cheese Slices (200 g)
        ("Britannia Cheese Slices", "BigBasket", 145.00, 
         "https://www.bigbasket.com/pd/104812/britannia-cheese-slices-200-g-10-slices/", "BigBasket Grocery"),
        ("Britannia Cheese Slices", "JioMart", 138.00, 
         "https://www.jiomart.com/p/groceries/britannia-cheese-slices-200-g/490003201", "JioMart Retail"),
        ("Britannia Cheese Slices", "Amazon Fresh", 148.00, 
         "https://www.amazon.in/dp/B077S9J9D4", "Amazon Fresh India"),
        ("Britannia Cheese Slices", "DMart Ready", 132.00, 
         "", "DMart Store - Store Only Listing"),  # Deliberate empty link to showcase "Link unavailable" state!

        # Maggi 2-Minute Masala Instant Noodles (840 g)
        ("Maggi 2-Minute Masala Instant Noodles", "BigBasket", 168.00, 
         "https://www.bigbasket.com/pd/266109/maggi-2-minute-instant-noodles-masala-840-g-pack-of-12/", "BigBasket Grocery"),
        ("Maggi 2-Minute Masala Instant Noodles", "JioMart", 158.00, 
         "https://www.jiomart.com/p/groceries/maggi-2-minute-masala-noodles-840-g/490004100", "JioMart Retail"),
        ("Maggi 2-Minute Masala Instant Noodles", "Amazon Fresh", 165.00, 
         "https://www.amazon.in/dp/B071VNRV2T", "Amazon Fresh India"),
        ("Maggi 2-Minute Masala Instant Noodles", "DMart Ready", 149.00, 
         "https://www.dmart.in/product/maggi-2-minute-masala-noodles-840-g", "DMart Store"),
        ("Maggi 2-Minute Masala Instant Noodles", "Flipkart Grocery", 160.00, 
         "https://www.flipkart.com/maggi-2-minute-masala-noodles-840-g/p/itm567", "Flipkart Supermart"),

        # Parle-G Original Glucose Biscuits (800 g)
        ("Parle-G Original Glucose Biscuits", "BigBasket", 85.00, 
         "https://www.bigbasket.com/pd/264426/parle-g-original-glucose-biscuits-800-g/", "BigBasket Grocery"),
        ("Parle-G Original Glucose Biscuits", "JioMart", 79.00, 
         "https://www.jiomart.com/p/groceries/parle-g-glucose-biscuits-800-g/490004200", "JioMart Retail"),
        ("Parle-G Original Glucose Biscuits", "Amazon Fresh", 85.00, 
         "https://www.amazon.in/dp/B07P82R4Q9", "Amazon Fresh India"),
        ("Parle-G Original Glucose Biscuits", "DMart Ready", 74.00, 
         "https://www.dmart.in/product/parle-g-biscuits-800-g", "DMart Store"),

        # Britannia Good Day Cashew Cookies (600 g)
        ("Britannia Good Day Cashew Cookies", "BigBasket", 140.00, 
         "https://www.bigbasket.com/pd/40003889/britannia-good-day-cashew-cookies-600-g/", "BigBasket Grocery"),
        ("Britannia Good Day Cashew Cookies", "JioMart", 130.00, 
         "https://www.jiomart.com/p/groceries/britannia-good-day-cashew-600-g/490004205", "JioMart Retail"),
        ("Britannia Good Day Cashew Cookies", "Amazon Fresh", 138.00, 
         "https://www.amazon.in/dp/B07D3Z7Y4J", "Amazon Fresh India"),
        ("Britannia Good Day Cashew Cookies", "DMart Ready", 122.00, 
         "https://www.dmart.in/product/britannia-good-day-cashew-600-g", "DMart Store"),

        # Tata Tea Gold Premium Black Tea (500 g)
        ("Tata Tea Gold Premium Black Tea", "BigBasket", 325.00, 
         "https://www.bigbasket.com/pd/266579/tata-tea-gold-leaf-tea-500-g-pouch/", "BigBasket Grocery"),
        ("Tata Tea Gold Premium Black Tea", "JioMart", 310.00, 
         "https://www.jiomart.com/p/groceries/tata-tea-gold-500-g/490005100", "JioMart Retail"),
        ("Tata Tea Gold Premium Black Tea", "Amazon Fresh", 320.00, 
         "https://www.amazon.in/dp/B00V4K139A", "Amazon Fresh India"),
        ("Tata Tea Gold Premium Black Tea", "DMart Ready", 295.00, 
         "https://www.dmart.in/product/tata-tea-gold-500-g", "DMart Store"),

        # Red Label Natural Care Tea (1 kg)
        ("Red Label Natural Care Tea", "BigBasket", 540.00, 
         "https://www.bigbasket.com/pd/266539/brooke-bond-red-label-natural-care-tea-1-kg/", "BigBasket Grocery"),
        ("Red Label Natural Care Tea", "JioMart", 515.00, 
         "https://www.jiomart.com/p/groceries/red-label-natural-care-tea-1-kg/490005105", "JioMart Retail"),
        ("Red Label Natural Care Tea", "Amazon Fresh", 535.00, 
         "https://www.amazon.in/dp/B079Z1K26B", "Amazon Fresh India"),
        ("Red Label Natural Care Tea", "DMart Ready", 489.00, 
         "https://www.dmart.in/product/red-label-natural-care-tea-1-kg", "DMart Store"),

        # Nescafe Classic Instant Coffee Glass Jar (200 g)
        ("Nescafe Classic Instant Coffee Glass Jar", "BigBasket", 695.00, 
         "https://www.bigbasket.com/pd/266587/nescafe-classic-instant-coffee-200-g-jar/", "BigBasket Grocery"),
        ("Nescafe Classic Instant Coffee Glass Jar", "JioMart", 670.00, 
         "https://www.jiomart.com/p/groceries/nescafe-classic-coffee-200-g/490005200", "JioMart Retail"),
        ("Nescafe Classic Instant Coffee Glass Jar", "Amazon Fresh", 685.00, 
         "https://www.amazon.in/dp/B00V4K0XX4", "Amazon Fresh India"),
        ("Nescafe Classic Instant Coffee Glass Jar", "DMart Ready", 645.00, 
         "https://www.dmart.in/product/nescafe-classic-coffee-200-g", "DMart Store"),

        # Tata Sampann Unpolished Toor Dal (1 kg)
        ("Tata Sampann Unpolished Toor Dal", "BigBasket", 175.00, 
         "https://www.bigbasket.com/pd/40000277/tata-sampann-unpolished-toor-dal-arhar-dal-1-kg/", "BigBasket Grocery"),
        ("Tata Sampann Unpolished Toor Dal", "JioMart", 168.00, 
         "https://www.jiomart.com/p/groceries/tata-sampann-toor-dal-1-kg/490006100", "JioMart Retail"),
        ("Tata Sampann Unpolished Toor Dal", "Amazon Fresh", 172.00, 
         "https://www.amazon.in/dp/B01B5R3B30", "Amazon Fresh India"),
        ("Tata Sampann Unpolished Toor Dal", "DMart Ready", 158.00, 
         "https://www.dmart.in/product/tata-sampann-toor-dal-1-kg", "DMart Store"),

        # Dettol Original Germ Protection Soap (625 g)
        ("Dettol Original Germ Protection Soap", "BigBasket", 210.00, 
         "https://www.bigbasket.com/pd/40118800/dettol-original-bath-soap-125-g-pack-of-5/", "BigBasket Grocery"),
        ("Dettol Original Germ Protection Soap", "JioMart", 195.00, 
         "https://www.jiomart.com/p/groceries/dettol-original-soap-5x125g/490007100", "JioMart Retail"),
        ("Dettol Original Germ Protection Soap", "Amazon Fresh", 205.00, 
         "https://www.amazon.in/dp/B07C2R8W9J", "Amazon Fresh India"),
        ("Dettol Original Germ Protection Soap", "DMart Ready", 188.00, 
         "https://www.dmart.in/product/dettol-soap-5x125g", "DMart Store"),

        # Colgate Strong Teeth Dental Toothpaste (500 g)
        ("Colgate Strong Teeth Dental Toothpaste", "BigBasket", 260.00, 
         "https://www.bigbasket.com/pd/40019230/colgate-strong-teeth-anticavity-toothpaste-combo-500-g/", "BigBasket Grocery"),
        ("Colgate Strong Teeth Dental Toothpaste", "JioMart", 245.00, 
         "https://www.jiomart.com/p/groceries/colgate-strong-teeth-toothpaste-500-g/490007200", "JioMart Retail"),
        ("Colgate Strong Teeth Dental Toothpaste", "Amazon Fresh", 255.00, 
         "https://www.amazon.in/dp/B07P8MBLN8", "Amazon Fresh India"),
        ("Colgate Strong Teeth Dental Toothpaste", "DMart Ready", 232.00, 
         "https://www.dmart.in/product/colgate-strong-teeth-500-g", "DMart Store")
    ]

    for prod_name, store_name, price, url, source in store_prices_data:
        p_id = products_dict.get(prod_name)
        s_id = stores_dict.get(store_name)
        if p_id and s_id:
            cursor.execute("""
                INSERT OR REPLACE INTO store_prices (product_id, store_id, price, product_url, source_name, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (p_id, s_id, price, url, source, today_str))

    conn.commit()
    conn.close()
    print("Database seeded with realistic sample products, stores, and verified price records.")

if __name__ == '__main__':
    init_db()
    seed_data()
