/**
 * SMARTCART – Grocery Price Comparison System
 * Client-Side JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
  initMobileMenu();
  initSearchAutocomplete();
  initComparisonTableFilter();
  initAdminDashboard();
});

/* ==========================================================================
   Mobile Menu Toggle
   ========================================================================== */
function initMobileMenu() {
  const toggleBtn = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener('click', function () {
      navLinks.classList.toggle('show');
    });
  }
}

/* ==========================================================================
   Live Search Autocomplete with Debounce & Keyboard Nav
   ========================================================================== */
function initSearchAutocomplete() {
  const searchInput = document.getElementById('mainSearchInput');
  const suggestionsBox = document.getElementById('searchSuggestions');

  if (!searchInput || !suggestionsBox) return;

  let debounceTimer = null;
  let activeIndex = -1;

  searchInput.addEventListener('input', function () {
    clearTimeout(debounceTimer);
    const query = searchInput.value.trim();

    if (query.length < 1) {
      suggestionsBox.style.display = 'none';
      suggestionsBox.innerHTML = '';
      return;
    }

    debounceTimer = setTimeout(() => {
      fetch(`/api/suggestions?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
          renderSuggestions(data);
        })
        .catch(err => {
          console.error("Autocomplete fetch error:", err);
        });
    }, 200);
  });

  function renderSuggestions(items) {
    if (!items || items.length === 0) {
      suggestionsBox.innerHTML = `
        <div class="suggestion-item" style="cursor: default; color: #64748b;">
          <span>No matching grocery products found</span>
        </div>`;
      suggestionsBox.style.display = 'block';
      return;
    }

    let html = '';
    items.forEach((item, index) => {
      html += `
        <div class="suggestion-item" data-id="${item.product_id}" data-index="${index}">
          <img src="${item.image}" alt="${item.product_name}" class="suggestion-img" onerror="this.src='/static/images/placeholder_grocery.svg'">
          <div class="suggestion-info">
            <div class="suggestion-title">${escapeHtml(item.product_name)}</div>
            <div class="suggestion-meta">${escapeHtml(item.brand)} • ${escapeHtml(item.category)} • ${item.quantity} ${item.unit}</div>
          </div>
        </div>`;
    });

    suggestionsBox.innerHTML = html;
    suggestionsBox.style.display = 'block';
    activeIndex = -1;

    // Click handler for suggestion items
    const elements = suggestionsBox.querySelectorAll('.suggestion-item');
    elements.forEach(el => {
      el.addEventListener('click', function () {
        const pId = this.getAttribute('data-id');
        if (pId) {
          window.location.href = `/compare/${pId}`;
        }
      });
    });
  }

  // Keyboard navigation
  searchInput.addEventListener('keydown', function (e) {
    const items = suggestionsBox.querySelectorAll('.suggestion-item[data-id]');
    if (!items.length || suggestionsBox.style.display === 'none') return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeIndex = (activeIndex + 1) % items.length;
      updateActiveItem(items);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeIndex = (activeIndex - 1 + items.length) % items.length;
      updateActiveItem(items);
    } else if (e.key === 'Enter') {
      if (activeIndex >= 0 && items[activeIndex]) {
        e.preventDefault();
        items[activeIndex].click();
      }
    } else if (e.key === 'Escape') {
      suggestionsBox.style.display = 'none';
    }
  });

  function updateActiveItem(items) {
    items.forEach((it, idx) => {
      if (idx === activeIndex) {
        it.classList.add('active');
        it.scrollIntoView({ block: 'nearest' });
      } else {
        it.classList.remove('active');
      }
    });
  }

  // Close suggestions when clicking outside
  document.addEventListener('click', function (e) {
    if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
      suggestionsBox.style.display = 'none';
    }
  });
}

/* ==========================================================================
   Comparison Table Filter & Sort Controls
   ========================================================================== */
function initComparisonTableFilter() {
  const storeFilterSelect = document.getElementById('storeFilterSelect');
  const sortSelect = document.getElementById('comparisonSortSelect');
  const tableBody = document.getElementById('comparisonTableBody');

  if (!tableBody) return;

  function applyFilters() {
    const selectedStore = storeFilterSelect ? storeFilterSelect.value : 'all';
    const selectedSort = sortSelect ? sortSelect.value : 'price_asc';

    const rows = Array.from(tableBody.querySelectorAll('tr[data-store]'));

    // Filter by store
    rows.forEach(row => {
      const storeName = row.getAttribute('data-store');
      if (selectedStore === 'all' || storeName === selectedStore) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });

    // Sort rows
    rows.sort((a, b) => {
      const priceA = parseFloat(a.getAttribute('data-price')) || 0;
      const priceB = parseFloat(b.getAttribute('data-price')) || 0;
      const unitA = parseFloat(a.getAttribute('data-unit-price')) || 0;
      const unitB = parseFloat(b.getAttribute('data-unit-price')) || 0;
      const storeA = (a.getAttribute('data-store') || '').toLowerCase();
      const storeB = (b.getAttribute('data-store') || '').toLowerCase();

      if (selectedSort === 'price_asc') return priceA - priceB;
      if (selectedSort === 'price_desc') return priceB - priceA;
      if (selectedSort === 'unit_price_asc') return unitA - unitB;
      if (selectedSort === 'store_asc') return storeA.localeCompare(storeB);
      return 0;
    });

    rows.forEach(row => tableBody.appendChild(row));
  }

  if (storeFilterSelect) storeFilterSelect.addEventListener('change', applyFilters);
  if (sortSelect) sortSelect.addEventListener('change', applyFilters);
}

/* ==========================================================================
   Admin Dashboard Tab & Modal Management
   ========================================================================== */
function initAdminDashboard() {
  const tabs = document.querySelectorAll('.admin-tab');
  const panes = document.querySelectorAll('.tab-pane');

  if (!tabs.length) return;

  tabs.forEach(tab => {
    tab.addEventListener('click', function () {
      const targetId = this.getAttribute('data-tab');

      tabs.forEach(t => t.classList.remove('active'));
      panes.forEach(p => p.classList.remove('active'));

      this.classList.add('active');
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add('active');
    });
  });
}

// Edit Product helper
window.editProduct = function (id, name, brand, category, quantity, unit, image, desc) {
  const modal = document.getElementById('editProductModal');
  if (!modal) return;

  document.getElementById('edit_product_id').value = id;
  document.getElementById('edit_product_name').value = name;
  document.getElementById('edit_brand').value = brand;
  document.getElementById('edit_category').value = category;
  document.getElementById('edit_quantity').value = quantity;
  document.getElementById('edit_unit').value = unit;
  document.getElementById('edit_image').value = image;
  document.getElementById('edit_description').value = desc || '';

  const form = document.getElementById('editProductForm');
  form.action = `/admin/product/edit/${id}`;
  modal.style.display = 'block';
};

// Edit Store helper
window.editStore = function (id, name, location, website) {
  const modal = document.getElementById('editStoreModal');
  if (!modal) return;

  document.getElementById('edit_store_id').value = id;
  document.getElementById('edit_store_name').value = name;
  document.getElementById('edit_location').value = location;
  document.getElementById('edit_website').value = website || '';

  const form = document.getElementById('editStoreForm');
  form.action = `/admin/store/edit/${id}`;
  modal.style.display = 'block';
};

// Edit Price helper
window.editPrice = function (id, prodId, storeId, price, url, source, updated) {
  const modal = document.getElementById('editPriceModal');
  if (!modal) return;

  document.getElementById('edit_price_id').value = id;
  document.getElementById('edit_price_val').value = price;
  document.getElementById('edit_product_url').value = url || '';
  document.getElementById('edit_source_name').value = source || '';
  document.getElementById('edit_updated_at').value = updated || '';

  const form = document.getElementById('editPriceForm');
  form.action = `/admin/price/edit/${id}`;
  modal.style.display = 'block';
};

window.closeModal = function (modalId) {
  const m = document.getElementById(modalId);
  if (m) m.style.display = 'none';
};

// Helper to escape HTML characters
function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
