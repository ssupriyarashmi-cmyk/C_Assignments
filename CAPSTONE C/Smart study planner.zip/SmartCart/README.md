# SMARTCART – Grocery Price Comparison System

**First-Year Engineering Python Capstone Project**  
*A comprehensive, full-stack, data-driven web application for comparing everyday grocery prices across major online Indian supermarkets.*

---

## 1. Project Objective & Workflow

SmartCart helps consumers discover the lowest available prices for everyday grocery essentials, calculate potential savings across competing retailers, and seamlessly visit the original shopping website to complete purchases.

### Core Workflow
```
SEARCH PRODUCT
      ↓
FIND MATCHING PRODUCTS
      ↓
COMPARE STORE PRICES
      ↓
IDENTIFY LOWEST PRICE
      ↓
CALCULATE POSSIBLE SAVINGS
      ↓
VISIT ORIGINAL SHOPPING WEBSITE
```

### Important Project Scope
SmartCart is strictly a **Price Comparison Platform**:
- **No** shopping cart or checkout
- **No** payment gateways or financial transactions
- **No** online delivery tracking or order fulfillment
- Users are redirected directly to the original shopping website (`target="_blank" rel="noopener noreferrer"`) when clicking a product link.

---

## 2. Technology Stack

- **Frontend:** Semantic HTML5, Custom Responsive CSS3 (Green & White modern theme), Vanilla JavaScript (Autocomplete, Debouncing, Dynamic Sort & Filter).
- **Backend:** Python 3.14 / Flask web framework with secure session management and PBKDF2:SHA-256 password hashing.
- **Database:** SQLite relational database with strict foreign key constraints (`PRAGMA foreign_keys = ON;`), uniqueness constraints, and positive price validation (`CHECK(price > 0)`).
- **Comparison Engine:** Modular Python comparison engine calculating lowest price, highest price, potential savings, and normalized unit cost (₹/kg and ₹/L).
- **Automated Testing:** Python `unittest` suite with 31 automated test cases.

---

## 3. Project Structure

```
SmartCart/
│
├── app.py                      # Flask Application Entry Point & Route Handlers
├── config.py                   # Configuration & Secret Keys
├── comparison_engine.py        # Python Price Comparison & Savings Calculation Logic
├── compat.py                   # Standard Library Compatibility Layer (Zero External Deps)
├── requirements.txt            # Python Dependencies Specification
├── run_tests.py                # Master Automated Test Suite Runner & Reporter
├── README.md                   # Complete Documentation & Capstone Manual
├── .gitignore                  # Git Ignore Specifications
│
├── database/
│   ├── __init__.py             # Database Module Package Init
│   ├── setup.py                # SQLite Schema Definition, Foreign Keys & Seed Data
│   └── database.db             # SQLite Relational Database File
│
├── templates/
│   ├── base.html               # Master Layout, Green/White Navbar, Alerts & Footer
│   ├── index.html              # Homepage with Live Search, Categories, Top Deals & Steps
│   ├── categories.html         # Category Browser & Dynamic Product Grid
│   ├── products.html           # Full Search Catalog with Multi-Filter Sidebar
│   ├── comparison.html         # Core Multi-Store Comparison Table, Savings & Links
│   ├── product_details.html    # Detailed Product Specifications & Store Breakdown
│   ├── about.html              # Capstone Project Architecture, Workflow & Scope
│   ├── admin_login.html        # Secure Administrator Authentication Form
│   └── admin_dashboard.html    # Admin CRUD for Products, Stores & Prices
│
├── static/
│   ├── css/
│   │   └── style.css           # Premium Green & White Modern Responsive Stylesheet
│   ├── js/
│   │   └── script.js           # Live Autocomplete, Modal Handlers & Filter Logic
│   └── images/                 # Crisp Vector SVG Grocery Illustrations & Logos
│
└── tests/
    ├── test_search.py          # Search & Navigation Automated Test Suite
    ├── test_comparison.py      # Price Comparison & Unit Cost Test Suite
    ├── test_database.py        # SQLite Schema, Cascade & Constraint Tests
    ├── test_admin.py           # Admin Auth & CRUD Operations Test Suite
    └── test_product_links.py   # External Retailer Links & Validator Tests
```

---

## 4. Key Features & Implementation Details

### 1. Price Comparison Engine
- Retrieves matching records across multiple stores (Amazon Fresh, BigBasket, JioMart, DMart Ready, Flipkart Grocery).
- Automatically identifies the minimum price and highlights the cheapest store with a verified badge.
- Automatically calculates the maximum price, absolute savings (₹), and percentage discount (%).
- **Unit Cost Normalization:** Converts weights (e.g. 500g vs 1kg) and volumes (e.g. 500ml vs 1L) to standard ₹/kg or ₹/L metrics to support fair comparison.

### 2. Genuine External Retailer Links
- Retailer product listings include direct "Visit Store" action buttons that open the genuine retailer page in a new browser tab.
- Links are validated (`http://` or `https://` with valid domain).
- In cases where a direct external link is unavailable, the UI gracefully renders a non-clickable `🚫 Link unavailable` badge.

### 3. Live Autocomplete Search
- Real-time search by product name, brand, or category.
- Case-insensitive, partial keyword matching.
- Interactive suggestions dropdown with thumbnail preview.
- Keyboard accessible (Arrow Down, Arrow Up, Enter, Escape).

### 4. Admin Management Portal
- Secure login with PBKDF2:SHA-256 hashed credentials.
- Summary analytics: Total Products, Total Stores, Total Price Records.
- **Product Management:** Add, View, Edit, and Delete grocery items.
- **Store Management:** Add, View, Edit, and Delete retail stores.
- **Price Management:** Add, View, Edit, and Delete store-wise price records, update price freshness dates, and enter original retailer URLs.

---

## 5. Setup & Running the Application

### Prerequisites
- Python 3.8 or higher installed on your machine.
- Google Chrome (or any modern web browser).

### Step 1: Navigate to the Project Folder
```bash
cd SmartCart
```

### Step 2: (Optional) Install Dependencies
```bash
pip install -r requirements.txt
```
*Note: SmartCart is engineered with a built-in standard-library compatibility engine. It will automatically run even without pip packages installed!*

### Step 3: Initialize Database & Seed Sample Data
```bash
python database/setup.py
```
This creates `database/database.db` with 20 sample products, 5 stores, 76 store prices, and the default admin account.

### Step 4: Run the Application
```bash
python app.py
```
The server will start on local port 5000:
```
 * Serving SmartCart on http://127.0.0.1:5000/
```

### Step 5: Open in Google Chrome
Open Google Chrome and navigate to:
```
http://127.0.0.1:5000/
```

---

## 6. Default Admin Credentials

- **URL:** `http://127.0.0.1:5000/admin/login`
- **Username:** `admin`
- **Password:** `admin123`

---

## 7. Automated Test Suite Execution

To run all automated verification tests:
```bash
python run_tests.py
```

### Test Results Summary (31 Tests - 100% Passed)
| # | Test Suite | Focus Area | Status |
|---|---|---|---|
| 1–8 | `test_search.py` | Homepage loading, Exact/partial search, Case-insensitivity, Brand search, Nonexistent query friendly error, Suggestions API | **PASS** |
| 9–15 | `test_comparison.py` | Multi-store comparison, Ascending sorting, Lowest/highest price, Savings (₹ and %), Unit price normalization (kg/L) | **PASS** |
| 16–22 | `test_database.py` | Product CRUD, Cascade deletions, Store uniqueness, Positive price validation, Foreign key enforcement | **PASS** |
| 23–27 | `test_admin.py` | Admin login, Invalid credentials rejection, Route protection, Logout, Admin product & price management | **PASS** |
| 28–31 | `test_product_links.py` | URL validator, Genuine links with target="_blank", Link unavailable state, Malformed URL rejection | **PASS** |

---

## 8. College Capstone Demonstration Highlights

When presenting this project:
1. **Homepage Demonstration:** Showcase the clean green and white theme, search bar with live autocomplete, and popular search tags.
2. **Search & Filter:** Search for "oil" or "rice", show partial matching, category tabs, and sorting options.
3. **Core Price Comparison (`/compare/1`):** Show the key metric cards (Lowest Price, Highest Price, Possible Savings, Normalized Unit Price), highlight the cheapest store, and filter/sort dynamically.
4. **External Retailer Links:** Click "Visit Store" to demonstrate opening the original retailer page in a new tab; showcase product #9 (Britannia Cheese Slices) to demonstrate the "Link unavailable" badge for unlinked records.
5. **Admin Portal (`/admin/dashboard`):** Log in as admin, add a new store price, edit an existing listing, and observe the live updates immediately reflected on the comparison page.
6. **Automated Verification:** Run `python run_tests.py` in the terminal to display the 31 passing tests.
