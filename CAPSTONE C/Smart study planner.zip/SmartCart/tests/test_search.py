import os
import sys
import unittest

# Add SmartCart root to sys.path
SMARTCART_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if SMARTCART_DIR not in sys.path:
    sys.path.insert(0, SMARTCART_DIR)

from app import app
from database.setup import get_db_connection
from comparison_engine import get_search_suggestions, get_product_cards

class TestProductSearch(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.client = self.app.test_client()
        self.conn = get_db_connection()

    def tearDown(self):
        self.conn.close()

    def test_homepage_loads(self):
        """TEST 1: Homepage loads with HTTP status 200 and has navigation links."""
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn("SmartCart", res.text)
        self.assertIn("Compare Grocery Prices", res.text)
        self.assertIn("/categories", res.text)
        self.assertIn("/products", res.text)
        self.assertIn("/about", res.text)

    def test_search_existing_product(self):
        """TEST 2.1: Search for an exact existing product."""
        results = get_product_cards(self.conn, search_term="Daawat Rozana Super Basmati Rice")
        self.assertGreaterEqual(len(results), 1)
        self.assertEqual(results[0]['product_name'], "Daawat Rozana Super Basmati Rice")

    def test_search_partial_keyword(self):
        """TEST 2.2: Search using a partial keyword like 'atta'."""
        results = get_product_cards(self.conn, search_term="atta")
        self.assertGreaterEqual(len(results), 2)
        names = [r['product_name'].lower() for r in results]
        self.assertTrue(any("atta" in n for n in names))

    def test_search_case_insensitivity(self):
        """TEST 2.3: Search using different letter cases (lowercase, uppercase, mixed)."""
        res_lower = get_product_cards(self.conn, search_term="oil")
        res_upper = get_product_cards(self.conn, search_term="OIL")
        res_mixed = get_product_cards(self.conn, search_term="OiL")

        self.assertEqual(len(res_lower), len(res_upper))
        self.assertEqual(len(res_lower), len(res_mixed))
        self.assertGreater(len(res_lower), 0)

    def test_search_by_brand(self):
        """TEST 2.4: Search by brand name like 'Amul'."""
        results = get_product_cards(self.conn, search_term="Amul")
        self.assertGreaterEqual(len(results), 2)
        for r in results:
            self.assertTrue("amul" in r['brand'].lower() or "amul" in r['product_name'].lower())

    def test_search_nonexistent_product(self):
        """TEST 2.5: Search for a nonexistent product returns empty result and friendly message."""
        results = get_product_cards(self.conn, search_term="NonExistentSuperJuice999xyz")
        self.assertEqual(len(results), 0)

        # Check frontend search page renders friendly empty message
        res = self.client.get('/products?q=NonExistentSuperJuice999xyz')
        self.assertEqual(res.status_code, 200)
        self.assertIn("No products found. Try another search.", res.text)

    def test_empty_search_input(self):
        """TEST 2.6: Test empty search input gracefully returns all products."""
        results = get_product_cards(self.conn, search_term="")
        self.assertGreaterEqual(len(results), 10)

    def test_search_suggestions_api(self):
        """TEST 2.7: Autocomplete suggestions API endpoint."""
        res = self.client.get('/api/suggestions?q=tea')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)
        self.assertTrue(any("tea" in item['product_name'].lower() for item in data))

if __name__ == '__main__':
    unittest.main()
