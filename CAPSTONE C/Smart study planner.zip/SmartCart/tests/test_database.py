import os
import sys
import sqlite3
import unittest

SMARTCART_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if SMARTCART_DIR not in sys.path:
    sys.path.insert(0, SMARTCART_DIR)

from database.setup import get_db_connection

class TestDatabase(unittest.TestCase):
    def setUp(self):
        # Create an in-memory SQLite database with exact schema for isolated testing
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE products (
                product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_name TEXT NOT NULL,
                brand TEXT NOT NULL,
                category TEXT NOT NULL,
                quantity REAL NOT NULL CHECK(quantity > 0),
                unit TEXT NOT NULL,
                image TEXT NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        cursor.execute("""
            CREATE TABLE stores (
                store_id INTEGER PRIMARY KEY AUTOINCREMENT,
                store_name TEXT NOT NULL UNIQUE,
                location TEXT NOT NULL,
                website TEXT,
                logo_color TEXT DEFAULT '#2e7d32',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        cursor.execute("""
            CREATE TABLE store_prices (
                price_id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                store_id INTEGER NOT NULL,
                price REAL NOT NULL CHECK(price > 0),
                product_url TEXT,
                source_name TEXT,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
                FOREIGN KEY (store_id) REFERENCES stores(store_id) ON DELETE CASCADE,
                UNIQUE(product_id, store_id)
            );
        """)
        cursor.execute("""
            CREATE TABLE admins (
                admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        self.conn.commit()

    def tearDown(self):
        self.conn.close()

    def test_add_and_get_product(self):
        """TEST 4.1: Add a product and verify retrieved attributes."""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO products (product_name, brand, category, quantity, unit, image, description)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, ("Test Oats", "Quaker", "Breakfast", 1.0, "kg", "/static/images/placeholder.svg", "Healthy whole oats"))
        self.conn.commit()

        cursor.execute("SELECT * FROM products WHERE product_name = 'Test Oats'")
        row = cursor.fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row['brand'], "Quaker")
        self.assertEqual(row['quantity'], 1.0)
        self.assertEqual(row['unit'], "kg")

    def test_update_product(self):
        """TEST 4.2: Update product information."""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO products (product_name, brand, category, quantity, unit, image)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ("Corn Flakes", "Kellogg's", "Breakfast", 500.0, "g", "/img.svg"))
        pid = cursor.lastrowid
        self.conn.commit()

        cursor.execute("""
            UPDATE products SET quantity = ?, unit = ? WHERE product_id = ?
        """, (1.0, "kg", pid))
        self.conn.commit()

        cursor.execute("SELECT quantity, unit FROM products WHERE product_id = ?", (pid,))
        updated = cursor.fetchone()
        self.assertEqual(updated['quantity'], 1.0)
        self.assertEqual(updated['unit'], "kg")

    def test_delete_product_cascades_to_prices(self):
        """TEST 4.3: Deleting a product cascades and removes its store price records."""
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO products (product_name, brand, category, quantity, unit, image) VALUES ('P1', 'B1', 'C1', 1, 'kg', 'i.svg')")
        pid = cursor.lastrowid
        cursor.execute("INSERT INTO stores (store_name, location) VALUES ('Store 1', 'City A')")
        sid = cursor.lastrowid
        cursor.execute("INSERT INTO store_prices (product_id, store_id, price, updated_at) VALUES (?, ?, 100, '2026-11-21')", (pid, sid))
        self.conn.commit()

        # Delete product
        cursor.execute("DELETE FROM products WHERE product_id = ?", (pid,))
        self.conn.commit()

        # Verify price record was deleted via cascade
        cursor.execute("SELECT COUNT(*) FROM store_prices WHERE product_id = ?", (pid,))
        self.assertEqual(cursor.fetchone()[0], 0)

    def test_add_store(self):
        """TEST 4.4: Add store and check unique constraint."""
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO stores (store_name, location, website) VALUES ('SuperMart', 'Mumbai', 'https://supermart.com')")
        self.conn.commit()

        # Attempt duplicate store name
        with self.assertRaises(sqlite3.IntegrityError):
            cursor.execute("INSERT INTO stores (store_name, location) VALUES ('SuperMart', 'Delhi')")

    def test_add_price_record(self):
        """TEST 4.5: Add store price record."""
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO products (product_name, brand, category, quantity, unit, image) VALUES ('Salt', 'Tata', 'Staples', 1, 'kg', 'i.svg')")
        pid = cursor.lastrowid
        cursor.execute("INSERT INTO stores (store_name, location) VALUES ('Local Grocer', 'Bengaluru')")
        sid = cursor.lastrowid
        cursor.execute("""
            INSERT INTO store_prices (product_id, store_id, price, product_url, source_name, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (pid, sid, 25.0, "https://store.com/p/salt", "Local Store", "21-11-2026"))
        self.conn.commit()

        cursor.execute("SELECT price, product_url FROM store_prices WHERE product_id = ?", (pid,))
        p_row = cursor.fetchone()
        self.assertEqual(p_row['price'], 25.0)
        self.assertEqual(p_row['product_url'], "https://store.com/p/salt")

    def test_reject_negative_or_zero_price(self):
        """TEST 4.6: Database constraint CHECK(price > 0) rejects zero or negative prices."""
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO products (product_name, brand, category, quantity, unit, image) VALUES ('Tea', 'Wagh Bakri', 'Beverages', 250, 'g', 'i.svg')")
        pid = cursor.lastrowid
        cursor.execute("INSERT INTO stores (store_name, location) VALUES ('Corner Store', 'Pune')")
        sid = cursor.lastrowid

        with self.assertRaises(sqlite3.IntegrityError):
            cursor.execute("INSERT INTO store_prices (product_id, store_id, price, updated_at) VALUES (?, ?, -10.0, '2026-11-21')", (pid, sid))

        with self.assertRaises(sqlite3.IntegrityError):
            cursor.execute("INSERT INTO store_prices (product_id, store_id, price, updated_at) VALUES (?, ?, 0.0, '2026-11-21')", (pid, sid))

    def test_foreign_key_enforcement(self):
        """TEST 4.7: Foreign key enforcement blocks inserting price for non-existent product or store."""
        cursor = self.conn.cursor()
        with self.assertRaises(sqlite3.IntegrityError):
            cursor.execute("INSERT INTO store_prices (product_id, store_id, price, updated_at) VALUES (99999, 88888, 50.0, '2026-11-21')")

if __name__ == '__main__':
    unittest.main()
