import os
import sys
import unittest

SMARTCART_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if SMARTCART_DIR not in sys.path:
    sys.path.insert(0, SMARTCART_DIR)

from app import app
from database.setup import get_db_connection
from comparison_engine import compare_product_prices, calculate_unit_price

class TestPriceComparison(unittest.TestCase):
    def setUp(self):
        self.conn = get_db_connection()
        self.client = app.test_client()

    def tearDown(self):
        self.conn.close()

    def test_compare_product_multiple_stores(self):
        """TEST 3.1: Compare product #1 across multiple stores (at least 3)."""
        res = compare_product_prices(1, self.conn)
        self.assertIsNotNone(res)
        self.assertGreaterEqual(res['total_stores'], 3)
        self.assertEqual(len(res['listings']), res['total_stores'])

    def test_ascending_price_sorting(self):
        """TEST 3.2: Verify ascending price sorting is properly enforced."""
        res = compare_product_prices(1, self.conn, sort_by='price_asc')
        prices = [item['price'] for item in res['listings']]
        sorted_prices = sorted(prices)
        self.assertEqual(prices, sorted_prices)

    def test_cheapest_and_highest_price_identification(self):
        """TEST 3.3: Verify minimum price, maximum price, and cheapest store."""
        res = compare_product_prices(1, self.conn)
        prices = [item['price'] for item in res['listings']]
        expected_min = min(prices)
        expected_max = max(prices)

        self.assertEqual(res['lowest_price'], expected_min)
        self.assertEqual(res['highest_price'], expected_max)
        self.assertTrue(any(item['is_cheapest'] for item in res['listings']))
        cheapest_item = next(item for item in res['listings'] if item['is_cheapest'])
        self.assertIn(cheapest_item['store_name'], res['cheapest_store'])

    def test_savings_calculation(self):
        """TEST 3.4: Verify possible savings (highest_price - lowest_price) and percentage."""
        res = compare_product_prices(1, self.conn)
        expected_savings = round(res['highest_price'] - res['lowest_price'], 2)
        expected_pct = round((expected_savings / res['highest_price']) * 100, 1)

        self.assertEqual(res['savings'], expected_savings)
        self.assertEqual(res['savings_pct'], expected_pct)

    def test_unit_price_calculation_weight(self):
        """TEST 3.5: Unit price calculation for weights (g -> kg)."""
        # 500g butter at Rs 275 -> 275 / 0.5 = 550 Rs/kg
        unit_price, label = calculate_unit_price(275.0, 500, "g")
        self.assertEqual(unit_price, 550.0)
        self.assertEqual(label, "₹/kg")

        # 1kg rice at Rs 78 -> 78 Rs/kg
        unit_price_kg, label_kg = calculate_unit_price(78.0, 1.0, "kg")
        self.assertEqual(unit_price_kg, 78.0)
        self.assertEqual(label_kg, "₹/kg")

    def test_unit_price_calculation_volume(self):
        """TEST 3.6: Unit price calculation for volumes (ml -> L)."""
        # 500ml oil at Rs 80 -> 80 / 0.5 = 160 Rs/L
        unit_price, label = calculate_unit_price(80.0, 500, "ml")
        self.assertEqual(unit_price, 160.0)
        self.assertEqual(label, "₹/L")

        # 5L oil at Rs 650 -> 650 / 5 = 130 Rs/L
        unit_price_5l, label_5l = calculate_unit_price(650.0, 5.0, "L")
        self.assertEqual(unit_price_5l, 130.0)
        self.assertEqual(label_5l, "₹/L")

    def test_compare_route_render(self):
        """TEST 3.7: HTTP route /compare/<id> renders comparison table with savings."""
        res = self.client.get('/compare/1')
        self.assertEqual(res.status_code, 200)
        self.assertIn("Store-by-Store Comparison", res.text)
        self.assertIn("Lowest Available Price", res.text)
        self.assertIn("Possible Savings", res.text)
        self.assertIn("CHEAPEST STORE HIGHLIGHT", res.text)

if __name__ == '__main__':
    unittest.main()
