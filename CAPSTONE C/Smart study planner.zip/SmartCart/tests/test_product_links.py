import os
import sys
import unittest

SMARTCART_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if SMARTCART_DIR not in sys.path:
    sys.path.insert(0, SMARTCART_DIR)

from app import app
from database.setup import get_db_connection
from comparison_engine import validate_url, compare_product_prices

class TestProductLinks(unittest.TestCase):
    def setUp(self):
        self.conn = get_db_connection()
        self.client = app.test_client()

    def tearDown(self):
        self.conn.close()

    def test_url_validator(self):
        """TEST 6.1: Verify URL validation logic detects well-formed and rejected URLs."""
        # Valid URLs
        self.assertTrue(validate_url("https://www.amazon.in/dp/B00TS8AE8E"))
        self.assertTrue(validate_url("https://www.bigbasket.com/pd/10000407/daawat-rice/"))
        self.assertTrue(validate_url("https://www.jiomart.com/p/groceries/daawat-rice/490000000"))
        self.assertTrue(validate_url("https://www.dmart.in/product/daawat-rice"))
        self.assertTrue(validate_url("http://groceries.example.co.in/item"))

        # Invalid URLs
        self.assertFalse(validate_url(""))
        self.assertFalse(validate_url(None))
        self.assertFalse(validate_url("not_a_valid_url"))
        self.assertFalse(validate_url("ftp://files.example.com"))
        self.assertFalse(validate_url("javascript:alert(1)"))
        self.assertFalse(validate_url("https://localhost/item"))

    def test_visit_store_rendered_attributes(self):
        """TEST 6.2: Verify Visit Store buttons contain genuine URLs, target='_blank', and rel='noopener noreferrer'."""
        res = self.client.get('/compare/1')
        self.assertEqual(res.status_code, 200)
        html = res.text

        # Product #1 has listings with BigBasket and Amazon URLs
        self.assertIn('target="_blank"', html)
        self.assertIn('rel="noopener noreferrer"', html)
        self.assertIn('Visit Store', html)
        self.assertIn('https://www.bigbasket.com', html)
        self.assertIn('https://www.amazon.in', html)

    def test_link_unavailable_badge_when_missing_url(self):
        """TEST 6.3: Verify that missing or empty URLs render 'Link unavailable' badge (not clickable)."""
        # Product #9 (Britannia Cheese Slices) has a deliberate listing at DMart Ready with no URL
        cursor = self.conn.cursor()
        cursor.execute("SELECT product_id FROM products WHERE product_name = 'Britannia Cheese Slices'")
        row = cursor.fetchone()
        self.assertIsNotNone(row)
        pid = row['product_id']

        res = self.client.get(f'/compare/{pid}')
        self.assertEqual(res.status_code, 200)
        self.assertIn("Link unavailable", res.text)
        self.assertIn("badge-link-unavailable", res.text)

    def test_admin_rejects_invalid_url_submission(self):
        """TEST 6.4: Admin price addition rejects malformed URLs."""
        # Log in
        self.client.post('/admin/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)

        # Attempt to add price with malformed URL
        bad_price_data = {
            'product_id': 1,
            'store_id': 2,
            'price': '85.0',
            'product_url': 'invalid-url-without-http-or-domain',
            'source_name': 'Test Store',
            'updated_at': '21-11-2026'
        }
        res = self.client.post('/admin/price/add', data=bad_price_data, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("Invalid product URL format", res.text)

if __name__ == '__main__':
    unittest.main()
