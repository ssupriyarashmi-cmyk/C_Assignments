import os
import sys
import unittest

SMARTCART_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if SMARTCART_DIR not in sys.path:
    sys.path.insert(0, SMARTCART_DIR)

from app import app
from database.setup import get_db_connection

class TestAdmin(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_unauthenticated_dashboard_access_blocked(self):
        """TEST 5.1: Unauthenticated visitors are redirected to /admin/login."""
        res = self.client.get('/admin/dashboard', follow_redirects=False)
        self.assertEqual(res.status_code, 302)
        self.assertIn("/admin/login", res.headers.get('Location', ''))

    def test_invalid_admin_login(self):
        """TEST 5.2: Invalid admin credentials are rejected with an alert."""
        res = self.client.post('/admin/login', data={'username': 'admin', 'password': 'wrongpassword999'}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("Invalid administrator credentials", res.text)

    def test_valid_admin_login_and_dashboard(self):
        """TEST 5.3: Valid admin login creates authenticated session and opens dashboard."""
        res = self.client.post('/admin/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("SmartCart Administration Portal", res.text)
        self.assertIn("Total Products", res.text)
        self.assertIn("Price Records", res.text)

    def test_admin_logout(self):
        """TEST 5.4: Admin logout terminates the session."""
        # Log in
        self.client.post('/admin/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)
        # Log out
        res = self.client.get('/admin/logout', follow_redirects=False)
        self.assertEqual(res.status_code, 302)
        # Verify dashboard now blocked again
        dash_res = self.client.get('/admin/dashboard', follow_redirects=False)
        self.assertEqual(dash_res.status_code, 302)

    def test_admin_add_product_and_price(self):
        """TEST 5.5: Authenticated admin can add a new product and price record."""
        # Log in first
        self.client.post('/admin/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)

        # Add Product
        prod_data = {
            'product_name': 'Automated Test Basmati',
            'brand': 'Kohinoor',
            'category': 'Rice and Grains',
            'quantity': '1.0',
            'unit': 'kg',
            'image': '/static/images/placeholder_grocery.svg',
            'description': 'Test description'
        }
        res_prod = self.client.post('/admin/product/add', data=prod_data, follow_redirects=True)
        self.assertEqual(res_prod.status_code, 200)

        # Check product created in DB
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT product_id FROM products WHERE product_name = 'Automated Test Basmati'")
        prod_row = cursor.fetchone()
        self.assertIsNotNone(prod_row)
        pid = prod_row['product_id']

        # Add Store Price
        price_data = {
            'product_id': pid,
            'store_id': 1,
            'price': '95.50',
            'product_url': 'https://www.bigbasket.com/pd/test',
            'source_name': 'Test Store',
            'updated_at': '21-11-2026'
        }
        res_price = self.client.post('/admin/price/add', data=price_data, follow_redirects=True)
        self.assertEqual(res_price.status_code, 200)

        # Verify price stored
        cursor.execute("SELECT price FROM store_prices WHERE product_id = ?", (pid,))
        price_row = cursor.fetchone()
        self.assertIsNotNone(price_row)
        self.assertEqual(price_row['price'], 95.50)

        # Clean up test product (cascades price)
        self.client.post(f'/admin/product/delete/{pid}', follow_redirects=True)
        conn.close()

if __name__ == '__main__':
    unittest.main()
