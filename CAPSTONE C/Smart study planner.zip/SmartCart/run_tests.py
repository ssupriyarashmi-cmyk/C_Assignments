import os
import sys
import time
import unittest

SMARTCART_DIR = os.path.abspath(os.path.dirname(__file__))
if SMARTCART_DIR not in sys.path:
    sys.path.insert(0, SMARTCART_DIR)

class SmartCartTestResult(unittest.TextTestResult):
    def __init__(self, stream, descriptions, verbosity):
        super().__init__(stream, descriptions, verbosity)
        self.report_records = []

    def addSuccess(self, test):
        super().addSuccess(test)
        doc = test._testMethodDoc or test._testMethodName
        self.report_records.append({
            'name': test._testMethodName,
            'description': doc.strip(),
            'expected': 'Success / Expected output matched',
            'actual': 'Matched expected assertions exactly',
            'status': 'PASS',
            'correction': 'None required'
        })

    def addFailure(self, test, err):
        super().addFailure(test, err)
        doc = test._testMethodDoc or test._testMethodName
        self.report_records.append({
            'name': test._testMethodName,
            'description': doc.strip(),
            'expected': 'Success / Expected assertions matched',
            'actual': f"Assertion Failed: {str(err[1])}",
            'status': 'FAIL',
            'correction': 'Investigate and correct logic'
        })

    def addError(self, test, err):
        super().addError(test, err)
        doc = test._testMethodDoc or test._testMethodName
        self.report_records.append({
            'name': test._testMethodName,
            'description': doc.strip(),
            'expected': 'No runtime error',
            'actual': f"Error: {str(err[1])}",
            'status': 'FAIL',
            'correction': 'Fix runtime exception'
        })

def run_all_tests():
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Discover and add test modules
    from tests.test_search import TestProductSearch
    from tests.test_comparison import TestPriceComparison
    from tests.test_database import TestDatabase
    from tests.test_admin import TestAdmin
    from tests.test_product_links import TestProductLinks

    suite.addTests(loader.loadTestsFromTestCase(TestProductSearch))
    suite.addTests(loader.loadTestsFromTestCase(TestPriceComparison))
    suite.addTests(loader.loadTestsFromTestCase(TestDatabase))
    suite.addTests(loader.loadTestsFromTestCase(TestAdmin))
    suite.addTests(loader.loadTestsFromTestCase(TestProductLinks))

    runner = unittest.TextTestRunner(resultclass=SmartCartTestResult, verbosity=2)
    start_time = time.time()
    result = runner.run(suite)
    duration = time.time() - start_time

    print("\n" + "=" * 90)
    print("SMARTCART AUTOMATED VERIFICATION TEST REPORT")
    print("=" * 90)
    print(f"Total Tests Executed: {result.testsRun}")
    print(f"Passed: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failed: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Execution Duration: {duration:.3f} seconds")
    print("-" * 90)
    print(f"{'#':<3} | {'Test Name':<35} | {'Status':<6} | {'Details'}")
    print("-" * 90)

    for idx, rec in enumerate(result.report_records, 1):
        print(f"{idx:<3} | {rec['name']:<35} | {rec['status']:<6} | {rec['description']}")

    print("=" * 90)
    return result.wasSuccessful()

if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
