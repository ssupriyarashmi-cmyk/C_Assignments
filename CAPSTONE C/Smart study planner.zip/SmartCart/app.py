import os
import sys
from datetime import date
from functools import wraps

# Ensure local SmartCart directory is in sys.path
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Import Flask and Werkzeug or fallback to pure standard library compat module
try:
    from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
    from werkzeug.security import generate_password_hash, check_password_hash
except ImportError:
    from compat import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort, generate_password_hash, check_password_hash

from config import Config
from database.setup import get_db_connection, init_db, seed_data
from comparison_engine import (
    compare_product_prices,
    get_product_cards,
    get_search_suggestions,
    validate_url,
    calculate_unit_price
)

def create_app():
    # Initialize and seed database if not yet present
    init_db()
    seed_data()

    app = Flask(__name__, 
                template_folder=os.path.join(BASE_DIR, 'templates'), 
                static_folder=os.path.join(BASE_DIR, 'static'))
    app.config['SECRET_KEY'] = Config.SECRET_KEY
    app.config['DATABASE_PATH'] = Config.DATABASE_PATH

    # Admin access control decorator
    def admin_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not session.get('admin_logged_in'):
                flash('Please log in with administrator credentials to access this area.', 'danger')
                return redirect(url_for('admin_login'))
            return f(*args, **kwargs)
        return decorated_function

    # -------------------------------------------------------------
    # PUBLIC ROUTES
    # -------------------------------------------------------------

    @app.route('/')
    def index():
        conn = get_db_connection()
        try:
            # Top compared products for homepage
            featured_products = get_product_cards(conn, limit=8, sort_by='popular')
            return render_template('index.html', featured_products=featured_products)
        finally:
            conn.close()

    @app.route('/categories')
    def categories():
        category = request.args.get('category', 'all').strip()
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT DISTINCT category FROM products ORDER BY category ASC")
            all_cats = [row['category'] for row in cursor.fetchall()]

            products = get_product_cards(conn, category=category, sort_by='popular')
            return render_template('categories.html', 
                                   categories=all_cats, 
                                   active_category=category, 
                                   products=products)
        finally:
            conn.close()

    @app.route('/products')
    def products():
        query = request.args.get('q', '').strip()
        category = request.args.get('category', 'all').strip()
        brand = request.args.get('brand', 'all').strip()
        sort_by = request.args.get('sort', 'popular').strip()

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT DISTINCT category FROM products ORDER BY category ASC")
            all_categories = [r['category'] for r in cursor.fetchall()]

            cursor.execute("SELECT DISTINCT brand FROM products ORDER BY brand ASC")
            all_brands = [r['brand'] for r in cursor.fetchall()]

            product_list = get_product_cards(
                conn, 
                category=category, 
                search_term=query, 
                brand=brand, 
                sort_by=sort_by
            )

            return render_template(
                'products.html',
                products=product_list,
                query=query,
                active_category=category,
                active_brand=brand,
                active_sort=sort_by,
                all_categories=all_categories,
                all_brands=all_brands
            )
        finally:
            conn.close()

    @app.route('/api/suggestions')
    def api_suggestions():
        q = request.args.get('q', '').strip()
        conn = get_db_connection()
        try:
            results = get_search_suggestions(conn, q, limit=8)
            return jsonify(results)
        finally:
            conn.close()

    @app.route('/compare/<int:product_id>')
    def compare(product_id):
        sort_by = request.args.get('sort', 'price_asc').strip()
        store_filter = request.args.get('store', None)
        if store_filter == 'all':
            store_filter = None

        conn = get_db_connection()
        try:
            comparison_data = compare_product_prices(
                product_id, 
                conn, 
                sort_by=sort_by, 
                store_filter=store_filter
            )
            if not comparison_data:
                flash("Product not found in our grocery catalog.", "danger")
                return redirect(url_for('products'))

            return render_template('comparison.html', 
                                   comp=comparison_data, 
                                   active_sort=sort_by)
        finally:
            conn.close()

    @app.route('/product/<int:product_id>')
    def product_details(product_id):
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM products WHERE product_id = ?", (product_id,))
            prod = cursor.fetchone()
            if not prod:
                flash("Product not found.", "danger")
                return redirect(url_for('products'))

            comp = compare_product_prices(product_id, conn)
            return render_template('product_details.html', product=dict(prod), comp=comp)
        finally:
            conn.close()

    @app.route('/about')
    def about():
        return render_template('about.html')

    # -------------------------------------------------------------
    # ADMIN AUTHENTICATION
    # -------------------------------------------------------------

    @app.route('/admin/login', methods=['GET', 'POST'])
    def admin_login():
        if session.get('admin_logged_in'):
            return redirect(url_for('admin_dashboard'))

        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '').strip()

            if not username or not password:
                flash('Please enter both username and password.', 'danger')
                return render_template('admin_login.html')

            conn = get_db_connection()
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM admins WHERE username = ?", (username,))
                admin_row = cursor.fetchone()

                if admin_row and check_password_hash(admin_row['password_hash'], password):
                    session['admin_logged_in'] = True
                    session['admin_username'] = admin_row['username']
                    flash(f"Welcome back, Administrator {admin_row['username']}!", 'success')
                    return redirect(url_for('admin_dashboard'))
                else:
                    flash('Invalid administrator credentials. Access denied.', 'danger')
            finally:
                conn.close()

        return render_template('admin_login.html')

    @app.route('/admin/logout')
    def admin_logout():
        session.pop('admin_logged_in', None)
        session.pop('admin_username', None)
        flash('You have been securely signed out.', 'info')
        return redirect(url_for('index'))

    # -------------------------------------------------------------
    # ADMIN DASHBOARD & CRUD MANAGEMENT
    # -------------------------------------------------------------

    @app.route('/admin/dashboard')
    @admin_required
    def admin_dashboard():
        conn = get_db_connection()
        try:
            cursor = conn.cursor()

            # Stats summary
            cursor.execute("SELECT COUNT(*) FROM products")
            total_products = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM stores")
            total_stores = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM store_prices")
            total_prices = cursor.fetchone()[0]

            # Product list
            cursor.execute("SELECT * FROM products ORDER BY product_id DESC")
            products = [dict(r) for r in cursor.fetchall()]

            # Stores list
            cursor.execute("SELECT * FROM stores ORDER BY store_name ASC")
            stores = [dict(r) for r in cursor.fetchall()]

            # Prices list with joins
            cursor.execute("""
                SELECT sp.price_id, sp.price, sp.product_url, sp.source_name, sp.updated_at,
                       p.product_id, p.product_name, s.store_id, s.store_name
                FROM store_prices sp
                JOIN products p ON sp.product_id = p.product_id
                JOIN stores s ON sp.store_id = s.store_id
                ORDER BY sp.price_id DESC
            """)
            prices = [dict(r) for r in cursor.fetchall()]

            stats = {
                'total_products': total_products,
                'total_stores': total_stores,
                'total_prices': total_prices
            }
            today_str = date.today().strftime("%d-%m-%Y")

            return render_template('admin_dashboard.html',
                                   stats=stats,
                                   products=products,
                                   stores=stores,
                                   prices=prices,
                                   today_str=today_str)
        finally:
            conn.close()

    # Product Operations
    @app.route('/admin/product/add', methods=['POST'])
    @admin_required
    def admin_product_add():
        name = request.form.get('product_name', '').strip()
        brand = request.form.get('brand', '').strip()
        category = request.form.get('category', '').strip()
        qty_str = request.form.get('quantity', '1').strip()
        unit = request.form.get('unit', 'kg').strip()
        image = request.form.get('image', '').strip() or '/static/images/placeholder_grocery.svg'
        desc = request.form.get('description', '').strip()

        if not name or not brand or not category:
            flash('Product Name, Brand, and Category are mandatory.', 'danger')
            return redirect(url_for('admin_dashboard'))

        try:
            qty = float(qty_str)
            if qty <= 0:
                raise ValueError()
        except ValueError:
            flash('Quantity must be a positive number.', 'danger')
            return redirect(url_for('admin_dashboard'))

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO products (product_name, brand, category, quantity, unit, image, description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, brand, category, qty, unit, image, desc))
            conn.commit()
            flash(f"Grocery product '{name}' created successfully.", 'success')
        except Exception as e:
            flash(f"Error creating product: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    @app.route('/admin/product/edit/<int:product_id>', methods=['POST'])
    @admin_required
    def admin_product_edit(product_id):
        name = request.form.get('product_name', '').strip()
        brand = request.form.get('brand', '').strip()
        category = request.form.get('category', '').strip()
        qty_str = request.form.get('quantity', '1').strip()
        unit = request.form.get('unit', 'kg').strip()
        image = request.form.get('image', '').strip()
        desc = request.form.get('description', '').strip()

        try:
            qty = float(qty_str)
            if qty <= 0:
                raise ValueError()
        except ValueError:
            flash('Quantity must be positive.', 'danger')
            return redirect(url_for('admin_dashboard'))

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE products
                SET product_name = ?, brand = ?, category = ?, quantity = ?, unit = ?, image = ?, description = ?
                WHERE product_id = ?
            """, (name, brand, category, qty, unit, image, desc, product_id))
            conn.commit()
            flash(f"Product #{product_id} updated successfully.", 'success')
        except Exception as e:
            flash(f"Error updating product: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    @app.route('/admin/product/delete/<int:product_id>', methods=['POST'])
    @admin_required
    def admin_product_delete(product_id):
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
            conn.commit()
            flash(f"Product #{product_id} and all its prices deleted.", 'info')
        except Exception as e:
            flash(f"Error deleting product: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    # Store Operations
    @app.route('/admin/store/add', methods=['POST'])
    @admin_required
    def admin_store_add():
        name = request.form.get('store_name', '').strip()
        location = request.form.get('location', '').strip()
        website = request.form.get('website', '').strip()

        if not name or not location:
            flash('Store Name and Location are mandatory.', 'danger')
            return redirect(url_for('admin_dashboard'))

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO stores (store_name, location, website)
                VALUES (?, ?, ?)
            """, (name, location, website))
            conn.commit()
            flash(f"Store '{name}' registered successfully.", 'success')
        except Exception as e:
            flash(f"Error adding store: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    @app.route('/admin/store/edit/<int:store_id>', methods=['POST'])
    @admin_required
    def admin_store_edit(store_id):
        name = request.form.get('store_name', '').strip()
        location = request.form.get('location', '').strip()
        website = request.form.get('website', '').strip()

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE stores
                SET store_name = ?, location = ?, website = ?
                WHERE store_id = ?
            """, (name, location, website, store_id))
            conn.commit()
            flash(f"Store #{store_id} updated.", 'success')
        except Exception as e:
            flash(f"Error updating store: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    @app.route('/admin/store/delete/<int:store_id>', methods=['POST'])
    @admin_required
    def admin_store_delete(store_id):
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM stores WHERE store_id = ?", (store_id,))
            conn.commit()
            flash(f"Store #{store_id} removed.", 'info')
        except Exception as e:
            flash(f"Error deleting store: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    # Store Price Operations
    @app.route('/admin/price/add', methods=['POST'])
    @admin_required
    def admin_price_add():
        product_id = request.form.get('product_id')
        store_id = request.form.get('store_id')
        price_str = request.form.get('price', '').strip()
        url = request.form.get('product_url', '').strip()
        source = request.form.get('source_name', '').strip()
        updated_at = request.form.get('updated_at', '').strip() or date.today().strftime("%d-%m-%Y")

        try:
            price = float(price_str)
            if price <= 0:
                raise ValueError()
        except ValueError:
            flash('Price must be a positive value greater than zero.', 'danger')
            return redirect(url_for('admin_dashboard'))

        # URL Validation
        if url and not validate_url(url):
            flash('Invalid product URL format. Must begin with http:// or https:// with a valid domain name.', 'danger')
            return redirect(url_for('admin_dashboard'))

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO store_prices (product_id, store_id, price, product_url, source_name, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (product_id, store_id, price, url, source, updated_at))
            conn.commit()
            flash("Store price record saved successfully.", 'success')
        except Exception as e:
            flash(f"Error saving price record: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    @app.route('/admin/price/edit/<int:price_id>', methods=['POST'])
    @admin_required
    def admin_price_edit(price_id):
        price_str = request.form.get('price', '').strip()
        url = request.form.get('product_url', '').strip()
        source = request.form.get('source_name', '').strip()
        updated_at = request.form.get('updated_at', '').strip() or date.today().strftime("%d-%m-%Y")

        try:
            price = float(price_str)
            if price <= 0:
                raise ValueError()
        except ValueError:
            flash('Price must be greater than zero.', 'danger')
            return redirect(url_for('admin_dashboard'))

        if url and not validate_url(url):
            flash('Invalid product URL format. Must start with http:// or https://', 'danger')
            return redirect(url_for('admin_dashboard'))

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE store_prices
                SET price = ?, product_url = ?, source_name = ?, updated_at = ?
                WHERE price_id = ?
            """, (price, url, source, updated_at, price_id))
            conn.commit()
            flash(f"Price record #{price_id} updated.", 'success')
        except Exception as e:
            flash(f"Error updating price: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    @app.route('/admin/price/delete/<int:price_id>', methods=['POST'])
    @admin_required
    def admin_price_delete(price_id):
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM store_prices WHERE price_id = ?", (price_id,))
            conn.commit()
            flash(f"Price listing #{price_id} deleted.", 'info')
        except Exception as e:
            flash(f"Error deleting price: {str(e)}", 'danger')
        finally:
            conn.close()

        return redirect(url_for('admin_dashboard'))

    # Friendly Error Handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('base.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('base.html'), 500

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"==================================================")
    print(f"SMARTCART – Grocery Price Comparison System")
    print(f"Starting server on http://127.0.0.1:{port}/")
    print(f"==================================================")
    app.run(host='127.0.0.1', port=port, debug=True)
