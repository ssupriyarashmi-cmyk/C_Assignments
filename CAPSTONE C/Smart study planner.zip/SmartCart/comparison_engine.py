import re
from urllib.parse import urlparse

def calculate_unit_price(price, quantity, unit):
    """
    Calculate normalized unit price per standard unit (₹/kg, ₹/L, or ₹/piece).
    Supports fair comparison when package sizes differ.
    """
    try:
        p = float(price)
        q = float(quantity)
        if p <= 0 or q <= 0:
            return None, ""
        
        u = str(unit).strip().lower()
        
        # Weight normalisation
        if u in ['g', 'gm', 'gram', 'grams']:
            normalized_qty = q / 1000.0
            unit_price = round(p / normalized_qty, 2)
            return unit_price, "₹/kg"
        elif u in ['kg', 'kilo', 'kilogram', 'kilograms']:
            normalized_qty = q
            unit_price = round(p / normalized_qty, 2)
            return unit_price, "₹/kg"
        
        # Volume normalisation
        elif u in ['ml', 'milli', 'millilitre', 'millilitres']:
            normalized_qty = q / 1000.0
            unit_price = round(p / normalized_qty, 2)
            return unit_price, "₹/L"
        elif u in ['l', 'ltr', 'litre', 'litres']:
            normalized_qty = q
            unit_price = round(p / normalized_qty, 2)
            return unit_price, "₹/L"
        
        # Pieces or packs
        elif u in ['pcs', 'pc', 'piece', 'pieces']:
            unit_price = round(p / q, 2)
            return unit_price, "₹/pc"
        else:
            unit_price = round(p / q, 2)
            return unit_price, f"₹/{u}"
    except (ValueError, TypeError, ZeroDivisionError):
        return None, ""

def validate_url(url):
    """
    Validate external retailer product URL.
    Ensures safe, well-formed HTTP/HTTPS URLs with valid domain.
    """
    if not url or not isinstance(url, str):
        return False
    url = url.strip()
    if not (url.startswith('http://') or url.startswith('https://')):
        return False
    try:
        parsed = urlparse(url)
        # Check netloc has at least one dot and is not localhost
        return bool(parsed.scheme in ('http', 'https') and parsed.netloc and '.' in parsed.netloc)
    except Exception:
        return False

def compare_product_prices(product_id, conn, sort_by='price_asc', store_filter=None):
    """
    Core Price Comparison Logic:
    1. Retrieve product details
    2. Retrieve matching store price records
    3. Validate price values
    4. Calculate unit prices for fair comparison
    5. Sort results
    6. Identify lowest and highest prices
    7. Calculate potential savings
    8. Mark cheapest store and valid external links
    """
    cursor = conn.cursor()
    cursor.execute("""
        SELECT product_id, product_name, brand, category, quantity, unit, image, description
        FROM products
        WHERE product_id = ?
    """, (product_id,))
    prod_row = cursor.fetchone()
    if not prod_row:
        return None

    product = dict(prod_row)

    # Retrieve store listings
    query = """
        SELECT sp.price_id, sp.price, sp.product_url, sp.source_name, sp.updated_at,
               s.store_id, s.store_name, s.location, s.website, s.logo_color
        FROM store_prices sp
        JOIN stores s ON sp.store_id = s.store_id
        WHERE sp.product_id = ? AND sp.price > 0
    """
    params = [product_id]

    if store_filter:
        query += " AND s.store_name = ?"
        params.append(store_filter)

    cursor.execute(query, params)
    raw_listings = [dict(row) for row in cursor.fetchall()]

    if not raw_listings:
        return {
            'product': product,
            'listings': [],
            'total_stores': 0,
            'lowest_price': 0,
            'highest_price': 0,
            'savings': 0,
            'savings_pct': 0,
            'cheapest_store': 'N/A',
            'cheapest_unit_price': 0,
            'unit_label': ''
        }

    # Compute unit prices and check links
    processed_listings = []
    for item in raw_listings:
        u_price, u_label = calculate_unit_price(item['price'], product['quantity'], product['unit'])
        item['unit_price'] = u_price
        item['unit_label'] = u_label
        item['has_valid_url'] = validate_url(item.get('product_url'))
        processed_listings.append(item)

    # Identify minimum and maximum prices
    prices = [item['price'] for item in processed_listings]
    min_price = min(prices)
    max_price = max(prices)
    savings = round(max_price - min_price, 2)
    savings_pct = round((savings / max_price) * 100, 1) if max_price > 0 else 0.0

    # Mark cheapest stores and price differences
    cheapest_stores = []
    for item in processed_listings:
        item['price_diff'] = round(item['price'] - min_price, 2)
        if item['price'] == min_price:
            item['is_cheapest'] = True
            cheapest_stores.append(item['store_name'])
        else:
            item['is_cheapest'] = False

    # Sorting
    if sort_by == 'price_desc':
        processed_listings.sort(key=lambda x: x['price'], reverse=True)
    elif sort_by == 'unit_price_asc':
        processed_listings.sort(key=lambda x: x['unit_price'] or 999999)
    elif sort_by == 'store_asc':
        processed_listings.sort(key=lambda x: x['store_name'].lower())
    else:  # Default: price_asc
        processed_listings.sort(key=lambda x: x['price'])

    # Unit price for cheapest listing
    cheapest_item = next((it for it in processed_listings if it['is_cheapest']), processed_listings[0])

    return {
        'product': product,
        'listings': processed_listings,
        'total_stores': len(processed_listings),
        'lowest_price': min_price,
        'highest_price': max_price,
        'savings': savings,
        'savings_pct': savings_pct,
        'cheapest_store': ", ".join(cheapest_stores),
        'cheapest_unit_price': cheapest_item['unit_price'],
        'unit_label': cheapest_item['unit_label']
    }

def get_product_cards(conn, category=None, search_term=None, brand=None, sort_by='popular', limit=None):
    """
    Retrieve products with aggregated lowest price and store count for card displays.
    """
    cursor = conn.cursor()
    base_sql = """
        SELECT p.product_id, p.product_name, p.brand, p.category, p.quantity, p.unit, p.image, p.description,
               MIN(sp.price) as lowest_price,
               MAX(sp.price) as highest_price,
               COUNT(sp.price_id) as store_count
        FROM products p
        LEFT JOIN store_prices sp ON p.product_id = sp.product_id AND sp.price > 0
        WHERE 1=1
    """
    params = []

    if category and category.lower() != 'all':
        base_sql += " AND LOWER(p.category) = LOWER(?)"
        params.append(category)

    if brand and brand.lower() != 'all':
        base_sql += " AND LOWER(p.brand) = LOWER(?)"
        params.append(brand)

    if search_term:
        term = f"%{search_term.strip().lower()}%"
        base_sql += " AND (LOWER(p.product_name) LIKE ? OR LOWER(p.brand) LIKE ? OR LOWER(p.category) LIKE ?)"
        params.extend([term, term, term])

    base_sql += " GROUP BY p.product_id"

    # Sorting
    if sort_by == 'price_asc':
        base_sql += " ORDER BY lowest_price ASC"
    elif sort_by == 'price_desc':
        base_sql += " ORDER BY lowest_price DESC"
    elif sort_by == 'name_asc':
        base_sql += " ORDER BY p.product_name ASC"
    elif sort_by == 'savings_desc':
        base_sql += " ORDER BY (highest_price - lowest_price) DESC"
    else:  # Popular or default
        base_sql += " ORDER BY store_count DESC, p.product_id ASC"

    if limit:
        base_sql += f" LIMIT {int(limit)}"

    cursor.execute(base_sql, params)
    rows = cursor.fetchall()

    cards = []
    for r in rows:
        d = dict(r)
        lp = d['lowest_price'] or 0
        hp = d['highest_price'] or 0
        d['lowest_price'] = lp
        d['highest_price'] = hp
        d['savings'] = round(hp - lp, 2) if hp > lp else 0
        cards.append(d)

    return cards

def get_search_suggestions(conn, query, limit=8):
    """
    Autocomplete suggestions for live product search dropdown.
    """
    if not query or len(query.strip()) < 1:
        return []
    term = f"%{query.strip().lower()}%"
    cursor = conn.cursor()
    cursor.execute("""
        SELECT product_id, product_name, brand, category, quantity, unit, image
        FROM products
        WHERE LOWER(product_name) LIKE ? OR LOWER(brand) LIKE ? OR LOWER(category) LIKE ?
        ORDER BY product_name ASC
        LIMIT ?
    """, (term, term, term, limit))
    return [dict(row) for row in cursor.fetchall()]
