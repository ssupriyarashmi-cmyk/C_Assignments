import os

IMAGES_DIR = os.path.join(os.path.dirname(__file__), 'static', 'images')
os.makedirs(IMAGES_DIR, exist_ok=True)

# Helper function to create SVG
def save_svg(filename, content):
    path = os.path.join(IMAGES_DIR, filename)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip())
    print(f"Generated {filename}")

# 1. Logo
logo_svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 64" fill="none">
  <defs>
    <linearGradient id="gradLogo" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1b5e20"/>
      <stop offset="100%" stop-color="#4caf50"/>
    </linearGradient>
  </defs>
  <!-- Shopping Cart Icon with Price Tag -->
  <rect x="4" y="6" width="52" height="52" rx="14" fill="url(#gradLogo)"/>
  <path d="M18 20h5l4.5 15h16l3.5-10H25" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="28" cy="42" r="2.5" fill="#ffffff"/>
  <circle cx="41" cy="42" r="2.5" fill="#ffffff"/>
  <!-- Percent / Bargain Badge -->
  <path d="M33 24l5 6m-5 0l5-6" stroke="#c8e6c9" stroke-width="1.8" stroke-linecap="round"/>
  <!-- Text -->
  <text x="68" y="38" font-family="'Segoe UI', Roboto, Helvetica, sans-serif" font-size="28" font-weight="900" fill="#1b5e20" letter-spacing="-0.5">SMART<tspan fill="#2e7d32">CART</tspan></text>
  <text x="69" y="52" font-family="'Segoe UI', Roboto, Helvetica, sans-serif" font-size="10" font-weight="700" fill="#6c757d" letter-spacing="1.5">PRICE COMPARISON</text>
  <!-- Green Dot -->
  <circle cx="230" cy="35" r="4" fill="#4caf50"/>
</svg>"""
save_svg("logo.svg", logo_svg)

favicon_svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <defs>
    <linearGradient id="favGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1b5e20"/>
      <stop offset="100%" stop-color="#4caf50"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" rx="16" fill="url(#favGrad)"/>
  <path d="M16 18h6l5.5 18h20l4.5-12H24" stroke="#ffffff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  <circle cx="28" cy="46" r="3.5" fill="#ffffff"/>
  <circle cx="45" cy="46" r="3.5" fill="#ffffff"/>
  <path d="M33 22l7 7m-7 0l7-7" stroke="#c8e6c9" stroke-width="2.5" stroke-linecap="round"/>
</svg>"""
save_svg("favicon.svg", favicon_svg)

# Generator for Product Illustrations
def product_svg(title, subtitle, bg_color, accent_color, icon_type):
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 240" fill="none">
  <rect width="320" height="240" rx="16" fill="{bg_color}"/>
  <rect x="12" y="12" width="296" height="216" rx="12" fill="#ffffff" stroke="{accent_color}" stroke-opacity="0.2" stroke-width="1.5"/>
  <circle cx="160" cy="100" r="54" fill="{accent_color}" fill-opacity="0.12"/>
  
  <!-- Icon Graphics based on type -->
  {get_icon_graphic(icon_type, accent_color)}

  <!-- Badge / Tag -->
  <rect x="230" y="24" width="66" height="22" rx="11" fill="{accent_color}" fill-opacity="0.15"/>
  <text x="263" y="39" font-family="'Segoe UI', sans-serif" font-size="10" font-weight="700" fill="{accent_color}" text-anchor="middle">AUTHENTIC</text>

  <!-- Typography -->
  <text x="160" y="180" font-family="'Segoe UI', Roboto, sans-serif" font-size="17" font-weight="800" fill="#1b5e20" text-anchor="middle">{title}</text>
  <text x="160" y="202" font-family="'Segoe UI', Roboto, sans-serif" font-size="12" font-weight="600" fill="#6c757d" text-anchor="middle">{subtitle}</text>
</svg>"""

def get_icon_graphic(t, c):
    if t == 'rice':
        return f"""
        <!-- Sack of Rice -->
        <path d="M125 75 Q160 60 195 75 L205 135 Q160 148 115 135 Z" fill="{c}" fill-opacity="0.8"/>
        <path d="M125 75 C140 70 180 70 195 75 C190 65 130 65 125 75 Z" fill="#ffffff" opacity="0.6"/>
        <ellipse cx="160" cy="105" rx="16" ry="24" fill="#ffffff" fill-opacity="0.9"/>
        <text x="160" y="110" font-family="'Segoe UI', sans-serif" font-size="11" font-weight="900" fill="{c}" text-anchor="middle">RICE</text>
        """
    elif t == 'atta':
        return f"""
        <!-- Flour Sack / Atta -->
        <rect x="120" y="65" width="80" height="75" rx="10" fill="{c}" fill-opacity="0.8"/>
        <path d="M120 75 Q160 85 200 75" stroke="#ffffff" stroke-width="3" fill="none"/>
        <circle cx="160" cy="105" r="18" fill="#ffffff"/>
        <text x="160" y="110" font-family="'Segoe UI', sans-serif" font-size="10" font-weight="900" fill="{c}" text-anchor="middle">ATTA</text>
        """
    elif t == 'oil':
        return f"""
        <!-- Oil Bottle -->
        <rect x="145" y="55" width="30" height="15" rx="3" fill="{c}"/>
        <path d="M142 70 Q130 85 130 135 Q160 145 190 135 Q190 85 178 70 Z" fill="{c}" fill-opacity="0.75"/>
        <path d="M160 90 C150 105 150 115 160 125 C170 115 170 105 160 90 Z" fill="#fbc02d"/>
        """
    elif t == 'dairy':
        return f"""
        <!-- Butter / Cheese Pack -->
        <rect x="120" y="75" width="80" height="55" rx="8" fill="#ffd54f"/>
        <rect x="125" y="80" width="70" height="45" rx="5" fill="#fff9c4"/>
        <text x="160" y="108" font-family="'Segoe UI', sans-serif" font-size="12" font-weight="900" fill="#f57f17" text-anchor="middle">PURE MILK</text>
        """
    elif t == 'noodles':
        return f"""
        <!-- Noodle / Snack Pack -->
        <rect x="115" y="70" width="90" height="65" rx="8" fill="#e53935"/>
        <path d="M125 102 Q140 88 155 102 T185 102" stroke="#ffeb3b" stroke-width="4" fill="none"/>
        <text x="160" y="125" font-family="'Segoe UI', sans-serif" font-size="11" font-weight="900" fill="#ffffff" text-anchor="middle">MASALA</text>
        """
    elif t == 'tea':
        return f"""
        <!-- Tea Box / Leaves -->
        <rect x="125" y="65" width="70" height="75" rx="8" fill="#2e7d32"/>
        <path d="M160 85 C150 75 140 90 160 110 C180 90 170 75 160 85 Z" fill="#81c784"/>
        <text x="160" y="128" font-family="'Segoe UI', sans-serif" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">TEA</text>
        """
    elif t == 'dal':
        return f"""
        <!-- Dal / Pulses Bowl -->
        <ellipse cx="160" cy="115" rx="42" ry="18" fill="#f57c00"/>
        <ellipse cx="160" cy="110" rx="36" ry="14" fill="#ffb74d"/>
        <circle cx="152" cy="108" r="4" fill="#e65100"/>
        <circle cx="164" cy="111" r="3.5" fill="#e65100"/>
        <circle cx="160" cy="105" r="3" fill="#e65100"/>
        <text x="160" y="90" font-family="'Segoe UI', sans-serif" font-size="11" font-weight="900" fill="#e65100" text-anchor="middle">PULSES</text>
        """
    elif t == 'soap':
        return f"""
        <!-- Care / Soap Bar -->
        <rect x="125" y="75" width="70" height="50" rx="14" fill="#00897b"/>
        <ellipse cx="160" cy="100" rx="20" ry="12" fill="#80cbc4" opacity="0.6"/>
        <text x="160" y="104" font-family="'Segoe UI', sans-serif" font-size="10" font-weight="900" fill="#ffffff" text-anchor="middle">CARE</text>
        """
    else:
        return f"""
        <circle cx="160" cy="100" r="30" fill="{c}" fill-opacity="0.3"/>
        <text x="160" y="106" font-family="'Segoe UI', sans-serif" font-size="14" font-weight="900" fill="{c}" text-anchor="middle">GROCERY</text>
        """

# Products dictionary
products = [
    ("daawat_rice.svg", "Daawat Rozana Rice", "Super Basmati • 1 kg", "#f1f8e9", "#2e7d32", "rice"),
    ("india_gate_rice.svg", "India Gate Basmati", "Feast Rozana • 1 kg", "#f1f8e9", "#1b5e20", "rice"),
    ("aashirvaad_atta.svg", "Aashirvaad Atta", "Whole Wheat • 5 kg", "#fff8e1", "#e65100", "atta"),
    ("fortune_atta.svg", "Fortune Chakki Atta", "Chakki Fresh • 5 kg", "#fff8e1", "#f57c00", "atta"),
    ("fortune_oil.svg", "Fortune Sunflower Oil", "Refined Sunlite • 1 L", "#fffde7", "#fbc02d", "oil"),
    ("saffola_oil.svg", "Saffola Gold Oil", "Pro Lifestyle • 1 L", "#fffde7", "#e65100", "oil"),
    ("amul_ghee.svg", "Amul Pure Ghee", "Clarified Butter • 1 L", "#fffde7", "#f57f17", "oil"),
    ("amul_butter.svg", "Amul Table Butter", "Pasteurized • 500 g", "#fff8e1", "#fbc02d", "dairy"),
    ("britannia_cheese.svg", "Britannia Cheese", "10 Processed Slices • 200 g", "#fffde7", "#ffb300", "dairy"),
    ("amul_milk.svg", "Amul Taaza Milk", "Homogenised Toned • 1 L", "#e3f2fd", "#0288d1", "dairy"),
    ("maggi_noodles.svg", "Maggi 2-Min Noodles", "Special Masala • 840 g", "#ffebee", "#c62828", "noodles"),
    ("parle_g.svg", "Parle-G Biscuits", "Original Glucose • 800 g", "#fff8e1", "#e65100", "noodles"),
    ("good_day.svg", "Good Day Cashew", "Butter Cookies • 600 g", "#fff8e1", "#d84315", "noodles"),
    ("tata_tea.svg", "Tata Tea Gold", "Fine Assam Leaves • 500 g", "#e8f5e9", "#1b5e20", "tea"),
    ("red_label.svg", "Red Label Natural Care", "5 Ayurvedic Herbs • 1 kg", "#ffebee", "#b71c1c", "tea"),
    ("nescafe_coffee.svg", "Nescafe Classic Coffee", "100% Pure Jar • 200 g", "#efebe9", "#4e342e", "tea"),
    ("toor_dal.svg", "Tata Sampann Toor Dal", "Unpolished Arhar • 1 kg", "#fff3e0", "#ef6c00", "dal"),
    ("moong_dal.svg", "Tata Sampann Moong", "Yellow Split Dal • 1 kg", "#fff8e1", "#f9a825", "dal"),
    ("dettol_soap.svg", "Dettol Bathing Soap", "Original Germ Protect • 5x125g", "#e0f2f1", "#00695c", "soap"),
    ("colgate.svg", "Colgate Strong Teeth", "Calcium Boost • 500 g", "#ffebee", "#d32f2f", "soap"),
    ("placeholder_grocery.svg", "Grocery Item", "Verified Grocery Product", "#f5f5f5", "#4caf50", "other")
]

for filename, title, subtitle, bg, accent, itype in products:
    save_svg(filename, product_svg(title, subtitle, bg, accent, itype))

print("All SVG assets successfully generated!")
