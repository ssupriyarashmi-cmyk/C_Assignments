import sqlite3
import random
import string
import secrets
from datetime import datetime, timedelta
from database import get_db
from compat import generate_password_hash, check_password_hash

def _parse_db_time(time_val):
    if not time_val:
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S.%f'):
        try:
            return datetime.strptime(str(time_val).split('.')[0], '%Y-%m-%d %H:%M:%S')
        except Exception:
            pass
    return None

def generate_enrolment_code(prefix="CLS"):
    """Generates a clean readable unique 7-character class code like PYAI27K."""
    clean_prefix = "".join(c for c in (prefix or "").upper() if c.isalnum())[:4] or "CLS"
    needed_len = max(3, 7 - len(clean_prefix))
    rand_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=needed_len))
    return f"{clean_prefix}{rand_part}"[:7]

# ==========================================
# USER OPERATIONS
# ==========================================
class UserModel:
    @staticmethod
    def generate_otp():
        """Generates a secure 6-digit numerical OTP."""
        return f"{secrets.randbelow(900000) + 100000}"

    @staticmethod
    def create_user(role, name, email, password, identifier, department, year_of_study=None, semester=None, subjects_handled=None, is_verified=1):
        conn = get_db()
        cursor = conn.cursor()
        password_hash = generate_password_hash(password)
        try:
            cursor.execute("""
                INSERT INTO users (role, name, email, password_hash, identifier, department, year_of_study, semester, subjects_handled, is_verified)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (role, name.strip(), email.strip().lower(), password_hash, identifier.strip(), department.strip(), year_of_study, semester, subjects_handled, is_verified))
            conn.commit()
            user_id = cursor.lastrowid
            
            # If student, create default timetable record
            if role == 'student':
                cursor.execute("""
                    INSERT INTO timetables (student_id, title, daily_study_hours, preferred_start_time, preferred_end_time)
                    VALUES (?, 'Weekly Study Timetable', 3.0, '18:00', '21:30')
                """, (user_id,))
                conn.commit()

            return user_id, None
        except sqlite3.IntegrityError:
            return None, "An account with this email address already exists."
        finally:
            conn.close()

    @staticmethod
    def get_by_email(email):
        if not email:
            return None
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE LOWER(email) = LOWER(?)", (email.strip().lower(),)).fetchone()
        conn.close()
        return user

    @staticmethod
    def get_by_id(user_id):
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        conn.close()
        return user

    @staticmethod
    def update_profile(user_id, name, department, identifier, year_of_study=None, semester=None, subjects_handled=None):
        conn = get_db()
        conn.execute("""
            UPDATE users 
            SET name = ?, department = ?, identifier = ?, year_of_study = ?, semester = ?, subjects_handled = ?
            WHERE id = ?
        """, (name.strip(), department.strip(), identifier.strip(), year_of_study, semester, subjects_handled, user_id))
        conn.commit()
        conn.close()

    @staticmethod
    def update_password(user_id, new_password):
        conn = get_db()
        pwd_hash = generate_password_hash(new_password)
        conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (pwd_hash, user_id))
        conn.commit()
        conn.close()

    @staticmethod
    def set_verification_otp(user_id, otp_code=None, expires_in_minutes=5):
        """Generates and securely stores a hashed 6-digit verification OTP."""
        if otp_code is None:
            otp_code = UserModel.generate_otp()
        otp_hash = generate_password_hash(str(otp_code).strip())
        expires_at = (datetime.now() + timedelta(minutes=expires_in_minutes)).strftime('%Y-%m-%d %H:%M:%S')

        conn = get_db()
        conn.execute("""
            UPDATE users 
            SET verification_otp_hash = ?, otp_expires_at = ?, otp_attempts = 0, otp_last_sent_at = datetime('now')
            WHERE id = ?
        """, (otp_hash, expires_at, user_id))
        conn.commit()
        conn.close()
        return otp_code

    @staticmethod
    def can_resend_verification_otp(user_id, cooldown_seconds=60):
        """Checks if enough time has passed to resend verification OTP."""
        user = UserModel.get_by_id(user_id)
        if not user or not user['otp_last_sent_at']:
            return True, 0
        last_sent = _parse_db_time(user['otp_last_sent_at'])
        if not last_sent:
            return True, 0
        elapsed = (datetime.now() - last_sent).total_seconds()
        if elapsed < cooldown_seconds:
            return False, int(cooldown_seconds - elapsed)
        return True, 0

    @staticmethod
    def verify_registration_otp(user_id, submitted_otp):
        """Verifies the submitted registration OTP."""
        user = UserModel.get_by_id(user_id)
        if not user:
            return False, "User account not found."
        if user['is_verified']:
            return True, "Account is already verified."
        if not user['verification_otp_hash']:
            return False, "No active verification request found. Please request a new OTP."

        attempts = user['otp_attempts'] or 0
        if attempts >= 5:
            return False, "Too many failed attempts. Please request a new verification code."

        if user['otp_expires_at']:
            expires_at = _parse_db_time(user['otp_expires_at'])
            if expires_at and datetime.now() > expires_at:
                return False, "Verification code has expired. Please request a new OTP."

        if not check_password_hash(user['verification_otp_hash'], str(submitted_otp).strip()):
            conn = get_db()
            conn.execute("UPDATE users SET otp_attempts = otp_attempts + 1 WHERE id = ?", (user_id,))
            conn.commit()
            conn.close()
            remaining = max(0, 4 - attempts)
            return False, f"Invalid verification code. {remaining} attempts remaining."

        # Success - mark user verified and clear OTP fields
        conn = get_db()
        conn.execute("""
            UPDATE users 
            SET is_verified = 1, verification_otp_hash = NULL, otp_expires_at = NULL, otp_attempts = 0
            WHERE id = ?
        """, (user_id,))
        conn.commit()
        conn.close()
        return True, "Email verified successfully! You can now log in."

    @staticmethod
    def set_password_reset_otp(email, expires_in_minutes=15, reset_code=None):
        """Generates and securely stores a password reset verification code."""
        user = UserModel.get_by_email(email)
        if not user:
            return None, None, "No account found with this email."

        if user['reset_last_sent_at']:
            last_sent = _parse_db_time(user['reset_last_sent_at'])
            if last_sent:
                elapsed = (datetime.now() - last_sent).total_seconds()
                if elapsed < 60:
                    return user, None, f"Please wait {int(60 - elapsed)} seconds before requesting another code."

        if reset_code is None:
            reset_code = UserModel.generate_otp()
        reset_hash = generate_password_hash(str(reset_code).strip())
        expires_at = (datetime.now() + timedelta(minutes=expires_in_minutes)).strftime('%Y-%m-%d %H:%M:%S')

        conn = get_db()
        conn.execute("""
            UPDATE users 
            SET reset_token_hash = ?, reset_expires_at = ?, reset_attempts = 0, reset_last_sent_at = datetime('now')
            WHERE id = ?
        """, (reset_hash, expires_at, user['id']))
        conn.commit()
        conn.close()
        return user, reset_code, None

    @staticmethod
    def verify_and_reset_password(email, submitted_code, new_password):
        """Verifies the reset code and updates the user's password."""
        user = UserModel.get_by_email(email)
        if not user:
            return False, "No account found with this email."
        if not user['reset_token_hash']:
            return False, "No active password reset request. Please request a new code."

        attempts = user['reset_attempts'] or 0
        if attempts >= 5:
            return False, "Too many failed attempts. Please request a new password reset code."

        if user['reset_expires_at']:
            expires_at = _parse_db_time(user['reset_expires_at'])
            if expires_at and datetime.now() > expires_at:
                return False, "Password reset code has expired. Please request a new code."

        if not check_password_hash(user['reset_token_hash'], str(submitted_code).strip()):
            conn = get_db()
            conn.execute("UPDATE users SET reset_attempts = reset_attempts + 1 WHERE id = ?", (user['id'],))
            conn.commit()
            conn.close()
            remaining = max(0, 4 - attempts)
            return False, f"Invalid reset verification code. {remaining} attempts remaining."

        if len(new_password) < 6:
            return False, "Password must be at least 6 characters long."

        new_hash = generate_password_hash(new_password)
        conn = get_db()
        conn.execute("""
            UPDATE users 
            SET password_hash = ?, reset_token_hash = NULL, reset_expires_at = NULL, reset_attempts = 0
            WHERE id = ?
        """, (new_hash, user['id']))
        conn.commit()
        conn.close()
        return True, "Password reset successful! You can now log in with your new password."

# ==========================================
# SUBJECT & ENROLMENT OPERATIONS (CLASSROOMS)
# ==========================================
class SubjectModel:
    @staticmethod
    def create_subject(teacher_id, code, name, department, description="", academic_year="1st Year"):
        conn = get_db()
        cursor = conn.cursor()
        
        # Ensure unique code
        while True:
            enrolment_code = generate_enrolment_code(code)
            existing = cursor.execute("SELECT id FROM subjects WHERE enrolment_code = ?", (enrolment_code,)).fetchone()
            if not existing:
                break

        cursor.execute("""
            INSERT INTO subjects (teacher_id, code, name, enrolment_code, description, department, academic_year)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (teacher_id, code.strip().upper(), name.strip(), enrolment_code, description.strip(), department.strip(), (academic_year or "1st Year").strip()))
        conn.commit()
        subj_id = cursor.lastrowid
        conn.close()
        return subj_id, enrolment_code

    @staticmethod
    def get_by_id(subject_id):
        conn = get_db()
        subject = conn.execute("""
            SELECT s.*, u.name as teacher_name, u.email as teacher_email, u.department as teacher_department
            FROM subjects s
            JOIN users u ON s.teacher_id = u.id
            WHERE s.id = ?
        """, (subject_id,)).fetchone()
        conn.close()
        return subject

    @staticmethod
    def get_by_enrolment_code(code):
        if not code:
            return None
        conn = get_db()
        clean_code = str(code).strip().upper().replace(' ', '')
        clean_no_hyphen = clean_code.replace('-', '')
        subject = conn.execute("""
            SELECT s.*, u.name as teacher_name, u.email as teacher_email
            FROM subjects s
            JOIN users u ON s.teacher_id = u.id
            WHERE UPPER(s.enrolment_code) = ? 
               OR UPPER(REPLACE(s.enrolment_code, '-', '')) = ?
               OR UPPER(s.code) = ?
        """, (clean_code, clean_no_hyphen, clean_code)).fetchone()
        conn.close()
        return subject

    @staticmethod
    def get_by_code(code):
        if not code:
            return None
        conn = get_db()
        clean_code = str(code).strip().upper()
        subject = conn.execute("""
            SELECT s.*, u.name as teacher_name, u.email as teacher_email
            FROM subjects s
            JOIN users u ON s.teacher_id = u.id
            WHERE UPPER(s.code) = ? OR UPPER(s.enrolment_code) = ?
        """, (clean_code, clean_code)).fetchone()
        conn.close()
        return subject

    @staticmethod
    def get_teacher_subjects(teacher_id):
        conn = get_db()
        subjects = conn.execute("""
            SELECT s.*, 
                   COUNT(DISTINCT e.student_id) as student_count,
                   COUNT(DISTINCT m.id) as material_count,
                   COUNT(DISTINCT a.id) as assignment_count,
                   COUNT(DISTINCT q.id) as quiz_count,
                   (
                       SELECT ROUND(AVG(qa.score_percentage), 1)
                       FROM quiz_attempts qa
                       JOIN quizzes q2 ON qa.quiz_id = q2.id
                       WHERE q2.subject_id = s.id
                   ) as avg_quiz_score
            FROM subjects s
            LEFT JOIN enrolments e ON s.id = e.subject_id
            LEFT JOIN study_materials m ON s.id = m.subject_id
            LEFT JOIN assignments a ON s.id = a.subject_id
            LEFT JOIN quizzes q ON s.id = q.subject_id
            WHERE s.teacher_id = ?
            GROUP BY s.id
            ORDER BY s.created_at DESC
        """, (teacher_id,)).fetchall()
        conn.close()
        return subjects

    @staticmethod
    def get_teacher_classrooms(teacher_id):
        return SubjectModel.get_teacher_subjects(teacher_id)

    @staticmethod
    def get_student_subjects(student_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        subjects = conn.execute("""
            SELECT s.*, u.name as teacher_name, u.email as teacher_email, e.enrolled_at,
                   COUNT(DISTINCT m.id) as material_count,
                   COUNT(DISTINCT a.id) as assignment_count,
                   COUNT(DISTINCT q.id) as quiz_count,
                   (
                       SELECT COUNT(a2.id) 
                       FROM assignments a2 
                       LEFT JOIN assignment_submissions sub ON a2.id = sub.assignment_id AND sub.student_id = ?
                       WHERE a2.subject_id = s.id AND (sub.status IS NULL OR sub.status != 'completed')
                   ) as pending_assignments_count,
                   (
                       SELECT ROUND(AVG(qa.score_percentage), 1)
                       FROM quiz_attempts qa
                       JOIN quizzes q2 ON qa.quiz_id = q2.id
                       WHERE q2.subject_id = s.id AND qa.student_id = ?
                   ) as my_avg_score
            FROM enrolments e
            JOIN subjects s ON e.subject_id = s.id
            JOIN users u ON s.teacher_id = u.id
            LEFT JOIN study_materials m ON s.id = m.subject_id
            LEFT JOIN assignments a ON s.id = a.subject_id
            LEFT JOIN quizzes q ON s.id = q.subject_id
            WHERE e.student_id = ?
            GROUP BY s.id
            ORDER BY e.enrolled_at DESC
        """, (student_id, student_id, student_id)).fetchall()
        conn.close()
        return subjects

    @staticmethod
    def get_student_classrooms(student_id):
        return SubjectModel.get_student_subjects(student_id)

    @staticmethod
    def enroll_student(student_id, enrolment_code):
        conn = get_db()
        cursor = conn.cursor()
        raw_code = str(enrolment_code or '').strip()
        clean_code = raw_code.upper().replace(' ', '')
        if not clean_code:
            conn.close()
            return False, "Please enter a class enrolment code."

        clean_no_hyphen = clean_code.replace('-', '')
        subject = cursor.execute("""
            SELECT id, name, code, enrolment_code FROM subjects 
            WHERE UPPER(enrolment_code) = ? 
               OR UPPER(code) = ? 
               OR UPPER(REPLACE(enrolment_code, '-', '')) = ?
               OR UPPER(enrolment_code) = ?
        """, (clean_code, clean_code, clean_no_hyphen, clean_no_hyphen)).fetchone()
        
        if not subject:
            conn.close()
            return False, "No class found with this code."
        
        # Check if already enrolled
        existing = cursor.execute("SELECT id FROM enrolments WHERE student_id = ? AND subject_id = ?", (student_id, subject['id'])).fetchone()
        if existing:
            conn.close()
            return False, "You are already enrolled in this class."

        try:
            cursor.execute("INSERT INTO enrolments (student_id, subject_id) VALUES (?, ?)", (student_id, subject['id']))
            conn.commit()
            conn.close()
            return True, "Successfully enrolled in the class!"
        except Exception:
            conn.close()
            return False, "Something went wrong during enrolment. Please try again."

    @staticmethod
    def is_student_enrolled(student_id, subject_id):
        conn = get_db()
        row = conn.execute("SELECT id FROM enrolments WHERE student_id = ? AND subject_id = ?", (student_id, subject_id)).fetchone()
        conn.close()
        return bool(row)

    @staticmethod
    def get_enrolled_students(subject_id):
        conn = get_db()
        students = conn.execute("""
            SELECT u.id, u.name, u.email, u.identifier, u.department, u.year_of_study, u.semester, e.enrolled_at,
                   (
                       SELECT ROUND(AVG(qa.score_percentage), 1)
                       FROM quiz_attempts qa
                       JOIN quizzes q ON qa.quiz_id = q.id
                       WHERE qa.student_id = u.id AND q.subject_id = ?
                   ) as quiz_avg,
                   (
                       SELECT COUNT(qa.id)
                       FROM quiz_attempts qa
                       JOIN quizzes q ON qa.quiz_id = q.id
                       WHERE qa.student_id = u.id AND q.subject_id = ?
                   ) as quizzes_taken,
                   (
                       SELECT COUNT(sub.id)
                       FROM assignment_submissions sub
                       JOIN assignments a ON sub.assignment_id = a.id
                       WHERE sub.student_id = u.id AND a.subject_id = ? AND sub.status = 'completed'
                   ) as assignments_completed
            FROM enrolments e
            JOIN users u ON e.student_id = u.id
            WHERE e.subject_id = ?
            ORDER BY u.name ASC
        """, (subject_id, subject_id, subject_id, subject_id)).fetchall()
        conn.close()
        return students

    @staticmethod
    def update_subject(subject_id, teacher_id, code, name, department, description, academic_year=None):
        conn = get_db()
        if academic_year:
            conn.execute("""
                UPDATE subjects
                SET code = ?, name = ?, department = ?, description = ?, academic_year = ?
                WHERE id = ? AND teacher_id = ?
            """, (code.strip().upper(), name.strip(), department.strip(), description.strip(), academic_year.strip(), subject_id, teacher_id))
        else:
            conn.execute("""
                UPDATE subjects
                SET code = ?, name = ?, department = ?, description = ?
                WHERE id = ? AND teacher_id = ?
            """, (code.strip().upper(), name.strip(), department.strip(), description.strip(), subject_id, teacher_id))
        conn.commit()
        conn.close()

    @staticmethod
    def delete_subject(subject_id, teacher_id):
        conn = get_db()
        conn.execute("DELETE FROM subjects WHERE id = ? AND teacher_id = ?", (subject_id, teacher_id))
        conn.commit()
        conn.close()

# ==========================================
# STUDY MATERIAL OPERATIONS
# ==========================================
class MaterialModel:
    @staticmethod
    def create_material(subject_id, teacher_id, title, topic, description, material_type, file_path=None, original_filename=None, file_type=None, external_link=None):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO study_materials (subject_id, teacher_id, title, topic, description, material_type, file_path, original_filename, file_type, external_link)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (subject_id, teacher_id, title.strip(), topic.strip(), description.strip(), material_type, file_path, original_filename, file_type, external_link))
        conn.commit()
        mat_id = cursor.lastrowid
        conn.close()
        return mat_id

    @staticmethod
    def get_by_id(material_id):
        conn = get_db()
        mat = conn.execute("""
            SELECT m.*, s.name as subject_name, s.code as subject_code
            FROM study_materials m
            JOIN subjects s ON m.subject_id = s.id
            WHERE m.id = ?
        """, (material_id,)).fetchone()
        conn.close()
        return mat

    @staticmethod
    def get_by_subject(subject_id):
        conn = get_db()
        materials = conn.execute("""
            SELECT m.*, u.name as teacher_name
            FROM study_materials m
            JOIN users u ON m.teacher_id = u.id
            WHERE m.subject_id = ?
            ORDER BY m.topic ASC, m.created_at DESC
        """, (subject_id,)).fetchall()
        conn.close()
        return materials

    @staticmethod
    def get_student_materials(student_id):
        conn = get_db()
        materials = conn.execute("""
            SELECT m.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name
            FROM study_materials m
            JOIN subjects s ON m.subject_id = s.id
            JOIN users u ON m.teacher_id = u.id
            JOIN enrolments e ON s.id = e.subject_id
            WHERE e.student_id = ?
            ORDER BY s.name ASC, m.topic ASC, m.created_at DESC
        """, (student_id,)).fetchall()
        conn.close()
        return materials

    @staticmethod
    def get_teacher_materials(teacher_id):
        conn = get_db()
        materials = conn.execute("""
            SELECT m.*, s.name as subject_name, s.code as subject_code
            FROM study_materials m
            JOIN subjects s ON m.subject_id = s.id
            WHERE m.teacher_id = ?
            ORDER BY m.created_at DESC
        """, (teacher_id,)).fetchall()
        conn.close()
        return materials

    @staticmethod
    def delete_material(material_id, teacher_id):
        conn = get_db()
        mat = conn.execute("SELECT file_path FROM study_materials WHERE id = ? AND teacher_id = ?", (material_id, teacher_id)).fetchone()
        if mat and mat['file_path'] and os.path.exists(mat['file_path']):
            try:
                os.remove(mat['file_path'])
            except Exception:
                pass
        conn.execute("DELETE FROM study_materials WHERE id = ? AND teacher_id = ?", (material_id, teacher_id))
        conn.commit()
        conn.close()

# ==========================================
# ANNOUNCEMENT OPERATIONS
# ==========================================
class AnnouncementModel:
    @staticmethod
    def create_announcement(subject_id, teacher_id, title, message):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO announcements (subject_id, teacher_id, title, message)
            VALUES (?, ?, ?, ?)
        """, (subject_id, teacher_id, title.strip(), message.strip()))
        conn.commit()
        ann_id = cursor.lastrowid
        conn.close()
        return ann_id

    @staticmethod
    def get_by_subject(subject_id):
        conn = get_db()
        announcements = conn.execute("""
            SELECT a.*, u.name as teacher_name
            FROM announcements a
            JOIN users u ON a.teacher_id = u.id
            WHERE a.subject_id = ?
            ORDER BY a.created_at DESC
        """, (subject_id,)).fetchall()
        conn.close()
        return announcements

    @staticmethod
    def delete_announcement(announcement_id, teacher_id):
        conn = get_db()
        conn.execute("DELETE FROM announcements WHERE id = ? AND teacher_id = ?", (announcement_id, teacher_id))
        conn.commit()
        conn.close()

    @staticmethod
    def get_student_announcements(student_id, limit=5):
        conn = get_db()
        announcements = conn.execute("""
            SELECT a.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name
            FROM announcements a
            JOIN subjects s ON a.subject_id = s.id
            JOIN users u ON a.teacher_id = u.id
            JOIN enrolments e ON s.id = e.subject_id
            WHERE e.student_id = ?
            ORDER BY a.created_at DESC
            LIMIT ?
        """, (student_id, limit)).fetchall()
        conn.close()
        return announcements

# ==========================================
# ASSIGNMENT OPERATIONS
# ==========================================
class AssignmentModel:
    @staticmethod
    def create_assignment(subject_id, teacher_id, title, topic, description, due_date, priority="Medium", instructions="", attachment_url=None):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO assignments (subject_id, teacher_id, title, topic, description, due_date, priority, instructions, attachment_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (subject_id, teacher_id, title.strip(), topic.strip(), description.strip(), due_date, priority or "Medium", instructions or "", attachment_url))
        conn.commit()
        assign_id = cursor.lastrowid
        conn.close()
        return assign_id

    @staticmethod
    def get_by_id(assignment_id):
        conn = get_db()
        assign = conn.execute("""
            SELECT a.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            JOIN users u ON a.teacher_id = u.id
            WHERE a.id = ?
        """, (assignment_id,)).fetchone()
        conn.close()
        return assign

    @staticmethod
    def get_student_assignments(student_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        assignments = conn.execute("""
            SELECT a.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name,
                   sub.status as submission_status, sub.completed_at
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            JOIN users u ON a.teacher_id = u.id
            JOIN enrolments e ON s.id = e.subject_id
            LEFT JOIN assignment_submissions sub ON a.id = sub.assignment_id AND sub.student_id = ?
            WHERE e.student_id = ?
            ORDER BY a.due_date ASC
        """, (student_id, student_id)).fetchall()
        conn.close()
        
        result = []
        for a in assignments:
            item = dict(a)
            is_completed = item.get('submission_status') == 'completed'
            item['is_completed'] = is_completed
            if is_completed:
                item['calculated_status'] = 'completed'
            elif item['due_date'] < today:
                item['calculated_status'] = 'overdue'
            else:
                item['calculated_status'] = 'pending'
            result.append(item)
        return result

    @staticmethod
    def toggle_student_completion(assignment_id, student_id, mark_completed=True):
        conn = get_db()
        cursor = conn.cursor()
        if mark_completed:
            cursor.execute("""
                INSERT INTO assignment_submissions (assignment_id, student_id, status, completed_at)
                VALUES (?, ?, 'completed', CURRENT_TIMESTAMP)
                ON CONFLICT(assignment_id, student_id) DO UPDATE SET status = 'completed', completed_at = CURRENT_TIMESTAMP
            """, (assignment_id, student_id))
        else:
            cursor.execute("""
                DELETE FROM assignment_submissions WHERE assignment_id = ? AND student_id = ?
            """, (assignment_id, student_id))
        conn.commit()
        conn.close()

    @staticmethod
    def get_teacher_assignments(teacher_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        assignments = conn.execute("""
            SELECT a.*, s.name as subject_name, s.code as subject_code,
                   (SELECT COUNT(*) FROM enrolments e WHERE e.subject_id = a.subject_id) as enrolled_count,
                   (SELECT COUNT(*) FROM assignment_submissions sub WHERE sub.assignment_id = a.id AND sub.status = 'completed') as completed_count
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            WHERE a.teacher_id = ?
            ORDER BY a.due_date ASC
        """, (teacher_id,)).fetchall()
        conn.close()
        return assignments

    @staticmethod
    def get_assignment_submissions_detail(assignment_id, teacher_id):
        conn = get_db()
        assign = conn.execute("SELECT * FROM assignments WHERE id = ? AND teacher_id = ?", (assignment_id, teacher_id)).fetchone()
        if not assign:
            conn.close()
            return None, []
        
        rows = conn.execute("""
            SELECT u.id as student_id, u.name, u.email, u.identifier, u.department, u.year_of_study,
                   sub.status, sub.completed_at
            FROM enrolments e
            JOIN users u ON e.student_id = u.id
            LEFT JOIN assignment_submissions sub ON sub.assignment_id = ? AND sub.student_id = u.id
            WHERE e.subject_id = ?
            ORDER BY u.name ASC
        """, (assignment_id, assign['subject_id'])).fetchall()
        conn.close()
        return assign, rows

    @staticmethod
    def delete_assignment(assignment_id, teacher_id):
        conn = get_db()
        conn.execute("DELETE FROM assignments WHERE id = ? AND teacher_id = ?", (assignment_id, teacher_id))
        conn.commit()
        conn.close()

    @staticmethod
    def get_by_subject(subject_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        assignments = conn.execute("""
            SELECT a.*, s.name as subject_name, s.code as subject_code,
                   (SELECT COUNT(*) FROM enrolments e WHERE e.subject_id = a.subject_id) as enrolled_count,
                   (SELECT COUNT(*) FROM assignment_submissions sub WHERE sub.assignment_id = a.id AND sub.status = 'completed') as completed_count
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            WHERE a.subject_id = ?
            ORDER BY a.due_date ASC
        """, (subject_id,)).fetchall()
        conn.close()
        return assignments

    @staticmethod
    def get_subject_assignments_for_student(subject_id, student_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        assignments = conn.execute("""
            SELECT a.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name,
                   sub.status as submission_status, sub.completed_at
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            JOIN users u ON a.teacher_id = u.id
            LEFT JOIN assignment_submissions sub ON a.id = sub.assignment_id AND sub.student_id = ?
            WHERE a.subject_id = ?
            ORDER BY a.due_date ASC
        """, (student_id, subject_id)).fetchall()
        conn.close()
        
        result = []
        for a in assignments:
            item = dict(a)
            is_completed = item.get('submission_status') == 'completed'
            item['is_completed'] = is_completed
            if is_completed:
                item['calculated_status'] = 'completed'
            elif item['due_date'] < today:
                item['calculated_status'] = 'overdue'
            else:
                item['calculated_status'] = 'pending'
            result.append(item)
        return result

# ==========================================
# TOPIC OPERATIONS
# ==========================================
class TopicModel:
    @staticmethod
    def add_topic(subject_id, name, description=""):
        conn = get_db()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO topics (subject_id, name, description)
                VALUES (?, ?, ?)
                ON CONFLICT(subject_id, name) DO NOTHING
            """, (subject_id, name.strip(), description.strip()))
            conn.commit()
            tid = cursor.lastrowid
        except Exception:
            tid = None
        finally:
            conn.close()
        return tid

    @staticmethod
    def get_by_subject(subject_id):
        conn = get_db()
        topics = conn.execute("SELECT * FROM topics WHERE subject_id = ? ORDER BY id ASC", (subject_id,)).fetchall()
        conn.close()
        return topics

    @staticmethod
    def get_all_topics():
        conn = get_db()
        topics = conn.execute("SELECT t.*, s.name as subject_name FROM topics t JOIN subjects s ON t.subject_id = s.id ORDER BY s.name ASC, t.id ASC").fetchall()
        conn.close()
        return topics

# ==========================================
# QUIZ & TEST OPERATIONS
# ==========================================
class QuizModel:
    @staticmethod
    def create_quiz(subject_id, teacher_id, title, topic, description, duration_minutes=15, is_published=1, difficulty='Medium', quiz_type='teacher'):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO quizzes (subject_id, teacher_id, title, topic, description, duration_minutes, is_published, difficulty, quiz_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (subject_id, teacher_id, title.strip(), topic.strip(), description.strip(), int(duration_minutes), int(is_published), difficulty, quiz_type))
        conn.commit()
        quiz_id = cursor.lastrowid
        conn.close()
        return quiz_id

    @staticmethod
    def create_ai_quiz(student_id, subject_id, topic, difficulty="Medium", question_count=5):
        from ai_quiz import AIQuizEngine
        return AIQuizEngine.create_ai_practice_quiz(student_id, subject_id, topic, difficulty, question_count)

    @staticmethod
    def get_by_id(quiz_id):
        conn = get_db()
        quiz = conn.execute("""
            SELECT q.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            JOIN users u ON q.teacher_id = u.id
            WHERE q.id = ?
        """, (quiz_id,)).fetchone()
        conn.close()
        return quiz

    @staticmethod
    def get_teacher_quizzes(teacher_id):
        conn = get_db()
        quizzes = conn.execute("""
            SELECT q.*, s.name as subject_name, s.code as subject_code,
                   (SELECT COUNT(*) FROM quiz_questions qq WHERE qq.quiz_id = q.id) as question_count,
                   (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.quiz_id = q.id) as attempt_count,
                   (SELECT AVG(qa.score_percentage) FROM quiz_attempts qa WHERE qa.quiz_id = q.id) as avg_score
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            WHERE q.teacher_id = ?
            ORDER BY q.created_at DESC
        """, (teacher_id,)).fetchall()
        conn.close()
        return quizzes

    @staticmethod
    def get_student_quizzes(student_id):
        conn = get_db()
        quizzes = conn.execute("""
            SELECT q.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name,
                   (SELECT COUNT(*) FROM quiz_questions qq WHERE qq.quiz_id = q.id) as question_count,
                   (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ?) as student_attempts_count,
                   (SELECT MAX(qa.score_percentage) FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ?) as best_score
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            JOIN users u ON q.teacher_id = u.id
            JOIN enrolments e ON s.id = e.subject_id
            WHERE e.student_id = ? AND q.is_published = 1
            ORDER BY q.created_at DESC
        """, (student_id, student_id, student_id)).fetchall()
        conn.close()
        return quizzes

    @staticmethod
    def add_question(quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation="", difficulty="Medium"):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO quiz_questions (quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (quiz_id, topic.strip(), question_text.strip(), option_a.strip(), option_b.strip(), option_c.strip(), option_d.strip(), correct_option.strip().upper(), explanation.strip(), difficulty.capitalize()))
        conn.commit()
        qid = cursor.lastrowid
        conn.close()
        return qid

    @staticmethod
    def get_questions(quiz_id):
        conn = get_db()
        questions = conn.execute("""
            SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id ASC
        """, (quiz_id,)).fetchall()
        conn.close()
        return questions

    @staticmethod
    def delete_question(question_id, quiz_id, teacher_id):
        conn = get_db()
        # Verify ownership
        quiz = conn.execute("SELECT id FROM quizzes WHERE id = ? AND teacher_id = ?", (quiz_id, teacher_id)).fetchone()
        if quiz:
            conn.execute("DELETE FROM quiz_questions WHERE id = ? AND quiz_id = ?", (question_id, quiz_id))
            conn.commit()
        conn.close()

    @staticmethod
    def delete_quiz(quiz_id, teacher_id):
        conn = get_db()
        conn.execute("DELETE FROM quizzes WHERE id = ? AND teacher_id = ?", (quiz_id, teacher_id))
        conn.commit()
        conn.close()

    @staticmethod
    def create_teacher_ai_quiz(teacher_id, subject_id, topic, difficulty="Medium", question_count=5, title=None, duration_minutes=15):
        from ai_quiz import AIQuizEngine
        conn = get_db()
        cursor = conn.cursor()
        subj = cursor.execute("SELECT name, code FROM subjects WHERE id = ?", (subject_id,)).fetchone()
        subj_name = subj['name'] if subj else 'Classroom'
        if not title:
            title = f"{subj_name}: {topic} ({difficulty} Quiz)"
        description = f"AI-generated quiz on '{topic}' for {subj_name}. Prepared by Faculty."
        
        # MUST NOT auto-publish: is_published = 0
        cursor.execute("""
            INSERT INTO quizzes (subject_id, teacher_id, title, topic, description, duration_minutes, is_published, difficulty, quiz_type)
            VALUES (?, ?, ?, ?, ?, ?, 0, ?, 'ai_teacher')
        """, (subject_id, teacher_id, title.strip(), topic.strip(), description.strip(), int(duration_minutes or 15), difficulty.capitalize()))
        quiz_id = cursor.lastrowid

        questions = AIQuizEngine.generate_questions(topic, difficulty=difficulty, count=int(question_count or 5))
        for q in questions:
            cursor.execute("""
                INSERT INTO quiz_questions (quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (quiz_id, topic, q['question'], q['options']['A'], q['options']['B'], q['options']['C'], q['options']['D'], q['correct'], q.get('explanation', ''), difficulty.capitalize()))

        conn.commit()
        conn.close()
        return quiz_id, None

    @staticmethod
    def publish_quiz(quiz_id, teacher_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE quizzes SET is_published = 1 WHERE id = ? AND teacher_id = ?", (quiz_id, teacher_id))
        conn.commit()
        conn.close()

    @staticmethod
    def update_question(question_id, quiz_id, teacher_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation="", difficulty="Medium"):
        conn = get_db()
        cursor = conn.cursor()
        quiz = cursor.execute("SELECT id FROM quizzes WHERE id = ? AND teacher_id = ?", (quiz_id, teacher_id)).fetchone()
        if not quiz:
            conn.close()
            return False
        cursor.execute("""
            UPDATE quiz_questions 
            SET question_text = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_option = ?, explanation = ?, difficulty = ?
            WHERE id = ? AND quiz_id = ?
        """, (question_text.strip(), option_a.strip(), option_b.strip(), option_c.strip(), option_d.strip(), correct_option.strip().upper(), explanation.strip(), difficulty.capitalize(), question_id, quiz_id))
        conn.commit()
        conn.close()
        return True

    @staticmethod
    def get_by_subject(subject_id):
        conn = get_db()
        quizzes = conn.execute("""
            SELECT q.*, s.name as subject_name, s.code as subject_code,
                   (SELECT COUNT(*) FROM quiz_questions qq WHERE qq.quiz_id = q.id) as question_count,
                   (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.quiz_id = q.id) as attempt_count,
                   (SELECT ROUND(AVG(qa.score_percentage), 1) FROM quiz_attempts qa WHERE qa.quiz_id = q.id) as avg_score
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            WHERE q.subject_id = ?
            ORDER BY q.created_at DESC
        """, (subject_id,)).fetchall()
        conn.close()
        return quizzes

    @staticmethod
    def get_subject_quizzes_for_student(subject_id, student_id):
        conn = get_db()
        quizzes = conn.execute("""
            SELECT q.*, s.name as subject_name, s.code as subject_code, u.name as teacher_name,
                   (SELECT COUNT(*) FROM quiz_questions qq WHERE qq.quiz_id = q.id) as question_count,
                   (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ?) as student_attempts_count,
                   (SELECT MAX(qa.score_percentage) FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ?) as best_score
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            JOIN users u ON q.teacher_id = u.id
            WHERE q.subject_id = ? AND q.is_published = 1
            ORDER BY q.created_at DESC
        """, (student_id, student_id, subject_id)).fetchall()
        conn.close()
        return quizzes

    @staticmethod
    def evaluate_and_record_attempt(quiz_id, student_id, submitted_answers, time_taken_seconds=0):
        """
        submitted_answers: dict mapping question_id (int or str) -> selected_option ('A', 'B', 'C', 'D')
        Compares with correct_option, computes score, saves attempt and per-question topic results in SQLite.
        Automatically triggers AI topic analysis, study recommendations, and adaptive timetable update.
        """
        conn = get_db()
        cursor = conn.cursor()
        
        quiz_row = cursor.execute("SELECT * FROM quizzes WHERE id = ?", (quiz_id,)).fetchone()
        if not quiz_row:
            conn.close()
            return None, "Quiz not found."

        quiz_type = quiz_row['quiz_type'] if 'quiz_type' in quiz_row.keys() else 'teacher'

        questions = cursor.execute("SELECT * FROM quiz_questions WHERE quiz_id = ?", (quiz_id,)).fetchall()
        if not questions:
            conn.close()
            return None, "This quiz has no questions."

        total_questions = len(questions)
        correct_count = 0
        detailed_answers = []

        for q in questions:
            qid_str = str(q['id'])
            selected = submitted_answers.get(qid_str, '').strip().upper()
            is_correct = 1 if (selected == q['correct_option']) else 0
            if is_correct:
                correct_count += 1
            detailed_answers.append({
                'question_id': q['id'],
                'topic': q['topic'],
                'selected_option': selected,
                'correct_option': q['correct_option'],
                'is_correct': is_correct,
                'question_text': q['question_text'],
                'option_a': q['option_a'],
                'option_b': q['option_b'],
                'option_c': q['option_c'],
                'option_d': q['option_d'],
                'explanation': q['explanation']
            })

        score_percentage = round((correct_count / total_questions) * 100.0, 1)

        cursor.execute("""
            INSERT INTO quiz_attempts (quiz_id, student_id, total_questions, correct_answers, score_percentage, time_taken_seconds, quiz_type)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (quiz_id, student_id, total_questions, correct_count, score_percentage, int(time_taken_seconds or 0), quiz_type))
        attempt_id = cursor.lastrowid

        for ans in detailed_answers:
            cursor.execute("""
                INSERT INTO quiz_attempt_answers (attempt_id, question_id, topic, selected_option, correct_option, is_correct)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (attempt_id, ans['question_id'], ans['topic'], ans['selected_option'], ans['correct_option'], ans['is_correct']))

        conn.commit()
        conn.close()

        # Automatic post-quiz intelligence triggers
        recomms = []
        adaptation_info = None
        try:
            from ai_recommendations import RecommendationEngine
            recomms = RecommendationEngine.generate_recommendations(student_id)
        except Exception as e:
            print("Error generating recommendations:", e)

        try:
            from adaptive_timetable import AdaptiveTimetableEngine
            success, msg, adaptation_info = AdaptiveTimetableEngine.adapt_timetable(
                student_id,
                trigger_reason=f"Automatic adaptation after submitting quiz '{quiz_row['title']}' (Score: {score_percentage}%)"
            )
        except Exception as e:
            print("Error updating adaptive timetable:", e)

        return {
            'attempt_id': attempt_id,
            'total_questions': total_questions,
            'correct_answers': correct_count,
            'score_percentage': score_percentage,
            'details': detailed_answers,
            'recommendations': recomms,
            'adaptation_info': adaptation_info
        }, None

    @staticmethod
    def get_student_attempts(student_id):
        conn = get_db()
        attempts = conn.execute("""
            SELECT qa.*, q.title as quiz_title, q.topic as quiz_topic, s.name as subject_name, s.code as subject_code
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ?
            ORDER BY qa.attempted_at DESC
        """, (student_id,)).fetchall()
        conn.close()
        return attempts

    @staticmethod
    def get_attempt_detail(attempt_id):
        conn = get_db()
        attempt = conn.execute("""
            SELECT qa.*, q.title as quiz_title, q.topic as quiz_topic, q.duration_minutes,
                   s.name as subject_name, s.code as subject_code, u.name as student_name, u.identifier as student_identifier
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            JOIN users u ON qa.student_id = u.id
            WHERE qa.id = ?
        """, (attempt_id,)).fetchone()
        
        if not attempt:
            conn.close()
            return None, []

        answers = conn.execute("""
            SELECT qaa.*, qq.question_text, qq.option_a, qq.option_b, qq.option_c, qq.option_d, qq.explanation
            FROM quiz_attempt_answers qaa
            JOIN quiz_questions qq ON qaa.question_id = qq.id
            WHERE qaa.attempt_id = ?
            ORDER BY qq.id ASC
        """, (attempt_id,)).fetchall()
        conn.close()
        return attempt, answers

# ==========================================
# TIMETABLE OPERATIONS
# ==========================================
class TimetableModel:
    @staticmethod
    def get_or_create(student_id):
        conn = get_db()
        cursor = conn.cursor()
        tt = cursor.execute("SELECT * FROM timetables WHERE student_id = ?", (student_id,)).fetchone()
        if not tt:
            cursor.execute("""
                INSERT INTO timetables (student_id, title, daily_study_hours, preferred_start_time, preferred_end_time)
                VALUES (?, 'My Study Schedule', 3.0, '18:00', '21:30')
            """, (student_id,))
            conn.commit()
            tt = cursor.execute("SELECT * FROM timetables WHERE student_id = ?", (student_id,)).fetchone()
        conn.close()
        return tt

    @staticmethod
    def update_settings(student_id, daily_study_hours, preferred_start_time, preferred_end_time, exam_date=None):
        conn = get_db()
        conn.execute("""
            UPDATE timetables
            SET daily_study_hours = ?, preferred_start_time = ?, preferred_end_time = ?, exam_date = ?, updated_at = CURRENT_TIMESTAMP
            WHERE student_id = ?
        """, (float(daily_study_hours), preferred_start_time, preferred_end_time, exam_date, student_id))
        conn.commit()
        conn.close()

    @staticmethod
    def get_student_sessions(student_id):
        conn = get_db()
        sessions = conn.execute("""
            SELECT ts.*, s.code as subject_code
            FROM timetable_sessions ts
            LEFT JOIN subjects s ON ts.subject_id = s.id
            WHERE ts.student_id = ?
            ORDER BY 
                CASE ts.day_of_week
                    WHEN 'Monday' THEN 1
                    WHEN 'Tuesday' THEN 2
                    WHEN 'Wednesday' THEN 3
                    WHEN 'Thursday' THEN 4
                    WHEN 'Friday' THEN 5
                    WHEN 'Saturday' THEN 6
                    WHEN 'Sunday' THEN 7
                    ELSE 8
                END,
                ts.start_time ASC
        """, (student_id,)).fetchall()
        conn.close()
        return sessions

    @staticmethod
    def add_session(timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, session_type='study', priority='Normal'):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO timetable_sessions (timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, session_type, priority)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, int(duration_minutes), session_type, priority))
        conn.commit()
        sid = cursor.lastrowid
        conn.close()
        return sid

    @staticmethod
    def update_session(session_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, priority):
        conn = get_db()
        conn.execute("""
            UPDATE timetable_sessions
            SET subject_id = ?, subject_name = ?, topic = ?, day_of_week = ?, start_time = ?, end_time = ?, duration_minutes = ?, priority = ?
            WHERE id = ? AND student_id = ?
        """, (subject_id, subject_name, topic, day_of_week, start_time, end_time, int(duration_minutes), priority, session_id, student_id))
        conn.commit()
        conn.close()

    @staticmethod
    def delete_session(session_id, student_id):
        conn = get_db()
        conn.execute("DELETE FROM timetable_sessions WHERE id = ? AND student_id = ?", (session_id, student_id))
        conn.commit()
        conn.close()

    @staticmethod
    def toggle_session_completed(session_id, student_id):
        conn = get_db()
        row = conn.execute("SELECT is_completed FROM timetable_sessions WHERE id = ? AND student_id = ?", (session_id, student_id)).fetchone()
        if row:
            new_val = 0 if row['is_completed'] else 1
            conn.execute("UPDATE timetable_sessions SET is_completed = ? WHERE id = ? AND student_id = ?", (new_val, session_id, student_id))
            conn.commit()
        conn.close()

    @staticmethod
    def adapt_timetable(student_id, reason="Manual user regeneration"):
        from adaptive_timetable import AdaptiveTimetableEngine
        return AdaptiveTimetableEngine.adapt_timetable(student_id, trigger_reason=reason)

    @staticmethod
    def get_latest_adaptation(student_id):
        from adaptive_timetable import AdaptiveTimetableEngine
        return AdaptiveTimetableEngine.get_latest_adaptations(student_id)

    @staticmethod
    def get_version_history(student_id):
        conn = get_db()
        versions = conn.execute("""
            SELECT tv.*, 
                   (SELECT COUNT(*) FROM timetable_adaptations ta WHERE ta.version_id = tv.id) as adaptation_count
            FROM timetable_versions tv
            WHERE tv.student_id = ?
            ORDER BY tv.version_number DESC
        """, (student_id,)).fetchall()
        conn.close()
        return [dict(v) for v in versions]

    @staticmethod
    def generate_timetable_schedule(student_id, selected_subject_ids, daily_hours=3.0, start_time_str="18:00", exam_date=None):
        """
        Generates a balanced weekly timetable:
        - Splits daily study hours into ~45-50 min study sessions with 10-15 min breaks.
        - Rotates selected subjects fairly across Monday to Sunday.
        - Structured for Phase 2 AI-adaptive rebalancing.
        """
        conn = get_db()
        cursor = conn.cursor()
        
        # Get timetable ID
        tt = cursor.execute("SELECT id FROM timetables WHERE student_id = ?", (student_id,)).fetchone()
        if not tt:
            cursor.execute("INSERT INTO timetables (student_id) VALUES (?)", (student_id,))
            conn.commit()
            timetable_id = cursor.lastrowid
        else:
            timetable_id = tt['id']

        # Clear existing sessions for regeneration
        cursor.execute("DELETE FROM timetable_sessions WHERE student_id = ?", (student_id,))

        # Fetch subjects details and topics
        subjects = []
        if selected_subject_ids:
            placeholders = ','.join('?' for _ in selected_subject_ids)
            subjects = cursor.execute(f"SELECT id, name, code FROM subjects WHERE id IN ({placeholders})", selected_subject_ids).fetchall()

        if not subjects:
            # Fallback to all enrolled subjects
            subjects = cursor.execute("""
                SELECT s.id, s.name, s.code 
                FROM enrolments e 
                JOIN subjects s ON e.subject_id = s.id 
                WHERE e.student_id = ?
            """, (student_id,)).fetchall()

        if not subjects:
            conn.close()
            return False, "Please enrol in at least one subject before generating a timetable."

        # Fetch topics per subject from materials & quizzes
        subject_topics = {}
        for s in subjects:
            t_rows = cursor.execute("""
                SELECT DISTINCT topic FROM study_materials WHERE subject_id = ?
                UNION
                SELECT DISTINCT topic FROM quizzes WHERE subject_id = ?
            """, (s['id'], s['id'])).fetchall()
            topics = [r['topic'] for r in t_rows if r['topic']]
            if not topics:
                topics = ["General Concepts", "Core Theories", "Problem Solving", "Revision & Practice"]
            subject_topics[s['id']] = topics

        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        
        # Parse start time
        try:
            start_hour, start_minute = map(int, start_time_str.split(':'))
        except Exception:
            start_hour, start_minute = 18, 0

        # Number of sessions per day (e.g., 3 hours -> 3 study blocks of 50 min + 10 min break)
        blocks_per_day = max(1, min(6, int(round(daily_hours))))
        slot_duration = 50  # minutes
        break_duration = 10  # minutes

        subject_idx = 0
        topic_idx_map = {s['id']: 0 for s in subjects}

        for day in days:
            cur_time = datetime(2026, 1, 1, start_hour, start_minute)
            for b in range(blocks_per_day):
                curr_subject = subjects[subject_idx % len(subjects)]
                subject_idx += 1

                t_list = subject_topics[curr_subject['id']]
                t_idx = topic_idx_map[curr_subject['id']]
                topic_name = t_list[t_idx % len(t_list)]
                topic_idx_map[curr_subject['id']] += 1

                s_start = cur_time.strftime("%H:%M")
                cur_time += timedelta(minutes=slot_duration)
                s_end = cur_time.strftime("%H:%M")

                cursor.execute("""
                    INSERT INTO timetable_sessions (timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, session_type, priority)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'study', 'Normal')
                """, (timetable_id, student_id, curr_subject['id'], curr_subject['name'], topic_name, day, s_start, s_end, slot_duration))

                # Insert rest break if not last block of the day
                if b < blocks_per_day - 1:
                    b_start = cur_time.strftime("%H:%M")
                    cur_time += timedelta(minutes=break_duration)
                    b_end = cur_time.strftime("%H:%M")
                    cursor.execute("""
                        INSERT INTO timetable_sessions (timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, session_type, priority)
                        VALUES (?, ?, NULL, 'Rest Break', 'Refresh and hydrate', ?, ?, ?, ?, 'break', 'Low')
                    """, (timetable_id, student_id, day, b_start, b_end, break_duration))

        # Update timetable settings
        cursor.execute("""
            UPDATE timetables 
            SET daily_study_hours = ?, preferred_start_time = ?, exam_date = ?, updated_at = CURRENT_TIMESTAMP
            WHERE student_id = ?
        """, (daily_hours, start_time_str, exam_date, student_id))

        conn.commit()
        conn.close()
        return True, "Your personalized weekly study timetable has been generated successfully!"

# ==========================================
# STATS & PERFORMANCE REPORTING
# ==========================================
class StatsModel:
    @staticmethod
    def get_student_dashboard_stats(student_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        day_name = datetime.now().strftime("%A")

        # 1. Total enrolled subjects
        enrolled_count = conn.execute("SELECT COUNT(*) FROM enrolments WHERE student_id = ?", (student_id,)).fetchone()[0]

        # 2. Pending assignments
        pending_assignments = conn.execute("""
            SELECT COUNT(*) 
            FROM assignments a
            JOIN enrolments e ON a.subject_id = e.subject_id
            LEFT JOIN assignment_submissions s ON a.id = s.assignment_id AND s.student_id = ?
            WHERE e.student_id = ? AND (s.status IS NULL OR s.status != 'completed')
        """, (student_id, student_id)).fetchone()[0]

        # 3. Upcoming tests/quizzes available
        available_quizzes = conn.execute("""
            SELECT COUNT(*) 
            FROM quizzes q
            JOIN enrolments e ON q.subject_id = e.subject_id
            WHERE e.student_id = ? AND q.is_published = 1
        """, (student_id,)).fetchone()[0]

        # 4. Today's sessions
        today_sessions = conn.execute("""
            SELECT ts.*, s.code as subject_code
            FROM timetable_sessions ts
            LEFT JOIN subjects s ON ts.subject_id = s.id
            WHERE ts.student_id = ? AND ts.day_of_week = ?
            ORDER BY ts.start_time ASC
        """, (student_id, day_name)).fetchall()

        # 5. Recent quiz results
        recent_quizzes = conn.execute("""
            SELECT qa.*, q.title as quiz_title, q.topic as quiz_topic, s.name as subject_name
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ?
            ORDER BY qa.attempted_at DESC
            LIMIT 5
        """, (student_id,)).fetchall()

        # 6. Overall average quiz percentage
        avg_score_row = conn.execute("SELECT AVG(score_percentage) FROM quiz_attempts WHERE student_id = ?", (student_id,)).fetchone()[0]
        avg_score = round(avg_score_row, 1) if avg_score_row is not None else 0.0

        conn.close()
        return {
            'enrolled_count': enrolled_count,
            'pending_assignments': pending_assignments,
            'available_quizzes': available_quizzes,
            'today_sessions': today_sessions,
            'recent_quizzes': recent_quizzes,
            'avg_score': avg_score,
            'today_day_name': day_name
        }

    @staticmethod
    def get_students_needing_attention(teacher_id, subject_id=None):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Get all students enrolled in teacher's subjects
        sql = """
            SELECT DISTINCT u.id as student_id, u.name, u.email, u.identifier, u.department,
                            s.id as subject_id, s.name as subject_name
            FROM enrolments e
            JOIN subjects s ON e.subject_id = s.id
            JOIN users u ON e.student_id = u.id
            WHERE s.teacher_id = ?
        """
        params = [teacher_id]
        if subject_id:
            sql += " AND s.id = ?"
            params.append(subject_id)

        rows = conn.execute(sql, params).fetchall()
        attention_list = []

        for row in rows:
            sid = row['student_id']
            sub_id = row['subject_id']

            # 1. Check quiz average in this subject
            quiz_stats = conn.execute("""
                SELECT AVG(qa.score_percentage) as avg_score, COUNT(qa.id) as attempt_count
                FROM quiz_attempts qa
                JOIN quizzes q ON qa.quiz_id = q.id
                WHERE qa.student_id = ? AND q.subject_id = ?
            """, (sid, sub_id)).fetchone()

            avg_score = quiz_stats['avg_score'] if quiz_stats and quiz_stats['avg_score'] is not None else None
            attempt_count = quiz_stats['attempt_count'] if quiz_stats else 0

            # 2. Check overdue assignments
            overdue_count = conn.execute("""
                SELECT COUNT(a.id)
                FROM assignments a
                LEFT JOIN assignment_submissions sub ON a.id = sub.assignment_id AND sub.student_id = ?
                WHERE a.subject_id = ? AND a.due_date < ? AND (sub.status IS NULL OR sub.status != 'completed')
            """, (sid, sub_id, today)).fetchone()[0]

            # 3. Check declining trend (latest attempt significantly lower than previous)
            recent_attempts = conn.execute("""
                SELECT qa.score_percentage
                FROM quiz_attempts qa
                JOIN quizzes q ON qa.quiz_id = q.id
                WHERE qa.student_id = ? AND q.subject_id = ?
                ORDER BY qa.attempted_at DESC
                LIMIT 2
            """, (sid, sub_id)).fetchall()

            is_declining = False
            if len(recent_attempts) >= 2:
                latest = recent_attempts[0]['score_percentage']
                prev = recent_attempts[1]['score_percentage']
                if (prev - latest) >= 15.0:
                    is_declining = True

            # Determine risk signals
            reasons = []
            badge = 'warning'

            if avg_score is not None and avg_score < 50.0:
                reasons.append(f"Low Quiz Average ({round(avg_score, 1)}%)")
                badge = 'danger'
            elif avg_score is not None and avg_score < 65.0:
                reasons.append(f"Needs Practice ({round(avg_score, 1)}%)")

            if overdue_count > 0:
                reasons.append(f"{overdue_count} Overdue Assignment{'s' if overdue_count > 1 else ''}")
                if overdue_count >= 2:
                    badge = 'danger'

            if is_declining:
                reasons.append("Declining Test Scores (recent drop >= 15%)")
                badge = 'danger'

            if reasons:
                attention_list.append({
                    'student_id': sid,
                    'name': row['name'],
                    'email': row['email'],
                    'identifier': row['identifier'],
                    'department': row['department'],
                    'subject_id': sub_id,
                    'subject_name': row['subject_name'],
                    'reasons': reasons,
                    'primary_reason': " • ".join(reasons),
                    'badge': badge,
                    'avg_score': round(avg_score, 1) if avg_score is not None else "No tests",
                    'overdue_count': overdue_count
                })

        conn.close()
        attention_list.sort(key=lambda x: (0 if x['badge'] == 'danger' else 1, x['name']))
        return attention_list

    @staticmethod
    def get_teacher_reports(teacher_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")

        classrooms = conn.execute("""
            SELECT s.id, s.name, s.code, s.academic_year, s.department,
                   COUNT(DISTINCT e.student_id) as student_count,
                   COUNT(DISTINCT a.id) as assignment_count,
                   COUNT(DISTINCT q.id) as quiz_count,
                   COUNT(DISTINCT m.id) as material_count,
                   ROUND(COALESCE(AVG(qa.score_percentage), 0), 1) as avg_score,
                   (
                       SELECT COUNT(sub.id) 
                       FROM assignment_submissions sub
                       JOIN assignments a2 ON sub.assignment_id = a2.id
                       WHERE a2.subject_id = s.id AND sub.status = 'completed'
                   ) as completed_assignments_count
            FROM subjects s
            LEFT JOIN enrolments e ON s.id = e.subject_id
            LEFT JOIN assignments a ON s.id = a.subject_id
            LEFT JOIN quizzes q ON s.id = q.subject_id
            LEFT JOIN study_materials m ON s.id = m.subject_id
            LEFT JOIN quiz_attempts qa ON q.id = qa.quiz_id
            WHERE s.teacher_id = ?
            GROUP BY s.id
            ORDER BY s.name ASC
        """, (teacher_id,)).fetchall()

        classroom_summaries = []
        for c in classrooms:
            item = dict(c)
            st_count = item['student_count']
            as_count = item['assignment_count']
            comp_count = item['completed_assignments_count']
            possible_submissions = st_count * as_count
            item['completion_rate'] = round((comp_count / possible_submissions * 100.0), 1) if possible_submissions > 0 else 100.0
            classroom_summaries.append(item)

        topic_stats = conn.execute("""
            SELECT qaa.topic, s.name as subject_name,
                   COUNT(qaa.id) as total_questions,
                   SUM(qaa.is_correct) as correct_questions,
                   ROUND(CAST(SUM(qaa.is_correct) AS REAL) / COUNT(qaa.id) * 100.0, 1) as accuracy_pct
            FROM quiz_attempt_answers qaa
            JOIN quiz_attempts qa ON qaa.attempt_id = qa.id
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE s.teacher_id = ?
            GROUP BY qaa.topic, s.id
            ORDER BY accuracy_pct ASC
        """, (teacher_id,)).fetchall()

        topics = []
        for t in topic_stats:
            acc = t['accuracy_pct'] or 0.0
            status = 'Mastered' if acc >= 75.0 else ('Moderate' if acc >= 50.0 else 'Weak')
            topics.append({
                'topic': t['topic'],
                'subject_name': t['subject_name'],
                'total_questions': t['total_questions'],
                'correct_questions': t['correct_questions'],
                'accuracy_pct': acc,
                'status': status
            })

        all_attempts = conn.execute("""
            SELECT qa.score_percentage
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE s.teacher_id = ?
        """, (teacher_id,)).fetchall()

        brackets = {
            'below_50': 0,
            '50_to_69': 0,
            '70_to_84': 0,
            '85_and_above': 0
        }
        for a in all_attempts:
            sc = a['score_percentage']
            if sc < 50:
                brackets['below_50'] += 1
            elif sc < 70:
                brackets['50_to_69'] += 1
            elif sc < 85:
                brackets['70_to_84'] += 1
            else:
                brackets['85_and_above'] += 1

        conn.close()
        return {
            'classrooms': classroom_summaries,
            'topics': topics,
            'brackets': brackets,
            'total_attempts': len(all_attempts)
        }

    @staticmethod
    def get_teacher_dashboard_stats(teacher_id):
        conn = get_db()
        today = datetime.now().strftime("%Y-%m-%d")
        
        # 1. Total unique students enrolled in teacher's subjects
        students_count = conn.execute("""
            SELECT COUNT(DISTINCT e.student_id)
            FROM enrolments e
            JOIN subjects s ON e.subject_id = s.id
            WHERE s.teacher_id = ?
        """, (teacher_id,)).fetchone()[0]

        # 2. Total subjects / classrooms handled
        subjects_count = conn.execute("SELECT COUNT(*) FROM subjects WHERE teacher_id = ?", (teacher_id,)).fetchone()[0]

        # 3. Total uploaded materials
        materials_count = conn.execute("SELECT COUNT(*) FROM study_materials WHERE teacher_id = ?", (teacher_id,)).fetchone()[0]

        # 4. Total assignments created
        assignments_count = conn.execute("SELECT COUNT(*) FROM assignments WHERE teacher_id = ?", (teacher_id,)).fetchone()[0]

        # 5. Total quizzes created
        quizzes_count = conn.execute("SELECT COUNT(*) FROM quizzes WHERE teacher_id = ?", (teacher_id,)).fetchone()[0]

        # 6. Active assignments count (due date >= today)
        active_assignments_count = conn.execute("""
            SELECT COUNT(*) FROM assignments WHERE teacher_id = ? AND due_date >= ?
        """, (teacher_id, today)).fetchone()[0]

        # 7. Upcoming / published quizzes count
        upcoming_quizzes_count = conn.execute("""
            SELECT COUNT(*) FROM quizzes WHERE teacher_id = ? AND is_published = 1
        """, (teacher_id,)).fetchone()[0]

        # 8. Average Class Performance
        avg_perf_row = conn.execute("""
            SELECT AVG(qa.score_percentage)
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE s.teacher_id = ?
        """, (teacher_id,)).fetchone()[0]
        avg_class_performance = round(avg_perf_row, 1) if avg_perf_row is not None else 0.0

        # 9. Active students recently (last 7 days)
        active_students_count = conn.execute("""
            SELECT COUNT(DISTINCT student_id) FROM (
                SELECT qa.student_id FROM quiz_attempts qa
                JOIN quizzes q ON qa.quiz_id = q.id
                JOIN subjects s ON q.subject_id = s.id
                WHERE s.teacher_id = ? AND qa.attempted_at >= datetime('now', '-7 days')
                UNION
                SELECT sub.student_id FROM assignment_submissions sub
                JOIN assignments a ON sub.assignment_id = a.id
                WHERE a.teacher_id = ? AND sub.completed_at >= datetime('now', '-7 days')
            )
        """, (teacher_id, teacher_id)).fetchone()[0]

        # 10. Pending assignments across all students
        total_pending_submissions = conn.execute("""
            SELECT COUNT(DISTINCT e.student_id || '-' || a.id)
            FROM assignments a
            JOIN enrolments e ON a.subject_id = e.subject_id
            LEFT JOIN assignment_submissions sub ON a.id = sub.assignment_id AND e.student_id = sub.student_id AND sub.status = 'completed'
            WHERE a.teacher_id = ? AND (sub.id IS NULL OR sub.status != 'completed')
        """, (teacher_id,)).fetchone()[0]

        # 11. Recent student activity (quizzes and assignments)
        recent_quiz_activity = conn.execute("""
            SELECT 'quiz' as activity_type, u.name as student_name, u.identifier as student_identifier,
                   q.title as item_title, s.name as subject_name, qa.score_percentage as result_val, qa.attempted_at as activity_date
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            JOIN users u ON qa.student_id = u.id
            WHERE s.teacher_id = ?
            ORDER BY qa.attempted_at DESC
            LIMIT 5
        """, (teacher_id,)).fetchall()

        recent_assignment_activity = conn.execute("""
            SELECT 'assignment' as activity_type, u.name as student_name, u.identifier as student_identifier,
                   a.title as item_title, s.name as subject_name, 'Completed' as result_val, sub.completed_at as activity_date
            FROM assignment_submissions sub
            JOIN assignments a ON sub.assignment_id = a.id
            JOIN subjects s ON a.subject_id = s.id
            JOIN users u ON sub.student_id = u.id
            WHERE s.teacher_id = ? AND sub.status = 'completed'
            ORDER BY sub.completed_at DESC
            LIMIT 5
        """, (teacher_id,)).fetchall()

        recent_activity = sorted(
            [dict(r) for r in recent_quiz_activity] + [dict(r) for r in recent_assignment_activity],
            key=lambda x: str(x['activity_date']),
            reverse=True
        )[:8]

        conn.close()

        # Students needing attention
        attention_students = StatsModel.get_students_needing_attention(teacher_id)

        # Classroom list
        classrooms = SubjectModel.get_teacher_classrooms(teacher_id)

        return {
            'students_count': students_count,
            'subjects_count': subjects_count,
            'classrooms_count': subjects_count,
            'materials_count': materials_count,
            'assignments_count': assignments_count,
            'quizzes_count': quizzes_count,
            'active_assignments_count': active_assignments_count,
            'upcoming_quizzes_count': upcoming_quizzes_count,
            'avg_class_performance': avg_class_performance,
            'active_students_count': active_students_count,
            'pending_assignments_count': total_pending_submissions,
            'recent_activity': recent_activity,
            'attention_students': attention_students,
            'attention_count': len(attention_students),
            'classrooms': classrooms
        }

    @staticmethod
    def get_teacher_student_performance(teacher_id, student_id):
        """Fetches detailed academic performance of an individual student for a teacher."""
        conn = get_db()
        
        # Verify student is in at least one subject of this teacher
        enrolled = conn.execute("""
            SELECT s.id, s.name, s.code
            FROM enrolments e
            JOIN subjects s ON e.subject_id = s.id
            WHERE e.student_id = ? AND s.teacher_id = ?
        """, (student_id, teacher_id)).fetchall()

        if not enrolled:
            conn.close()
            return None

        student = conn.execute("SELECT * FROM users WHERE id = ?", (student_id,)).fetchone()

        # Quiz attempts for teacher's subjects
        attempts = conn.execute("""
            SELECT qa.*, q.title as quiz_title, q.topic as quiz_topic, s.name as subject_name, s.code as subject_code
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ? AND s.teacher_id = ?
            ORDER BY qa.attempted_at ASC
        """, (student_id, teacher_id)).fetchall()

        # Subject-wise score breakdown
        subject_perf = conn.execute("""
            SELECT s.name as subject_name, AVG(qa.score_percentage) as avg_score, COUNT(qa.id) as attempts_count
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ? AND s.teacher_id = ?
            GROUP BY s.id
        """, (student_id, teacher_id)).fetchall()

        # Topic-wise score breakdown (from quiz_attempt_answers)
        topic_perf = conn.execute("""
            SELECT qaa.topic, 
                   COUNT(qaa.id) as total_questions,
                   SUM(qaa.is_correct) as correct_questions,
                   ROUND(CAST(SUM(qaa.is_correct) AS REAL) / COUNT(qaa.id) * 100.0, 1) as accuracy_pct
            FROM quiz_attempt_answers qaa
            JOIN quiz_attempts qa ON qaa.attempt_id = qa.id
            JOIN quizzes q ON qa.quiz_id = q.id
            JOIN subjects s ON q.subject_id = s.id
            WHERE qa.student_id = ? AND s.teacher_id = ?
            GROUP BY qaa.topic
            ORDER BY accuracy_pct ASC
        """, (student_id, teacher_id)).fetchall()

        # Assignment completion status
        assignments = conn.execute("""
            SELECT a.title as assignment_title, a.due_date, s.name as subject_name,
                   sub.status as submission_status, sub.completed_at
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            JOIN enrolments e ON s.id = e.subject_id AND e.student_id = ?
            LEFT JOIN assignment_submissions sub ON a.id = sub.assignment_id AND sub.student_id = ?
            WHERE s.teacher_id = ?
            ORDER BY a.due_date DESC
        """, (student_id, student_id, teacher_id)).fetchall()

        conn.close()

        # Prepare chart JSON data
        labels_history = [a['attempted_at'][:10] + f" ({a['quiz_title'][:12]})" for a in attempts]
        scores_history = [round(a['score_percentage'], 1) for a in attempts]

        subj_labels = [sp['subject_name'] for sp in subject_perf]
        subj_scores = [round(sp['avg_score'], 1) for sp in subject_perf]

        topic_labels = [tp['topic'] for tp in topic_perf]
        topic_scores = [tp['accuracy_pct'] for tp in topic_perf]

        return {
            'student': student,
            'enrolled_subjects': enrolled,
            'attempts': attempts,
            'subject_perf': subject_perf,
            'topic_perf': topic_perf,
            'assignments': assignments,
            'chart_data': {
                'history': {'labels': labels_history, 'data': scores_history},
                'subjects': {'labels': subj_labels, 'data': subj_scores},
                'topics': {'labels': topic_labels, 'data': topic_scores}
            }
        }
