import sqlite3
import os
from config import Config

def get_db():
    """Returns a SQLite connection with Row factory and foreign keys enabled."""
    db_path = Config.DATABASE
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db():
    """Initializes all database tables and necessary indexes."""
    conn = get_db()
    cursor = conn.cursor()
    
    # 1. Users table (Students and Teachers)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL CHECK(role IN ('student', 'teacher')),
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        identifier TEXT NOT NULL, -- Student Roll No or Teacher ID
        department TEXT NOT NULL,
        year_of_study TEXT,       -- Students only (e.g. '1st Year')
        semester TEXT,            -- Students only (e.g. 'Semester 2')
        subjects_handled TEXT,    -- Teachers only
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. Subjects table (Created by Teachers)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        teacher_id INTEGER NOT NULL,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        enrolment_code TEXT NOT NULL UNIQUE,
        description TEXT,
        department TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 3. Student Enrolments table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS enrolments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(student_id, subject_id),
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE
    );
    """)

    # 4. Study Materials table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_materials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        teacher_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        topic TEXT NOT NULL,
        description TEXT,
        material_type TEXT NOT NULL CHECK(material_type IN ('file', 'link')),
        file_path TEXT,
        original_filename TEXT,
        file_type TEXT,
        external_link TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE,
        FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 5. Assignments table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        teacher_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        topic TEXT NOT NULL,
        description TEXT,
        due_date TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE,
        FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 6. Assignment Submissions / Completion Status table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS assignment_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'completed' CHECK(status IN ('pending', 'completed')),
        completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(assignment_id, student_id),
        FOREIGN KEY (assignment_id) REFERENCES assignments (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 7. Quizzes table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quizzes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        teacher_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        topic TEXT NOT NULL,
        description TEXT,
        duration_minutes INTEGER NOT NULL DEFAULT 15,
        is_published INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE,
        FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 8. Quiz Questions table (Multiple Choice with 4 options and topic association)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quiz_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quiz_id INTEGER NOT NULL,
        topic TEXT NOT NULL,
        question_text TEXT NOT NULL,
        option_a TEXT NOT NULL,
        option_b TEXT NOT NULL,
        option_c TEXT NOT NULL,
        option_d TEXT NOT NULL,
        correct_option TEXT NOT NULL CHECK(correct_option IN ('A', 'B', 'C', 'D')),
        explanation TEXT,
        FOREIGN KEY (quiz_id) REFERENCES quizzes (id) ON DELETE CASCADE
    );
    """)

    # 9. Quiz Attempts table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quiz_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        total_questions INTEGER NOT NULL,
        correct_answers INTEGER NOT NULL,
        score_percentage REAL NOT NULL,
        attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (quiz_id) REFERENCES quizzes (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 10. Quiz Attempt Individual Answers table (Topic-level storage for Phase 2 readiness)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quiz_attempt_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        attempt_id INTEGER NOT NULL,
        question_id INTEGER NOT NULL,
        topic TEXT NOT NULL,
        selected_option TEXT NOT NULL,
        correct_option TEXT NOT NULL,
        is_correct INTEGER NOT NULL CHECK(is_correct IN (0, 1)),
        FOREIGN KEY (attempt_id) REFERENCES quiz_attempts (id) ON DELETE CASCADE,
        FOREIGN KEY (question_id) REFERENCES quiz_questions (id) ON DELETE CASCADE
    );
    """)

    # 11. Student Timetables config table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timetables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL UNIQUE,
        title TEXT DEFAULT 'My Study Schedule',
        daily_study_hours REAL DEFAULT 3.0,
        preferred_start_time TEXT DEFAULT '18:00',
        preferred_end_time TEXT DEFAULT '22:00',
        exam_date TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 12. Timetable Sessions table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timetable_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timetable_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        subject_id INTEGER,
        subject_name TEXT NOT NULL,
        topic TEXT NOT NULL,
        day_of_week TEXT NOT NULL, -- Monday, Tuesday, Wednesday, etc.
        start_time TEXT NOT NULL,  -- HH:MM
        end_time TEXT NOT NULL,    -- HH:MM
        duration_minutes INTEGER NOT NULL,
        session_type TEXT NOT NULL DEFAULT 'study' CHECK(session_type IN ('study', 'break')),
        is_completed INTEGER NOT NULL DEFAULT 0,
        priority TEXT DEFAULT 'Normal',
        FOREIGN KEY (timetable_id) REFERENCES timetables (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL
    );
    """)

    # 13. Subject Topics table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS topics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(subject_id, name),
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE
    );
    """)

    # 14. Timetable Versions table (Tracks history of adaptive timetable updates)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timetable_versions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        version_number INTEGER NOT NULL,
        trigger_reason TEXT NOT NULL,
        change_summary TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 15. Timetable Adaptations table (Session-level previous vs new duration changes and explanations)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timetable_adaptations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        version_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        subject_id INTEGER,
        subject_name TEXT NOT NULL,
        topic TEXT NOT NULL,
        prev_duration INTEGER DEFAULT 0,
        new_duration INTEGER DEFAULT 0,
        delta_minutes INTEGER DEFAULT 0,
        priority_level TEXT DEFAULT 'Normal',
        reason TEXT NOT NULL,
        FOREIGN KEY (version_id) REFERENCES timetable_versions (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 16. Personalized Study Recommendations table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_recommendations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER,
        subject_name TEXT NOT NULL,
        topic TEXT NOT NULL,
        score_percentage REAL,
        status TEXT NOT NULL, -- Strong, Moderate, Weak, Improving, Declining
        recommended_action TEXT NOT NULL,
        suggested_duration_mins INTEGER DEFAULT 45,
        material_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (material_id) REFERENCES study_materials (id) ON DELETE SET NULL
    );
    """)

    # 17. Classroom Announcements table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        teacher_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE,
        FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # Safe column migrations on existing tables
    def safe_add_column(table, column_def):
        col_name = column_def.split()[0]
        col_info = cursor.execute(f"PRAGMA table_info({table})").fetchall()
        existing_cols = [c[1] for c in col_info]
        if col_name not in existing_cols:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column_def};")

    safe_add_column("subjects", "academic_year TEXT DEFAULT '1st Year'")
    safe_add_column("assignments", "priority TEXT DEFAULT 'Medium'")
    safe_add_column("assignments", "instructions TEXT")
    safe_add_column("assignments", "attachment_url TEXT")
    safe_add_column("quizzes", "start_date TEXT")
    safe_add_column("quizzes", "end_date TEXT")
    safe_add_column("quizzes", "total_marks INTEGER DEFAULT 100")
    safe_add_column("quiz_questions", "marks INTEGER DEFAULT 1")
    safe_add_column("quizzes", "quiz_type TEXT DEFAULT 'teacher'")
    safe_add_column("quizzes", "difficulty TEXT DEFAULT 'Medium'")
    safe_add_column("quiz_questions", "difficulty TEXT DEFAULT 'Medium'")
    safe_add_column("quiz_attempts", "time_taken_seconds INTEGER DEFAULT 0")
    safe_add_column("quiz_attempts", "quiz_type TEXT DEFAULT 'teacher'")

    # Authentication & Email verification columns
    safe_add_column("users", "is_verified INTEGER DEFAULT 0")
    safe_add_column("users", "verification_otp_hash TEXT")
    safe_add_column("users", "otp_expires_at TIMESTAMP")
    safe_add_column("users", "otp_attempts INTEGER DEFAULT 0")
    safe_add_column("users", "otp_last_sent_at TIMESTAMP")
    safe_add_column("users", "reset_token_hash TEXT")
    safe_add_column("users", "reset_expires_at TIMESTAMP")
    safe_add_column("users", "reset_attempts INTEGER DEFAULT 0")
    safe_add_column("users", "reset_last_sent_at TIMESTAMP")

    # Migrate legacy users: ensure pre-existing accounts are marked as verified
    cursor.execute("UPDATE users SET is_verified = 1 WHERE is_verified = 0 AND verification_otp_hash IS NULL;")

    # Indexes for performance
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_subjects_enrolment ON subjects(enrolment_code);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_enrolments_student ON enrolments(student_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_enrolments_subject ON enrolments(subject_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_materials_subject ON study_materials(subject_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_assignments_subject ON assignments(subject_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_quizzes_subject ON quizzes(subject_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_quiz_attempts_student ON quiz_attempts(student_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_quiz_answers_topic ON quiz_attempt_answers(topic);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_student ON timetable_sessions(student_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_topics_subject ON topics(subject_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tt_versions_student ON timetable_versions(student_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tt_adapt_version ON timetable_adaptations(version_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_recomms_student ON study_recommendations(student_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_announcements_subject ON announcements(subject_id);")

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database tables initialized successfully.")
