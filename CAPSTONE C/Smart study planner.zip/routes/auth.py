import re
from functools import wraps
from compat import Blueprint, render_template, request, redirect, url_for, session, flash, check_password_hash
from models import UserModel
from config import Config
from email_service import is_email_configured, send_verification_otp, send_password_reset_otp

auth_bp = Blueprint('auth', __name__)

EMAIL_REGEX = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def student_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in as a student to access this page.", "warning")
            return redirect(url_for('auth.login'))
        if session.get('role') != 'student':
            flash("Access denied. This section is reserved for students.", "danger")
            return redirect(url_for('teacher.dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def teacher_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in as a teacher to access this page.", "warning")
            return redirect(url_for('auth.login'))
        if session.get('role') != 'teacher':
            flash("Access denied. This section is reserved for teachers.", "danger")
            return redirect(url_for('student.dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        if session.get('role') == 'teacher':
            return redirect(url_for('teacher.dashboard'))
        return redirect(url_for('student.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        selected_role = request.form.get('role', '').strip()

        if not email or not password:
            flash("Please enter both email and password.", "danger")
            return render_template('auth/login.html', email=email, role=selected_role)

        # 1. Check whether the email exists in SQLite users table
        user = UserModel.get_by_email(email)
        if not user:
            flash("No account found with this email. Please register first.", "danger")
            return render_template('auth/login.html', email=email, role=selected_role)

        # 2. Verify submitted password against stored password hash
        if not check_password_hash(user['password_hash'], password):
            flash("Incorrect password. Please try again.", "danger")
            return render_template('auth/login.html', email=email, role=selected_role)

        # 3. Enforce student and teacher role validation
        if selected_role and user['role'] != selected_role:
            flash(f"Account found, but it is registered as a {user['role'].capitalize()}, not a {selected_role.capitalize()}.", "warning")
            return render_template('auth/login.html', email=email, role=user['role'])

        # 4. Prevent unverified accounts from logging in
        if not user['is_verified']:
            session['unverified_user_id'] = user['id']
            session['unverified_email'] = user['email']
            session['unverified_role'] = user['role']
            session['unverified_name'] = user['name']
            flash("Please verify your email address before logging in. An OTP is required to activate your account.", "warning")
            return redirect(url_for('auth.verify_otp'))

        # Establish authenticated session
        session['user_id'] = user['id']
        session['role'] = user['role']
        session['name'] = user['name']
        session['email'] = user['email']
        session['identifier'] = user['identifier']
        session['department'] = user['department']

        flash(f"Welcome back, {user['name']}!", "success")
        if user['role'] == 'teacher':
            return redirect(url_for('teacher.dashboard'))
        else:
            return redirect(url_for('student.dashboard'))

    # Pre-select role if passed in query param e.g. /login?role=teacher
    role = request.args.get('role', '')
    return render_template('auth/login.html', role=role)

@auth_bp.route('/register/student', methods=['GET', 'POST'])
def register_student():
    if 'user_id' in session:
        return redirect(url_for('student.dashboard') if session.get('role') == 'student' else url_for('teacher.dashboard'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        student_id = request.form.get('student_id', '').strip()
        department = request.form.get('department', '').strip()
        year_of_study = request.form.get('year_of_study', '').strip()
        semester = request.form.get('semester', '').strip()

        # Validation
        if not all([name, email, password, student_id, department, year_of_study, semester]):
            flash("All fields are required. Please fill in the complete form.", "danger")
            return render_template('auth/register_student.html', form=request.form)

        if not re.match(EMAIL_REGEX, email):
            flash("Please enter a valid email address.", "danger")
            return render_template('auth/register_student.html', form=request.form)

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template('auth/register_student.html', form=request.form)

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return render_template('auth/register_student.html', form=request.form)

        # Check existing user
        existing_user = UserModel.get_by_email(email)
        if existing_user:
            if existing_user['is_verified']:
                flash("An account with this email address already exists. Please sign in instead.", "danger")
                return render_template('auth/register_student.html', form=request.form)
            else:
                user_id = existing_user['id']
                UserModel.update_profile(user_id, name, department, student_id, year_of_study, semester)
                UserModel.update_password(user_id, password)
        else:
            # Check email configuration
            if not is_email_configured() and not getattr(Config, 'TESTING', False):
                flash("Gmail SMTP is not configured. Please set your Gmail address and 16-character App Password in .env, or run 'python configure_email.py' to configure email delivery.", "danger")
                return render_template('auth/register_student.html', form=request.form)

            user_id, err = UserModel.create_user(
                role='student',
                name=name,
                email=email,
                password=password,
                identifier=student_id,
                department=department,
                year_of_study=year_of_study,
                semester=semester,
                is_verified=0
            )

            if err:
                flash(err, "danger")
                return render_template('auth/register_student.html', form=request.form)

        # Generate and store OTP hash
        otp_code = UserModel.set_verification_otp(user_id)
        
        # Send OTP email
        sent_ok, send_err = send_verification_otp(email, name, otp_code)
        if not sent_ok:
            flash(f"Failed to send verification email: {send_err}", "danger")
            return render_template('auth/register_student.html', form=request.form)

        session['unverified_user_id'] = user_id
        session['unverified_email'] = email
        session['unverified_name'] = name
        session['unverified_role'] = 'student'

        flash(f"Registration details saved! A 6-digit verification code has been sent to {email}. Please enter it below to activate your account.", "success")
        return redirect(url_for('auth.verify_otp'))

    return render_template('auth/register_student.html', form={})

@auth_bp.route('/register/teacher', methods=['GET', 'POST'])
def register_teacher():
    if 'user_id' in session:
        return redirect(url_for('teacher.dashboard') if session.get('role') == 'teacher' else url_for('student.dashboard'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        teacher_id = request.form.get('teacher_id', '').strip()
        department = request.form.get('department', '').strip()
        subjects_handled = request.form.get('subjects_handled', '').strip()

        if not all([name, email, password, teacher_id, department, subjects_handled]):
            flash("All fields are required. Please fill in the complete form.", "danger")
            return render_template('auth/register_teacher.html', form=request.form)

        if not re.match(EMAIL_REGEX, email):
            flash("Please enter a valid email address.", "danger")
            return render_template('auth/register_teacher.html', form=request.form)

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template('auth/register_teacher.html', form=request.form)

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return render_template('auth/register_teacher.html', form=request.form)

        # Check existing user
        existing_user = UserModel.get_by_email(email)
        if existing_user:
            if existing_user['is_verified']:
                flash("An account with this email address already exists. Please sign in instead.", "danger")
                return render_template('auth/register_teacher.html', form=request.form)
            else:
                user_id = existing_user['id']
                UserModel.update_profile(user_id, name, department, teacher_id, subjects_handled=subjects_handled)
                UserModel.update_password(user_id, password)
        else:
            if not is_email_configured() and not getattr(Config, 'TESTING', False):
                flash("Gmail SMTP is not configured. Please set your Gmail address and 16-character App Password in .env, or run 'python configure_email.py' to configure email delivery.", "danger")
                return render_template('auth/register_teacher.html', form=request.form)

            user_id, err = UserModel.create_user(
                role='teacher',
                name=name,
                email=email,
                password=password,
                identifier=teacher_id,
                department=department,
                subjects_handled=subjects_handled,
                is_verified=0
            )

            if err:
                flash(err, "danger")
                return render_template('auth/register_teacher.html', form=request.form)

        # Generate and store OTP hash
        otp_code = UserModel.set_verification_otp(user_id)
        
        # Send OTP email
        sent_ok, send_err = send_verification_otp(email, name, otp_code)
        if not sent_ok:
            flash(f"Failed to send verification email: {send_err}", "danger")
            return render_template('auth/register_teacher.html', form=request.form)

        session['unverified_user_id'] = user_id
        session['unverified_email'] = email
        session['unverified_name'] = name
        session['unverified_role'] = 'teacher'

        flash(f"Registration details saved! A 6-digit verification code has been sent to {email}. Please enter it below to activate your account.", "success")
        return redirect(url_for('auth.verify_otp'))

    return render_template('auth/register_teacher.html', form={})

@auth_bp.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    if 'user_id' in session:
        return redirect(url_for('teacher.dashboard') if session.get('role') == 'teacher' else url_for('student.dashboard'))

    user_id = session.get('unverified_user_id')
    email = session.get('unverified_email') or request.args.get('email', '')

    if not user_id and email:
        u = UserModel.get_by_email(email)
        if u:
            user_id = u['id']
            session['unverified_user_id'] = user_id
            session['unverified_email'] = u['email']
            session['unverified_role'] = u['role']
            session['unverified_name'] = u['name']

    if request.method == 'POST':
        otp = request.form.get('otp', '').strip()
        user_id = user_id or request.form.get('user_id')

        if not user_id:
            flash("Session expired or user not found. Please sign up or log in again.", "danger")
            return redirect(url_for('auth.login'))

        if not otp:
            flash("Please enter the 6-digit verification code.", "danger")
            return render_template('auth/verify_otp.html', email=email)

        success, msg = UserModel.verify_registration_otp(user_id, otp)
        if success:
            user = UserModel.get_by_id(user_id)
            role = user['role'] if user else session.get('unverified_role', 'student')
            session.pop('unverified_user_id', None)
            session.pop('unverified_email', None)
            session.pop('unverified_name', None)
            session.pop('unverified_role', None)
            flash("Email verified successfully! You can now log in with your credentials.", "success")
            return redirect(url_for('auth.login', role=role))
        else:
            flash(msg, "danger")
            return render_template('auth/verify_otp.html', email=email)

    return render_template('auth/verify_otp.html', email=email)

@auth_bp.route('/resend-otp', methods=['POST'])
def resend_otp():
    user_id = session.get('unverified_user_id')
    email = request.form.get('email') or session.get('unverified_email')

    if not user_id and email:
        u = UserModel.get_by_email(email)
        if u:
            user_id = u['id']
            session['unverified_user_id'] = user_id
            session['unverified_email'] = u['email']
            session['unverified_role'] = u['role']
            session['unverified_name'] = u['name']

    if not user_id:
        flash("User session not found. Please register or try logging in.", "danger")
        return redirect(url_for('auth.login'))

    user = UserModel.get_by_id(user_id)
    if not user:
        flash("User account not found.", "danger")
        return redirect(url_for('auth.login'))

    if user['is_verified']:
        flash("Your account is already verified! Please sign in.", "info")
        return redirect(url_for('auth.login'))

    can_resend, wait_sec = UserModel.can_resend_verification_otp(user_id, cooldown_seconds=60)
    if not can_resend:
        flash(f"Please wait {wait_sec} seconds before requesting a new verification code.", "warning")
        return redirect(url_for('auth.verify_otp'))

    if not is_email_configured() and not getattr(Config, 'TESTING', False):
        flash("Gmail SMTP email service is not configured. Cannot resend email.", "danger")
        return redirect(url_for('auth.verify_otp'))

    new_otp = UserModel.set_verification_otp(user_id)
    sent_ok, send_err = send_verification_otp(user['email'], user['name'], new_otp)
    if sent_ok:
        flash("A fresh 6-digit verification code has been sent to your email.", "success")
    else:
        flash(f"Failed to resend email: {send_err}", "danger")

    return redirect(url_for('auth.verify_otp'))

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if 'user_id' in session:
        return redirect(url_for('teacher.dashboard') if session.get('role') == 'teacher' else url_for('student.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        if not email:
            flash("Please enter your registered email address.", "danger")
            return render_template('auth/forgot_password.html')

        if not is_email_configured() and not getattr(Config, 'TESTING', False):
            flash("Gmail SMTP email service is not configured. Cannot process password reset.", "danger")
            return render_template('auth/forgot_password.html', email=email)

        user, reset_code, err = UserModel.set_password_reset_otp(email)
        if err:
            if "wait" in err.lower():
                flash(err, "warning")
                return render_template('auth/forgot_password.html', email=email)
            # Avoid leaking user existence
            flash("If an account exists with this email address, a password reset code has been sent.", "info")
            return redirect(url_for('auth.reset_password', email=email))

        sent_ok, send_err = send_password_reset_otp(user['email'], user['name'], reset_code)
        if sent_ok:
            session['reset_email'] = user['email']
            flash("If an account exists with this email address, a password reset code has been sent.", "info")
            return redirect(url_for('auth.reset_password', email=user['email']))
        else:
            flash(f"Failed to send password reset email: {send_err}", "danger")
            return render_template('auth/forgot_password.html', email=email)

    return render_template('auth/forgot_password.html')

@auth_bp.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if 'user_id' in session:
        return redirect(url_for('teacher.dashboard') if session.get('role') == 'teacher' else url_for('student.dashboard'))

    email = request.args.get('email') or session.get('reset_email', '')

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        code = request.form.get('code', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not all([email, code, password, confirm_password]):
            flash("All fields are required. Please fill in the complete form.", "danger")
            return render_template('auth/reset_password.html', email=email, code=code)

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template('auth/reset_password.html', email=email, code=code)

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return render_template('auth/reset_password.html', email=email, code=code)

        success, msg = UserModel.verify_and_reset_password(email, code, password)
        if success:
            session.pop('reset_email', None)
            flash("Password reset successful! You can now log in with your new password.", "success")
            return redirect(url_for('auth.login'))
        else:
            flash(msg, "danger")
            return render_template('auth/reset_password.html', email=email, code=code)

    return render_template('auth/reset_password.html', email=email)

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash("You have been securely logged out.", "info")
    return redirect(url_for('auth.login'))
