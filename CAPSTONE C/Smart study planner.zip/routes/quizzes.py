from compat import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from routes.auth import student_required, teacher_required, login_required
from models import QuizModel, SubjectModel, TopicModel, TimetableModel
from ai_analysis import PerformanceAnalyzer
from ai_recommendations import RecommendationEngine
from ai_quiz import AIQuizEngine

quizzes_bp = Blueprint('quizzes', __name__, url_prefix='/quizzes')

@quizzes_bp.route('/student')
@student_required
def student_quizzes():
    student_id = session['user_id']
    quizzes = QuizModel.get_student_quizzes(student_id)
    attempts = QuizModel.get_student_attempts(student_id)
    subjects = SubjectModel.get_student_subjects(student_id)

    subject_filter = request.args.get('subject_id')
    if subject_filter:
        quizzes = [q for q in quizzes if str(q['subject_id']) == subject_filter]

    # Collect available topics across enrolled subjects for AI generation
    subject_topics = {}
    for s in subjects:
        t_list = TopicModel.get_by_subject(s['id'])
        subject_topics[s['id']] = [t['name'] for t in t_list] if t_list else AIQuizEngine.get_available_topics_for_subject(s['name'])

    return render_template('student/quizzes.html', quizzes=quizzes, attempts=attempts, subjects=subjects, current_subject=subject_filter, subject_topics=subject_topics)

@quizzes_bp.route('/student/generate-ai', methods=['POST'])
@student_required
def generate_ai_quiz():
    student_id = session['user_id']
    is_json = request.is_json or ('application/json' in request.headers.get('Content-Type', ''))
    if is_json:
        data = request.get_json() or {}
        subject_id = data.get('subject_id')
        topic = str(data.get('topic', '')).strip()
        difficulty = str(data.get('difficulty', 'Medium')).strip().capitalize()
        question_count = data.get('question_count', 5)
    else:
        subject_id = request.form.get('subject_id')
        topic = request.form.get('topic', '').strip()
        difficulty = request.form.get('difficulty', 'Medium').strip().capitalize()
        question_count = request.form.get('question_count', 5)

    if not subject_id or not topic:
        if is_json:
            return jsonify({'error': 'Subject and topic are required'}), 400
        flash("Subject and topic are required to generate an AI practice quiz.", "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    # Verify student is enrolled
    if not SubjectModel.is_student_enrolled(student_id, int(subject_id)):
        if is_json:
            return jsonify({'error': 'Not enrolled in this subject'}), 403
        flash("You can only generate practice quizzes for subjects you are enrolled in.", "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    try:
        count = int(question_count)
    except Exception:
        count = 5

    quiz_id, err = QuizModel.create_ai_quiz(student_id, int(subject_id), topic, difficulty, count)
    if err:
        if is_json:
            return jsonify({'error': err}), 400
        flash(err, "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    if is_json:
        return jsonify({'success': True, 'quiz_id': quiz_id, 'redirect_url': url_for('quizzes.take_quiz', quiz_id=quiz_id)}), 200

    flash(f"✨ AI Practice Quiz for '{topic}' ({difficulty} level, {count} questions) generated! Attempt your test below.", "success")
    return redirect(url_for('quizzes.take_quiz', quiz_id=quiz_id))

@quizzes_bp.route('/api/topics/<int:subject_id>')
@login_required
def get_subject_topics(subject_id):
    subj = SubjectModel.get_by_id(subject_id)
    if not subj:
        return jsonify({'topics': []}), 404
    t_list = TopicModel.get_by_subject(subject_id)
    topics = [t['name'] for t in t_list] if t_list else AIQuizEngine.get_available_topics_for_subject(subj['name'])
    return jsonify({'topics': topics})

@quizzes_bp.route('/student/take/<int:quiz_id>')
@student_required
def take_quiz(quiz_id):
    student_id = session['user_id']
    quiz = QuizModel.get_by_id(quiz_id)
    if not quiz or not quiz['is_published']:
        flash("Quiz not found or not published.", "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    if not SubjectModel.is_student_enrolled(student_id, quiz['subject_id']):
        flash("You are not enrolled in the subject for this quiz.", "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    questions = QuizModel.get_questions(quiz_id)
    if not questions:
        flash("This quiz currently has no questions.", "warning")
        return redirect(url_for('quizzes.student_quizzes'))

    return render_template('student/quiz_take.html', quiz=quiz, questions=questions)

@quizzes_bp.route('/student/submit/<int:quiz_id>', methods=['POST'])
@student_required
def submit_quiz(quiz_id):
    student_id = session['user_id']
    quiz = QuizModel.get_by_id(quiz_id)
    if not quiz:
        flash("Quiz not found.", "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    # Extract answers from form
    # Keys will be 'q_{question_id}' -> 'A', 'B', 'C', 'D'
    submitted_answers = {}
    for key, val in request.form.items():
        if key.startswith('q_'):
            qid = key.split('_')[1]
            submitted_answers[qid] = val

    time_taken_seconds = request.form.get('time_taken_seconds', 0)
    try:
        time_taken_seconds = int(time_taken_seconds)
    except Exception:
        time_taken_seconds = 0

    result, err = QuizModel.evaluate_and_record_attempt(quiz_id, student_id, submitted_answers, time_taken_seconds=time_taken_seconds)
    if err:
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', ''):
            return jsonify({'error': err}), 400
        flash(err, "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', ''):
        return jsonify({
            'success': True,
            'attempt_id': result['attempt_id'],
            'total_questions': result['total_questions'],
            'correct_answers': result['correct_answers'],
            'score_percentage': result['score_percentage'],
            'adaptation_info': result.get('adaptation_info'),
            'redirect_url': url_for('quizzes.quiz_result', attempt_id=result['attempt_id'])
        })

    flash(f"🎉 Quiz submitted successfully! You scored {result['correct_answers']}/{result['total_questions']} ({result['score_percentage']}%). Your study timetable has been automatically adapted!", "success")
    return redirect(url_for('quizzes.quiz_result', attempt_id=result['attempt_id']))

@quizzes_bp.route('/student/result/<int:attempt_id>')
@student_required
def quiz_result(attempt_id):
    student_id = session['user_id']
    attempt, answers = QuizModel.get_attempt_detail(attempt_id)
    if not attempt or attempt['student_id'] != student_id:
        flash("Quiz result not found or access denied.", "danger")
        return redirect(url_for('quizzes.student_quizzes'))

    analysis = PerformanceAnalyzer.analyze_attempt(attempt_id)
    recommendations = RecommendationEngine.get_latest_recommendations(student_id)
    latest_version, latest_adaptations = TimetableModel.get_latest_adaptation(student_id)

    return render_template('student/quiz_result.html',
                           attempt=attempt,
                           answers=answers,
                           analysis=analysis,
                           recommendations=recommendations,
                           latest_version=latest_version,
                           latest_adaptations=latest_adaptations)

@quizzes_bp.route('/teacher')
@teacher_required
def teacher_quizzes():
    teacher_id = session['user_id']
    quizzes = QuizModel.get_teacher_quizzes(teacher_id)
    subjects = SubjectModel.get_teacher_subjects(teacher_id)

    # Collect available topics across subjects for AI generator dropdown
    subject_topics = {}
    for s in subjects:
        t_list = TopicModel.get_by_subject(s['id'])
        subject_topics[s['id']] = [t['name'] for t in t_list] if t_list else AIQuizEngine.get_available_topics_for_subject(s['name'])

    return render_template('teacher/quizzes.html', quizzes=quizzes, subjects=subjects, classrooms=subjects, subject_topics=subject_topics)

@quizzes_bp.route('/teacher/create', methods=['POST'])
@teacher_required
def create_quiz():
    teacher_id = session['user_id']
    subject_id = request.form.get('subject_id')
    title = request.form.get('title', '').strip()
    topic = request.form.get('topic', '').strip()
    description = request.form.get('description', '').strip()
    duration_minutes = request.form.get('duration_minutes', '15').strip()

    if not all([subject_id, title, topic]):
        flash("Subject, Title, and Topic are required.", "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    quiz_id = QuizModel.create_quiz(subject_id, teacher_id, title, topic, description, duration_minutes)
    flash(f"Quiz '{title}' created! Now add multiple choice questions below.", "success")
    return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

@quizzes_bp.route('/teacher/generate-ai', methods=['POST'])
@teacher_required
def teacher_generate_ai():
    teacher_id = session['user_id']
    subject_id = request.form.get('subject_id')
    topic = request.form.get('topic', '').strip()
    difficulty = request.form.get('difficulty', 'Medium').strip().capitalize()
    question_count = request.form.get('question_count', 5)
    title = request.form.get('title', '').strip()
    duration_minutes = request.form.get('duration_minutes', 15)

    if not subject_id or not topic:
        flash("Classroom and Topic are required to generate an AI quiz.", "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    subj = SubjectModel.get_by_id(subject_id)
    if not subj or subj['teacher_id'] != teacher_id:
        flash("Classroom not found or unauthorized.", "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    try:
        count = int(question_count)
    except Exception:
        count = 5

    try:
        duration = int(duration_minutes)
    except Exception:
        duration = 15

    quiz_id, err = QuizModel.create_teacher_ai_quiz(
        teacher_id=teacher_id,
        subject_id=int(subject_id),
        topic=topic,
        difficulty=difficulty,
        question_count=count,
        title=title or None,
        duration_minutes=duration
    )
    if err:
        flash(err, "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    flash(f"✨ AI Quiz on '{topic}' generated in Draft mode! Review the questions below, make any edits, and click 'Publish Quiz' when you're ready.", "success")
    return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

@quizzes_bp.route('/teacher/<int:quiz_id>/publish', methods=['POST'])
@teacher_required
def publish_quiz(quiz_id):
    teacher_id = session['user_id']
    quiz = QuizModel.get_by_id(quiz_id)
    if not quiz or quiz['teacher_id'] != teacher_id:
        flash("Quiz not found or unauthorized.", "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    questions = QuizModel.get_questions(quiz_id)
    if not questions:
        flash("Cannot publish a quiz with no questions. Please add at least one question.", "warning")
        return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

    QuizModel.publish_quiz(quiz_id, teacher_id)
    flash(f"🚀 Quiz '{quiz['title']}' is now published and active for students!", "success")
    return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

@quizzes_bp.route('/teacher/<int:quiz_id>/questions/<int:question_id>/edit', methods=['POST'])
@teacher_required
def edit_question(quiz_id, question_id):
    teacher_id = session['user_id']
    quiz = QuizModel.get_by_id(quiz_id)
    if not quiz or quiz['teacher_id'] != teacher_id:
        flash("Quiz not found or unauthorized.", "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    question_text = request.form.get('question_text', '').strip()
    option_a = request.form.get('option_a', '').strip()
    option_b = request.form.get('option_b', '').strip()
    option_c = request.form.get('option_c', '').strip()
    option_d = request.form.get('option_d', '').strip()
    correct_option = request.form.get('correct_option', '').strip().upper()
    explanation = request.form.get('explanation', '').strip()
    difficulty = request.form.get('difficulty', 'Medium').strip().capitalize()

    if not all([question_text, option_a, option_b, option_c, option_d, correct_option]):
        flash("All fields and options are required.", "danger")
    elif correct_option not in ['A', 'B', 'C', 'D']:
        flash("Correct option must be A, B, C, or D.", "danger")
    else:
        QuizModel.update_question(question_id, quiz_id, teacher_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty)
        flash("Question updated successfully!", "success")

    return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

@quizzes_bp.route('/teacher/<int:quiz_id>/questions', methods=['GET', 'POST'])
@teacher_required
def manage_questions(quiz_id):
    teacher_id = session['user_id']
    quiz = QuizModel.get_by_id(quiz_id)
    if not quiz or quiz['teacher_id'] != teacher_id:
        flash("Quiz not found or unauthorized.", "danger")
        return redirect(url_for('quizzes.teacher_quizzes'))

    if request.method == 'POST':
        question_text = request.form.get('question_text', '').strip()
        topic = request.form.get('topic', '').strip() or quiz['topic']
        option_a = request.form.get('option_a', '').strip()
        option_b = request.form.get('option_b', '').strip()
        option_c = request.form.get('option_c', '').strip()
        option_d = request.form.get('option_d', '').strip()
        correct_option = request.form.get('correct_option', '').strip().upper()
        explanation = request.form.get('explanation', '').strip()

        if not all([question_text, topic, option_a, option_b, option_c, option_d, correct_option]):
            flash("All question fields and 4 options are required.", "danger")
        elif correct_option not in ['A', 'B', 'C', 'D']:
            flash("Correct option must be A, B, C, or D.", "danger")
        else:
            QuizModel.add_question(quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation)
            flash("Question added successfully!", "success")
            return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

    questions = QuizModel.get_questions(quiz_id)
    return render_template('teacher/quiz_edit.html', quiz=quiz, questions=questions)

@quizzes_bp.route('/teacher/<int:quiz_id>/questions/<int:question_id>/delete', methods=['POST'])
@teacher_required
def delete_question(quiz_id, question_id):
    teacher_id = session['user_id']
    QuizModel.delete_question(question_id, quiz_id, teacher_id)
    flash("Question removed.", "info")
    return redirect(url_for('quizzes.manage_questions', quiz_id=quiz_id))

@quizzes_bp.route('/teacher/<int:quiz_id>/delete', methods=['POST'])
@teacher_required
def delete_quiz(quiz_id):
    teacher_id = session['user_id']
    QuizModel.delete_quiz(quiz_id, teacher_id)
    flash("Quiz deleted.", "info")
    return redirect(url_for('quizzes.teacher_quizzes'))
