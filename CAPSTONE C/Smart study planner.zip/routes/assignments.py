from compat import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from routes.auth import student_required, teacher_required
from models import AssignmentModel, SubjectModel

assignments_bp = Blueprint('assignments', __name__, url_prefix='/assignments')

@assignments_bp.route('/student')
@student_required
def student_assignments():
    student_id = session['user_id']
    assignments = AssignmentModel.get_student_assignments(student_id)
    subjects = SubjectModel.get_student_subjects(student_id)
    
    status_filter = request.args.get('status', 'all')
    subject_filter = request.args.get('subject_id')

    filtered = assignments
    if status_filter != 'all':
        filtered = [a for a in filtered if a.get('calculated_status') == status_filter]
    if subject_filter:
        filtered = [a for a in filtered if str(a.get('subject_id')) == subject_filter]

    # Calculate summary counts
    pending_count = sum(1 for a in assignments if a.get('calculated_status') == 'pending')
    completed_count = sum(1 for a in assignments if a.get('calculated_status') == 'completed')
    overdue_count = sum(1 for a in assignments if a.get('calculated_status') == 'overdue')

    return render_template('student/assignments.html', 
                           assignments=filtered,
                           subjects=subjects,
                           current_status=status_filter,
                           current_subject=subject_filter,
                           pending_count=pending_count,
                           completed_count=completed_count,
                           overdue_count=overdue_count)

@assignments_bp.route('/student/toggle/<int:assignment_id>', methods=['POST'])
@student_required
def toggle_completion(assignment_id):
    student_id = session['user_id']
    all_assignments = AssignmentModel.get_student_assignments(student_id)
    target = next((a for a in all_assignments if a['id'] == assignment_id), None)
    
    if not target:
        flash("Assignment not found.", "danger")
        return redirect(url_for('assignments.student_assignments'))

    new_state = not target['is_completed']
    AssignmentModel.toggle_student_completion(assignment_id, student_id, mark_completed=new_state)

    if new_state:
        flash(f"Marked '{target['title']}' as completed!", "success")
    else:
        flash(f"Marked '{target['title']}' as pending.", "info")

    return redirect(request.form.get('next') or url_for('assignments.student_assignments'))

@assignments_bp.route('/teacher')
@teacher_required
def teacher_assignments():
    teacher_id = session['user_id']
    assignments = AssignmentModel.get_teacher_assignments(teacher_id)
    subjects = SubjectModel.get_teacher_subjects(teacher_id)
    return render_template('teacher/assignments.html', assignments=assignments, subjects=subjects)

@assignments_bp.route('/teacher/create', methods=['POST'])
@teacher_required
def create_assignment():
    teacher_id = session['user_id']
    subject_id = request.form.get('subject_id')
    title = request.form.get('title', '').strip()
    topic = request.form.get('topic', '').strip()
    description = request.form.get('description', '').strip()
    due_date = request.form.get('due_date', '').strip()

    if not all([subject_id, title, topic, due_date]):
        flash("Subject, Title, Topic, and Due Date are required.", "danger")
        return redirect(url_for('assignments.teacher_assignments'))

    AssignmentModel.create_assignment(subject_id, teacher_id, title, topic, description, due_date)
    flash(f"Assignment '{title}' created successfully!", "success")
    return redirect(url_for('assignments.teacher_assignments'))

@assignments_bp.route('/teacher/<int:assignment_id>/submissions')
@teacher_required
def assignment_submissions(assignment_id):
    teacher_id = session['user_id']
    assignment, submissions = AssignmentModel.get_assignment_submissions_detail(assignment_id, teacher_id)
    if not assignment:
        flash("Assignment not found or unauthorized.", "danger")
        return redirect(url_for('assignments.teacher_assignments'))

    completed_students = [s for s in submissions if s['status'] == 'completed']
    pending_students = [s for s in submissions if s['status'] != 'completed']

    return render_template('teacher/assignment_submissions.html', 
                           assignment=assignment, 
                           submissions=submissions,
                           completed_students=completed_students,
                           pending_students=pending_students)

@assignments_bp.route('/teacher/<int:assignment_id>/delete', methods=['POST'])
@teacher_required
def delete_assignment(assignment_id):
    teacher_id = session['user_id']
    AssignmentModel.delete_assignment(assignment_id, teacher_id)
    flash("Assignment deleted.", "info")
    return redirect(url_for('assignments.teacher_assignments'))
