import os
import uuid
from compat import Blueprint, render_template, request, redirect, url_for, session, flash, send_from_directory, secure_filename
from routes.auth import login_required, student_required, teacher_required
from models import MaterialModel, SubjectModel
from config import Config

materials_bp = Blueprint('materials', __name__, url_prefix='/materials')

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS

@materials_bp.route('/student')
@student_required
def student_materials():
    student_id = session['user_id']
    materials = MaterialModel.get_student_materials(student_id)
    subjects = SubjectModel.get_student_subjects(student_id)
    
    # Optional filters
    subject_filter = request.args.get('subject_id')
    search_q = request.args.get('q', '').strip().lower()

    if subject_filter:
        materials = [m for m in materials if str(m['subject_id']) == subject_filter]
    if search_q:
        materials = [m for m in materials if search_q in m['title'].lower() or search_q in m['topic'].lower()]

    return render_template('student/materials.html', materials=materials, subjects=subjects, current_subject=subject_filter, search_q=search_q)

@materials_bp.route('/teacher')
@teacher_required
def teacher_materials():
    teacher_id = session['user_id']
    materials = MaterialModel.get_teacher_materials(teacher_id)
    subjects = SubjectModel.get_teacher_subjects(teacher_id)
    
    subject_filter = request.args.get('subject_id')
    if subject_filter:
        materials = [m for m in materials if str(m['subject_id']) == subject_filter]

    return render_template('teacher/materials.html', materials=materials, subjects=subjects, current_subject=subject_filter)

@materials_bp.route('/teacher/upload', methods=['POST'])
@teacher_required
def upload_material():
    teacher_id = session['user_id']
    subject_id = request.form.get('subject_id')
    title = request.form.get('title', '').strip()
    topic = request.form.get('topic', '').strip()
    description = request.form.get('description', '').strip()
    material_type = request.form.get('material_type', 'file')

    if not subject_id or not title or not topic:
        flash("Subject, Title, and Topic are required fields.", "danger")
        return redirect(url_for('materials.teacher_materials'))

    file_path = None
    original_filename = None
    file_type = None
    external_link = None

    if material_type == 'file':
        if 'material_file' not in request.files:
            flash("Please select a file to upload.", "danger")
            return redirect(url_for('materials.teacher_materials'))
        
        file = request.files['material_file']
        if file.filename == '':
            flash("No file selected.", "danger")
            return redirect(url_for('materials.teacher_materials'))

        if file and allowed_file(file.filename):
            orig_name = secure_filename(file.filename)
            ext = orig_name.rsplit('.', 1)[1].lower() if '.' in orig_name else 'dat'
            saved_filename = f"{uuid.uuid4().hex[:12]}_{orig_name}"
            dest_path = os.path.join(Config.UPLOAD_FOLDER, saved_filename)
            file.save(dest_path)

            file_path = dest_path
            original_filename = orig_name
            file_type = ext
        else:
            flash("File type not allowed. Please upload PDF, PPT, PPTX, DOC, DOCX, or TXT.", "danger")
            return redirect(url_for('materials.teacher_materials'))

    elif material_type == 'link':
        external_link = request.form.get('external_link', '').strip()
        if not external_link:
            flash("Please provide a valid web URL.", "danger")
            return redirect(url_for('materials.teacher_materials'))
        if not (external_link.startswith('http://') or external_link.startswith('https://')):
            external_link = 'https://' + external_link

    MaterialModel.create_material(
        subject_id=subject_id,
        teacher_id=teacher_id,
        title=title,
        topic=topic,
        description=description,
        material_type=material_type,
        file_path=file_path,
        original_filename=original_filename,
        file_type=file_type,
        external_link=external_link
    )

    flash(f"Study material '{title}' uploaded successfully!", "success")
    return redirect(url_for('materials.teacher_materials'))

@materials_bp.route('/download/<int:material_id>')
@login_required
def download_material(material_id):
    user_id = session['user_id']
    role = session.get('role')
    material = MaterialModel.get_by_id(material_id)

    if not material:
        flash("Study material not found.", "danger")
        return redirect(url_for('student.dashboard') if role == 'student' else url_for('teacher.dashboard'))

    # Access control
    if role == 'student':
        if not SubjectModel.is_student_enrolled(user_id, material['subject_id']):
            flash("Access denied. You are not enrolled in this subject.", "danger")
            return redirect(url_for('student.dashboard'))
    elif role == 'teacher':
        if material['teacher_id'] != user_id:
            flash("Access denied. You can only download materials for your own subjects.", "danger")
            return redirect(url_for('teacher.dashboard'))

    if material['material_type'] == 'link':
        return redirect(material['external_link'])

    if not material['file_path'] or not os.path.exists(material['file_path']):
        flash("File no longer exists on server.", "danger")
        return redirect(url_for('materials.student_materials') if role == 'student' else url_for('materials.teacher_materials'))

    directory = os.path.dirname(material['file_path'])
    filename = os.path.basename(material['file_path'])
    return send_from_directory(directory, filename, as_attachment=False)

@materials_bp.route('/teacher/<int:material_id>/delete', methods=['POST'])
@teacher_required
def delete_material(material_id):
    teacher_id = session['user_id']
    MaterialModel.delete_material(material_id, teacher_id)
    flash("Study material has been deleted.", "info")
    return redirect(url_for('materials.teacher_materials'))
