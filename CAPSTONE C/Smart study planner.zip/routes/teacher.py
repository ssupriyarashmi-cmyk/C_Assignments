from compat import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from routes.auth import teacher_required
from models import (
    UserModel, SubjectModel, StatsModel, MaterialModel,
    AssignmentModel, QuizModel, AnnouncementModel, TopicModel
)
from database import get_db
import json

teacher_bp = Blueprint('teacher', __name__, url_prefix='/teacher')

@teacher_bp.route('/dashboard')
@teacher_required
def dashboard():
    teacher_id = session['user_id']
    stats = StatsModel.get_teacher_dashboard_stats(teacher_id)
    classrooms = stats.get('classrooms', [])
    subjects = classrooms
    return render_template('teacher/dashboard.html', stats=stats, subjects=subjects, classrooms=classrooms)

@teacher_bp.route('/classrooms')
@teacher_bp.route('/subjects')
@teacher_required
def classrooms():
    teacher_id = session['user_id']
    teacher_subjects = SubjectModel.get_teacher_classrooms(teacher_id)
    return render_template('teacher/classrooms.html', classrooms=teacher_subjects, subjects=teacher_subjects)

@teacher_bp.route('/classrooms/create', methods=['POST'])
@teacher_bp.route('/subjects/create', methods=['POST'])
@teacher_required
def create_classroom():
    teacher_id = session['user_id']
    code = request.form.get('code', '').strip()
    name = request.form.get('name', '').strip()
    department = request.form.get('department', '').strip()
    academic_year = request.form.get('academic_year', '1st Year').strip()
    description = request.form.get('description', '').strip()

    if not code or not name or not department:
        flash("Subject Code, Classroom Name, and Department are required.", "danger")
        return redirect(url_for('teacher.classrooms'))

    subj_id, code_gen = SubjectModel.create_subject(teacher_id, code, name, department, description, academic_year=academic_year)
    flash(f"Classroom '{name}' created successfully! Class Code: {code_gen}", "success")
    return redirect(url_for('teacher.classroom_detail', subject_id=subj_id))

# Alias for backwards compatibility with existing test suite
create_subject = create_classroom

@teacher_bp.route('/classrooms/<int:subject_id>')
@teacher_bp.route('/subjects/<int:subject_id>')
@teacher_required
def classroom_detail(subject_id):
    teacher_id = session['user_id']
    subject = SubjectModel.get_by_id(subject_id)
    if not subject or subject['teacher_id'] != teacher_id:
        flash("Classroom not found or unauthorized.", "danger")
        return redirect(url_for('teacher.classrooms'))

    students = SubjectModel.get_enrolled_students(subject_id)
    assignments = AssignmentModel.get_by_subject(subject_id)
    quizzes = QuizModel.get_by_subject(subject_id)
    materials = MaterialModel.get_by_subject(subject_id)
    announcements = AnnouncementModel.get_by_subject(subject_id)
    topics = TopicModel.get_by_subject(subject_id)
    attention_students = StatsModel.get_students_needing_attention(teacher_id, subject_id=subject_id)

    # Topic-level performance for this classroom
    conn = get_db()
    topic_perf = conn.execute("""
        SELECT qaa.topic, 
               COUNT(qaa.id) as total_questions,
               SUM(qaa.is_correct) as correct_questions,
               ROUND(CAST(SUM(qaa.is_correct) AS REAL) / COUNT(qaa.id) * 100.0, 1) as accuracy_pct
        FROM quiz_attempt_answers qaa
        JOIN quiz_attempts qa ON qaa.attempt_id = qa.id
        JOIN quizzes q ON qa.quiz_id = q.id
        WHERE q.subject_id = ?
        GROUP BY qaa.topic
        ORDER BY accuracy_pct ASC
    """, (subject_id,)).fetchall()
    conn.close()

    active_tab = request.args.get('tab', 'overview')

    return render_template('teacher/classroom_detail.html',
                           subject=subject,
                           classroom=subject,
                           students=students,
                           assignments=assignments,
                           quizzes=quizzes,
                           materials=materials,
                           announcements=announcements,
                           topics=topics,
                           topic_perf=topic_perf,
                           attention_students=attention_students,
                           active_tab=active_tab)

@teacher_bp.route('/classrooms/<int:subject_id>/edit', methods=['POST'])
@teacher_bp.route('/subjects/<int:subject_id>/edit', methods=['POST'])
@teacher_required
def edit_classroom(subject_id):
    teacher_id = session['user_id']
    code = request.form.get('code', '').strip()
    name = request.form.get('name', '').strip()
    department = request.form.get('department', '').strip()
    academic_year = request.form.get('academic_year', '').strip()
    description = request.form.get('description', '').strip()

    if not code or not name or not department:
        flash("All fields are required.", "danger")
        return redirect(url_for('teacher.classrooms'))

    SubjectModel.update_subject(subject_id, teacher_id, code, name, department, description, academic_year=academic_year)
    flash(f"Classroom '{name}' updated successfully.", "success")
    return redirect(url_for('teacher.classroom_detail', subject_id=subject_id))

edit_subject = edit_classroom

@teacher_bp.route('/classrooms/<int:subject_id>/delete', methods=['POST'])
@teacher_bp.route('/subjects/<int:subject_id>/delete', methods=['POST'])
@teacher_required
def delete_classroom(subject_id):
    teacher_id = session['user_id']
    SubjectModel.delete_subject(subject_id, teacher_id)
    flash("Classroom and its associated materials/assignments/quizzes have been removed.", "info")
    return redirect(url_for('teacher.classrooms'))

delete_subject = delete_classroom

@teacher_bp.route('/subjects/<int:subject_id>/students')
@teacher_required
def subject_students(subject_id):
    teacher_id = session['user_id']
    subject = SubjectModel.get_by_id(subject_id)
    if not subject or subject['teacher_id'] != teacher_id:
        flash("Classroom not found or unauthorized.", "danger")
        return redirect(url_for('teacher.classrooms'))

    students = SubjectModel.get_enrolled_students(subject_id)
    return render_template('teacher/subject_students.html', subject=subject, students=students)

@teacher_bp.route('/students')
@teacher_required
def students_directory():
    teacher_id = session['user_id']
    query = request.args.get('q', '').strip().lower()
    subject_filter = request.args.get('subject_id', '')

    conn = get_db()
    sql = """
        SELECT DISTINCT u.id, u.name, u.email, u.identifier, u.department, u.year_of_study, u.semester,
               s.id as subject_id, s.name as subject_name, s.code as subject_code, e.enrolled_at,
               (SELECT COUNT(DISTINCT e2.subject_id) FROM enrolments e2 JOIN subjects s2 ON e2.subject_id = s2.id WHERE e2.student_id = u.id AND s2.teacher_id = ?) as subject_count,
               (SELECT COUNT(qa.id) FROM quiz_attempts qa JOIN quizzes q ON qa.quiz_id = q.id JOIN subjects s3 ON q.subject_id = s3.id WHERE qa.student_id = u.id AND s3.teacher_id = ?) as quizzes_taken,
               (SELECT AVG(qa.score_percentage) FROM quiz_attempts qa JOIN quizzes q ON qa.quiz_id = q.id JOIN subjects s4 ON q.subject_id = s4.id WHERE qa.student_id = u.id AND s4.teacher_id = ?) as avg_quiz_score,
               (SELECT COUNT(sub.id) FROM assignment_submissions sub JOIN assignments a ON sub.assignment_id = a.id JOIN subjects s5 ON a.subject_id = s5.id WHERE sub.student_id = u.id AND s5.teacher_id = ? AND sub.status = 'completed') as assignments_completed
        FROM enrolments e
        JOIN subjects s ON e.subject_id = s.id
        JOIN users u ON e.student_id = u.id
        WHERE s.teacher_id = ?
    """
    params = [teacher_id, teacher_id, teacher_id, teacher_id, teacher_id]

    if subject_filter:
        sql += " AND s.id = ?"
        params.append(subject_filter)

    if query:
        sql += " AND (LOWER(u.name) LIKE ? OR LOWER(u.identifier) LIKE ? OR LOWER(u.email) LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%", f"%{query}%"])

    sql += " ORDER BY u.name ASC"
    students = conn.execute(sql, params).fetchall()

    teacher_subjects = SubjectModel.get_teacher_classrooms(teacher_id)
    conn.close()

    attention_list = StatsModel.get_students_needing_attention(teacher_id)
    attention_ids = {a['student_id']: a for a in attention_list}

    return render_template('teacher/students.html',
                           students=students,
                           subjects=teacher_subjects,
                           classrooms=teacher_subjects,
                           search_query=query,
                           current_subject=subject_filter,
                           attention_map=attention_ids)

@teacher_bp.route('/announcements/create', methods=['POST'])
@teacher_required
def create_announcement():
    teacher_id = session['user_id']
    subject_id = request.form.get('subject_id')
    title = request.form.get('title', '').strip()
    message = request.form.get('message', '').strip()

    if not subject_id or not title or not message:
        flash("Classroom, Announcement Title, and Message are required.", "danger")
        return redirect(request.referrer or url_for('teacher.classrooms'))

    subj = SubjectModel.get_by_id(subject_id)
    if not subj or subj['teacher_id'] != teacher_id:
        flash("Classroom not found or unauthorized.", "danger")
        return redirect(url_for('teacher.classrooms'))

    AnnouncementModel.create_announcement(int(subject_id), teacher_id, title, message)
    flash(f"Announcement '{title}' posted to {subj['name']}!", "success")
    return redirect(url_for('teacher.classroom_detail', subject_id=subject_id, tab='announcements'))

@teacher_bp.route('/announcements/<int:announcement_id>/delete', methods=['POST'])
@teacher_required
def delete_announcement(announcement_id):
    teacher_id = session['user_id']
    subject_id = request.form.get('subject_id')
    AnnouncementModel.delete_announcement(announcement_id, teacher_id)
    flash("Announcement deleted.", "info")
    if subject_id:
        return redirect(url_for('teacher.classroom_detail', subject_id=subject_id, tab='announcements'))
    return redirect(request.referrer or url_for('teacher.classrooms'))

@teacher_bp.route('/reports')
@teacher_required
def reports():
    teacher_id = session['user_id']
    report_data = StatsModel.get_teacher_reports(teacher_id)
    return render_template('teacher/reports.html', report_data=report_data)

@teacher_bp.route('/performance')
@teacher_required
def performance():
    teacher_id = session['user_id']
    query = request.args.get('q', '').strip().lower()
    subject_filter = request.args.get('subject_id', '')

    from ai_analysis import PerformanceAnalyzer
    class_analytics = PerformanceAnalyzer.analyze_teacher_class(teacher_id, subject_id=subject_filter or None)

    from database import get_db
    conn = get_db()
    
    # Get distinct students enrolled in this teacher's subjects
    sql = """
        SELECT DISTINCT u.id, u.name, u.email, u.identifier, u.department, u.year_of_study, u.semester,
               (SELECT COUNT(DISTINCT e2.subject_id) FROM enrolments e2 JOIN subjects s2 ON e2.subject_id = s2.id WHERE e2.student_id = u.id AND s2.teacher_id = ?) as subject_count,
               (SELECT COUNT(qa.id) FROM quiz_attempts qa JOIN quizzes q ON qa.quiz_id = q.id JOIN subjects s3 ON q.subject_id = s3.id WHERE qa.student_id = u.id AND s3.teacher_id = ?) as quizzes_taken,
               (SELECT AVG(qa.score_percentage) FROM quiz_attempts qa JOIN quizzes q ON qa.quiz_id = q.id JOIN subjects s4 ON q.subject_id = s4.id WHERE qa.student_id = u.id AND s4.teacher_id = ?) as avg_quiz_score,
               (SELECT COUNT(sub.id) FROM assignment_submissions sub JOIN assignments a ON sub.assignment_id = a.id JOIN subjects s5 ON a.subject_id = s5.id WHERE sub.student_id = u.id AND s5.teacher_id = ? AND sub.status = 'completed') as assignments_completed
        FROM enrolments e
        JOIN subjects s ON e.subject_id = s.id
        JOIN users u ON e.student_id = u.id
        WHERE s.teacher_id = ?
    """
    params = [teacher_id, teacher_id, teacher_id, teacher_id, teacher_id]

    if subject_filter:
        sql += " AND s.id = ?"
        params.append(subject_filter)

    if query:
        sql += " AND (LOWER(u.name) LIKE ? OR LOWER(u.identifier) LIKE ? OR LOWER(u.email) LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%", f"%{query}%"])

    sql += " ORDER BY u.name ASC"
    students = conn.execute(sql, params).fetchall()

    teacher_subjects = SubjectModel.get_teacher_subjects(teacher_id)
    conn.close()

    return render_template('teacher/performance.html',
                           students=students,
                           subjects=teacher_subjects,
                           search_query=query,
                           current_subject=subject_filter,
                           class_analytics=class_analytics)

@teacher_bp.route('/performance/<int:student_id>')
@teacher_required
def student_detail(student_id):
    teacher_id = session['user_id']
    perf_data = StatsModel.get_teacher_student_performance(teacher_id, student_id)
    if not perf_data:
        flash("Student not found or not enrolled in any of your subjects.", "danger")
        return redirect(url_for('teacher.performance'))

    from ai_analysis import PerformanceAnalyzer
    from models import TimetableModel
    from ai_recommendations import RecommendationEngine

    student_analysis = PerformanceAnalyzer.analyze_student(student_id)
    recommendations = RecommendationEngine.get_latest_recommendations(student_id)
    latest_version, latest_adaptations = TimetableModel.get_latest_adaptation(student_id)

    chart_payload = student_analysis['chart_data'] if student_analysis.get('has_data') else perf_data['chart_data']

    return render_template('teacher/student_detail.html',
                           student=perf_data['student'],
                           enrolled_subjects=perf_data['enrolled_subjects'],
                           attempts=perf_data['attempts'],
                           subject_perf=perf_data['subject_perf'],
                           topic_perf=perf_data['topic_perf'],
                           assignments=perf_data['assignments'],
                           chart_data=chart_payload,
                           chart_data_json=json.dumps(chart_payload),
                           student_analysis=student_analysis,
                           recommendations=recommendations,
                           latest_version=latest_version,
                           latest_adaptations=latest_adaptations)

@teacher_bp.route('/profile', methods=['GET', 'POST'])
@teacher_required
def profile():
    teacher_id = session['user_id']
    user = UserModel.get_by_id(teacher_id)

    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'update_info':
            name = request.form.get('name', '').strip()
            department = request.form.get('department', '').strip()
            teacher_identifier = request.form.get('identifier', '').strip()
            subjects_handled = request.form.get('subjects_handled', '').strip()

            if not all([name, department, teacher_identifier, subjects_handled]):
                flash("All personal details are required.", "danger")
            else:
                UserModel.update_profile(teacher_id, name, department, teacher_identifier, subjects_handled=subjects_handled)
                session['name'] = name
                session['department'] = department
                session['identifier'] = teacher_identifier
                flash("Your teacher profile has been updated.", "success")
                return redirect(url_for('teacher.profile'))

        elif action == 'change_password':
            old_pwd = request.form.get('old_password', '')
            new_pwd = request.form.get('new_password', '')
            confirm_pwd = request.form.get('confirm_password', '')

            from compat import check_password_hash
            if not check_password_hash(user['password_hash'], old_pwd):
                flash("Current password is incorrect.", "danger")
            elif new_pwd != confirm_pwd:
                flash("New passwords do not match.", "danger")
            elif len(new_pwd) < 6:
                flash("New password must be at least 6 characters long.", "danger")
            else:
                UserModel.update_password(teacher_id, new_pwd)
                flash("Password updated successfully.", "success")
                return redirect(url_for('teacher.profile'))

    return render_template('teacher/profile.html', user=user)
