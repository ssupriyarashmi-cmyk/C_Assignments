from datetime import datetime, timedelta
from compat import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from routes.auth import student_required
from models import TimetableModel, SubjectModel

timetable_bp = Blueprint('timetable', __name__, url_prefix='/timetable')

@timetable_bp.route('/student')
@student_required
def student_timetable():
    student_id = session['user_id']
    timetable = TimetableModel.get_or_create(student_id)
    sessions = TimetableModel.get_student_sessions(student_id)
    enrolled_subjects = SubjectModel.get_student_subjects(student_id)
    latest_version, latest_adaptations = TimetableModel.get_latest_adaptation(student_id)
    versions = TimetableModel.get_version_history(student_id)

    # Date and calendar mapping for daily presentation
    now = datetime.now()
    today_date = now.date()
    today_day_name = now.strftime('%A')
    today_time_str = now.strftime('%H:%M')
    # Monday of the current calendar week
    monday_date = today_date - timedelta(days=now.weekday())

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    day_date_map = {}
    for idx, d in enumerate(days):
        d_date = monday_date + timedelta(days=idx)
        day_date_map[d] = {
            'date': d_date,
            'date_str': d_date.strftime('%Y-%m-%d'),
            'formatted_date': d_date.strftime('%b %d, %Y'),
            'short_date': d_date.strftime('%a, %b %d'),
            'is_today': (d == today_day_name)
        }

    # Map adaptation reasons by topic and by subject
    adaptation_map = {}
    subject_adaptation_map = {}
    if latest_adaptations:
        for a in latest_adaptations:
            if a.get('topic'):
                topic_key = a['topic'].strip().lower()
                adaptation_map[topic_key] = a
            if a.get('subject_name'):
                subj_key = a['subject_name'].strip().lower()
                subject_adaptation_map[subj_key] = a
            if a.get('subject_id'):
                subject_adaptation_map[str(a['subject_id'])] = a

    daily_schedule = []
    grouped_sessions = {d: [] for d in days}
    total_study_minutes = 0
    total_completed_minutes = 0
    missed_sessions_count = 0
    completed_sessions_count = 0
    pending_sessions_count = 0

    for s in sessions:
        s_item = dict(s)
        day = s_item.get('day_of_week', 'Monday')
        day_info = day_date_map.get(day, {
            'date': today_date,
            'date_str': today_date.strftime('%Y-%m-%d'),
            'formatted_date': today_date.strftime('%b %d, %Y'),
            'short_date': today_date.strftime('%a, %b %d'),
            'is_today': (day == today_day_name)
        })

        s_item['study_date'] = day_info['formatted_date']
        s_item['date_iso'] = day_info['date_str']
        s_item['day_with_date'] = f"{day}, {day_info['formatted_date']}"
        s_item['is_today'] = day_info['is_today']

        # Determine status: Completed, Pending, or Missed
        if s_item['is_completed']:
            s_item['status'] = 'Completed'
            s_item['status_badge'] = 'badge-success'
            if s_item['session_type'] == 'study':
                completed_sessions_count += 1
        elif s_item['session_type'] == 'break':
            s_item['status'] = 'Rest Break'
            s_item['status_badge'] = 'badge-secondary'
        else:
            session_date = day_info['date']
            if session_date < today_date:
                s_item['status'] = 'Missed'
                s_item['status_badge'] = 'badge-danger'
                missed_sessions_count += 1
            elif session_date == today_date and s_item.get('end_time', '23:59') < today_time_str:
                s_item['status'] = 'Missed'
                s_item['status_badge'] = 'badge-danger'
                missed_sessions_count += 1
            else:
                s_item['status'] = 'Pending'
                s_item['status_badge'] = 'badge-warning'
                pending_sessions_count += 1

        # Brief adaptation reason where relevant
        topic_key = s_item.get('topic', '').strip().lower()
        subj_key = s_item.get('subject_name', '').strip().lower()
        subj_id_key = str(s_item.get('subject_id', ''))
        adaptation_reason = None
        if topic_key in adaptation_map:
            ad = adaptation_map[topic_key]
            delta = ad.get('delta_minutes') or ad.get('delta') or 0
            p_level = ad.get('priority_level') or ''
            if delta > 0 or p_level == 'High':
                adaptation_reason = "Additional practice scheduled because of low quiz performance."
            elif delta < 0 or p_level == 'Low':
                adaptation_reason = "Revision schedule optimized for high topic mastery."
            elif ad.get('reason'):
                adaptation_reason = ad['reason']
        elif subj_key in subject_adaptation_map:
            ad = subject_adaptation_map[subj_key]
            delta = ad.get('delta_minutes') or ad.get('delta') or 0
            p_level = ad.get('priority_level') or ''
            if delta > 0 or p_level == 'High':
                adaptation_reason = "Additional practice scheduled because of low quiz performance."
            elif delta < 0 or p_level == 'Low':
                adaptation_reason = "Revision schedule optimized for high topic mastery."
            elif ad.get('reason'):
                adaptation_reason = ad['reason']
        elif subj_id_key in subject_adaptation_map:
            ad = subject_adaptation_map[subj_id_key]
            delta = ad.get('delta_minutes') or ad.get('delta') or 0
            p_level = ad.get('priority_level') or ''
            if delta > 0 or p_level == 'High':
                adaptation_reason = "Additional practice scheduled because of low quiz performance."
            elif delta < 0 or p_level == 'Low':
                adaptation_reason = "Revision schedule optimized for high topic mastery."
            elif ad.get('reason'):
                adaptation_reason = ad['reason']
        elif s_item.get('priority') == 'High':
            adaptation_reason = "Additional practice scheduled because of low quiz performance."
        elif s_item.get('priority') == 'Low':
            adaptation_reason = "Revision schedule optimized for high topic mastery."

        s_item['adaptation_reason'] = adaptation_reason

        if day in grouped_sessions:
            grouped_sessions[day].append(s_item)

        daily_schedule.append(s_item)

        if s_item['session_type'] == 'study':
            total_study_minutes += s_item['duration_minutes']
            if s_item['is_completed']:
                total_completed_minutes += s_item['duration_minutes']

    completion_percentage = round((total_completed_minutes / total_study_minutes * 100), 1) if total_study_minutes > 0 else 0

    # Structured daily days data
    days_data = []
    for d in days:
        d_info = day_date_map[d]
        d_sessions = grouped_sessions[d]
        study_sessions = [s for s in d_sessions if s['session_type'] == 'study']
        days_data.append({
            'day_name': d,
            'date': d_info['formatted_date'],
            'short_date': d_info['short_date'],
            'date_iso': d_info['date_str'],
            'is_today': d_info['is_today'],
            'sessions': d_sessions,
            'total_sessions': len(d_sessions),
            'study_count': len(study_sessions),
            'study_minutes': sum(s['duration_minutes'] for s in study_sessions)
        })

    return render_template('student/timetable.html',
                           timetable=timetable,
                           grouped_sessions=grouped_sessions,
                           daily_schedule=daily_schedule,
                           days_data=days_data,
                           days=days,
                           today_day_name=today_day_name,
                           today_date=today_date.strftime('%b %d, %Y'),
                           enrolled_subjects=enrolled_subjects,
                           total_study_hours=round(total_study_minutes / 60, 1),
                           completed_study_hours=round(total_completed_minutes / 60, 1),
                           completion_percentage=completion_percentage,
                           completed_count=completed_sessions_count,
                           missed_count=missed_sessions_count,
                           pending_count=pending_sessions_count,
                           latest_version=latest_version,
                           latest_adaptations=latest_adaptations,
                           versions=versions)

@timetable_bp.route('/student/adapt', methods=['POST'])
@student_required
def adapt():
    student_id = session['user_id']
    from adaptive_timetable import AdaptiveTimetableEngine
    success, msg, info = AdaptiveTimetableEngine.adapt_timetable(student_id, trigger_reason="Manual student recalculation")
    if success:
        flash(f"✨ {msg}", "success")
    else:
        flash(msg, "warning")
    return redirect(url_for('timetable.student_timetable'))

@timetable_bp.route('/student/generate', methods=['POST'])
@student_required
def generate():
    student_id = session['user_id']
    daily_hours = float(request.form.get('daily_study_hours', 3.0))
    start_time = request.form.get('preferred_start_time', '18:00')
    exam_date = request.form.get('exam_date') or None
    
    # Selected subjects
    selected_subject_ids = request.form.getlist('subject_ids')
    if isinstance(selected_subject_ids, str):
        selected_subject_ids = [selected_subject_ids]

    success, msg = TimetableModel.generate_timetable_schedule(
        student_id=student_id,
        selected_subject_ids=selected_subject_ids,
        daily_hours=daily_hours,
        start_time_str=start_time,
        exam_date=exam_date
    )

    if success:
        flash(msg, "success")
    else:
        flash(msg, "warning")

    return redirect(url_for('timetable.student_timetable'))

@timetable_bp.route('/student/session/add', methods=['POST'])
@student_required
def add_session():
    student_id = session['user_id']
    timetable = TimetableModel.get_or_create(student_id)

    subject_id = request.form.get('subject_id') or None
    subject_name = request.form.get('subject_name', '').strip()
    topic = request.form.get('topic', '').strip() or 'Self Study & Practice'
    day_of_week = request.form.get('day_of_week', 'Monday')
    start_time = request.form.get('start_time', '18:00')
    end_time = request.form.get('end_time', '18:50')
    session_type = request.form.get('session_type', 'study')
    priority = request.form.get('priority', 'Normal')

    # If subject_id provided, fetch name
    if subject_id:
        subj = SubjectModel.get_by_id(subject_id)
        if subj:
            subject_name = subj['name']

    if not subject_name:
        subject_name = "Self Study"

    # Calculate duration in minutes
    try:
        sh, sm = map(int, start_time.split(':'))
        eh, em = map(int, end_time.split(':'))
        dur = (eh * 60 + em) - (sh * 60 + sm)
        if dur <= 0:
            dur = 50
    except Exception:
        dur = 50

    TimetableModel.add_session(
        timetable_id=timetable['id'],
        student_id=student_id,
        subject_id=subject_id,
        subject_name=subject_name,
        topic=topic,
        day_of_week=day_of_week,
        start_time=start_time,
        end_time=end_time,
        duration_minutes=dur,
        session_type=session_type,
        priority=priority
    )

    flash("Study session added successfully!", "success")
    return redirect(url_for('timetable.student_timetable'))

@timetable_bp.route('/student/session/<int:session_id>/delete', methods=['POST'])
@student_required
def delete_session(session_id):
    student_id = session['user_id']
    TimetableModel.delete_session(session_id, student_id)
    flash("Session removed from your timetable.", "info")
    return redirect(url_for('timetable.student_timetable'))

@timetable_bp.route('/student/session/<int:session_id>/toggle', methods=['POST'])
@student_required
def toggle_session(session_id):
    student_id = session['user_id']
    TimetableModel.toggle_session_completed(session_id, student_id)
    next_url = request.form.get('next') or url_for('timetable.student_timetable')
    return redirect(next_url)
