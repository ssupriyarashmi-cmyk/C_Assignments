from compat import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from routes.auth import student_required
from models import (
    UserModel, SubjectModel, MaterialModel, AssignmentModel,
    QuizModel, StatsModel, TimetableModel, AnnouncementModel
)
from database import get_db
from ai_analysis import PerformanceAnalyzer
from ai_recommendations import RecommendationEngine
import json

student_bp = Blueprint('student', __name__, url_prefix='/student')

@student_bp.route('/dashboard')
@student_required
def dashboard():
    student_id = session['user_id']
    stats = StatsModel.get_student_dashboard_stats(student_id)
    subjects = SubjectModel.get_student_classrooms(student_id)
    announcements = AnnouncementModel.get_student_announcements(student_id, limit=4)

    analysis = PerformanceAnalyzer.analyze_student(student_id)
    recommendations = RecommendationEngine.get_latest_recommendations(student_id)
    latest_version, latest_adaptations = TimetableModel.get_latest_adaptation(student_id)

    return render_template('student/dashboard.html',
                           stats=stats,
                           subjects=subjects,
                           classrooms=subjects,
                           announcements=announcements,
                           analysis=analysis,
                           recommendations=recommendations,
                           latest_version=latest_version,
                           latest_adaptations=latest_adaptations,
                           chart_data_json=json.dumps(analysis.get('chart_data', {})))

@student_bp.route('/analytics')
@student_required
def analytics():
    student_id = session['user_id']
    analysis = PerformanceAnalyzer.analyze_student(student_id)
    recommendations = RecommendationEngine.get_latest_recommendations(student_id)
    latest_version, latest_adaptations = TimetableModel.get_latest_adaptation(student_id)
    versions = TimetableModel.get_version_history(student_id)

    return render_template('student/analytics.html',
                           analysis=analysis,
                           recommendations=recommendations,
                           latest_version=latest_version,
                           latest_adaptations=latest_adaptations,
                           versions=versions,
                           chart_data_json=json.dumps(analysis.get('chart_data', {})))

@student_bp.route('/classrooms')
@student_bp.route('/subjects')
@student_required
def classrooms():
    student_id = session['user_id']
    enrolled_classrooms = SubjectModel.get_student_classrooms(student_id)
    return render_template('student/classrooms.html', classrooms=enrolled_classrooms, subjects=enrolled_classrooms)

# Alias for backwards compatibility
subjects = classrooms

@student_bp.route('/classrooms/join', methods=['POST'])
@student_bp.route('/subjects/join', methods=['POST'])
@student_required
def join_classroom():
    student_id = session['user_id']
    enrolment_code = request.form.get('enrolment_code', '').strip()
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest' or \
              request.headers.get('Accept') == 'application/json' or \
              request.form.get('is_ajax') == '1'

    if not enrolment_code:
        if is_ajax:
            return jsonify({'success': False, 'msg': 'Please enter an enrolment code.'}), 400
        flash("Please enter an enrolment code.", "warning")
        return redirect(request.referrer or url_for('student.classrooms'))

    success, msg = SubjectModel.enroll_student(student_id, enrolment_code)
    
    if is_ajax:
        status_code = 200 if success else 400
        subject_info = None
        if success:
            subj = SubjectModel.get_by_enrolment_code(enrolment_code) or SubjectModel.get_by_code(enrolment_code)
            if subj:
                subject_info = {
                    'id': subj['id'],
                    'name': subj['name'],
                    'code': subj['code'],
                    'teacher_name': subj.get('teacher_name', '')
                }
        return jsonify({'success': success, 'msg': msg, 'subject': subject_info}), status_code

    if success:
        flash(msg, "success")
    else:
        flash(msg, "danger")
    return redirect(request.referrer or url_for('student.classrooms'))

join_subject = join_classroom

@student_bp.route('/classrooms/<int:subject_id>')
@student_bp.route('/subjects/<int:subject_id>')
@student_required
def classroom_detail(subject_id):
    student_id = session['user_id']
    if not SubjectModel.is_student_enrolled(student_id, subject_id):
        flash("You are not enrolled in this classroom.", "danger")
        return redirect(url_for('student.classrooms'))

    subject = SubjectModel.get_by_id(subject_id)
    materials = MaterialModel.get_by_subject(subject_id)
    assignments = AssignmentModel.get_subject_assignments_for_student(subject_id, student_id)
    quizzes = QuizModel.get_subject_quizzes_for_student(subject_id, student_id)
    announcements = AnnouncementModel.get_by_subject(subject_id)

    # Student's past quiz attempts in this subject
    conn = get_db()
    my_attempts = conn.execute("""
        SELECT qa.*, q.title as quiz_title, q.topic as quiz_topic
        FROM quiz_attempts qa
        JOIN quizzes q ON qa.quiz_id = q.id
        WHERE qa.student_id = ? AND q.subject_id = ?
        ORDER BY qa.attempted_at DESC
    """, (student_id, subject_id)).fetchall()

    topic_mastery = conn.execute("""
        SELECT qaa.topic,
               COUNT(qaa.id) as total_questions,
               SUM(qaa.is_correct) as correct_questions,
               ROUND(CAST(SUM(qaa.is_correct) AS REAL) / COUNT(qaa.id) * 100.0, 1) as accuracy_pct
        FROM quiz_attempt_answers qaa
        JOIN quiz_attempts qa ON qaa.attempt_id = qa.id
        JOIN quizzes q ON qa.quiz_id = q.id
        WHERE qa.student_id = ? AND q.subject_id = ?
        GROUP BY qaa.topic
        ORDER BY accuracy_pct ASC
    """, (student_id, subject_id)).fetchall()
    conn.close()

    return render_template('student/classroom_detail.html',
                           subject=subject,
                           classroom=subject,
                           materials=materials,
                           assignments=assignments,
                           quizzes=quizzes,
                           announcements=announcements,
                           my_attempts=my_attempts,
                           topic_mastery=topic_mastery)

subject_detail = classroom_detail

@student_bp.route('/profile', methods=['GET', 'POST'])
@student_required
def profile():
    student_id = session['user_id']
    user = UserModel.get_by_id(student_id)

    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'update_info':
            name = request.form.get('name', '').strip()
            department = request.form.get('department', '').strip()
            student_identifier = request.form.get('identifier', '').strip()
            year_of_study = request.form.get('year_of_study', '').strip()
            semester = request.form.get('semester', '').strip()

            if not all([name, department, student_identifier, year_of_study, semester]):
                flash("All personal details are required.", "danger")
            else:
                UserModel.update_profile(student_id, name, department, student_identifier, year_of_study=year_of_study, semester=semester)
                session['name'] = name
                session['department'] = department
                session['identifier'] = student_identifier
                flash("Your profile details have been updated successfully.", "success")
                return redirect(url_for('student.profile'))

        elif action == 'change_password':
            old_pwd = request.form.get('old_password', '')
            new_pwd = request.form.get('new_password', '')
            confirm_pwd = request.form.get('confirm_password', '')

            from compat import check_password_hash
            if not check_password_hash(user['password_hash'], old_pwd):
                flash("Current password is incorrect.", "danger")
            elif new_pwd != confirm_pwd:
                flash("New passwords do not match.", "danger")
            elif len(new_pwd) < 6:
                flash("New password must be at least 6 characters long.", "danger")
            else:
                UserModel.update_password(student_id, new_pwd)
                flash("Password updated successfully.", "success")
                return redirect(url_for('student.profile'))

    return render_template('student/profile.html', user=user)
