#!/usr/bin/env python3
"""
Study Planner - AI-Powered Adaptive Study System Backend Server
Runs an HTTP server with static file serving and RESTful SQLite-backed API.
"""

import http.server
import socketserver
import urllib.parse
import json
import sqlite3
import os
import sys
from datetime import datetime, timedelta

PORT = 8000
DB_FILE = "study_planner.db"

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        avatar TEXT,
        academic_year TEXT,
        course_program TEXT,
        institution TEXT,
        daily_hours REAL DEFAULT 3.0,
        preferred_start TEXT DEFAULT '18:00',
        preferred_end TEXT DEFAULT '21:00'
    );

    CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        code TEXT,
        color TEXT,
        icon TEXT
    );

    CREATE TABLE IF NOT EXISTS topics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        name TEXT,
        mastery_score REAL DEFAULT 70.0,
        tests_taken INTEGER DEFAULT 1,
        status TEXT DEFAULT 'neutral',
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        course_id INTEGER,
        description TEXT,
        due_date TEXT,
        priority TEXT DEFAULT 'Medium',
        status TEXT DEFAULT 'pending',
        reminder_setting TEXT DEFAULT '24 hours before',
        reminder_time TEXT,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        course_id INTEGER,
        exam_date TEXT,
        priority TEXT DEFAULT 'High',
        topics_json TEXT,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS quizzes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        course_id INTEGER,
        difficulty TEXT DEFAULT 'Medium',
        total_questions INTEGER,
        score INTEGER,
        percentage REAL,
        completed_at TEXT,
        topic_breakdown_json TEXT,
        source TEXT DEFAULT 'ai',
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS topic_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        topic_id INTEGER,
        quiz_id INTEGER,
        percentage REAL,
        recorded_at TEXT,
        FOREIGN KEY (topic_id) REFERENCES topics (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS timetable_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day_date TEXT,
        start_time TEXT,
        end_time TEXT,
        duration_mins INTEGER,
        course_id INTEGER,
        topic_id INTEGER,
        is_adaptive INTEGER DEFAULT 0,
        change_delta_mins INTEGER DEFAULT 0,
        change_reason TEXT,
        completed INTEGER DEFAULT 0,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (topic_id) REFERENCES topics (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        message TEXT,
        type TEXT DEFAULT 'insight',
        created_at TEXT,
        read INTEGER DEFAULT 0,
        link_view TEXT
    );
    """)
    conn.commit()

    # Check if empty, seed defaults
    c.execute("SELECT COUNT(*) FROM users")
    if c.fetchone()[0] == 0:
        seed_default_data(conn)
    conn.close()

def seed_default_data(conn):
    c = conn.cursor()
    # 1. User
    c.execute("""
    INSERT INTO users (name, email, password, avatar, academic_year, course_program, institution, daily_hours, preferred_start, preferred_end)
    VALUES ('Alex Morgan', 'alex.morgan@apex.edu', 'study123', '👨‍🎓', 'Year 2, Semester 1', 'B.Sc. Natural & Computer Sciences', 'Apex University', 3.0, '18:00', '21:00')
    """)

    # 2. Courses
    courses = [
        ('Chemistry', 'CHEM201', '#8B5CF6', 'flask'),
        ('Physics', 'PHYS201', '#3B82F6', 'atom'),
        ('Mathematics', 'MATH201', '#EC4899', 'sigma'),
        ('Computer Science', 'CS201', '#10B981', 'code')
    ]
    course_ids = {}
    for name, code, color, icon in courses:
        c.execute("INSERT INTO courses (name, code, color, icon) VALUES (?, ?, ?, ?)", (name, code, color, icon))
        course_ids[name] = c.lastrowid

    # 3. Topics with performance tracking
    # Chemistry: Chemical Bonding (weak: 45->58->72), Thermodynamics (55), Atomic Structure (90), Organic Chemistry (80)
    topics = [
        (course_ids['Chemistry'], 'Atomic Structure', 90.0, 3, 'mastered'),
        (course_ids['Chemistry'], 'Chemical Bonding', 72.0, 3, 'improving'),
        (course_ids['Chemistry'], 'Thermodynamics', 55.0, 2, 'weak'),
        (course_ids['Chemistry'], 'Organic Chemistry', 80.0, 2, 'mastered'),
        
        (course_ids['Physics'], 'Mechanics', 75.0, 2, 'neutral'),
        (course_ids['Physics'], 'Electromagnetism', 60.0, 2, 'weak'),
        (course_ids['Physics'], 'Optics', 82.0, 2, 'mastered'),
        (course_ids['Physics'], 'Waves & Sound', 70.0, 1, 'neutral'),

        (course_ids['Mathematics'], 'Calculus', 88.0, 3, 'mastered'),
        (course_ids['Mathematics'], 'Linear Algebra', 85.0, 2, 'mastered'),
        (course_ids['Mathematics'], 'Probability & Statistics', 65.0, 1, 'weak'),
        (course_ids['Mathematics'], 'Trigonometry', 90.0, 3, 'mastered'),

        (course_ids['Computer Science'], 'Data Structures', 82.0, 2, 'mastered'),
        (course_ids['Computer Science'], 'Algorithms', 68.0, 2, 'weak'),
        (course_ids['Computer Science'], 'Database Systems', 92.0, 3, 'mastered'),
        (course_ids['Computer Science'], 'Operating Systems', 74.0, 1, 'neutral'),
    ]
    topic_ids = {}
    for cid, name, score, count, status in topics:
        c.execute("INSERT INTO topics (course_id, name, mastery_score, tests_taken, status) VALUES (?, ?, ?, ?, ?)",
                  (cid, name, score, count, status))
        topic_ids[name] = c.lastrowid

    # 4. Topic History for trend demonstration (Chemical Bonding: 45% -> 58% -> 72%)
    cb_id = topic_ids['Chemical Bonding']
    c.execute("INSERT INTO topic_history (topic_id, quiz_id, percentage, recorded_at) VALUES (?, 1, 45.0, '2026-11-01 19:30:00')", (cb_id,))
    c.execute("INSERT INTO topic_history (topic_id, quiz_id, percentage, recorded_at) VALUES (?, 2, 58.0, '2026-11-06 20:00:00')", (cb_id,))
    c.execute("INSERT INTO topic_history (topic_id, quiz_id, percentage, recorded_at) VALUES (?, 3, 72.0, '2026-11-12 18:45:00')", (cb_id,))

    # Thermodynamics: 50% -> 55%
    th_id = topic_ids['Thermodynamics']
    c.execute("INSERT INTO topic_history (topic_id, quiz_id, percentage, recorded_at) VALUES (?, 1, 50.0, '2026-11-02 20:15:00')", (th_id,))
    c.execute("INSERT INTO topic_history (topic_id, quiz_id, percentage, recorded_at) VALUES (?, 3, 55.0, '2026-11-12 18:45:00')", (th_id,))

    # 5. Exams
    now = datetime.now()
    c.execute("""
    INSERT INTO exams (title, course_id, exam_date, priority, topics_json)
    VALUES (?, ?, ?, ?, ?)
    """, (
        'Chemistry Internal Assessment',
        course_ids['Chemistry'],
        (now + timedelta(days=6)).strftime('%Y-%m-%d'),
        'High',
        json.dumps(['Atomic Structure', 'Chemical Bonding', 'Thermodynamics', 'Organic Chemistry'])
    ))
    c.execute("""
    INSERT INTO exams (title, course_id, exam_date, priority, topics_json)
    VALUES (?, ?, ?, ?, ?)
    """, (
        'Mathematics Midterm',
        course_ids['Mathematics'],
        (now + timedelta(days=12)).strftime('%Y-%m-%d'),
        'High',
        json.dumps(['Calculus', 'Linear Algebra', 'Trigonometry'])
    ))
    c.execute("""
    INSERT INTO exams (title, course_id, exam_date, priority, topics_json)
    VALUES (?, ?, ?, ?, ?)
    """, (
        'Physics Unit Test',
        course_ids['Physics'],
        (now + timedelta(days=18)).strftime('%Y-%m-%d'),
        'Medium',
        json.dumps(['Mechanics', 'Electromagnetism'])
    ))

    # 6. Assignments with Reminders
    c.execute("""
    INSERT INTO assignments (title, course_id, description, due_date, priority, status, reminder_setting, reminder_time)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'Unit 2 Record: Mechanics Lab',
        course_ids['Physics'],
        'Complete the lab report on rotational inertia and error analysis.',
        (now + timedelta(days=3)).strftime('%Y-%m-%d 17:00'),
        'High',
        'pending',
        '24 hours before',
        (now + timedelta(days=2)).strftime('%Y-%m-%d 17:00')
    ))
    c.execute("""
    INSERT INTO assignments (title, course_id, description, due_date, priority, status, reminder_setting, reminder_time)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'Thermodynamics Problem Set',
        course_ids['Chemistry'],
        'Solve enthalpy and Gibbs free energy numerical problems from Chapter 4.',
        (now + timedelta(days=5)).strftime('%Y-%m-%d 23:59'),
        'Medium',
        'pending',
        '12 hours before',
        (now + timedelta(days=5)).strftime('%Y-%m-%d 11:59')
    ))
    c.execute("""
    INSERT INTO assignments (title, course_id, description, due_date, priority, status, reminder_setting, reminder_time)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'Binary Search Tree Implementation',
        course_ids['Computer Science'],
        'Implement AVL self-balancing tree insert and delete routines in Python/C++.',
        (now + timedelta(days=8)).strftime('%Y-%m-%d 18:00'),
        'Medium',
        'pending',
        '2 days before',
        (now + timedelta(days=6)).strftime('%Y-%m-%d 18:00')
    ))

    # 7. Past Quizzes
    c.execute("""
    INSERT INTO quizzes (title, course_id, difficulty, total_questions, score, percentage, completed_at, topic_breakdown_json, source)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'Chemistry Assessment #3',
        course_ids['Chemistry'],
        'Medium',
        20,
        14,
        70.0,
        (now - timedelta(days=2)).strftime('%Y-%m-%d %H:%M'),
        json.dumps({
            'Atomic Structure': {'score': 9, 'total': 10, 'percentage': 90.0},
            'Chemical Bonding': {'score': 7, 'total': 10, 'percentage': 70.0},
            'Thermodynamics': {'score': 5, 'total': 9, 'percentage': 55.5},
            'Organic Chemistry': {'score': 8, 'total': 10, 'percentage': 80.0}
        }),
        'ai'
    ))

    # 8. Today's Adaptive Timetable (respecting 3 hours: 18:00 - 21:00)
    today_str = now.strftime('%Y-%m-%d')
    c.execute("""
    INSERT INTO timetable_sessions (day_date, start_time, end_time, duration_mins, course_id, topic_id, is_adaptive, change_delta_mins, change_reason, completed)
    VALUES (?, '18:00', '18:45', 45, ?, ?, 1, -15, 'Reduced because performance is strong (88%) and exam is 12 days away.', 0)
    """, (today_str, course_ids['Mathematics'], topic_ids['Trigonometry']))

    c.execute("""
    INSERT INTO timetable_sessions (day_date, start_time, end_time, duration_mins, course_id, topic_id, is_adaptive, change_delta_mins, change_reason, completed)
    VALUES (?, '18:45', '19:35', 50, ?, ?, 1, 20, 'Increased: Exam is in 6 days and past quiz score was 58% (now improving to 72%).', 0)
    """, (today_str, course_ids['Chemistry'], topic_ids['Chemical Bonding']))

    c.execute("""
    INSERT INTO timetable_sessions (day_date, start_time, end_time, duration_mins, course_id, topic_id, is_adaptive, change_delta_mins, change_reason, completed)
    VALUES (?, '19:35', '20:15', 40, ?, ?, 1, 10, 'Increased: Lowest topic score (55%) with upcoming assignment due in 5 days.', 0)
    """, (today_str, course_ids['Chemistry'], topic_ids['Thermodynamics']))

    c.execute("""
    INSERT INTO timetable_sessions (day_date, start_time, end_time, duration_mins, course_id, topic_id, is_adaptive, change_delta_mins, change_reason, completed)
    VALUES (?, '20:15', '21:00', 45, ?, ?, 1, -15, 'Adjusted for Physics assignment due in 3 days; Mechanics lab review.', 0)
    """, (today_str, course_ids['Physics'], topic_ids['Mechanics']))

    # 9. Notifications
    c.execute("""
    INSERT INTO notifications (title, message, type, created_at, read, link_view)
    VALUES (?, ?, ?, ?, 0, 'planner')
    """, (
        'Timetable Adapted by AI',
        'Your study timetable was updated: Chemistry (+30m on Chemical Bonding & Thermodynamics) prioritizing your approaching exam in 6 days.',
        'adaptive',
        (now - timedelta(hours=2)).strftime('%Y-%m-%d %H:%M')
    ))

    c.execute("""
    INSERT INTO notifications (title, message, type, created_at, read, link_view)
    VALUES (?, ?, ?, ?, 0, 'assignments')
    """, (
        'Assignment Reminder',
        'Physics "Unit 2 Record" is due in 3 days (Nov 17). Reminder set for 24h prior.',
        'assignment',
        (now - timedelta(hours=5)).strftime('%Y-%m-%d %H:%M')
    ))

    c.execute("""
    INSERT INTO notifications (title, message, type, created_at, read, link_view)
    VALUES (?, ?, ?, ?, 1, 'progress')
    """, (
        'AI Performance Milestone',
        'You have improved by +14% in Chemical Bonding across your last two mock tests! Keep up the momentum.',
        'insight',
        (now - timedelta(days=1)).strftime('%Y-%m-%d %H:%M')
    ))

    conn.commit()

class StudyPlannerHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data, default=str).encode('utf-8'))

    def read_json_body(self):
        length = int(self.headers.get('Content-Length', 0))
        if length > 0:
            return json.loads(self.rfile.read(length).decode('utf-8'))
        return {}

    def do_GET(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path

        if path.startswith('/api/'):
            self.handle_api_get(path, url_parts.query)
            return

        # Serve static file
        if path == '/' or path == '':
            self.path = '/index.html'
        super().do_GET()

    def handle_api_get(self, path, query):
        conn = get_db()
        c = conn.cursor()

        if path == '/api/bootstrap':
            # Returns all state needed by UI
            c.execute("SELECT * FROM users LIMIT 1")
            user_row = c.fetchone()
            user = dict(user_row) if user_row else {}

            c.execute("SELECT * FROM courses")
            courses = [dict(r) for r in c.fetchall()]

            c.execute("SELECT * FROM topics")
            topics = [dict(r) for r in c.fetchall()]

            c.execute("SELECT * FROM assignments ORDER BY due_date ASC")
            assignments = [dict(r) for r in c.fetchall()]

            c.execute("SELECT * FROM exams ORDER BY exam_date ASC")
            exams = []
            for r in c.fetchall():
                d = dict(r)
                d['topics'] = json.loads(d['topics_json']) if d.get('topics_json') else []
                exams.append(d)

            c.execute("SELECT * FROM quizzes ORDER BY completed_at DESC")
            quizzes = []
            for r in c.fetchall():
                d = dict(r)
                d['topic_breakdown'] = json.loads(d['topic_breakdown_json']) if d.get('topic_breakdown_json') else {}
                quizzes.append(d)

            c.execute("SELECT * FROM topic_history ORDER BY recorded_at ASC")
            history = [dict(r) for r in c.fetchall()]

            c.execute("SELECT * FROM timetable_sessions ORDER BY start_time ASC")
            sessions = [dict(r) for r in c.fetchall()]

            c.execute("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20")
            notifications = [dict(r) for r in c.fetchall()]

            conn.close()

            # Attach topics to courses
            for course in courses:
                course['topics'] = [t for t in topics if t['course_id'] == course['id']]
                scores = [t['mastery_score'] for t in course['topics'] if t.get('mastery_score')]
                course['average_performance'] = round(sum(scores)/len(scores), 1) if scores else 0
                course['weak_topics_count'] = len([t for t in course['topics'] if t['mastery_score'] < 65])
                course['upcoming_tests_count'] = len([e for e in exams if e['course_id'] == course['id']])

            self.send_json({
                'user': user,
                'courses': courses,
                'topics': topics,
                'assignments': assignments,
                'exams': exams,
                'quizzes': quizzes,
                'topic_history': history,
                'timetable': sessions,
                'notifications': notifications
            })
            return

        conn.close()
        self.send_json({'error': 'Endpoint not found'}, 404)

    def do_POST(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path
        body = self.read_json_body()

        conn = get_db()
        c = conn.cursor()

        if path == '/api/reset-demo':
            c.executescript("""
            DELETE FROM users;
            DELETE FROM courses;
            DELETE FROM topics;
            DELETE FROM assignments;
            DELETE FROM exams;
            DELETE FROM quizzes;
            DELETE FROM topic_history;
            DELETE FROM timetable_sessions;
            DELETE FROM notifications;
            """)
            seed_default_data(conn)
            conn.close()
            self.send_json({'success': True, 'message': 'Demo data reset successfully.'})
            return

        if path == '/api/auth/login':
            email = body.get('email', '')
            password = body.get('password', '')
            c.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email, password))
            user = c.fetchone()
            conn.close()
            if user:
                self.send_json({'success': True, 'user': dict(user)})
            else:
                self.send_json({'success': False, 'message': 'Invalid credentials'}, 401)
            return

        if path == '/api/auth/signup':
            name = body.get('name', 'Student')
            email = body.get('email', '')
            password = body.get('password', '')
            c.execute("INSERT INTO users (name, email, password, daily_hours) VALUES (?, ?, ?, 3.0)",
                      (name, email, password))
            conn.commit()
            uid = c.lastrowid
            c.execute("SELECT * FROM users WHERE id = ?", (uid,))
            user = dict(c.fetchone())
            conn.close()
            self.send_json({'success': True, 'user': user})
            return

        if path == '/api/courses':
            name = body.get('name')
            code = body.get('code', '')
            color = body.get('color', '#8B5CF6')
            icon = body.get('icon', 'book')
            c.execute("INSERT INTO courses (name, code, color, icon) VALUES (?, ?, ?, ?)", (name, code, color, icon))
            cid = c.lastrowid
            # Optionally add initial topics
            initial_topics = body.get('topics', [])
            for tname in initial_topics:
                c.execute("INSERT INTO topics (course_id, name, mastery_score, tests_taken, status) VALUES (?, ?, 70.0, 0, 'neutral')",
                          (cid, tname))
            conn.commit()
            conn.close()
            self.send_json({'success': True, 'id': cid})
            return

        if path == '/api/topics':
            course_id = body.get('course_id')
            name = body.get('name')
            c.execute("INSERT INTO topics (course_id, name, mastery_score, tests_taken, status) VALUES (?, ?, 70.0, 0, 'neutral')",
                      (course_id, name))
            conn.commit()
            tid = c.lastrowid
            conn.close()
            self.send_json({'success': True, 'id': tid})
            return

        if path == '/api/assignments':
            title = body.get('title')
            course_id = body.get('course_id')
            description = body.get('description', '')
            due_date = body.get('due_date')
            priority = body.get('priority', 'Medium')
            reminder_setting = body.get('reminder_setting', '24 hours before')
            reminder_time = body.get('reminder_time', '')

            c.execute("""
            INSERT INTO assignments (title, course_id, description, due_date, priority, status, reminder_setting, reminder_time)
            VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
            """, (title, course_id, description, due_date, priority, reminder_setting, reminder_time))
            conn.commit()
            aid = c.lastrowid

            # Also create notification entry for reminder
            c.execute("""
            INSERT INTO notifications (title, message, type, created_at, read, link_view)
            VALUES (?, ?, 'assignment', ?, 0, 'assignments')
            """, (
                f"Reminder Set: {title}",
                f"Alert scheduled {reminder_setting} for due date {due_date}",
                datetime.now().strftime('%Y-%m-%d %H:%M')
            ))
            conn.commit()
            conn.close()
            self.send_json({'success': True, 'id': aid})
            return

        if path == '/api/exams':
            title = body.get('title')
            course_id = body.get('course_id')
            exam_date = body.get('exam_date')
            priority = body.get('priority', 'High')
            topics = body.get('topics', [])
            c.execute("""
            INSERT INTO exams (title, course_id, exam_date, priority, topics_json)
            VALUES (?, ?, ?, ?, ?)
            """, (title, course_id, exam_date, priority, json.dumps(topics)))
            conn.commit()
            eid = c.lastrowid

            # Add notification
            c.execute("""
            INSERT INTO notifications (title, message, type, created_at, read, link_view)
            VALUES (?, ?, 'exam', ?, 0, 'planner')
            """, (
                f"Exam Scheduled: {title}",
                f"Date set for {exam_date}. AI Timetable will ramp up revision as the exam nears.",
                datetime.now().strftime('%Y-%m-%d %H:%M')
            ))
            conn.commit()
            conn.close()
            self.send_json({'success': True, 'id': eid})
            return

        if path == '/api/quizzes':
            title = body.get('title')
            course_id = body.get('course_id')
            difficulty = body.get('difficulty', 'Medium')
            total = body.get('total_questions', 0)
            score = body.get('score', 0)
            percentage = round((score / total * 100), 1) if total > 0 else 0
            breakdown = body.get('topic_breakdown', {})
            source = body.get('source', 'ai')
            completed_at = datetime.now().strftime('%Y-%m-%d %H:%M')

            c.execute("""
            INSERT INTO quizzes (title, course_id, difficulty, total_questions, score, percentage, completed_at, topic_breakdown_json, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (title, course_id, difficulty, total, score, percentage, completed_at, json.dumps(breakdown), source))
            qid = c.lastrowid

            # Update topic scores and history
            weak_topics = []
            strong_topics = []
            for topic_name, perf in breakdown.items():
                c.execute("SELECT id, mastery_score, tests_taken FROM topics WHERE course_id = ? AND name = ?",
                          (course_id, topic_name))
                t_row = c.fetchone()
                if t_row:
                    t_id = t_row['id']
                    old_score = t_row['mastery_score']
                    tests_count = t_row['tests_taken'] + 1
                    t_pct = perf.get('percentage', 0.0)

                    # Exponential moving average / blended score
                    new_mastery = round(0.6 * t_pct + 0.4 * old_score, 1) if tests_count > 1 else t_pct
                    status = 'mastered' if new_mastery >= 80 else ('weak' if new_mastery < 65 else 'improving')

                    c.execute("UPDATE topics SET mastery_score = ?, tests_taken = ?, status = ? WHERE id = ?",
                              (new_mastery, tests_count, status, t_id))
                    c.execute("INSERT INTO topic_history (topic_id, quiz_id, percentage, recorded_at) VALUES (?, ?, ?, ?)",
                              (t_id, qid, t_pct, completed_at))

                    if new_mastery < 65:
                        weak_topics.append(topic_name)
                    else:
                        strong_topics.append(topic_name)

            # Insert adaptation notification
            weak_str = ", ".join(weak_topics) if weak_topics else "None"
            c.execute("""
            INSERT INTO notifications (title, message, type, created_at, read, link_view)
            VALUES (?, ?, 'adaptive', ?, 0, 'planner')
            """, (
                f"Quiz Evaluated: {percentage}%",
                f"Topic performance analyzed. Weak areas flagged ({weak_str}). AI Timetable automatically re-balanced.",
                completed_at
            ))

            conn.commit()
            conn.close()
            self.send_json({
                'success': True,
                'quiz_id': qid,
                'percentage': percentage,
                'weak_topics': weak_topics,
                'strong_topics': strong_topics
            })
            return

        if path == '/api/notifications/mark-read':
            c.execute("UPDATE notifications SET read = 1")
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        conn.close()
        self.send_json({'error': 'Endpoint not found'}, 404)

    def do_PUT(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path
        body = self.read_json_body()

        conn = get_db()
        c = conn.cursor()

        if path == '/api/profile':
            c.execute("""
            UPDATE users SET
                name = COALESCE(?, name),
                academic_year = COALESCE(?, academic_year),
                course_program = COALESCE(?, course_program),
                institution = COALESCE(?, institution),
                daily_hours = COALESCE(?, daily_hours),
                preferred_start = COALESCE(?, preferred_start),
                preferred_end = COALESCE(?, preferred_end)
            WHERE id = (SELECT id FROM users LIMIT 1)
            """, (
                body.get('name'),
                body.get('academic_year'),
                body.get('course_program'),
                body.get('institution'),
                body.get('daily_hours'),
                body.get('preferred_start'),
                body.get('preferred_end')
            ))
            conn.commit()
            c.execute("SELECT * FROM users LIMIT 1")
            user = dict(c.fetchone())
            conn.close()
            self.send_json({'success': True, 'user': user})
            return

        if path.startswith('/api/assignments/'):
            aid = path.split('/')[-1]
            status = body.get('status')
            c.execute("UPDATE assignments SET status = ? WHERE id = ?", (status, aid))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        if path.startswith('/api/timetable/sessions/'):
            sid = path.split('/')[-1]
            completed = body.get('completed', 0)
            c.execute("UPDATE timetable_sessions SET completed = ? WHERE id = ?", (completed, sid))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        if path == '/api/timetable/save-all':
            sessions = body.get('sessions', [])
            c.execute("DELETE FROM timetable_sessions")
            for s in sessions:
                c.execute("""
                INSERT INTO timetable_sessions (day_date, start_time, end_time, duration_mins, course_id, topic_id, is_adaptive, change_delta_mins, change_reason, completed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    s.get('day_date'),
                    s.get('start_time'),
                    s.get('end_time'),
                    s.get('duration_mins'),
                    s.get('course_id'),
                    s.get('topic_id'),
                    s.get('is_adaptive', 1),
                    s.get('change_delta_mins', 0),
                    s.get('change_reason', ''),
                    s.get('completed', 0)
                ))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        conn.close()
        self.send_json({'error': 'Endpoint not found'}, 404)

    def do_DELETE(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path
        conn = get_db()
        c = conn.cursor()

        if path.startswith('/api/assignments/'):
            aid = path.split('/')[-1]
            c.execute("DELETE FROM assignments WHERE id = ?", (aid,))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        if path.startswith('/api/exams/'):
            eid = path.split('/')[-1]
            c.execute("DELETE FROM exams WHERE id = ?", (eid,))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        if path.startswith('/api/courses/'):
            cid = path.split('/')[-1]
            c.execute("DELETE FROM courses WHERE id = ?", (cid,))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        if path.startswith('/api/topics/'):
            tid = path.split('/')[-1]
            c.execute("DELETE FROM topics WHERE id = ?", (tid,))
            conn.commit()
            conn.close()
            self.send_json({'success': True})
            return

        conn.close()
        self.send_json({'error': 'Endpoint not found'}, 404)

def run():
    init_db()
    with socketserver.TCPServer(("", PORT), StudyPlannerHandler) as httpd:
        print(f"Study Planner running on http://localhost:{PORT}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server.")

if __name__ == '__main__':
    run()
