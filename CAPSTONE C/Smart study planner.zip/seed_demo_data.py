"""
Demo Data Initialization Script
Populates the Smart Study Planner application with realistic academic sample data:
- Demo Teacher and Student accounts with secure password hashes
- 5 Core Subjects with specific enrolment codes
- 30 Preloaded Topics
- Uploaded Study Materials (with local sample files and educational references)
- Realistic Assignments with relative deadlines (pending and completed)
- Teacher-created Quizzes with MCQs and explanations
- Multi-attempt Quiz History demonstrating Strong, Weak, Improving, and Declining topics
- Initial and AI-Adapted Timetables with detailed change explanations

Safe & Idempotent: Can be run multiple times without creating duplicates.
"""

import os
import sqlite3
from datetime import datetime, timedelta
from config import Config
from database import init_db, get_db
from compat import generate_password_hash
from ai_quiz import QUESTION_BANK

def seed():
    print("=" * 60)
    print("SMART STUDY PLANNER - DEMO DATA INITIALIZATION")
    print("=" * 60)

    # 1. Initialize DB tables and migrations
    init_db()
    conn = get_db()
    cursor = conn.cursor()

    summary = {
        'users': 0,
        'subjects': 0,
        'enrolments': 0,
        'topics': 0,
        'materials': 0,
        'assignments': 0,
        'submissions': 0,
        'quizzes': 0,
        'questions': 0,
        'attempts': 0,
        'timetable_sessions': 0,
        'timetable_versions': 0
    }

    # =========================================================
    # A. Demo Accounts
    # =========================================================
    teacher_email = "teacher@studyglow.com"
    student_email = "student@studyglow.com"

    # Teacher Account
    teacher = cursor.execute("SELECT id FROM users WHERE email = ?", (teacher_email,)).fetchone()
    if not teacher:
        t_hash = generate_password_hash("Teacher@123")
        cursor.execute("""
            INSERT INTO users (role, name, email, password_hash, identifier, department, subjects_handled)
            VALUES ('teacher', 'Demo Teacher', ?, ?, 'TCH001', 'Computer Science and Engineering',
                    'Programming for Problem Solving, Engineering Mathematics, Engineering Physics, Fundamentals of AI, Digital Electronics')
        """, (teacher_email, t_hash))
        teacher_id = cursor.lastrowid
        summary['users'] += 1
        print(f"  ✓ Created Demo Teacher account: {teacher_email}")
    else:
        teacher_id = teacher['id']
        print(f"  • Demo Teacher exists (ID: {teacher_id})")

    # Student Account
    student = cursor.execute("SELECT id FROM users WHERE email = ?", (student_email,)).fetchone()
    if not student:
        s_hash = generate_password_hash("Student@123")
        cursor.execute("""
            INSERT INTO users (role, name, email, password_hash, identifier, department, year_of_study, semester)
            VALUES ('student', 'Demo Student', ?, ?, 'AIML001', 'Artificial Intelligence and Machine Learning', 'First Year', 'First Semester')
        """, (student_email, s_hash))
        student_id = cursor.lastrowid
        
        # Default student timetable configuration
        cursor.execute("""
            INSERT INTO timetables (student_id, title, daily_study_hours, preferred_start_time, preferred_end_time, exam_date)
            VALUES (?, 'Demo Weekly Study Schedule', 3.0, '18:00', '21:30', ?)
        """, (student_id, (datetime.now() + timedelta(days=21)).strftime("%Y-%m-%d")))

        summary['users'] += 1
        print(f"  ✓ Created Demo Student account: {student_email}")
    else:
        student_id = student['id']
        print(f"  • Demo Student exists (ID: {student_id})")

    # =========================================================
    # B. Preload 5 Subjects & Enrolment Codes
    # =========================================================
    subjects_data = [
        {
            "code": "PPS101",
            "name": "Programming for Problem Solving",
            "enrolment_code": "PPS101",
            "description": "Structured programming in C, algorithms, memory pointers, and problem solving paradigms.",
            "department": "Computer Science and Engineering"
        },
        {
            "code": "MAT102",
            "name": "Engineering Mathematics",
            "enrolment_code": "MAT102",
            "description": "Linear algebra, matrix eigenvalues, differential & integral calculus, and probability theory.",
            "department": "Mathematics"
        },
        {
            "code": "PHY103",
            "name": "Engineering Physics",
            "enrolment_code": "PHY103",
            "description": "Quantum mechanics, semiconductor physics, dielectric polarization, and laser optics.",
            "department": "Physics"
        },
        {
            "code": "AIML104",
            "name": "Fundamentals of Artificial Intelligence",
            "enrolment_code": "AIML104",
            "description": "Intelligent agents, machine learning algorithms, deep neural networks, and generative models.",
            "department": "Artificial Intelligence and Machine Learning"
        },
        {
            "code": "DEC105",
            "name": "Digital Electronics",
            "enrolment_code": "DEC105",
            "description": "Binary logic, Boolean theorems, combinational logic design, and sequential flip-flops.",
            "department": "Electronics and Communication"
        }
    ]

    subject_id_map = {}
    for s_info in subjects_data:
        existing_subj = cursor.execute("SELECT id FROM subjects WHERE code = ?", (s_info['code'],)).fetchone()
        if not existing_subj:
            cursor.execute("""
                INSERT INTO subjects (teacher_id, code, name, enrolment_code, description, department)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (teacher_id, s_info['code'], s_info['name'], s_info['enrolment_code'], s_info['description'], s_info['department']))
            subj_id = cursor.lastrowid
            summary['subjects'] += 1
            print(f"  ✓ Created Subject: {s_info['name']} (Code: {s_info['code']})")
        else:
            subj_id = existing_subj['id']
            # Ensure enrolment_code matches standard
            cursor.execute("UPDATE subjects SET enrolment_code = ? WHERE id = ?", (s_info['enrolment_code'], subj_id))
        subject_id_map[s_info['code']] = subj_id

        # Enrol Demo Student in all 5 subjects
        enrolled = cursor.execute("SELECT id FROM enrolments WHERE student_id = ? AND subject_id = ?", (student_id, subj_id)).fetchone()
        if not enrolled:
            cursor.execute("INSERT INTO enrolments (student_id, subject_id) VALUES (?, ?)", (student_id, subj_id))
            summary['enrolments'] += 1

    # Also handle the user's specific test class CSA0207 if present
    csa_subj = cursor.execute("SELECT id FROM subjects WHERE code = 'CSA0207'").fetchone()
    if csa_subj:
        # Enrol demo student in CSA0207 as well
        if not cursor.execute("SELECT id FROM enrolments WHERE student_id = ? AND subject_id = ?", (student_id, csa_subj['id'])).fetchone():
            cursor.execute("INSERT INTO enrolments (student_id, subject_id) VALUES (?, ?)", (student_id, csa_subj['id']))
            summary['enrolments'] += 1

    # =========================================================
    # C. Preload Topics (Section 13.D)
    # =========================================================
    topics_catalog = {
        "PPS101": [
            "Introduction to C Programming", "Variables and Data Types", "Operators and Expressions",
            "Conditional Statements", "Loops", "Arrays", "Functions", "Pointers"
        ],
        "MAT102": [
            "Matrices", "Differential Calculus", "Integral Calculus", "Differential Equations", "Probability"
        ],
        "PHY103": [
            "Quantum Physics", "Semiconductor Physics", "Dielectrics", "Crystal Structures", "Optical Properties"
        ],
        "AIML104": [
            "Introduction to AI", "Machine Learning Fundamentals", "Supervised Learning",
            "Unsupervised Learning", "Neural Networks", "Generative AI"
        ],
        "DEC105": [
            "Number Systems", "Boolean Algebra", "Logic Gates", "Combinational Circuits",
            "Sequential Circuits", "Flip-Flops"
        ]
    }

    for code, t_list in topics_catalog.items():
        s_id = subject_id_map[code]
        for t_name in t_list:
            existing_t = cursor.execute("SELECT id FROM topics WHERE subject_id = ? AND name = ?", (s_id, t_name)).fetchone()
            if not existing_t:
                cursor.execute("""
                    INSERT INTO topics (subject_id, name, description)
                    VALUES (?, ?, ?)
                """, (s_id, t_name, f"Curriculum topic for {code}: {t_name}"))
                summary['topics'] += 1

    # =========================================================
    # D. Preload Study Materials (Local Files & Resource Links)
    # =========================================================
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

    materials_data = [
        {
            "code": "PPS101",
            "title": "C Pointer Memory Allocation & Pointer Arithmetic Guide",
            "topic": "Pointers",
            "description": "Comprehensive reference guide explaining pointer declaration, dereferencing, and dynamic heap memory.",
            "material_type": "file",
            "filename": "C_Pointers_Comprehensive_Guide.txt",
            "content": "POINTERS & MEMORY MANAGEMENT IN C\n1. Memory Addresses: Pointer variables store hexadecimal memory addresses of other variables.\n2. Dereferencing Operator (*): Accesses the value stored at the referenced memory address.\n3. Pointer Arithmetic: Incrementing a pointer (ptr++) advances it by sizeof(*ptr) bytes.\n4. Dynamic Allocation: malloc() allocates raw heap memory, calloc() initializes to zero, and free() deallocates.\n",
            "file_type": "txt"
        },
        {
            "code": "PPS101",
            "title": "Structured Iteration & Nested Loops in C",
            "topic": "Loops",
            "description": "In-depth guide on for, while, and do-while loops with time complexity considerations.",
            "material_type": "link",
            "external_link": "https://www.geeksforgeeks.org/c-loops/"
        },
        {
            "code": "MAT102",
            "title": "Matrix Eigenvalues & Cayley-Hamilton Handout",
            "topic": "Matrices",
            "description": "Mathematical derivations of characteristic equations, modal matrices, and matrix diagonalization.",
            "material_type": "file",
            "filename": "Matrix_Eigenvalues_Derivations.txt",
            "content": "LINEAR ALGEBRA: EIGENVALUES & EIGENVECTORS\n1. Characteristic Equation: det(A - lambda * I) = 0.\n2. Properties: Sum of eigenvalues equals trace(A); product equals det(A).\n3. Cayley-Hamilton Theorem: Every square matrix satisfies its own characteristic polynomial equation.\n4. Diagonalization: If A has n linearly independent eigenvectors, A = P * D * P^(-1).\n",
            "file_type": "txt"
        },
        {
            "code": "PHY103",
            "title": "Semiconductor Bandgap & Carrier Mobility Notes",
            "topic": "Semiconductor Physics",
            "description": "Detailed lecture notes covering intrinsic carrier density, donor/acceptor doping, and Fermi level shifts.",
            "material_type": "file",
            "filename": "Semiconductor_Physics_Lecture_Notes.txt",
            "content": "SEMICONDUCTOR PHYSICS\n1. Energy Bands: Valence band (bound electrons) separated by bandgap Eg from conduction band (free electrons).\n2. Intrinsic Semiconductors: Pure silicon/germanium; ni = pi = intrinsic carrier concentration.\n3. Extrinsic Doping: Group V donors create n-type material; Group III acceptors create p-type material.\n4. Fermi Level: In intrinsic semiconductors, Ef sits near midgap; in n-type, it shifts upward toward Ec.\n",
            "file_type": "txt"
        },
        {
            "code": "PHY103",
            "title": "Dielectric Polarization & Clausius-Mossotti Derivation",
            "topic": "Dielectrics",
            "description": "Explains dielectric permittivity, electronic and ionic polarization, and loss tangents.",
            "material_type": "link",
            "external_link": "https://en.wikipedia.org/wiki/Dielectric"
        },
        {
            "code": "AIML104",
            "title": "Backpropagation & Gradient Descent Mathematical Walkthrough",
            "topic": "Neural Networks",
            "description": "Derivation of the multivariable calculus chain rule applied to multilayer perceptron weight updates.",
            "material_type": "file",
            "filename": "Neural_Networks_Backpropagation_Guide.txt",
            "content": "DEEP LEARNING: BACKPROPAGATION ALGORITHM\n1. Forward Pass: Computes layer-by-layer activations a = sigma(W * x + b).\n2. Loss Calculation: Mean Squared Error or Categorical Cross-Entropy measuring prediction error.\n3. Backward Pass: Uses multivariate chain rule dL/dW = dL/da * da/dz * dz/dW.\n4. Weight Update: Gradient descent rule W = W - eta * (dL/dW).\n",
            "file_type": "txt"
        },
        {
            "code": "DEC105",
            "title": "Karnaugh Map Minimization & Logic Gate Realizations",
            "topic": "Boolean Algebra",
            "description": "Step-by-step visual method for simplifying boolean algebraic equations into minimal Sum of Products (SOP).",
            "material_type": "file",
            "filename": "Karnaugh_Maps_and_Logic_Minimization.txt",
            "content": "DIGITAL LOGIC: K-MAP MINIMIZATION\n1. K-Map Structure: Gray code ordering ensures adjacent cells differ by exactly 1 bit.\n2. Grouping Rules: Form largest possible rectangular groups of 2^n adjacent 1s (groups of 1, 2, 4, 8, 16).\n3. Don't-Care Conditions: Can be included in groups if they aid expansion; otherwise ignore.\n4. Minimal Expression: Combine prime implicants to form minimal Sum-of-Products (SOP) form.\n",
            "file_type": "txt"
        }
    ]

    for m in materials_data:
        s_id = subject_id_map[m['code']]
        existing_m = cursor.execute("SELECT id FROM study_materials WHERE subject_id = ? AND title = ?", (s_id, m['title'])).fetchone()
        if not existing_m:
            file_path = None
            if m.get('filename'):
                file_path = os.path.join(Config.UPLOAD_FOLDER, m['filename'])
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(m['content'])

            cursor.execute("""
                INSERT INTO study_materials 
                (subject_id, teacher_id, title, topic, description, material_type, file_path, original_filename, file_type, external_link)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                s_id, teacher_id, m['title'], m['topic'], m['description'],
                m['material_type'], file_path, m.get('filename'), m.get('file_type'), m.get('external_link')
            ))
            summary['materials'] += 1

    # =========================================================
    # E. Preload Assignments (Relative Due Dates & Mixed Status)
    # =========================================================
    today = datetime.now()
    assignments_data = [
        # PPS101
        {
            "code": "PPS101",
            "title": "Pointers & Memory Allocation Lab Exercise",
            "topic": "Pointers",
            "description": "Implement a dynamic array expansion program in C using malloc, realloc, and pointer arithmetic.",
            "due_date": (today + timedelta(days=4)).strftime("%Y-%m-%d"),
            "completed": True
        },
        {
            "code": "PPS101",
            "title": "Multidimensional Arrays & Matrix Multiply",
            "topic": "Arrays",
            "description": "Write an optimized 2D matrix multiplication routine in C with boundary checking.",
            "due_date": (today + timedelta(days=9)).strftime("%Y-%m-%d"),
            "completed": False
        },
        # MAT102
        {
            "code": "MAT102",
            "title": "Eigenvalues & Diagonalization Problem Set",
            "topic": "Matrices",
            "description": "Calculate eigenvalues, eigenvectors, and modal matrices for three 3x3 symmetric matrices.",
            "due_date": (today + timedelta(days=3)).strftime("%Y-%m-%d"),
            "completed": True
        },
        {
            "code": "MAT102",
            "title": "First & Second Order Differential Equations",
            "topic": "Differential Equations",
            "description": "Solve non-homogeneous second-order ODEs using the method of undetermined coefficients.",
            "due_date": (today + timedelta(days=8)).strftime("%Y-%m-%d"),
            "completed": False
        },
        # PHY103
        {
            "code": "PHY103",
            "title": "Dielectric Permittivity & Capacitor Lab Simulation",
            "topic": "Dielectrics",
            "description": "Simulate parallel-plate capacitance changes with ceramic, mica, and air dielectrics.",
            "due_date": (today + timedelta(days=2)).strftime("%Y-%m-%d"),
            "completed": False
        },
        {
            "code": "PHY103",
            "title": "Semiconductor Hall Effect Analysis",
            "topic": "Semiconductor Physics",
            "description": "Calculate carrier concentration, Hall coefficient, and majority carrier type from given voltage curves.",
            "due_date": (today + timedelta(days=11)).strftime("%Y-%m-%d"),
            "completed": True
        },
        # AIML104
        {
            "code": "AIML104",
            "title": "Supervised Classification with Logistic Regression",
            "topic": "Supervised Learning",
            "description": "Implement logistic regression from scratch and evaluate precision, recall, and ROC-AUC curves.",
            "due_date": (today + timedelta(days=5)).strftime("%Y-%m-%d"),
            "completed": True
        },
        {
            "code": "AIML104",
            "title": "Multi-Layer Perceptron Forward & Backward Pass",
            "topic": "Neural Networks",
            "description": "Derive gradients and implement a 2-layer neural network on the MNIST handwritten digit subset.",
            "due_date": (today + timedelta(days=12)).strftime("%Y-%m-%d"),
            "completed": False
        },
        # DEC105
        {
            "code": "DEC105",
            "title": "K-Map Simplification & Logic Diagram Construction",
            "topic": "Boolean Algebra",
            "description": "Minimize 4-variable truth tables into minimal SOP expressions and draft schematic gates.",
            "due_date": (today + timedelta(days=6)).strftime("%Y-%m-%d"),
            "completed": True
        },
        {
            "code": "DEC105",
            "title": "Mod-16 Synchronous Counter Design with JK Flip-Flops",
            "topic": "Flip-Flops",
            "description": "Design state diagram, excitation tables, and logic gate network for a 4-bit binary counter.",
            "due_date": (today + timedelta(days=14)).strftime("%Y-%m-%d"),
            "completed": False
        }
    ]

    for a in assignments_data:
        s_id = subject_id_map[a['code']]
        existing_a = cursor.execute("SELECT id FROM assignments WHERE subject_id = ? AND title = ?", (s_id, a['title'])).fetchone()
        if not existing_a:
            cursor.execute("""
                INSERT INTO assignments (subject_id, teacher_id, title, topic, description, due_date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (s_id, teacher_id, a['title'], a['topic'], a['description'], a['due_date']))
            a_id = cursor.lastrowid
            summary['assignments'] += 1

            if a['completed']:
                cursor.execute("""
                    INSERT INTO assignment_submissions (assignment_id, student_id, status, completed_at)
                    VALUES (?, ?, 'completed', CURRENT_TIMESTAMP)
                """, (a_id, student_id))
                summary['submissions'] += 1
        else:
            a_id = existing_a['id']
            # Ensure status if completed
            if a['completed'] and not cursor.execute("SELECT id FROM assignment_submissions WHERE assignment_id = ? AND student_id = ?", (a_id, student_id)).fetchone():
                cursor.execute("""
                    INSERT INTO assignment_submissions (assignment_id, student_id, status, completed_at)
                    VALUES (?, ?, 'completed', CURRENT_TIMESTAMP)
                """, (a_id, student_id))
                summary['submissions'] += 1

    # =========================================================
    # F. Preload Teacher-Created Quizzes (>= 5 MCQs per subject)
    # =========================================================
    for code, t_list in topics_catalog.items():
        s_id = subject_id_map[code]
        q_topic = t_list[0]
        quiz_title = f"{code} Diagnostic Mastery Test: {q_topic}"
        existing_q = cursor.execute("SELECT id FROM quizzes WHERE subject_id = ? AND title = ?", (s_id, quiz_title)).fetchone()
        if not existing_q:
            cursor.execute("""
                INSERT INTO quizzes (subject_id, teacher_id, title, topic, description, duration_minutes, is_published, quiz_type, difficulty)
                VALUES (?, ?, ?, ?, ?, 15, 1, 'teacher', 'Medium')
            """, (s_id, teacher_id, quiz_title, q_topic, f"Official faculty diagnostic test covering core concepts in {q_topic}."))
            quiz_id = cursor.lastrowid
            summary['quizzes'] += 1

            # Populate 5 questions from QUESTION_BANK
            q_pool = []
            if q_topic in QUESTION_BANK:
                for diff in ['Easy', 'Medium', 'Hard']:
                    q_pool.extend(QUESTION_BANK[q_topic].get(diff, []))

            for q_item in q_pool[:5]:
                cursor.execute("""
                    INSERT INTO quiz_questions (quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Medium')
                """, (
                    quiz_id, q_topic, q_item['question'],
                    q_item['options']['A'], q_item['options']['B'], q_item['options']['C'], q_item['options']['D'],
                    q_item['correct'], q_item.get('explanation', '')
                ))
                summary['questions'] += 1

    # =========================================================
    # G. Preload Realistic Quiz History for Demo Student (Section 13.H)
    #
    # Explicit required trajectories:
    # 1. Semiconductor Physics: 35% -> 55% -> 75% (Improving)
    # 2. Dielectrics: 85% -> 65% -> 40% (Declining)
    # 3. Matrices: 90% -> 85% -> 90% (Consistently Strong)
    # 4. Loops: 45% -> 60% -> 80% (Improving)
    # 5. Neural Networks: 50% -> 55% -> 60% (Moderate/Improving)
    # =========================================================
    histories_plan = [
        {
            "code": "PHY103",
            "topic": "Semiconductor Physics",
            "attempts": [
                {"score": 35.0, "days_ago": 10, "correct_count": 2, "total": 6},
                {"score": 55.0, "days_ago": 5, "correct_count": 3, "total": 6},
                {"score": 75.0, "days_ago": 1, "correct_count": 4, "total": 6}
            ]
        },
        {
            "code": "PHY103",
            "topic": "Dielectrics",
            "attempts": [
                {"score": 85.0, "days_ago": 12, "correct_count": 5, "total": 6},
                {"score": 65.0, "days_ago": 6, "correct_count": 4, "total": 6},
                {"score": 40.0, "days_ago": 1, "correct_count": 2, "total": 6}
            ]
        },
        {
            "code": "MAT102",
            "topic": "Matrices",
            "attempts": [
                {"score": 90.0, "days_ago": 14, "correct_count": 5, "total": 6},
                {"score": 85.0, "days_ago": 7, "correct_count": 5, "total": 6},
                {"score": 90.0, "days_ago": 2, "correct_count": 5, "total": 6}
            ]
        },
        {
            "code": "PPS101",
            "topic": "Loops",
            "attempts": [
                {"score": 45.0, "days_ago": 11, "correct_count": 2, "total": 5},
                {"score": 60.0, "days_ago": 6, "correct_count": 3, "total": 5},
                {"score": 80.0, "days_ago": 2, "correct_count": 4, "total": 5}
            ]
        },
        {
            "code": "AIML104",
            "topic": "Neural Networks",
            "attempts": [
                {"score": 50.0, "days_ago": 13, "correct_count": 2, "total": 5},
                {"score": 55.0, "days_ago": 8, "correct_count": 3, "total": 5},
                {"score": 60.0, "days_ago": 3, "correct_count": 3, "total": 5}
            ]
        }
    ]

    for plan in histories_plan:
        s_id = subject_id_map[plan['code']]
        topic = plan['topic']

        # Ensure a dedicated quiz exists for this topic
        quiz_title = f"{plan['code']} Assessment: {topic}"
        q_row = cursor.execute("SELECT id FROM quizzes WHERE subject_id = ? AND title = ?", (s_id, quiz_title)).fetchone()
        if not q_row:
            cursor.execute("""
                INSERT INTO quizzes (subject_id, teacher_id, title, topic, description, duration_minutes, is_published, quiz_type, difficulty)
                VALUES (?, ?, ?, ?, ?, 15, 1, 'teacher', 'Medium')
            """, (s_id, teacher_id, quiz_title, topic, f"Diagnostic evaluation for {topic}."))
            quiz_id = cursor.lastrowid
            summary['quizzes'] += 1

            # Populate 6 questions
            q_pool = []
            if topic in QUESTION_BANK:
                for diff in ['Easy', 'Medium', 'Hard']:
                    q_pool.extend(QUESTION_BANK[topic].get(diff, []))

            # If not enough in question bank, pad with variants
            while len(q_pool) < 6:
                q_pool.append({
                    "question": f"Diagnostic concept check for {topic} (Question #{len(q_pool)+1})",
                    "options": {"A": "First principle", "B": "Second condition", "C": "Third rule", "D": "Fourth boundary"},
                    "correct": "A",
                    "explanation": f"Core theory of {topic}."
                })

            for q_item in q_pool[:6]:
                cursor.execute("""
                    INSERT INTO quiz_questions (quiz_id, topic, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Medium')
                """, (
                    quiz_id, topic, q_item['question'],
                    q_item['options']['A'], q_item['options']['B'], q_item['options']['C'], q_item['options']['D'],
                    q_item['correct'], q_item.get('explanation', '')
                ))
                summary['questions'] += 1
        else:
            quiz_id = q_row['id']

        # Fetch questions for this quiz
        db_questions = cursor.execute("SELECT * FROM quiz_questions WHERE quiz_id = ?", (quiz_id,)).fetchall()

        # Seed attempts if student does not yet have attempts for this quiz
        existing_attempts = cursor.execute("SELECT COUNT(*) FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?", (quiz_id, student_id)).fetchone()[0]
        if existing_attempts < len(plan['attempts']):
            # Clean old to re-seed exact plan
            cursor.execute("DELETE FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?", (quiz_id, student_id))

            for att_spec in plan['attempts']:
                att_time = (today - timedelta(days=att_spec['days_ago'])).strftime("%Y-%m-%d 15:30:00")
                total_q = min(len(db_questions), att_spec['total'])
                correct_target = min(total_q, att_spec['correct_count'])
                actual_pct = round((correct_target / total_q) * 100.0, 1)

                cursor.execute("""
                    INSERT INTO quiz_attempts (quiz_id, student_id, total_questions, correct_answers, score_percentage, attempted_at, time_taken_seconds, quiz_type)
                    VALUES (?, ?, ?, ?, ?, ?, 480, 'teacher')
                """, (quiz_id, student_id, total_q, correct_target, actual_pct, att_time))
                attempt_id = cursor.lastrowid
                summary['attempts'] += 1

                for idx, q in enumerate(db_questions[:total_q]):
                    is_corr = 1 if idx < correct_target else 0
                    sel_opt = q['correct_option'] if is_corr else ('B' if q['correct_option'] != 'B' else 'C')
                    cursor.execute("""
                        INSERT INTO quiz_attempt_answers (attempt_id, question_id, topic, selected_option, correct_option, is_correct)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (attempt_id, q['id'], topic, sel_opt, q['correct_option'], is_corr))

    # =========================================================
    # H. Preload Classroom Announcements
    # =========================================================
    sample_announcements = [
        {"code": "AIML104", "title": "Welcome to AI & Machine Learning 2026", "message": "Please review the syllabus and make sure you have Python 3 and basic scientific libraries installed."},
        {"code": "PPS101", "title": "Diagnostic Quiz 1 is Live", "message": "The diagnostic quiz on Pointers and Memory is now published. Please complete it by Friday so your adaptive study schedule is calibrated."}
    ]
    for ann in sample_announcements:
        if ann['code'] in subject_id_map:
            sub_id = subject_id_map[ann['code']]
            existing = cursor.execute("SELECT id FROM announcements WHERE subject_id = ? AND title = ?", (sub_id, ann['title'])).fetchone()
            if not existing:
                cursor.execute("""
                    INSERT INTO announcements (subject_id, teacher_id, title, message)
                    VALUES (?, ?, ?, ?)
                """, (sub_id, teacher_id, ann['title'], ann['message']))

    # Commit and close main connection before calling external engines
    conn.commit()
    conn.close()

    # =========================================================
    # I. Preload Initial and Adaptive Timetable (Section 13.I & 13.J)
    # =========================================================
    from adaptive_timetable import AdaptiveTimetableEngine
    from ai_recommendations import RecommendationEngine

    # 1. Generate Recommendations based on seeded quiz attempts
    RecommendationEngine.generate_recommendations(student_id)

    # 2. Run Adaptive Timetable Engine using the seeded multi-attempt histories
    # This automatically increases time for Dielectrics (declining), adjusts Semiconductor Physics,
    # maintains reasonable revision for Matrices, and records explanations in SQLite!
    AdaptiveTimetableEngine.adapt_timetable(student_id, trigger_reason="Initial seed: AI adaptive schedule rebalance based on topic diagnostics")

    print("=" * 60)
    print("DEMO DATA SEEDING COMPLETE! SUMMARY OF RECORDS:")
    print("=" * 60)
    print(f"  • Accounts Created/Verified: {summary['users']} users")
    print(f"  • Subjects Initialized:     {summary['subjects']} courses")
    print(f"  • Student Enrolments:       {summary['enrolments']} class memberships")
    print(f"  • Topics Populated:         {summary['topics']} distinct topics")
    print(f"  • Study Materials Uploaded: {summary['materials']} handouts/links")
    print(f"  • Coursework Assignments:   {summary['assignments']} assignments")
    print(f"  • Student Submissions:      {summary['submissions']} completed records")
    print(f"  • Tests & Quizzes:          {summary['quizzes']} quizzes")
    print(f"  • Questions Populated:      {summary['questions']} multiple choice questions")
    print(f"  • Student Quiz Attempts:    {summary['attempts']} historical attempts")
    print("=" * 60)
    print("DEMO CREDENTIALS FOR TESTING:")
    print("  👩‍🏫 Teacher Account:")
    print("     Email:    teacher@studyglow.com")
    print("     Password: Teacher@123")
    print("  👨‍🎓 Student Account:")
    print("     Email:    student@studyglow.com")
    print("     Password: Student@123")
    print("=" * 60)

if __name__ == '__main__':
    seed()
