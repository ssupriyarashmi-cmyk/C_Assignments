"""
Adaptive Timetable Engine
Dynamically adjusts weekly study schedules based on topic performance,
approaching exam dates, assignment deadlines, and student study hour constraints.
Generates human-readable change explanations and records version history in SQLite.
Preserves completed sessions (is_completed = 1) and prevents overlapping sessions.
"""

import math
from datetime import datetime, timedelta
from database import get_db
from ai_analysis import PerformanceAnalyzer

class AdaptiveTimetableEngine:
    DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

    @staticmethod
    def calculate_topic_priorities(student_id):
        """
        Calculates dynamic priority score (1.0 to 10.0) for each subject and topic based on:
        - Topic quiz accuracy (lower = higher priority)
        - Performance trend (Declining = +2.5 boost, Improving = -1.0 moderation)
        - Definitiveness check: topics with insufficient evidence (< 2 questions) receive preliminary weight
        - Approaching exam date (within 7 days = +3.0 boost, within 14 days = +1.5 boost)
        - Pending assignments due soon (due in <= 3 days = +2.0 boost)
        """
        conn = get_db()
        cursor = conn.cursor()

        # Enrolled subjects
        enrolled = cursor.execute("""
            SELECT s.id, s.name, s.code 
            FROM enrolments e
            JOIN subjects s ON e.subject_id = s.id
            WHERE e.student_id = ?
        """, (student_id,)).fetchall()

        if not enrolled:
            conn.close()
            return {}

        # Timetable config
        tt_config = cursor.execute("SELECT * FROM timetables WHERE student_id = ?", (student_id,)).fetchone()
        exam_date_str = tt_config['exam_date'] if tt_config else None

        # Assignments
        today_str = datetime.now().strftime("%Y-%m-%d")
        upcoming_assignments = cursor.execute("""
            SELECT a.subject_id, a.due_date, a.topic
            FROM assignments a
            JOIN enrolments e ON a.subject_id = e.subject_id
            LEFT JOIN assignment_submissions sub ON a.id = sub.assignment_id AND sub.student_id = ?
            WHERE e.student_id = ? AND (sub.status IS NULL OR sub.status != 'completed')
        """, (student_id, student_id)).fetchall()

        # Pre-fetch extra topics per subject
        extra_topics_by_subj = {}
        for subj in enrolled:
            sid = subj['id']
            extra = cursor.execute("""
                SELECT DISTINCT name as topic FROM topics WHERE subject_id = ?
                UNION
                SELECT DISTINCT topic FROM study_materials WHERE subject_id = ? AND topic IS NOT NULL AND topic != ''
                UNION
                SELECT DISTINCT topic FROM quizzes WHERE subject_id = ? AND topic IS NOT NULL AND topic != ''
            """, (sid, sid, sid)).fetchall()
            extra_topics_by_subj[sid] = [et['topic'].strip() for et in extra if et['topic']]

        conn.close()

        # Quiz performance analysis for this individual student
        analysis = PerformanceAnalyzer.analyze_student(student_id)
        topic_analysis_map = {t['topic']: t for t in analysis.get('all_topics', [])}

        priorities = {}

        for subj in enrolled:
            sid = subj['id']
            sname = subj['name']

            # 1. Topics tested in quizzes
            tested_topics = [t for t in analysis.get('all_topics', []) if t.get('subject_id') == sid or t.get('subject') == sname]
            tested_topic_names = {t['topic'] for t in tested_topics}

            # 2. Additional topics from topics table, study_materials, quizzes
            extra_topics = extra_topics_by_subj.get(sid, [])
            all_subj_topics = list(tested_topics)
            for et_name in extra_topics:
                if et_name and et_name not in tested_topic_names:
                    all_subj_topics.append({
                        'topic': et_name,
                        'subject': sname,
                        'subject_id': sid,
                        'accuracy': 70.0,
                        'total_questions': 0,
                        'correct_answers': 0,
                        'trend': 'Stable',
                        'status': 'Moderate',
                        'is_definitive': False
                    })
                    tested_topic_names.add(et_name)

            # 3. Fallback topics if none defined
            if not all_subj_topics:
                default_names = ["Core Concepts", "Problem Solving", "Revision & Practice"]
                for tn in default_names:
                    full_name = f"{sname} - {tn}"
                    all_subj_topics.append({
                        'topic': full_name,
                        'subject': sname,
                        'subject_id': sid,
                        'accuracy': 70.0,
                        'total_questions': 0,
                        'correct_answers': 0,
                        'trend': 'Stable',
                        'status': 'Moderate',
                        'is_definitive': False
                    })

            for t_info in all_subj_topics:
                t_name = t_info['topic']
                acc = t_info.get('accuracy', 70.0)
                trend = t_info.get('trend', 'Stable')
                q_count = t_info.get('total_questions', 0)
                is_definitive = t_info.get('is_definitive', q_count >= 2)

                # Base score: lower accuracy gives higher priority
                # 0% accuracy -> 8.0 base, 100% accuracy -> 2.0 base
                base_priority = 2.0 + (100.0 - acc) * 0.06

                reasons = []

                # Performance adjustments
                if trend == 'Declining':
                    base_priority += 2.5
                    reasons.append(f"Declining quiz scores in '{t_name}' (requires focused remediation)")
                elif trend == 'Improving':
                    base_priority -= 1.0
                    reasons.append(f"Improving performance trend in '{t_name}'")
                elif acc >= 80.0:
                    base_priority = max(1.5, base_priority - 1.5)
                    reasons.append(f"High mastery ({acc}%) in '{t_name}' (maintenance revision)")
                elif acc < 60.0:
                    if is_definitive:
                        base_priority += 2.0
                        reasons.append(f"Low quiz accuracy ({acc}%) in '{t_name}' (urgent remediation)")
                    else:
                        base_priority += 1.0
                        reasons.append(f"Preliminary low score ({acc}%) in '{t_name}' (practice needed)")

                # Upcoming exam boost
                if exam_date_str:
                    try:
                        ed = datetime.strptime(exam_date_str, "%Y-%m-%d")
                        days_until = (ed - datetime.now()).days
                        if 0 <= days_until <= 7:
                            base_priority += 3.0
                            reasons.append(f"Final exam in {days_until} days")
                        elif 0 <= days_until <= 14:
                            base_priority += 1.5
                            reasons.append(f"Upcoming exam in {days_until} days")
                    except Exception:
                        pass

                # Approaching assignment deadline boost
                for assign in upcoming_assignments:
                    if assign['subject_id'] == sid:
                        try:
                            ad = datetime.strptime(assign['due_date'], "%Y-%m-%d")
                            days_to_due = (ad - datetime.now()).days
                            if 0 <= days_to_due <= 3:
                                base_priority += 2.0
                                reasons.append(f"Assignment due in {days_to_due} days")
                                break
                        except Exception:
                            pass

                final_priority = max(1.0, min(10.0, round(base_priority, 2)))
                priority_level = "High" if final_priority >= 6.5 else ("Low" if final_priority <= 3.5 else "Normal")

                priorities[t_name] = {
                    'subject_id': sid,
                    'subject_name': sname,
                    'topic': t_name,
                    'accuracy': acc,
                    'trend': trend,
                    'total_questions': q_count,
                    'is_definitive': is_definitive,
                    'priority_score': final_priority,
                    'priority_level': priority_level,
                    'reasons': reasons or [f"Scheduled study for {sname}"]
                }

        return priorities

    @staticmethod
    def adapt_timetable(student_id, trigger_reason="Automatic quiz-driven adaptation"):
        """
        Rebalances student timetable sessions dynamically.
        Enforces:
        - Weak topics receive higher priority and additional study time.
        - Moderate topics receive regular practice.
        - Strong topics maintain essential revision with reduced duration.
        - Daily study capacity is never exceeded.
        - Built-in cognitive rest breaks are maintained.
        - Overlapping sessions are strictly prevented.
        - Completed sessions (is_completed = 1) are preserved without modification.
        - Only pending sessions (is_completed = 0) are adapted.
        - All changes are recorded with version history and human-readable explanations in SQLite.
        """
        conn = get_db()
        cursor = conn.cursor()

        tt = cursor.execute("SELECT * FROM timetables WHERE student_id = ?", (student_id,)).fetchone()
        if not tt:
            cursor.execute("INSERT INTO timetables (student_id) VALUES (?)", (student_id,))
            conn.commit()
            tt = cursor.execute("SELECT * FROM timetables WHERE student_id = ?", (student_id,)).fetchone()

        timetable_id = tt['id']
        daily_hours = float(tt['daily_study_hours'] or 3.0)
        start_time_str = tt['preferred_start_time'] or '18:00'
        daily_available_mins = int(round(daily_hours * 60))

        # 1. Fetch existing sessions to compute previous topic & subject durations
        existing_sessions = cursor.execute("""
            SELECT * FROM timetable_sessions WHERE student_id = ?
        """, (student_id,)).fetchall()

        old_topic_duration_map = {}
        old_subject_duration_map = {}
        for s in existing_sessions:
            if s['session_type'] == 'study':
                t_name = s['topic']
                s_name = s['subject_name']
                old_topic_duration_map[t_name] = old_topic_duration_map.get(t_name, 0) + s['duration_minutes']
                old_subject_duration_map[s_name] = old_subject_duration_map.get(s_name, 0) + s['duration_minutes']

        # 2. Identify and preserve completed sessions
        completed_sessions = [dict(s) for s in existing_sessions if s['is_completed']]

        # 3. Delete only pending sessions
        cursor.execute("DELETE FROM timetable_sessions WHERE student_id = ? AND is_completed = 0", (student_id,))

        # 4. Calculate dynamic topic priorities
        priorities = AdaptiveTimetableEngine.calculate_topic_priorities(student_id)
        if not priorities:
            conn.close()
            return False, "No enrolled subjects to schedule.", None

        # 5. Build candidate study blocks based on topic priority levels
        # Weak / High priority: 50 min blocks, 4 slots in queue
        # Moderate / Normal priority: 40 min blocks, 2 slots in queue
        # Strong / Low priority: 30 min blocks, 1 slot in queue (maintenance revision)
        sorted_topics = sorted(priorities.values(), key=lambda x: x['priority_score'], reverse=True)

        cand_queue = []
        for t in sorted_topics:
            p_score = t['priority_score']
            level = t['priority_level']
            if level == 'High':
                dur = 50
                weight = 4
            elif level == 'Low':
                dur = 30
                weight = 1
            else:
                dur = 40
                weight = 2

            for _ in range(weight):
                cand_queue.append({
                    'subject_id': t['subject_id'],
                    'subject_name': t['subject_name'],
                    'topic': t['topic'],
                    'duration': dur,
                    'priority': level,
                    'priority_score': p_score
                })

        # Parse daily start time
        try:
            sh, sm = map(int, start_time_str.split(':'))
        except Exception:
            sh, sm = 18, 0

        break_duration = 10
        new_sessions = []
        cand_idx = 0

        # Group completed sessions by day
        completed_by_day = {d: [] for d in AdaptiveTimetableEngine.DAYS}
        for cs in completed_sessions:
            completed_by_day[cs['day_of_week']].append(cs)

        # 6. Distribute sessions across all 7 days
        for day in AdaptiveTimetableEngine.DAYS:
            day_completed = completed_by_day[day]
            completed_time = sum(s['duration_minutes'] for s in day_completed)
            remaining_mins = daily_available_mins - completed_time
            if remaining_mins <= 20 or not cand_queue:
                continue

            day_end_limit = datetime(2026, 1, 1, sh, sm) + timedelta(minutes=daily_available_mins)

            if day_completed:
                last_end = max(s['end_time'] for s in day_completed)
                try:
                    leh, lem = map(int, last_end.split(':'))
                    cur_time = datetime(2026, 1, 1, leh, lem) + timedelta(minutes=break_duration)
                except Exception:
                    cur_time = datetime(2026, 1, 1, sh, sm) + timedelta(minutes=completed_time)
            else:
                cur_time = datetime(2026, 1, 1, sh, sm)

            while cur_time < day_end_limit:
                item = cand_queue[cand_idx % len(cand_queue)]
                dur = item['duration']

                # Cap if exceeding daily limit
                if cur_time + timedelta(minutes=dur) > day_end_limit:
                    avail_slot = int((day_end_limit - cur_time).total_seconds() // 60)
                    if avail_slot >= 25:
                        dur = avail_slot
                    else:
                        break

                st_str = cur_time.strftime("%H:%M")
                cur_time += timedelta(minutes=dur)
                et_str = cur_time.strftime("%H:%M")

                cursor.execute("""
                    INSERT INTO timetable_sessions (timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, session_type, priority, is_completed)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'study', ?, 0)
                """, (
                    timetable_id, student_id, item['subject_id'], item['subject_name'],
                    item['topic'], day, st_str, et_str, dur, item['priority']
                ))

                new_sessions.append({
                    'subject_id': item['subject_id'],
                    'subject_name': item['subject_name'],
                    'topic': item['topic'],
                    'day_of_week': day,
                    'start_time': st_str,
                    'end_time': et_str,
                    'duration_minutes': dur,
                    'session_type': 'study',
                    'priority': item['priority']
                })
                cand_idx += 1

                # Add rest break if time remains
                if cur_time + timedelta(minutes=break_duration) < day_end_limit:
                    brk_st = cur_time.strftime("%H:%M")
                    cur_time += timedelta(minutes=break_duration)
                    brk_et = cur_time.strftime("%H:%M")

                    cursor.execute("""
                        INSERT INTO timetable_sessions (timetable_id, student_id, subject_id, subject_name, topic, day_of_week, start_time, end_time, duration_minutes, session_type, priority, is_completed)
                        VALUES (?, ?, NULL, 'Cognitive Break', 'Rest eyes, hydrate & stretch', ?, ?, ?, ?, 'break', 'Normal', 0)
                    """, (timetable_id, student_id, day, brk_st, brk_et, break_duration))

        # 7. Compute new topic and subject durations (combining completed + newly inserted pending sessions)
        all_active_sessions = cursor.execute("""
            SELECT * FROM timetable_sessions WHERE student_id = ? AND session_type = 'study'
        """, (student_id,)).fetchall()

        new_topic_duration_map = {}
        new_subject_duration_map = {}
        for s in all_active_sessions:
            t = s['topic']
            sub = s['subject_name']
            new_topic_duration_map[t] = new_topic_duration_map.get(t, 0) + s['duration_minutes']
            new_subject_duration_map[sub] = new_subject_duration_map.get(sub, 0) + s['duration_minutes']

        # 8. Next version number
        last_ver_row = cursor.execute("""
            SELECT MAX(version_number) FROM timetable_versions WHERE student_id = ?
        """, (student_id,)).fetchone()[0]
        next_version = (last_ver_row or 0) + 1

        # 9. Generate detailed adaptations per topic
        adaptations = []
        summary_sentences = []

        # Analyze each topic in priorities
        for t_name, p_info in priorities.items():
            s_name = p_info['subject_name']
            new_dur = new_topic_duration_map.get(t_name, 0)
            prev_dur = old_topic_duration_map.get(t_name, 0)
            delta = new_dur - prev_dur
            acc = p_info['accuracy']
            trend = p_info['trend']
            level = p_info['priority_level']

            if delta > 0 and level == 'High':
                if trend == 'Declining':
                    reason = f"Additional {delta} minutes allocated to '{t_name}' to reverse score decline ({acc}%)."
                else:
                    reason = f"Additional {delta} minutes allocated to '{t_name}' due to low quiz performance ({acc}%)."
                summary_sentences.append(reason)
            elif delta < 0 and level == 'Low':
                reason = f"Reduced revision time by {abs(delta)} minutes for '{t_name}' due to high mastery ({acc}%), maintaining essential practice."
                summary_sentences.append(reason)
            elif delta > 0:
                reason = f"Allocated +{delta} minutes for '{t_name}' ({acc}% accuracy) to advance syllabus mastery."
            elif delta < 0:
                reason = f"Adjusted by {delta} minutes to balance schedule across weaker topics."
            else:
                reason = f"Maintained regular practice allocation ({new_dur}m) for '{t_name}'."

            adaptations.append({
                'subject_id': p_info['subject_id'],
                'subject_name': s_name,
                'topic': t_name,
                'prev_duration': prev_dur,
                'new_duration': new_dur,
                'delta': delta,
                'priority_level': level,
                'reason': reason
            })

        change_summary = " ".join(summary_sentences[:3]) if summary_sentences else "Timetable adapted based on dynamic topic priority matrix."

        # Insert version record
        cursor.execute("""
            INSERT INTO timetable_versions (student_id, version_number, trigger_reason, change_summary)
            VALUES (?, ?, ?, ?)
        """, (student_id, next_version, trigger_reason, change_summary))
        version_id = cursor.lastrowid

        # Insert adaptations records
        for adapt in adaptations:
            cursor.execute("""
                INSERT INTO timetable_adaptations 
                (version_id, student_id, subject_id, subject_name, topic, prev_duration, new_duration, delta_minutes, priority_level, reason)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                version_id, student_id, adapt['subject_id'], adapt['subject_name'], adapt['topic'],
                adapt['prev_duration'], adapt['new_duration'], adapt['delta'],
                adapt['priority_level'], adapt['reason']
            ))

        conn.commit()
        conn.close()

        return True, "Timetable adapted successfully based on topic mastery!", {
            'version_number': next_version,
            'change_summary': change_summary,
            'adaptations': adaptations
        }

    @staticmethod
    def get_latest_adaptations(student_id):
        """Returns the most recent timetable adaptation version and explanation."""
        conn = get_db()
        version = conn.execute("""
            SELECT * FROM timetable_versions 
            WHERE student_id = ? 
            ORDER BY version_number DESC LIMIT 1
        """, (student_id,)).fetchone()

        if not version:
            conn.close()
            return None, []

        adaptations = conn.execute("""
            SELECT * FROM timetable_adaptations 
            WHERE version_id = ?
            ORDER BY delta_minutes DESC
        """, (version['id'],)).fetchall()

        conn.close()
        return dict(version), [dict(a) for a in adaptations]
