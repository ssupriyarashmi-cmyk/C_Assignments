/**
 * Study Planner - AI Adaptive Timetable & Performance Engine
 * 
 * Implements the continuous feedback loop:
 * Plan → Study → Break → Study → Test → Analyze → Adapt → Study Again
 * 
 * Includes the Study Session + Break System with 3 Study Techniques:
 * 1. Pomodoro (25m study • 5m break)
 * 2. Focused Study (50m study • 10m break)
 * 3. Deep Study (80m study • 15m break)
 * Plus Quick Revision (10-20m) & AI Recommended technique selection.
 * 
 * All sessions & breaks strictly fit within the student's available daily hours.
 */

const STUDY_TECHNIQUES = {
  pomodoro: {
    id: 'pomodoro',
    name: 'Pomodoro',
    studyMins: 25,
    breakMins: 5,
    cycleMins: 30,
    label: 'Pomodoro (25m / 5m)',
    icon: '🍅',
    badgeClass: 'badge-technique-pomodoro',
    description: '25 min study followed by 5 min rest'
  },
  focused: {
    id: 'focused',
    name: 'Focused Study',
    studyMins: 50,
    breakMins: 10,
    cycleMins: 60,
    label: 'Focused Study (50m / 10m)',
    icon: '🎯',
    badgeClass: 'badge-technique-focused',
    description: '50 min study followed by 10 min rest'
  },
  deep: {
    id: 'deep',
    name: 'Deep Study',
    studyMins: 80,
    breakMins: 15,
    cycleMins: 95,
    label: 'Deep Study (80m / 15m)',
    icon: '🌊',
    badgeClass: 'badge-technique-deep',
    description: '80 min immersive study followed by 15 min rest'
  },
  quick: {
    id: 'quick',
    name: 'Quick Revision',
    studyMins: 15,
    breakMins: 0,
    cycleMins: 15,
    label: 'Quick Revision (10–20m)',
    icon: '⚡',
    badgeClass: 'badge-technique-quick',
    description: 'Targeted drill and summary recall'
  }
};

class AdaptiveEngine {
  /**
   * AI Technique Selection (Section 9)
   * Considers performance, weakness, difficulty, exam proximity, session history, and available time.
   */
  static selectTechnique(topic, userProfile = {}, sessionHistory = [], remainingMins = 60) {
    const pref = (userProfile.technique_preference || 'automatic').toLowerCase();
    const allowAi = userProfile.allow_ai_recommend !== false;

    // If student manually chose a technique and disabled AI recommendation
    if (pref !== 'automatic' && !allowAi) {
      if (pref === 'deep' && remainingMins >= 80) return STUDY_TECHNIQUES.deep;
      if (pref === 'focused' && remainingMins >= 45) return STUDY_TECHNIQUES.focused;
      if (pref === 'pomodoro' && remainingMins >= 25) return STUDY_TECHNIQUES.pomodoro;
    }

    // AI Recommendation Logic:
    // 1. Previous session completion tracking (Section 7 & 9)
    const pastTopicSessions = (sessionHistory || []).filter(h => h.topic_id === topic.topicId);
    const hadStruggles = pastTopicSessions.slice(-2).some(h => h.completion_status === 'Not Completed');
    if (hadStruggles && remainingMins >= 30) {
      // Lower cognitive activation barrier to build successful momentum
      return STUDY_TECHNIQUES.pomodoro;
    }

    // 2. High-priority upcoming exam with continuous block available
    const isUrgentExam = topic.closestExam && topic.minExamDays <= 7 && topic.closestExam.priority === 'High';
    if (isUrgentExam && remainingMins >= 95) {
      return STUDY_TECHNIQUES.deep;
    }

    // 3. Difficult / Low-performing topic (Mastery < 65%)
    if (topic.masteryScore < 65) {
      if (remainingMins >= 60 && topic.masteryScore >= 50) {
        return STUDY_TECHNIQUES.focused;
      }
      if (remainingMins >= 30) {
        return STUDY_TECHNIQUES.pomodoro;
      }
    }

    // 4. Respect user's preferred technique if it fits
    if (pref === 'deep' && remainingMins >= 95) return STUDY_TECHNIQUES.deep;
    if (pref === 'pomodoro' && remainingMins >= 30) return STUDY_TECHNIQUES.pomodoro;
    if (pref === 'focused' && remainingMins >= 60) return STUDY_TECHNIQUES.focused;

    // 5. Default by remaining time block
    if (remainingMins >= 60) return STUDY_TECHNIQUES.focused;
    if (remainingMins >= 30) return STUDY_TECHNIQUES.pomodoro;
    return STUDY_TECHNIQUES.quick;
  }

  /**
   * Generates actionable topic-specific goals (Section 4)
   */
  static generateSessionGoal(topicName, courseName, masteryScore) {
    const customGoals = {
      'Chemical Bonding': 'Understand VSEPR theory, molecular geometry, and solve 5 practice questions.',
      'Thermodynamics': 'Master enthalpy and Gibbs free energy equations; solve 4 numerical problems.',
      'Atomic Structure': 'Review quantum numbers and electron configurations with 5 orbital exercises.',
      'Organic Chemistry': 'Understand electrophilic substitution mechanisms and draw 4 reaction pathways.',
      'Mechanics': 'Solve rotational inertia and conservation of angular momentum problems.',
      'Electromagnetism': 'Master Faraday induction and magnetic flux calculation drills.',
      'Optics': 'Apply Snell’s law and thin lens equations to ray tracing problems.',
      'Waves & Sound': 'Analyze Doppler effect equations and harmonic standing wave modes.',
      'Calculus': 'Practice integration by parts and evaluate 5 definite integral problems.',
      'Linear Algebra': 'Calculate matrix determinants, eigenvalues, and solve 4 linear systems.',
      'Probability & Statistics': 'Apply Bayes theorem and solve 5 conditional probability problems.',
      'Trigonometry': 'Verify double-angle identities and solve 5 inverse trigonometric equations.',
      'Data Structures': 'Review AVL self-balancing tree rotations and node height properties.',
      'Algorithms': 'Analyze QuickSort partition complexity and practice Dynamic Programming memoization.',
      'Database Systems': 'Master normalization rules (1NF to 3NF) and write 4 complex SQL joins.',
      'Operating Systems': 'Review virtual memory page replacement algorithms and semaphore mechanisms.'
    };

    if (customGoals[topicName]) return customGoals[topicName];
    if (masteryScore < 60) return `Review foundational principles of ${topicName} and solve 5 diagnostic problems.`;
    if (masteryScore >= 80) return `Rapid formula recall for ${topicName} and tackle 3 advanced challenge problems.`;
    return `Comprehensive conceptual review of ${topicName} and complete 5 core practice exercises.`;
  }

  /**
   * Main calculation: Generates an adaptive daily study timetable WITH BREAKS
   * Available time → Study sessions → Breaks → Finish within available time.
   */
  static generateAdaptiveTimetable({
    courses = [],
    exams = [],
    assignments = [],
    topicHistory = [],
    sessionHistory = [],
    userProfile = { daily_hours: 3.0, preferred_start: '18:00', preferred_end: '21:00' },
    targetDate = new Date()
  }) {
    const totalMinutes = Math.round((userProfile.daily_hours || 3.0) * 60);
    const startStr = userProfile.preferred_start || '18:00';
    const [startH, startM] = startStr.split(':').map(Number);
    const now = new Date(targetDate);

    // 1. Flatten all active topics across all courses
    const topicPool = [];
    courses.forEach(course => {
      (course.topics || []).forEach(t => {
        topicPool.push({
          topicId: t.id,
          topicName: t.name,
          courseId: course.id,
          courseName: course.name,
          courseColor: course.color || '#6366f1',
          masteryScore: Number(t.mastery_score != null ? t.mastery_score : 70.0),
          status: t.status || 'neutral',
          testsTaken: t.tests_taken || 1
        });
      });
    });

    if (topicPool.length === 0) {
      return { sessions: [], diffs: [], insights: [] };
    }

    // 2. Multi-factor Scoring for each topic
    const scoredTopics = topicPool.map(t => {
      // Factor A: Weakness Urgency (0 to 100)
      const weaknessUrgency = Math.max(0, 100 - t.masteryScore);

      // Factor B: Exam Proximity & Importance
      let examUrgency = 0;
      let closestExam = null;
      let minExamDays = 999;

      exams.forEach(ex => {
        const coversCourse = ex.course_id === t.courseId;
        const coversTopic = !ex.topics || ex.topics.length === 0 || ex.topics.includes(t.topicName);

        if (coversCourse && coversTopic) {
          const exDate = new Date(ex.exam_date);
          const diffDays = Math.ceil((exDate - now) / (1000 * 60 * 60 * 24));
          if (diffDays >= 0 && diffDays < minExamDays) {
            minExamDays = diffDays;
            closestExam = ex;
          }
        }
      });

      if (closestExam) {
        const priorityMult = closestExam.priority === 'High' ? 1.5 : (closestExam.priority === 'Medium' ? 1.2 : 1.0);
        if (minExamDays <= 3) {
          examUrgency = 100 * priorityMult;
        } else if (minExamDays <= 7) {
          examUrgency = 80 * priorityMult;
        } else if (minExamDays <= 14) {
          examUrgency = 55 * priorityMult;
        } else {
          examUrgency = 25 * priorityMult;
        }
      }

      // Factor C: Assignment Deadlines for this course
      let assignmentUrgency = 0;
      let urgentAssignment = null;
      let minAssignDays = 999;

      assignments.forEach(asg => {
        if (asg.course_id === t.courseId && asg.status !== 'completed') {
          const asgDate = new Date(asg.due_date);
          const diffDays = Math.ceil((asgDate - now) / (1000 * 60 * 60 * 24));
          if (diffDays >= 0 && diffDays < minAssignDays) {
            minAssignDays = diffDays;
            urgentAssignment = asg;
          }
        }
      });

      if (urgentAssignment) {
        if (minAssignDays <= 2) assignmentUrgency = 85;
        else if (minAssignDays <= 5) assignmentUrgency = 50;
        else assignmentUrgency = 25;
      }

      // Factor D: Historical Trend (Improving vs Stagnant)
      const historyEntries = (topicHistory || []).filter(h => h.topic_id === t.topicId);
      let trendDelta = 0;
      let trendLabel = "Stable";

      if (historyEntries.length >= 2) {
        const sortedHistory = [...historyEntries].sort((a, b) => new Date(a.recorded_at) - new Date(b.recorded_at));
        const first = sortedHistory[0].percentage;
        const latest = sortedHistory[sortedHistory.length - 1].percentage;
        trendDelta = latest - first;
        if (trendDelta >= 10) trendLabel = "Improving";
        else if (trendDelta <= -5) trendLabel = "Declining";
      }

      let trendMultiplier = 1.0;
      if (t.masteryScore < 65 && trendDelta <= 0) {
        trendMultiplier = 1.35; // Persistently struggling needs extra focus
      } else if (trendLabel === "Improving") {
        trendMultiplier = 0.9; // Rewarding improvement by slightly easing stress
      }

      // Composite Priority Formula
      const compositeScore = (
        (weaknessUrgency * 0.40) +
        (examUrgency * 0.30) +
        (assignmentUrgency * 0.15) +
        (weaknessUrgency * 0.15)
      ) * trendMultiplier;

      return {
        ...t,
        compositeScore,
        weaknessUrgency,
        examUrgency,
        assignmentUrgency,
        closestExam,
        minExamDays,
        urgentAssignment,
        minAssignDays,
        trendDelta,
        trendLabel
      };
    });

    // 3. Sort by priority
    scoredTopics.sort((a, b) => b.compositeScore - a.compositeScore);

    // Pick top topics for today
    const slotCount = totalMinutes >= 180 ? 4 : (totalMinutes >= 120 ? 3 : 2);
    const selectedTopics = scoredTopics.slice(0, slotCount);

    // 4. BREAK-AWARE TIMETABLE SCHEDULER (Section 2 & 3)
    // Fit sessions + breaks STRICTLY inside totalMinutes (from startMinute to endMinute)
    let runningMinute = startH * 60 + startM;
    const endMinute = runningMinute + totalMinutes;
    const sessions = [];
    const changeDiffs = [];
    const insights = [];

    let topicIndex = 0;
    while (runningMinute < endMinute) {
      const remainingMins = endMinute - runningMinute;
      if (remainingMins <= 0) break;

      // Select topic in priority order
      const t = selectedTopics[topicIndex % selectedTopics.length];
      topicIndex++;

      // AI selects study technique
      const tech = AdaptiveEngine.selectTechnique(t, userProfile, sessionHistory, remainingMins);

      let studyMins = tech.studyMins;
      let breakMins = tech.breakMins;

      // Ensure study + break fit within remainingMins
      if (remainingMins < studyMins + breakMins) {
        if (remainingMins >= 40) {
          // Proportionally scale study & break
          breakMins = Math.min(10, Math.floor(remainingMins * 0.18));
          studyMins = remainingMins - breakMins;
        } else if (remainingMins >= 25) {
          if (remainingMins >= 30) {
            studyMins = 25;
            breakMins = remainingMins - 25;
          } else {
            studyMins = remainingMins;
            breakMins = 0;
          }
        } else {
          // Quick revision final slot
          studyMins = remainingMins;
          breakMins = 0;
        }
      }

      // If less than 10 mins remain, absorb into previous study session
      if (studyMins < 10) {
        const lastStudy = [...sessions].reverse().find(s => !s.is_break);
        if (lastStudy) {
          lastStudy.duration_mins += remainingMins;
          const lastStartMins = AdaptiveEngine.parseTimeToMinutes(lastStudy.start_time);
          lastStudy.end_time = AdaptiveEngine.formatMinutesToTime(lastStartMins + lastStudy.duration_mins);
        }
        break;
      }

      const startSlotStr = AdaptiveEngine.formatMinutesToTime(runningMinute);
      const endSlotStr = AdaptiveEngine.formatMinutesToTime(runningMinute + studyMins);
      runningMinute += studyMins;

      const goal = AdaptiveEngine.generateSessionGoal(t.topicName, t.courseName, t.masteryScore);
      const baselineMins = 45;
      const deltaMins = studyMins - baselineMins;
      const reason = AdaptiveEngine.generateExplanation(t, deltaMins);
      const priority = (t.masteryScore < 65 || (t.closestExam && t.minExamDays <= 7)) ? 'High' : (t.masteryScore < 80 ? 'Medium' : 'Low');

      // Add Study Session
      sessions.push({
        id: `sess_${sessions.length + 1}_${Date.now()}`,
        day_date: now.toISOString().split('T')[0],
        is_break: false,
        type: 'study',
        start_time: startSlotStr,
        end_time: endSlotStr,
        duration_mins: studyMins,
        course_id: t.courseId,
        course_name: t.courseName,
        course_color: t.courseColor,
        topic_id: t.topicId,
        topic_name: t.topicName,
        study_technique: tech.name,
        technique_id: tech.id,
        break_duration: breakMins,
        goal: goal,
        priority: priority,
        ai_rationale: reason,
        change_delta_mins: deltaMins,
        change_reason: reason,
        completed: 0,
        completion_status: null,
        mastery_score: t.masteryScore,
        composite_score: Math.round(t.compositeScore)
      });

      if (deltaMins !== 0) {
        changeDiffs.push({
          topic: t.topicName,
          course: t.courseName,
          delta: deltaMins,
          technique: tech.name,
          reason
        });
      }

      // Add Break if scheduled and within time window
      if (breakMins > 0 && runningMinute < endMinute) {
        breakMins = Math.min(breakMins, endMinute - runningMinute);
        if (breakMins > 0) {
          const breakStartStr = AdaptiveEngine.formatMinutesToTime(runningMinute);
          const breakEndStr = AdaptiveEngine.formatMinutesToTime(runningMinute + breakMins);
          runningMinute += breakMins;

          sessions.push({
            id: `break_${sessions.length + 1}_${Date.now()}`,
            day_date: now.toISOString().split('T')[0],
            is_break: true,
            type: 'break',
            start_time: breakStartStr,
            end_time: breakEndStr,
            duration_mins: breakMins,
            title: '☕ Break Time',
            topic_name: 'Rest & Recharge',
            break_type: `${tech.name} Break`,
            message: 'Take a short break before your next session. Step away from your desk, hydrate, or stretch.',
            completed: 0
          });
        }
      }
    }

    // 5. Generate high-level AI Insight summary
    const topUrgent = selectedTopics[0];
    if (topUrgent) {
      let insightTitle = `Focus Revision: ${topUrgent.topicName}`;
      let insightDesc = "";

      if (topUrgent.closestExam && topUrgent.minExamDays <= 7) {
        insightDesc = `Your ${topUrgent.courseName} exam is only ${topUrgent.minExamDays} days away. Since your mastery in ${topUrgent.topicName} is currently ${topUrgent.masteryScore}%, the system prioritized targeted study blocks with rest intervals.`;
      } else if (topUrgent.masteryScore < 60) {
        insightDesc = `Recent test analytics flagged ${topUrgent.topicName} as a critical weak area (${topUrgent.masteryScore}%). Study time has been structured into focused sessions to eliminate weak points.`;
      } else {
        insightDesc = `Balanced study schedule active across ${selectedTopics.length} core topics. Rest intervals ensure sustained focus throughout your study window.`;
      }

      insights.push({
        topic: topUrgent.topicName,
        course: topUrgent.courseName,
        title: insightTitle,
        recommendation: insightDesc,
        trend: topUrgent.trendLabel,
        score: topUrgent.masteryScore
      });
    }

    return {
      sessions,
      changeDiffs,
      insights,
      totalMinutes,
      date: now.toISOString().split('T')[0]
    };
  }

  /**
   * Generates a clear explanation for why timetable durations & techniques changed
   */
  static generateExplanation(topic, deltaMins) {
    const reasons = [];

    if (topic.masteryScore < 60) {
      reasons.push(`recent mock test score was low (${topic.masteryScore}%)`);
    } else if (topic.masteryScore >= 80) {
      reasons.push(`topic mastery is high (${topic.masteryScore}%)`);
    }

    if (topic.closestExam && topic.minExamDays <= 14) {
      reasons.push(`${topic.courseName} exam is in ${topic.minExamDays} days`);
    }

    if (topic.urgentAssignment && topic.minAssignDays <= 5) {
      reasons.push(`"${topic.urgentAssignment.title}" is due in ${topic.minAssignDays} days`);
    }

    if (topic.trendLabel === "Improving") {
      reasons.push(`performance is showing positive momentum (+${topic.trendDelta}%)`);
    }

    const direction = deltaMins > 0 ? "Increased" : (deltaMins < 0 ? "Reduced" : "Balanced");
    const deltaStr = deltaMins !== 0 ? ` by ${Math.abs(deltaMins)} min` : "";

    if (reasons.length > 0) {
      return `${direction}${deltaStr} because your ${reasons.join(" and ")}. Scheduled with rest intervals.`;
    }
    return `Allocated for steady curriculum progression with planned rest intervals.`;
  }

  /**
   * Converts minute integer (e.g. 1080) to 12-hour formatted time ("6:00 PM")
   */
  static formatMinutesToTime(totalMins) {
    let hours = Math.floor(totalMins / 60) % 24;
    const mins = totalMins % 60;
    const ampm = hours >= 12 ? 'PM' : 'AM';
    let h12 = hours % 12;
    if (h12 === 0) h12 = 12;
    const mStr = mins < 10 ? '0' + mins : mins;
    return `${h12}:${mStr} ${ampm}`;
  }

  /**
   * Parses time string ("6:00 PM") into minutes from midnight (1080)
   */
  static parseTimeToMinutes(timeStr) {
    if (!timeStr) return 0;
    const parts = timeStr.trim().split(' ');
    const [hStr, mStr] = parts[0].split(':');
    let h = parseInt(hStr, 10);
    const m = parseInt(mStr, 10) || 0;
    const ampm = (parts[1] || '').toUpperCase();
    if (ampm === 'PM' && h < 12) h += 12;
    if (ampm === 'AM' && h === 12) h = 0;
    return h * 60 + m;
  }

  /**
   * Generates a Break-Aware Initial Baseline Timetable (equal allocation before mock testing)
   */
  static generateInitialTimetable(courses, userProfile = {}) {
    const totalMinutes = Math.round((userProfile.daily_hours || 3.0) * 60);
    const startStr = userProfile.preferred_start || '18:00';
    const [startH, startM] = startStr.split(':').map(Number);
    const now = new Date();

    const activeCourses = courses.slice(0, 3);
    if (activeCourses.length === 0) return [];

    let runningMinute = startH * 60 + startM;
    const endMinute = runningMinute + totalMinutes;
    const sessions = [];

    let cIdx = 0;
    while (runningMinute < endMinute) {
      const remainingMins = endMinute - runningMinute;
      if (remainingMins <= 0) break;

      const c = activeCourses[cIdx % activeCourses.length];
      const top = (c.topics && c.topics[0]) ? c.topics[0] : { id: 1, name: 'Core Foundations' };
      cIdx++;

      // Use Focused Study by default (50m study + 10m break)
      let studyMins = 50;
      let breakMins = 10;

      if (remainingMins < 60) {
        if (remainingMins >= 30) {
          studyMins = 25;
          breakMins = remainingMins - 25;
        } else {
          studyMins = remainingMins;
          breakMins = 0;
        }
      }

      if (studyMins < 10) {
        const lastStudy = [...sessions].reverse().find(s => !s.is_break);
        if (lastStudy) {
          lastStudy.duration_mins += remainingMins;
          const lastStartMins = AdaptiveEngine.parseTimeToMinutes(lastStudy.start_time);
          lastStudy.end_time = AdaptiveEngine.formatMinutesToTime(lastStartMins + lastStudy.duration_mins);
        }
        break;
      }

      const start = AdaptiveEngine.formatMinutesToTime(runningMinute);
      const end = AdaptiveEngine.formatMinutesToTime(runningMinute + studyMins);
      runningMinute += studyMins;

      sessions.push({
        id: `init_sess_${sessions.length + 1}`,
        day_date: now.toISOString().split('T')[0],
        is_break: false,
        type: 'study',
        start_time: start,
        end_time: end,
        duration_mins: studyMins,
        course_id: c.id,
        course_name: c.name,
        course_color: c.color || '#6366f1',
        topic_id: top.id,
        topic_name: top.name,
        study_technique: studyMins >= 50 ? 'Focused Study' : (studyMins >= 25 ? 'Pomodoro' : 'Quick Revision'),
        technique_id: studyMins >= 50 ? 'focused' : (studyMins >= 25 ? 'pomodoro' : 'quick'),
        break_duration: breakMins,
        goal: `Initial orientation and review of core ${top.name} concepts.`,
        priority: 'Medium',
        ai_rationale: 'Standard baseline allocation: Equal distribution across primary subjects before mock quiz performance.',
        change_delta_mins: 0,
        change_reason: 'Standard baseline allocation.',
        completed: 0,
        completion_status: null
      });

      if (breakMins > 0 && runningMinute < endMinute) {
        breakMins = Math.min(breakMins, endMinute - runningMinute);
        if (breakMins > 0) {
          const breakStart = AdaptiveEngine.formatMinutesToTime(runningMinute);
          const breakEnd = AdaptiveEngine.formatMinutesToTime(runningMinute + breakMins);
          runningMinute += breakMins;

          sessions.push({
            id: `init_break_${sessions.length + 1}`,
            day_date: now.toISOString().split('T')[0],
            is_break: true,
            type: 'break',
            start_time: breakStart,
            end_time: breakEnd,
            duration_mins: breakMins,
            title: '☕ Break Time',
            topic_name: 'Rest & Recharge',
            break_type: 'Scheduled Break',
            message: 'Take a short break before your next session.',
            completed: 0
          });
        }
      }
    }

    return sessions;
  }
}

// Export for browser
window.STUDY_TECHNIQUES = STUDY_TECHNIQUES;
window.AdaptiveEngine = AdaptiveEngine;
