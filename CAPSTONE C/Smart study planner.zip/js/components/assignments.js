/**
 * Study Planner - Assignments Component
 * Dedicated assignment tracking with the specialized Reminder / Alert scheduling feature.
 */

class AssignmentsComponent {
  static currentFilter = 'all'; // 'all' | 'pending' | 'completed'

  static render(container) {
    const data = window.state.data;
    const assignments = data.assignments || [];
    const courses = data.courses || [];

    const filtered = assignments.filter(a => {
      if (AssignmentsComponent.currentFilter === 'pending') return a.status !== 'completed';
      if (AssignmentsComponent.currentFilter === 'completed') return a.status === 'completed';
      return true;
    });

    const getCourse = (cid) => courses.find(c => c.id === cid) || { name: 'General', color: '#6366f1' };

    const cardsHtml = filtered.length > 0 ? filtered.map(asg => {
      const course = getCourse(asg.course_id);
      const isDone = asg.status === 'completed';
      const checkClass = isDone ? 'checked' : '';

      let priorityBadge = 'badge-info';
      if (asg.priority === 'High') priorityBadge = 'badge-danger';
      else if (asg.priority === 'Medium') priorityBadge = 'badge-warning';

      return `
        <div class="assignment-card ${isDone ? 'completed' : ''}" id="asg_card_${asg.id}">
          <div class="assignment-left">
            <div class="assignment-checkbox ${checkClass}" onclick="window.state.toggleAssignmentCompleted('${asg.id}')" title="${isDone ? 'Mark as Incomplete' : 'Mark as Complete'}" role="button" tabindex="0">
              ${isDone ? '✓' : ''}
            </div>
            <div class="assignment-info">
              <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
                <h4 style="${isDone ? 'text-decoration:line-through;color:var(--text-muted);' : ''}">${asg.title}</h4>
                <span class="badge" style="background:${course.color}20;color:${course.color};font-weight:700;">${course.name}</span>
                <span class="badge ${priorityBadge}">${asg.priority} Priority</span>
                <span class="badge ${isDone ? 'badge-success' : 'badge-warning'}" style="font-weight:700;display:inline-flex;align-items:center;gap:0.25rem;">
                  ${isDone ? '✓ Completed' : 'Pending'}
                </span>
              </div>
              <p class="assignment-desc">${asg.description || 'No additional instructions provided.'}</p>
              
              <div class="assignment-meta-row">
                <span>📅 <strong>Due:</strong> ${asg.due_date}</span>
                <span class="assignment-reminder-badge">
                  🔔 <strong>Alert:</strong> ${asg.reminder_setting || '24 hours before'}
                </span>
                ${asg.reminder_time ? `<span style="color:var(--text-muted);">Scheduled alert: ${asg.reminder_time}</span>` : ''}
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:0.6rem;flex-shrink:0;">
            <button class="btn-sm ${isDone ? 'btn-secondary' : 'btn-primary'}" onclick="window.state.toggleAssignmentCompleted('${asg.id}')" title="${isDone ? 'Mark as Incomplete' : 'Mark as Complete'}" style="font-weight:600;white-space:nowrap;">
              ${isDone ? '↺ Mark Incomplete' : '✓ Mark Complete'}
            </button>
            <button class="btn-sm btn-secondary" onclick="AssignmentsComponent.deleteAssignment('${asg.id}')" title="Delete Assignment">
              🗑️
            </button>
          </div>
        </div>
      `;
    }).join('') : `
      <div style="padding:2.5rem;text-align:center;background:var(--bg-surface);border:1px solid var(--border);border-radius:var(--radius-lg);color:var(--text-muted);">
        No assignments in this filter. Keep up the great work!
      </div>
    `;

    container.innerHTML = `
      <div class="assignments-toolbar">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Assignments & Deadlines</h2>
          <p style="font-size:0.85rem;color:var(--text-muted);">
            Track coursework deadlines with pre-submission automated reminders.
          </p>
        </div>
        <div style="display:flex;align-items:center;gap:0.75rem;">
          <div class="filter-pills">
            <button class="filter-pill ${AssignmentsComponent.currentFilter === 'all' ? 'active' : ''}" onclick="AssignmentsComponent.setFilter('all')">
              All (${assignments.length})
            </button>
            <button class="filter-pill ${AssignmentsComponent.currentFilter === 'pending' ? 'active' : ''}" onclick="AssignmentsComponent.setFilter('pending')">
              Pending (${assignments.filter(a => a.status !== 'completed').length})
            </button>
            <button class="filter-pill ${AssignmentsComponent.currentFilter === 'completed' ? 'active' : ''}" onclick="AssignmentsComponent.setFilter('completed')">
              Completed (${assignments.filter(a => a.status === 'completed').length})
            </button>
          </div>
          <button class="btn-primary" onclick="AssignmentsComponent.openAddAssignmentModal()">
            + Add Assignment
          </button>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:0.5rem;">
        ${cardsHtml}
      </div>
    `;
  }

  static setFilter(filter) {
    AssignmentsComponent.currentFilter = filter;
    AssignmentsComponent.render(document.getElementById('view_container'));
  }

  static openAddAssignmentModal() {
    const courses = window.state.data.courses || [];
    const courseOptions = courses.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

    // Pre-populate default due date in 3 days
    const defaultDate = new Date(Date.now() + 3 * 86400000);
    const dateStr = defaultDate.toISOString().substring(0, 10);

    window.App.showModal({
      title: 'Add New Assignment',
      body: `
        <div class="form-group">
          <label class="form-label">Assignment Title</label>
          <input type="text" id="asg_title" class="form-input" placeholder="e.g. Unit 2 Record, Lab Report, Essay" required />
        </div>

        <div class="form-group">
          <label class="form-label">Subject</label>
          <select id="asg_course_id" class="form-select">
            ${courseOptions}
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Description / Instructions</label>
          <textarea id="asg_desc" class="form-textarea" rows="2" placeholder="Key deliverables or notes..."></textarea>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group">
            <label class="form-label">Submission Due Date & Time</label>
            <input type="datetime-local" id="asg_due" class="form-input" value="${dateStr}T17:00" required />
          </div>
          <div class="form-group">
            <label class="form-label">Priority</label>
            <select id="asg_priority" class="form-select">
              <option value="High">High Priority</option>
              <option value="Medium" selected>Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>
          </div>
        </div>

        <!-- SPECIAL ASSIGNMENT REMINDER FEATURE BOX -->
        <div class="reminder-select-box">
          <div class="reminder-box-title">
            <span>🔔 When should we remind you before the submission deadline?</span>
          </div>
          <p style="font-size:0.75rem;color:#0369a1;margin-bottom:0.75rem;">
            Select when you would like an alert notification triggered before submission.
          </p>

          <div class="reminder-options-grid">
            <label class="reminder-radio-label">
              <input type="radio" name="reminder_opt" value="1 hour before" />
              <span>1 hour before</span>
            </label>
            <label class="reminder-radio-label">
              <input type="radio" name="reminder_opt" value="3 hours before" />
              <span>3 hours before</span>
            </label>
            <label class="reminder-radio-label">
              <input type="radio" name="reminder_opt" value="6 hours before" />
              <span>6 hours before</span>
            </label>
            <label class="reminder-radio-label">
              <input type="radio" name="reminder_opt" value="12 hours before" />
              <span>12 hours before</span>
            </label>
            <label class="reminder-radio-label">
              <input type="radio" name="reminder_opt" value="24 hours before" checked />
              <span>24 hours before</span>
            </label>
            <label class="reminder-radio-label">
              <input type="radio" name="reminder_opt" value="2 days before" />
              <span>2 days before</span>
            </label>
          </div>
        </div>
      `,
      confirmText: 'Schedule Assignment & Reminder',
      onConfirm: async () => {
        const title = document.getElementById('asg_title').value.trim();
        const course_id = Number(document.getElementById('asg_course_id').value);
        const description = document.getElementById('asg_desc').value.trim();
        const due_date = document.getElementById('asg_due').value.replace('T', ' ');
        const priority = document.getElementById('asg_priority').value;

        const reminderRadio = document.querySelector('input[name="reminder_opt"]:checked');
        const reminder_setting = reminderRadio ? reminderRadio.value : '24 hours before';

        if (!title) {
          window.App.showToast('Please enter an assignment title', 'error');
          return;
        }

        // Calculate reminder time
        const dueTime = new Date(document.getElementById('asg_due').value).getTime();
        let offsetMs = 24 * 3600000;
        if (reminder_setting.includes('1 hour')) offsetMs = 1 * 3600000;
        else if (reminder_setting.includes('3 hours')) offsetMs = 3 * 3600000;
        else if (reminder_setting.includes('6 hours')) offsetMs = 6 * 3600000;
        else if (reminder_setting.includes('12 hours')) offsetMs = 12 * 3600000;
        else if (reminder_setting.includes('2 days')) offsetMs = 48 * 3600000;

        const reminder_time = new Date(dueTime - offsetMs).toISOString().replace('T', ' ').substring(0, 16);

        await ApiService.addAssignment({
          title,
          course_id,
          description,
          due_date,
          priority,
          reminder_setting,
          reminder_time
        });

        await window.state.loadBootstrap();
        window.App.showToast(`Assignment saved! Reminder set for ${reminder_setting}.`, 'success');
        AssignmentsComponent.render(document.getElementById('view_container'));
      }
    });
  }

  static async deleteAssignment(id) {
    if (confirm("Are you sure you want to remove this assignment?")) {
      const store = ApiService.getLocalStore();
      store.assignments = store.assignments.filter(a => a.id !== id);
      ApiService.saveLocalStore(store);
      await window.state.loadBootstrap();
      window.App.showToast("Assignment removed.", "info");
      AssignmentsComponent.render(document.getElementById('view_container'));
    }
  }
}

// Export for browser
window.AssignmentsComponent = AssignmentsComponent;
