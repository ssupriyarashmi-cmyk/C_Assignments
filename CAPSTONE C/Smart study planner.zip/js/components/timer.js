/**
 * Study Planner - Study Session Timer & Break System Component
 * Implements Section 5, 6, 7:
 * - Study Session Timer with countdown, pause/resume, and goal display
 * - Session Completion assessment (Completed, Partially Completed, Not Completed)
 * - Break Timer with countdown, skip break, and next session chaining
 */

class StudyTimerComponent {
  static currentSession = null;
  static timerMode = 'study'; // 'study' | 'completion_check' | 'break' | 'finished'
  static remainingSeconds = 0;
  static totalSeconds = 0;
  static isPaused = false;
  static intervalId = null;

  static breakRemainingSeconds = 0;
  static breakTotalSeconds = 0;
  static isBreakPaused = false;
  static breakIntervalId = null;

  static selectedCompletionStatus = 'Completed';

  /**
   * Opens the timer for a specific study session ID
   */
  static openTimer(sessionId) {
    const timetable = window.state.data.timetable || [];
    const session = timetable.find(s => s.id === sessionId);

    if (!session) {
      window.App.showToast("Session not found", "error");
      return;
    }

    if (session.is_break) {
      // Direct break launch
      StudyTimerComponent.startDirectBreak(session);
      return;
    }

    StudyTimerComponent.currentSession = session;
    StudyTimerComponent.timerMode = 'study';
    StudyTimerComponent.isPaused = false;
    StudyTimerComponent.totalSeconds = Math.max(60, (session.duration_mins || 50) * 60);
    StudyTimerComponent.remainingSeconds = StudyTimerComponent.totalSeconds;

    StudyTimerComponent.startStudyCountdown();
    StudyTimerComponent.renderModal();
  }

  /**
   * Starts accurate 1-second study countdown
   */
  static startStudyCountdown() {
    if (StudyTimerComponent.intervalId) clearInterval(StudyTimerComponent.intervalId);

    StudyTimerComponent.intervalId = setInterval(() => {
      if (!StudyTimerComponent.isPaused) {
        StudyTimerComponent.remainingSeconds--;
        StudyTimerComponent.updateClockDisplay();

        if (StudyTimerComponent.remainingSeconds <= 0) {
          clearInterval(StudyTimerComponent.intervalId);
          StudyTimerComponent.playChime();
          StudyTimerComponent.promptCompletionCheck();
        }
      }
    }, 1000);
  }

  /**
   * Pauses / Resumes Study Timer
   */
  static togglePauseStudy() {
    StudyTimerComponent.isPaused = !StudyTimerComponent.isPaused;
    StudyTimerComponent.renderModal();
  }

  /**
   * Ends study session early
   */
  static endSessionEarly() {
    if (StudyTimerComponent.intervalId) clearInterval(StudyTimerComponent.intervalId);
    StudyTimerComponent.promptCompletionCheck();
  }

  /**
   * Shows Goal Completion Question (Section 7)
   */
  static promptCompletionCheck() {
    StudyTimerComponent.timerMode = 'completion_check';
    StudyTimerComponent.selectedCompletionStatus = 'Completed';
    StudyTimerComponent.renderModal();
  }

  /**
   * Submits Goal Completion & Transitions to Break (Section 6 & 7)
   */
  static async submitGoalCompletion() {
    const session = StudyTimerComponent.currentSession;
    const status = StudyTimerComponent.selectedCompletionStatus;

    if (session) {
      await window.state.recordSessionCompletion(session.id, status);
      window.App.showToast(`Session recorded as ${status}!`, 'success');
    }

    // Determine break duration
    const breakMins = (session && session.break_duration > 0) ? session.break_duration : 10;
    StudyTimerComponent.startBreakCountdown(breakMins);
  }

  /**
   * Starts Break Countdown
   */
  static startBreakCountdown(breakMins = 10) {
    if (StudyTimerComponent.breakIntervalId) clearInterval(StudyTimerComponent.breakIntervalId);

    StudyTimerComponent.timerMode = 'break';
    StudyTimerComponent.isBreakPaused = false;
    StudyTimerComponent.breakTotalSeconds = breakMins * 60;
    StudyTimerComponent.breakRemainingSeconds = StudyTimerComponent.breakTotalSeconds;

    StudyTimerComponent.breakIntervalId = setInterval(() => {
      if (!StudyTimerComponent.isBreakPaused) {
        StudyTimerComponent.breakRemainingSeconds--;
        StudyTimerComponent.updateBreakClockDisplay();

        if (StudyTimerComponent.breakRemainingSeconds <= 0) {
          clearInterval(StudyTimerComponent.breakIntervalId);
          StudyTimerComponent.playChime();
          StudyTimerComponent.finishBreak();
        }
      }
    }, 1000);

    StudyTimerComponent.renderModal();
  }

  static togglePauseBreak() {
    StudyTimerComponent.isBreakPaused = !StudyTimerComponent.isBreakPaused;
    StudyTimerComponent.renderModal();
  }

  static skipBreak() {
    if (StudyTimerComponent.breakIntervalId) clearInterval(StudyTimerComponent.breakIntervalId);
    StudyTimerComponent.finishBreak();
  }

  static finishBreak() {
    StudyTimerComponent.timerMode = 'finished';
    StudyTimerComponent.renderModal();
  }

  /**
   * Finds the next study session in the timetable after currentSession
   */
  static getNextStudySession() {
    const timetable = window.state.data.timetable || [];
    if (!StudyTimerComponent.currentSession) {
      return timetable.find(s => !s.is_break && !s.completed) || null;
    }
    const currentIdx = timetable.findIndex(s => s.id === StudyTimerComponent.currentSession.id);
    if (currentIdx === -1) {
      return timetable.find(s => !s.is_break && !s.completed) || null;
    }

    // Find next session that is not a break and not completed
    for (let i = currentIdx + 1; i < timetable.length; i++) {
      if (!timetable[i].is_break) {
        return timetable[i];
      }
    }
    return null;
  }

  static startNextSession() {
    const next = StudyTimerComponent.getNextStudySession();
    if (next) {
      StudyTimerComponent.closeModal();
      StudyTimerComponent.openTimer(next.id);
    } else {
      StudyTimerComponent.closeModal();
      window.App.showToast("All scheduled sessions for today are complete! Excellent work.", "success");
      window.state.setView('planner');
    }
  }

  static startDirectBreak(breakSession) {
    StudyTimerComponent.currentSession = null;
    StudyTimerComponent.startBreakCountdown(breakSession.duration_mins || 10);
  }

  static closeModal() {
    if (StudyTimerComponent.intervalId) clearInterval(StudyTimerComponent.intervalId);
    if (StudyTimerComponent.breakIntervalId) clearInterval(StudyTimerComponent.breakIntervalId);

    const overlay = document.getElementById('study_timer_overlay');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.style.display = 'none';
    }
  }

  /**
   * Formats seconds into MM:SS
   */
  static formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  }

  static updateClockDisplay() {
    const clockEl = document.getElementById('timer_clock_display');
    if (clockEl) {
      clockEl.textContent = StudyTimerComponent.formatTime(StudyTimerComponent.remainingSeconds);
    }
    const barEl = document.getElementById('timer_progress_bar_fill');
    if (barEl && StudyTimerComponent.totalSeconds > 0) {
      const pct = Math.max(0, Math.min(100, ((StudyTimerComponent.totalSeconds - StudyTimerComponent.remainingSeconds) / StudyTimerComponent.totalSeconds) * 100));
      barEl.style.width = `${pct}%`;
    }
  }

  static updateBreakClockDisplay() {
    const clockEl = document.getElementById('break_clock_display');
    if (clockEl) {
      clockEl.textContent = StudyTimerComponent.formatTime(StudyTimerComponent.breakRemainingSeconds);
    }
    const barEl = document.getElementById('break_progress_bar_fill');
    if (barEl && StudyTimerComponent.breakTotalSeconds > 0) {
      const pct = Math.max(0, Math.min(100, ((StudyTimerComponent.breakTotalSeconds - StudyTimerComponent.breakRemainingSeconds) / StudyTimerComponent.breakTotalSeconds) * 100));
      barEl.style.width = `${pct}%`;
    }
  }

  /**
   * Soft web audio chime feedback
   */
  static playChime() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3); // A5
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
      osc.start();
      osc.stop(ctx.currentTime + 0.85);
    } catch (e) {
      // AudioContext unavailable or blocked by policy
    }
  }

  /**
   * Main Render Method for Timer Modal
   */
  static renderModal() {
    let overlay = document.getElementById('study_timer_overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'study_timer_overlay';
      overlay.className = 'timer-overlay';
      document.body.appendChild(overlay);
    }

    const session = StudyTimerComponent.currentSession || {};
    const mode = StudyTimerComponent.timerMode;
    const nextSession = StudyTimerComponent.getNextStudySession();

    let contentHtml = '';

    // ==========================================
    // 1. ACTIVE STUDY TIMER (Section 5)
    // ==========================================
    if (mode === 'study') {
      const timeStr = StudyTimerComponent.formatTime(StudyTimerComponent.remainingSeconds);
      const isPaused = StudyTimerComponent.isPaused;
      const techniqueName = session.study_technique || 'Focused Study';
      const techBadge = techniqueName.includes('Pomodoro') ? '🍅 Pomodoro' :
                        (techniqueName.includes('Deep') ? '🌊 Deep Study' : '🎯 Focused Study');

      contentHtml = `
        <div class="timer-modal-box">
          <div class="timer-modal-header" style="border-bottom:1px solid var(--border);">
            <div style="display:flex;align-items:center;gap:0.75rem;">
              <div class="course-avatar" style="width:38px;height:38px;font-size:0.9rem;background:${session.course_color || 'var(--primary)'};">
                ${(session.course_name || 'ST').substring(0, 2).toUpperCase()}
              </div>
              <div>
                <span class="badge" style="background:${session.course_color || 'var(--primary)'}20;color:${session.course_color || 'var(--primary)'};font-weight:700;">
                  ${session.course_name || 'Subject'}
                </span>
                <h3 style="font-size:1.15rem;font-weight:800;color:var(--text-main);margin-top:2px;">
                  ${session.topic_name || 'Study Session'}
                </h3>
              </div>
            </div>
            <button class="modal-close-btn" onclick="StudyTimerComponent.closeModal()" title="Close Timer">✕</button>
          </div>

          <div class="timer-body">
            <!-- Technique & Status Pill -->
            <div style="display:flex;align-items:center;justify-content:center;gap:0.75rem;margin-bottom:1rem;">
              <span class="badge" style="background:#ede9fe;color:#6d28d9;font-weight:700;font-size:0.85rem;padding:0.35rem 0.85rem;">
                ${techBadge} • ${session.duration_mins} min
              </span>
              <span class="badge ${session.priority === 'High' ? 'badge-danger' : 'badge-warning'}">
                ${session.priority || 'Medium'} Priority
              </span>
            </div>

            <!-- Digital Countdown Display -->
            <div class="timer-countdown-container">
              <div id="timer_clock_display" class="timer-clock-digits ${isPaused ? 'paused' : ''}">
                ${timeStr}
              </div>
              <div class="timer-status-hint">
                ${isPaused ? '⏸️ Session Paused' : '⚡ Focused Study in Progress'}
              </div>

              <!-- Progress Bar -->
              <div class="timer-progress-track">
                <div id="timer_progress_bar_fill" class="timer-progress-fill" style="width:0%;"></div>
              </div>
            </div>

            <!-- Session Goal Card (Section 4 & 5) -->
            <div class="timer-goal-card">
              <div class="timer-goal-title">
                <span>🎯 Session Goal:</span>
              </div>
              <p class="timer-goal-text">
                ${session.goal || 'Focus on understanding core principles and solve 5 practice questions.'}
              </p>
            </div>

            <!-- AI Rationale -->
            ${session.ai_rationale ? `
              <div style="font-size:0.78rem;color:var(--text-muted);background:var(--bg-subtle);padding:0.6rem 0.85rem;border-radius:var(--radius-md);margin-bottom:1.5rem;text-align:left;">
                💡 <strong>AI Rationale:</strong> ${session.ai_rationale}
              </div>
            ` : ''}

            <!-- Controls -->
            <div class="timer-actions-row">
              <button class="btn-secondary" style="padding:0.75rem 1.5rem;font-size:0.95rem;" onclick="StudyTimerComponent.togglePauseStudy()">
                ${isPaused ? '▶ Resume' : '⏸ Pause'}
              </button>
              <button class="btn-primary" style="padding:0.75rem 1.75rem;font-size:0.95rem;background:#10b981;" onclick="StudyTimerComponent.endSessionEarly()">
                ✓ End Session
              </button>
            </div>
          </div>
        </div>
      `;
    }

    // ==========================================
    // 2. COMPLETION ASSESSMENT (Section 7)
    // ==========================================
    else if (mode === 'completion_check') {
      contentHtml = `
        <div class="timer-modal-box">
          <div class="timer-modal-header" style="text-align:center;padding:1.5rem 1.5rem 0.75rem;">
            <div style="font-size:2.5rem;margin-bottom:0.5rem;">🎉</div>
            <h3 style="font-size:1.35rem;font-weight:800;color:var(--text-main);">Study Session Completed!</h3>
            <p style="font-size:0.85rem;color:var(--text-muted);margin-top:0.25rem;">
              ${session.course_name || 'Subject'} — ${session.topic_name || 'Topic'}
            </p>
          </div>

          <div class="timer-body" style="padding-top:0.75rem;">
            <!-- Goal Display -->
            <div class="timer-goal-card" style="margin-bottom:1.5rem;border-color:#c7d2fe;background:#f5f3ff;">
              <div class="timer-goal-title" style="color:#4f46e5;">
                <span>🎯 Stated Goal:</span>
              </div>
              <p class="timer-goal-text" style="color:#3730a3;font-weight:600;">
                ${session.goal || 'Complete core concept review and exercises.'}
              </p>
            </div>

            <div style="font-size:1rem;font-weight:700;color:var(--text-main);margin-bottom:0.75rem;">
              Did you complete your study goal?
            </div>

            <!-- 3 Completion Choices (Section 7) -->
            <div class="completion-options-grid">
              <button class="completion-choice-btn ${StudyTimerComponent.selectedCompletionStatus === 'Completed' ? 'selected' : ''}"
                onclick="StudyTimerComponent.selectCompletion('Completed')">
                <span style="font-size:1.5rem;">🟢</span>
                <div style="text-align:left;">
                  <div style="font-weight:700;font-size:0.95rem;">Completed</div>
                  <div style="font-size:0.75rem;color:var(--text-muted);">Accomplished all intended problems & concepts.</div>
                </div>
              </button>

              <button class="completion-choice-btn ${StudyTimerComponent.selectedCompletionStatus === 'Partially Completed' ? 'selected' : ''}"
                onclick="StudyTimerComponent.selectCompletion('Partially Completed')">
                <span style="font-size:1.5rem;">🟡</span>
                <div style="text-align:left;">
                  <div style="font-weight:700;font-size:0.95rem;">Partially Completed</div>
                  <div style="font-size:0.75rem;color:var(--text-muted);">Made solid progress, but some questions remain.</div>
                </div>
              </button>

              <button class="completion-choice-btn ${StudyTimerComponent.selectedCompletionStatus === 'Not Completed' ? 'selected' : ''}"
                onclick="StudyTimerComponent.selectCompletion('Not Completed')">
                <span style="font-size:1.5rem;">🔴</span>
                <div style="text-align:left;">
                  <div style="font-weight:700;font-size:0.95rem;">Not Completed</div>
                  <div style="font-size:0.75rem;color:var(--text-muted);">Faced difficulties or ran out of time.</div>
                </div>
              </button>
            </div>

            <div style="margin-top:1.5rem;">
              <button class="btn-primary" style="width:100%;padding:0.85rem;font-size:1rem;" onclick="StudyTimerComponent.submitGoalCompletion()">
                Save & Proceed to Break ☕
              </button>
            </div>
          </div>
        </div>
      `;
    }

    // ==========================================
    // 3. BREAK TIMER (Section 6)
    // ==========================================
    else if (mode === 'break') {
      const breakTimeStr = StudyTimerComponent.formatTime(StudyTimerComponent.breakRemainingSeconds);
      const isBreakPaused = StudyTimerComponent.isBreakPaused;

      contentHtml = `
        <div class="timer-modal-box">
          <div class="timer-modal-header" style="border-bottom:1px solid var(--border);">
            <div style="display:flex;align-items:center;gap:0.75rem;">
              <div style="width:40px;height:40px;border-radius:var(--radius-full);background:#fef3c7;display:flex;align-items:center;justify-content:center;font-size:1.3rem;">
                ☕
              </div>
              <div>
                <h3 style="font-size:1.25rem;font-weight:800;color:#92400e;">Break Time</h3>
                <p style="font-size:0.82rem;color:var(--text-muted);">Take a short break before your next session</p>
              </div>
            </div>
            <button class="modal-close-btn" onclick="StudyTimerComponent.skipBreak()" title="Skip Break">✕</button>
          </div>

          <div class="timer-body">
            <!-- Break Countdown -->
            <div class="timer-countdown-container" style="background:#fffbeb;border:2px dashed #fcd34d;">
              <div id="break_clock_display" class="timer-clock-digits" style="color:#b45309;">
                ${breakTimeStr}
              </div>
              <div class="timer-status-hint" style="color:#92400e;">
                ${isBreakPaused ? '⏸️ Break Paused' : '🌿 Rest, hydrate, and relax your eyes'}
              </div>

              <div class="timer-progress-track">
                <div id="break_progress_bar_fill" class="timer-progress-fill" style="background:#f59e0b;width:0%;"></div>
              </div>
            </div>

            <!-- Encouraging Message -->
            <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:var(--radius-md);padding:0.85rem 1rem;margin-bottom:1.25rem;text-align:left;">
              <div style="font-size:0.85rem;font-weight:700;color:#166534;margin-bottom:0.25rem;">
                💡 Why Breaks Matter:
              </div>
              <p style="font-size:0.8rem;color:#15803d;line-height:1.45;">
                Cognitive science shows that structured rest intervals consolidate neural pathways, prevent study burnout, and improve quiz performance.
              </p>
            </div>

            <!-- Next Up Preview -->
            ${nextSession ? `
              <div style="background:var(--bg-subtle);border-radius:var(--radius-md);padding:0.85rem 1rem;margin-bottom:1.5rem;text-align:left;border-left:4px solid ${nextSession.course_color || 'var(--primary)'};">
                <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;">
                  Next Session:
                </div>
                <div style="font-size:0.95rem;font-weight:800;color:var(--text-main);margin-top:2px;">
                  ${nextSession.course_name} — ${nextSession.topic_name}
                </div>
                <div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;">
                  ${nextSession.duration_mins} min • ${nextSession.study_technique || 'Focused Study'} (${nextSession.start_time})
                </div>
              </div>
            ` : `
              <div style="font-size:0.85rem;color:var(--text-muted);margin-bottom:1.5rem;">
                🎉 This was your last scheduled study session for today!
              </div>
            `}

            <!-- Controls -->
            <div class="timer-actions-row">
              <button class="btn-secondary" style="padding:0.75rem 1.25rem;" onclick="StudyTimerComponent.togglePauseBreak()">
                ${isBreakPaused ? '▶ Resume Break' : '⏸ Pause'}
              </button>
              <button class="btn-primary" style="padding:0.75rem 1.5rem;background:#d97706;" onclick="StudyTimerComponent.skipBreak()">
                Skip Break & Continue ➔
              </button>
            </div>
          </div>
        </div>
      `;
    }

    // ==========================================
    // 4. BREAK FINISHED / NEXT SESSION
    // ==========================================
    else if (mode === 'finished') {
      contentHtml = `
        <div class="timer-modal-box" style="text-align:center;">
          <div style="padding:2rem 1.5rem 1.5rem;">
            <div style="font-size:3rem;margin-bottom:0.75rem;">✨</div>
            <h3 style="font-size:1.4rem;font-weight:800;color:var(--text-main);">Break Complete!</h3>
            <p style="font-size:0.88rem;color:var(--text-muted);margin-top:0.25rem;max-width:380px;margin-left:auto;margin-right:auto;">
              You are refreshed and ready for your next study block.
            </p>

            ${nextSession ? `
              <div style="background:#faf5ff;border:1px solid #e9d5ff;border-radius:var(--radius-lg);padding:1.25rem;margin:1.5rem 0;text-align:left;border-left:5px solid ${nextSession.course_color || 'var(--primary)'};">
                <span class="badge" style="background:#ede9fe;color:#7c3aed;font-weight:700;">Up Next</span>
                <div style="font-size:1.1rem;font-weight:800;color:var(--text-main);margin-top:0.4rem;">
                  ${nextSession.course_name} — ${nextSession.topic_name}
                </div>
                <div style="font-size:0.82rem;color:var(--text-muted);margin-top:0.25rem;">
                  ${nextSession.duration_mins} min • ${nextSession.study_technique || 'Focused Study'}
                </div>
                <div style="font-size:0.8rem;color:#4c1d95;margin-top:0.5rem;font-weight:600;">
                  🎯 Goal: ${nextSession.goal || 'Focus on practice questions.'}
                </div>
              </div>

              <div style="display:flex;gap:1rem;justify-content:center;">
                <button class="btn-secondary" onclick="StudyTimerComponent.closeModal()">
                  Back to Planner
                </button>
                <button class="btn-primary" style="padding:0.75rem 1.75rem;" onclick="StudyTimerComponent.startNextSession()">
                  ▶ Start Next Session Now
                </button>
              </div>
            ` : `
              <div style="margin:2rem 0;">
                <p style="font-weight:700;color:var(--success);font-size:1.1rem;">
                  🏆 You completed today's entire adaptive study timetable!
                </p>
                <p style="font-size:0.85rem;color:var(--text-muted);margin-top:0.5rem;">
                  Ready to test your retention? Take a quick mock quiz to feed tomorrow's adaptive plan.
                </p>
              </div>

              <div style="display:flex;gap:1rem;justify-content:center;">
                <button class="btn-secondary" onclick="StudyTimerComponent.closeModal()">
                  Close
                </button>
                <button class="btn-primary" onclick="StudyTimerComponent.closeModal(); window.state.setView('quiz');">
                  ⚡ Take Diagnostic Quiz
                </button>
              </div>
            `}
          </div>
        </div>
      `;
    }

    overlay.innerHTML = contentHtml;
    overlay.style.display = 'flex';
    overlay.classList.add('active');
  }

  static selectCompletion(status) {
    StudyTimerComponent.selectedCompletionStatus = status;
    StudyTimerComponent.renderModal();
  }
}

// Export for browser
window.StudyTimerComponent = StudyTimerComponent;
