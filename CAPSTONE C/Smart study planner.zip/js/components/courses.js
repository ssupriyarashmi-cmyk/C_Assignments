/**
 * Study Planner - Courses Component
 * Topic-level subject management & mastery tracking.
 */

class CoursesComponent {
  static render(container) {
    const data = window.state.data;
    const courses = data.courses || [];

    const coursesHtml = courses.map(course => {
      const topics = course.topics || [];
      const avgScore = course.average_performance || 0;
      const weakCount = course.weak_topics_count || 0;
      const testsCount = course.upcoming_tests_count || 0;

      const topicsHtml = topics.map(t => {
        const score = t.mastery_score || 70;
        let badgeClass = 'badge-success';
        let statusText = 'Mastered';
        if (score < 65) {
          badgeClass = 'badge-danger';
          statusText = 'Needs Attention';
        } else if (score < 80) {
          badgeClass = 'badge-warning';
          statusText = 'Improving';
        }

        return `
          <div class="topic-item">
            <span style="font-weight:600;color:var(--text-main);">${t.name}</span>
            <div style="display:flex;align-items:center;gap:0.5rem;">
              <span class="badge ${badgeClass}">${statusText}</span>
              <span class="topic-score-badge" style="background:#f1f5f9;color:var(--text-main);">${score}%</span>
            </div>
          </div>
        `;
      }).join('');

      return `
        <div class="course-card">
          <div class="course-card-top">
            <div class="course-header-info">
              <div class="course-avatar" style="background:${course.color || 'var(--primary)'};">
                ${course.name.substring(0, 2).toUpperCase()}
              </div>
              <div>
                <h3 class="course-title">${course.name}</h3>
                <span class="course-code">${course.code || 'CORE'}</span>
              </div>
            </div>
            <button class="btn-sm btn-secondary" onclick="CoursesComponent.openAddTopicModal(${course.id}, '${course.name}')">
              + Add Topic
            </button>
          </div>

          <div class="course-stats-row">
            <div class="course-stat-mini">
              <div class="num" style="color:${avgScore < 65 ? 'var(--danger)' : 'var(--text-main)'};">${avgScore}%</div>
              <div class="lbl">Avg Score</div>
            </div>
            <div class="course-stat-mini">
              <div class="num" style="color:${weakCount > 0 ? 'var(--danger)' : 'var(--success)'};">${weakCount}</div>
              <div class="lbl">Weak Topics</div>
            </div>
            <div class="course-stat-mini">
              <div class="num" style="color:var(--primary);">${testsCount}</div>
              <div class="lbl">Upcoming Tests</div>
            </div>
          </div>

          <div class="topic-list-group">
            <div class="topic-list-title">
              <span>Topics (${topics.length})</span>
              <span style="font-size:0.7rem;text-transform:none;color:var(--text-muted);">Topic-Level Mastery</span>
            </div>
            ${topicsHtml}
          </div>

          <div style="margin-top:auto;padding-top:0.75rem;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
            <span style="font-size:0.75rem;color:var(--text-muted);">${topics.length} topics tracked by AI</span>
            <button class="btn-sm btn-primary" onclick="window.App.startQuizForCourse('${course.name}')">
              ⚡ Test This Subject
            </button>
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem;">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Course & Topic Directory</h2>
          <p style="font-size:0.85rem;color:var(--text-muted);">
            Manage subjects and fine-grained topics. The AI timetable adapts dynamically based on topic mastery.
          </p>
        </div>
        <button class="btn-primary" onclick="CoursesComponent.openAddCourseModal()">
          + Add New Course
        </button>
      </div>

      <div class="courses-grid">
        ${coursesHtml}
      </div>
    `;
  }

  static openAddCourseModal() {
    window.App.showModal({
      title: 'Add New Course',
      body: `
        <div class="form-group">
          <label class="form-label">Course Name</label>
          <input type="text" id="new_course_name" class="form-input" placeholder="e.g. Molecular Biology, Calculus II" required />
        </div>
        <div class="form-group">
          <label class="form-label">Course Code</label>
          <input type="text" id="new_course_code" class="form-input" placeholder="e.g. BIO201" />
        </div>
        <div class="form-group">
          <label class="form-label">Initial Topics (comma-separated)</label>
          <input type="text" id="new_course_topics" class="form-input" placeholder="e.g. Cell Membrane, Photosynthesis, Genetics" />
          <span class="form-hint">Separate topics by commas. These will be individually tracked by the AI.</span>
        </div>
        <div class="form-group">
          <label class="form-label">Card Theme Color</label>
          <select id="new_course_color" class="form-select">
            <option value="#8B5CF6">Purple / Violet</option>
            <option value="#3B82F6">Blue</option>
            <option value="#10B981">Emerald Green</option>
            <option value="#EC4899">Pink</option>
            <option value="#F59E0B">Amber</option>
            <option value="#06B6D4">Cyan</option>
          </select>
        </div>
      `,
      confirmText: 'Create Course',
      onConfirm: async () => {
        const name = document.getElementById('new_course_name').value.trim();
        const code = document.getElementById('new_course_code').value.trim();
        const color = document.getElementById('new_course_color').value;
        const topicsStr = document.getElementById('new_course_topics').value.trim();

        if (!name) {
          window.App.showToast('Please provide a course name', 'error');
          return;
        }

        const topics = topicsStr ? topicsStr.split(',').map(s => s.trim()).filter(Boolean) : ['Topic 1', 'Topic 2'];
        const store = ApiService.getLocalStore();
        const newCourseId = Date.now();
        const newCourse = {
          id: newCourseId,
          name,
          code,
          color,
          average_performance: 70.0,
          weak_topics_count: 0,
          upcoming_tests_count: 0,
          topics: topics.map((tname, idx) => ({
            id: newCourseId + idx + 1,
            course_id: newCourseId,
            name: tname,
            mastery_score: 70.0,
            status: 'neutral',
            tests_taken: 0
          }))
        };

        store.courses.push(newCourse);
        ApiService.saveLocalStore(store);
        await window.state.loadBootstrap();
        window.App.showToast(`Course "${name}" created with ${topics.length} topics!`, 'success');
        CoursesComponent.render(document.getElementById('view_container'));
      }
    });
  }

  static openAddTopicModal(courseId, courseName) {
    window.App.showModal({
      title: `Add Topic to ${courseName}`,
      body: `
        <div class="form-group">
          <label class="form-label">Topic Name</label>
          <input type="text" id="new_topic_name" class="form-input" placeholder="e.g. Enthalpy, Magnetism, Trees" required />
          <span class="form-hint">Topic will be tracked in quizzes and adaptive schedules.</span>
        </div>
      `,
      confirmText: 'Add Topic',
      onConfirm: async () => {
        const tname = document.getElementById('new_topic_name').value.trim();
        if (!tname) return;

        const store = ApiService.getLocalStore();
        const course = store.courses.find(c => c.id === courseId);
        if (course) {
          if (!course.topics) course.topics = [];
          course.topics.push({
            id: Date.now(),
            course_id: courseId,
            name: tname,
            mastery_score: 70.0,
            status: 'neutral',
            tests_taken: 0
          });
          ApiService.saveLocalStore(store);
          await window.state.loadBootstrap();
          window.App.showToast(`Topic "${tname}" added to ${courseName}!`, 'success');
          CoursesComponent.render(document.getElementById('view_container'));
        }
      }
    });
  }
}

// Export for browser
window.CoursesComponent = CoursesComponent;
