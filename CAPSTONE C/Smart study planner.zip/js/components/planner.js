/**
 * Study Planner - Planner Component (Break-Aware Adaptive Timetable)
 * Displays Daily & Weekly timetable views, visual indicators for Initial vs Adaptive plans,
 * study technique tags, session goals, priority, AI rationale, breaks, and session timer launcher.
 */

class PlannerComponent {
  static currentViewMode = 'daily'; // 'daily' | 'weekly'

  static render(container) {
    const data = window.state.data;
    const user = data.user || {};
    const timetable = data.timetable || [];
    const initialTimetable = data.initialTimetable || [];
    const isAdaptive = data.timetableMode === 'adaptive';
    const activeSessions = isAdaptive ? timetable : initialTimetable;

    // Calculate total allocated minutes (study + breaks)
    const totalAllocatedMins = activeSessions.reduce((acc, s) => acc + (s.duration_mins || 0), 0);
    const studySessionsOnly = activeSessions.filter(s => !s.is_break);
    const totalStudyMins = studySessionsOnly.reduce((acc, s) => acc + (s.duration_mins || 0), 0);
    const totalBreakMins = totalAllocatedMins - totalStudyMins;
    const targetMins = Math.round((user.daily_hours || 3.0) * 60);

    // Compute diff summary badges
    const diffsMap = {};
    if (isAdaptive) {
      studySessionsOnly.forEach(s => {
        if (s.change_delta_mins && s.change_delta_mins !== 0) {
          const cName = s.course_name || 'General';
          if (!diffsMap[cName]) diffsMap[cName] = 0;
          diffsMap[cName] += s.change_delta_mins;
        }
      });
    }

    const diffChipsHtml = Object.keys(diffsMap).map(cName => {
      const delta = diffsMap[cName];
      const isUp = delta > 0;
      return `
        <span class="diff-chip ${isUp ? 'up' : 'down'}">
          ${cName}: ${isUp ? '+' : ''}${delta} min
        </span>
      `;
    }).join('');

    // Daily View HTML
    const dailyHtml = `
      <div class="card" style="margin-bottom:1.5rem;">
        <div class="card-header" style="flex-wrap:wrap;gap:1rem;">
          <div>
            <h3 class="card-title">Today's Schedule (${isAdaptive ? 'Adaptive Plan' : 'Initial Plan'})</h3>
            <span class="card-subtitle">
              ${user.preferred_start || '18:00'} to ${user.preferred_end || '21:00'} • ${totalStudyMins}m study + ${totalBreakMins}m breaks = ${totalAllocatedMins}m / ${targetMins}m available
            </span>
          </div>
          <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;">
            <button class="btn-sm btn-secondary" onclick="window.App.openWhyTimetableModal()">
              🔍 Why did my timetable change?
            </button>
            <button class="btn-sm btn-primary" onclick="window.state.adaptTimetable('Manual trigger from planner')">
              ⚡ Recalculate AI Schedule
            </button>
          </div>
        </div>

        <div class="schedule-timeline">
          ${activeSessions.map((sess, idx) => {
            // Case A: BREAK ITEM (Section 2 & 6)
            if (sess.is_break) {
              return `
                <div class="timeline-slot timeline-break-slot" style="background:#fffbeb;border-left:4px solid #f59e0b;">
                  <div class="slot-time" style="color:#b45309;font-weight:700;">
                    ${sess.start_time} – ${sess.end_time}
                  </div>
                  <div class="slot-details">
                    <div style="display:flex;align-items:center;gap:0.5rem;">
                      <span style="font-size:1.1rem;">☕</span>
                      <strong style="color:#92400e;font-size:0.95rem;">${sess.title || 'Break Time'}</strong>
                      <span class="badge" style="background:#fef3c7;color:#92400e;font-weight:700;">${sess.duration_mins} min</span>
                    </div>
                    <div style="font-size:0.8rem;color:#b45309;margin-top:2px;">
                      ${sess.message || 'Rest, hydrate, and stretch before your next session.'}
                    </div>
                  </div>
                  <div class="slot-actions">
                    <button class="btn-sm btn-secondary" style="border-color:#fde68a;color:#92400e;background:white;" onclick="StudyTimerComponent.startDirectBreak({ duration_mins: ${sess.duration_mins} })">
                      ☕ Start Break
                    </button>
                  </div>
                </div>
              `;
            }

            // Case B: STUDY SESSION CARD (Section 4)
            const isCompleted = sess.completed ? 'completed' : '';
            const checkClass = sess.completed ? 'checked' : '';
            const technique = sess.study_technique || 'Focused Study';
            const techIcon = technique.includes('Pomodoro') ? '🍅' : (technique.includes('Deep') ? '🌊' : '🎯');

            const diffTag = sess.change_delta_mins > 0
              ? `<span class="slot-diff-tag diff-plus">+${sess.change_delta_mins}m AI</span>`
              : (sess.change_delta_mins < 0 ? `<span class="slot-diff-tag diff-minus">${sess.change_delta_mins}m AI</span>` : '');

            let completionPill = '';
            if (sess.completion_status === 'Completed') {
              completionPill = `<span class="badge badge-success" style="font-size:0.75rem;">🟢 Goal Completed</span>`;
            } else if (sess.completion_status === 'Partially Completed') {
              completionPill = `<span class="badge badge-warning" style="font-size:0.75rem;">🟡 Partially Completed</span>`;
            } else if (sess.completion_status === 'Not Completed') {
              completionPill = `<span class="badge badge-danger" style="font-size:0.75rem;">🔴 Not Completed</span>`;
            }

            return `
              <div class="timeline-slot ${isCompleted} study-session-card" style="border-left-color:${sess.course_color || 'var(--primary)'};">
                <div class="slot-time">
                  <div>${sess.start_time} – ${sess.end_time}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted);font-weight:500;margin-top:2px;">${sess.duration_mins} min study</div>
                </div>

                <div class="slot-details">
                  <!-- Header Row: Subject, Topic, Technique, Priority -->
                  <div class="slot-subject-topic" style="gap:0.5rem;align-items:center;">
                    <span class="slot-subject" style="color:${sess.course_color || 'var(--primary)'};">${sess.course_name}</span>
                    <span class="slot-topic" style="font-weight:700;">${sess.topic_name}</span>
                    <span class="badge" style="background:#ede9fe;color:#6d28d9;font-weight:700;font-size:0.75rem;">
                      ${techIcon} ${technique}
                    </span>
                    <span class="badge ${sess.priority === 'High' ? 'badge-danger' : 'badge-warning'}" style="font-size:0.72rem;">
                      ${sess.priority || 'Medium'}
                    </span>
                    ${diffTag}
                    ${completionPill}
                  </div>

                  <!-- Goal Callout (Section 4) -->
                  <div class="session-goal-box" style="margin-top:0.45rem;background:white;border:1px solid #e2e8f0;border-radius:var(--radius-sm);padding:0.4rem 0.65rem;font-size:0.82rem;">
                    <strong style="color:var(--primary);">🎯 Goal:</strong>
                    <span style="color:var(--text-main);">${sess.goal || 'Understand core concepts and practice 5 questions.'}</span>
                  </div>

                  <!-- AI Rationale (Section 4) -->
                  <div style="font-size:0.78rem;color:var(--text-muted);margin-top:0.35rem;">
                    💡 <strong>AI Rationale:</strong> ${sess.ai_rationale || sess.change_reason || 'Allocated based on performance feedback loop.'}
                  </div>
                </div>

                <!-- Session Action: Launch Timer (Section 5) -->
                <div class="slot-actions" style="flex-direction:column;gap:0.4rem;align-items:flex-end;">
                  <button class="btn-sm btn-primary" style="white-space:nowrap;padding:0.45rem 0.85rem;" onclick="StudyTimerComponent.openTimer('${sess.id}')">
                    ▶ ${sess.completed ? 'Restart Timer' : 'Start Session'}
                  </button>
                  <button class="slot-check-btn ${checkClass}" title="Toggle Completed" onclick="window.state.toggleSessionCompleted('${sess.id}')" style="width:26px;height:26px;font-size:0.75rem;">
                    ${sess.completed ? '✓' : ''}
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;

    // Weekly View HTML
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const todayDayIndex = 3; // e.g. Thursday/Friday
    const weeklyHtml = `
      <div class="week-grid">
        ${days.map((dName, dIdx) => {
          const isToday = dIdx === todayDayIndex;
          return `
            <div class="week-col ${isToday ? 'today' : ''}">
              <div class="week-col-header">
                <div class="week-day-name">${dName}</div>
                <div class="week-day-num">${14 + dIdx} Nov</div>
                ${isToday ? `<span class="badge badge-success" style="font-size:0.65rem;margin-top:2px;">Today</span>` : ''}
              </div>
              <div style="display:flex;flex-direction:column;gap:0.5rem;flex:1;">
                ${activeSessions.filter(s => !s.is_break).slice(0, 3).map(s => `
                  <div class="week-session-item" style="border-left-color:${s.course_color || 'var(--primary)'};">
                    <div style="font-weight:700;color:var(--text-main);">${s.course_name}</div>
                    <div style="color:var(--text-muted);font-size:0.7rem;">${s.topic_name}</div>
                    <div style="font-size:0.68rem;color:var(--primary);margin-top:3px;font-weight:600;">
                      ${s.study_technique || 'Focused Study'} (${s.duration_mins}m)
                    </div>
                  </div>
                `).join('')}
                <div style="font-size:0.7rem;color:#b45309;background:#fef3c7;padding:3px 6px;border-radius:4px;text-align:center;">
                  ☕ Planned Rest Breaks Included
                </div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;

    // Technique preference badge
    const techniquePref = (user.technique_preference || 'automatic');
    const techniqueLabel = techniquePref === 'pomodoro' ? 'Pomodoro (25/5)' :
                          (techniquePref === 'focused' ? 'Focused Study (50/10)' :
                          (techniquePref === 'deep' ? 'Deep Study (80/15)' : 'Automatic / AI Recommended'));

    container.innerHTML = `
      <!-- Toolbar -->
      <div class="planner-toolbar">
        <div class="planner-controls-left">
          <!-- Initial Plan vs Adaptive Plan Toggle -->
          <div class="plan-type-toggle">
            <button class="plan-type-btn ${isAdaptive ? '' : 'active'}" onclick="PlannerComponent.setPlanType('initial')">
              Initial Baseline Plan
            </button>
            <button class="plan-type-btn ${isAdaptive ? 'active' : ''}" onclick="PlannerComponent.setPlanType('adaptive')">
              🤖 Adaptive Plan (AI Active)
            </button>
          </div>

          <!-- View Mode: Daily vs Weekly -->
          <div class="view-mode-tabs">
            <button class="view-mode-btn ${PlannerComponent.currentViewMode === 'daily' ? 'active' : ''}" onclick="PlannerComponent.setViewMode('daily')">
              Daily View
            </button>
            <button class="view-mode-btn ${PlannerComponent.currentViewMode === 'weekly' ? 'active' : ''}" onclick="PlannerComponent.setViewMode('weekly')">
              Weekly View
            </button>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;">
          <span class="badge" style="background:#ede9fe;color:#6d28d9;padding:0.4rem 0.8rem;font-weight:700;">
            ⚙️ Mode: ${techniqueLabel}
          </span>
          <span style="font-size:0.85rem;color:var(--text-muted);">
            Available: <strong>${user.daily_hours || 3.0} hrs/day</strong>
          </span>
          <button class="btn-sm btn-secondary" onclick="window.state.setView('profile')">
            Adjust Hours & Technique
          </button>
        </div>
      </div>

      <!-- AI Adaptation Diff Summary Banner -->
      ${isAdaptive && diffChipsHtml ? `
        <div class="ai-adaptation-summary-banner">
          <div>
            <div style="font-weight:700;font-size:0.92rem;color:#701a75;display:flex;align-items:center;gap:0.4rem;">
              <span>⚡ Timetable Adapted with Study Sessions & Breaks</span>
            </div>
            <p style="font-size:0.8rem;color:#86198f;margin-top:2px;">
              Study sessions and structured breaks fit strictly inside your ${user.preferred_start || '18:00'} – ${user.preferred_end || '21:00'} study window.
            </p>
          </div>
          <div class="ai-diff-pills">
            ${diffChipsHtml}
          </div>
        </div>
      ` : ''}

      <!-- Main Calendar Container -->
      ${PlannerComponent.currentViewMode === 'daily' ? dailyHtml : weeklyHtml}
    `;
  }

  static setPlanType(mode) {
    window.state.data.timetableMode = mode;
    PlannerComponent.render(document.getElementById('view_container'));
    window.App.showToast(`Switched to ${mode === 'adaptive' ? 'Adaptive AI Plan' : 'Initial Baseline Plan'}`, 'info');
  }

  static setViewMode(mode) {
    PlannerComponent.currentViewMode = mode;
    PlannerComponent.render(document.getElementById('view_container'));
  }
}

// Export for browser
window.PlannerComponent = PlannerComponent;
