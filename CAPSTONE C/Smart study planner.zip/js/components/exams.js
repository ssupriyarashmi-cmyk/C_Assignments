/**
 * Study Planner - Exams & Tests Component
 * Tracks upcoming formal tests, internal assessments, and midterms.
 * High exam proximity dynamically raises topic weights in the adaptive timetable.
 */

class ExamsComponent {
  static render(container) {
    const data = window.state.data;
    const exams = data.exams || [];
    const courses = data.courses || [];
    const now = new Date();

    const getCourse = (cid) => courses.find(c => c.id === cid) || { name: 'General', color: '#6366f1' };

    const examCardsHtml = exams.map(ex => {
      const course = getCourse(ex.course_id);
      const exDate = new Date(ex.exam_date);
      const diffDays = Math.ceil((exDate - now) / (1000 * 60 * 60 * 24));

      let badgeClass = 'badge-info';
      if (diffDays <= 3) badgeClass = 'badge-danger';
      else if (diffDays <= 7) badgeClass = 'badge-warning';

      const topics = ex.topics || [];
      const topicsTags = topics.map(t => `<span class="exam-topic-tag">${t}</span>`).join('');

      return `
        <div class="exam-card">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;">
            <div>
              <span class="badge" style="background:${course.color}20;color:${course.color};font-weight:700;margin-bottom:0.4rem;">
                ${course.name}
              </span>
              <h3 style="font-size:1.1rem;font-weight:700;color:var(--text-main);">${ex.title}</h3>
            </div>
            <span class="badge ${badgeClass}" style="font-size:0.8rem;">
              ${diffDays <= 0 ? 'Today' : `${diffDays} days away`}
            </span>
          </div>

          <div class="exam-proximity-bar">
            <span>📅 <strong>Date:</strong> ${ex.exam_date}</span>
            <span>•</span>
            <span>⚡ <strong>Priority:</strong> ${ex.priority}</span>
          </div>

          <div>
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);margin-bottom:0.35rem;text-transform:uppercase;">
              Topics Included (${topics.length}):
            </div>
            <div class="exam-topics-wrap">
              ${topicsTags || '<span style="color:var(--text-muted);font-size:0.75rem;">All course topics</span>'}
            </div>
          </div>

          <div style="margin-top:auto;padding-top:0.75rem;border-top:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:0.75rem;color:var(--secondary);font-weight:600;">
              🤖 AI Timetable Priority: Active
            </span>
            <button class="btn-sm btn-primary" onclick="window.App.startQuizForCourse('${course.name}', ${JSON.stringify(topics).replace(/"/g, '&quot;')})">
              Practice Mock Test
            </button>
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem;">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Tests & Upcoming Exams</h2>
          <p style="font-size:0.85rem;color:var(--text-muted);">
            Upcoming exams automatically drive adaptive study weights as deadlines draw closer.
          </p>
        </div>
        <button class="btn-primary" onclick="ExamsComponent.openAddExamModal()">
          + Add Test / Exam
        </button>
      </div>

      <div class="exams-grid">
        ${examCardsHtml}
      </div>
    `;
  }

  static openAddExamModal() {
    const courses = window.state.data.courses || [];
    const courseOptions = courses.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

    const defaultDate = new Date(Date.now() + 7 * 86400000).toISOString().substring(0, 10);

    window.App.showModal({
      title: 'Schedule Upcoming Test / Exam',
      body: `
        <div class="form-group">
          <label class="form-label">Exam Name</label>
          <input type="text" id="exam_title" class="form-input" placeholder="e.g. Chemistry Internal Assessment, Math Midterm" required />
        </div>

        <div class="form-group">
          <label class="form-label">Course</label>
          <select id="exam_course_id" class="form-select" onchange="ExamsComponent.populateCourseTopics(this.value)">
            ${courseOptions}
          </select>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group">
            <label class="form-label">Exam Date</label>
            <input type="date" id="exam_date" class="form-input" value="${defaultDate}" required />
          </div>
          <div class="form-group">
            <label class="form-label">Exam Priority</label>
            <select id="exam_priority" class="form-select">
              <option value="High" selected>High (Final/Major)</option>
              <option value="Medium">Medium (Unit Test)</option>
              <option value="Low">Low (Pop Quiz)</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Topics Covered (comma-separated)</label>
          <input type="text" id="exam_topics" class="form-input" placeholder="e.g. Atomic Structure, Chemical Bonding, Thermodynamics" />
          <span class="form-hint">The AI will specifically prioritize these topics in your timetable.</span>
        </div>
      `,
      confirmText: 'Schedule Exam & Update AI Weights',
      onConfirm: async () => {
        const title = document.getElementById('exam_title').value.trim();
        const course_id = Number(document.getElementById('exam_course_id').value);
        const exam_date = document.getElementById('exam_date').value;
        const priority = document.getElementById('exam_priority').value;
        const topicsStr = document.getElementById('exam_topics').value.trim();

        if (!title) {
          window.App.showToast('Please enter an exam title', 'error');
          return;
        }

        const topics = topicsStr ? topicsStr.split(',').map(s => s.trim()).filter(Boolean) : [];

        await ApiService.addExam({
          title,
          course_id,
          exam_date,
          priority,
          topics
        });

        await window.state.loadBootstrap();
        // Immediately adapt timetable to reflect new exam proximity
        await window.state.adaptTimetable(`New exam "${title}" scheduled on ${exam_date}`);

        window.App.showToast(`Exam scheduled! Timetable updated to prioritize relevant topics.`, 'success');
        ExamsComponent.render(document.getElementById('view_container'));
      }
    });
  }
}

// Export for browser
window.ExamsComponent = ExamsComponent;
