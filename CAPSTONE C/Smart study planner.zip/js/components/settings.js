/**
 * Study Planner - Settings Component
 * Notification configurations, AI adaptive sensitivity, demo data reset, and JSON export/import.
 */

class SettingsComponent {
  static render(container) {
    const data = window.state.data;
    const user = data.user || {};

    container.innerHTML = `
      <div style="margin-bottom:1.5rem;">
        <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Application Settings</h2>
        <p style="font-size:0.85rem;color:var(--text-muted);">
          Configure notification alerts, AI adaptation parameters, study techniques, and data persistence.
        </p>
      </div>

      <div style="display:flex;flex-direction:column;gap:1.5rem;max-width:800px;">
        <!-- Study Technique & Break Preferences (Section 8) -->
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Study Technique & Break System Preferences</h3>
              <span class="card-subtitle">Configure session lengths, rest intervals, and AI technique assignment</span>
            </div>
            <span class="badge" style="background:#ede9fe;color:#7c3aed;font-weight:700;">Cognitive Science</span>
          </div>

          <div style="display:flex;flex-direction:column;gap:1.25rem;">
            <div>
              <label class="form-label" style="font-weight:700;margin-bottom:0.4rem;">Study Technique Mode</label>
              <select id="settings_technique_pref" class="form-input" style="font-weight:600;">
                <option value="automatic" ${user.technique_preference === 'automatic' || !user.technique_preference ? 'selected' : ''}>
                  🤖 Automatic — AI Recommended (Topic-Adaptive)
                </option>
                <option value="pomodoro" ${user.technique_preference === 'pomodoro' ? 'selected' : ''}>
                  🍅 Pomodoro (25m study • 5m break)
                </option>
                <option value="focused" ${user.technique_preference === 'focused' ? 'selected' : ''}>
                  🎯 Focused Study (50m study • 10m break)
                </option>
                <option value="deep" ${user.technique_preference === 'deep' ? 'selected' : ''}>
                  🌊 Deep Study (80m study • 15m break)
                </option>
              </select>
            </div>

            <!-- Detailed breakdown cards for each technique -->
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:0.75rem;">
              <div style="background:var(--bg-subtle);border-radius:var(--radius-md);padding:0.75rem;border-left:3px solid #ef4444;">
                <div style="font-weight:700;font-size:0.85rem;color:#b91c1c;">🍅 Pomodoro</div>
                <div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;">25m study • 5m break</div>
                <div style="font-size:0.75rem;color:var(--text-subtle);margin-top:4px;">Best for difficult/weak topics or low-energy review.</div>
              </div>
              <div style="background:var(--bg-subtle);border-radius:var(--radius-md);padding:0.75rem;border-left:3px solid #6366f1;">
                <div style="font-weight:700;font-size:0.85rem;color:#4338ca;">🎯 Focused Study</div>
                <div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;">50m study • 10m break</div>
                <div style="font-size:0.75rem;color:var(--text-subtle);margin-top:4px;">Standard high-yield block for balanced retention.</div>
              </div>
              <div style="background:var(--bg-subtle);border-radius:var(--radius-md);padding:0.75rem;border-left:3px solid #06b6d4;">
                <div style="font-weight:700;font-size:0.85rem;color:#0e7490;">🌊 Deep Study</div>
                <div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;">80m study • 15m break</div>
                <div style="font-size:0.75rem;color:var(--text-subtle);margin-top:4px;">Extended uninterrupted flow for complex problem sets.</div>
              </div>
            </div>

            <label style="display:flex;align-items:center;gap:0.75rem;padding:0.75rem;background:var(--bg-subtle);border-radius:var(--radius-md);cursor:pointer;">
              <input type="checkbox" id="settings_allow_ai_recommend" ${user.allow_ai_recommend !== false ? 'checked' : ''} style="width:18px;height:18px;accent-color:var(--primary);" />
              <div>
                <div style="font-weight:700;font-size:0.88rem;">Allow AI to recommend the best technique for each topic</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px;">
                  AI automatically evaluates topic difficulty, mock test weakness, exam proximity, and prior session completion history.
                </div>
              </div>
            </label>

            <div style="display:flex;justify-content:flex-end;">
              <button class="btn-primary" style="padding:0.6rem 1.25rem;font-size:0.88rem;" onclick="SettingsComponent.saveTechniqueSettings()">
                Save Technique Preference & Recalculate Timetable
              </button>
            </div>
          </div>
        </div>

        <!-- Notification Preferences (Section 21) -->
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Notification & Reminder Alerts</h3>
              <span class="card-subtitle">Choose which alerts trigger in-app & browser banners</span>
            </div>
            <span class="badge badge-success">Active</span>
          </div>

          <div style="display:flex;flex-direction:column;gap:1rem;">
            <label style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem;background:var(--bg-subtle);border-radius:var(--radius-md);cursor:pointer;">
              <div>
                <div style="font-weight:700;font-size:0.9rem;">Assignment Submission Alerts</div>
                <div style="font-size:0.75rem;color:var(--text-muted);">Receive alerts at your chosen interval before deadlines (e.g. 24h, 12h, 3h).</div>
              </div>
              <input type="checkbox" checked style="width:18px;height:18px;accent-color:var(--primary);" />
            </label>

            <label style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem;background:var(--bg-subtle);border-radius:var(--radius-md);cursor:pointer;">
              <div>
                <div style="font-weight:700;font-size:0.9rem;">Upcoming Exam Proximity Alerts</div>
                <div style="font-size:0.75rem;color:var(--text-muted);">Alert when an exam is within 7 days, 3 days, and 24 hours.</div>
              </div>
              <input type="checkbox" checked style="width:18px;height:18px;accent-color:var(--primary);" />
            </label>

            <label style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem;background:var(--bg-subtle);border-radius:var(--radius-md);cursor:pointer;">
              <div>
                <div style="font-weight:700;font-size:0.9rem;">AI Adaptive Timetable Updates</div>
                <div style="font-size:0.75rem;color:var(--text-muted);">Notifies you whenever mock test performance recalibrates your study schedule.</div>
              </div>
              <input type="checkbox" checked style="width:18px;height:18px;accent-color:var(--primary);" />
            </label>

            <label style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem;background:var(--bg-subtle);border-radius:var(--radius-md);cursor:pointer;">
              <div>
                <div style="font-weight:700;font-size:0.9rem;">AI Milestone & Insight Notifications</div>
                <div style="font-size:0.75rem;color:var(--text-muted);">Highlights when a weak topic shows sustained positive improvement.</div>
              </div>
              <input type="checkbox" checked style="width:18px;height:18px;accent-color:var(--primary);" />
            </label>
          </div>
        </div>

        <!-- AI Adaptive Engine Controls -->
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">AI Adaptive Engine Parameters</h3>
              <span class="card-subtitle">Fine-tune the weight distribution for timetable adjustments</span>
            </div>
            <span class="badge-ai">Multi-Factor Engine</span>
          </div>

          <div style="display:flex;flex-direction:column;gap:1.25rem;">
            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.85rem;font-weight:600;margin-bottom:0.25rem;">
                <span>Topic Weakness Weight</span>
                <span>40%</span>
              </div>
              <div class="progress-bar-container">
                <div class="progress-bar-fill" style="width:40%;background:var(--danger);"></div>
              </div>
            </div>

            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.85rem;font-weight:600;margin-bottom:0.25rem;">
                <span>Exam Proximity Weight</span>
                <span>30%</span>
              </div>
              <div class="progress-bar-container">
                <div class="progress-bar-fill" style="width:30%;background:var(--secondary);"></div>
              </div>
            </div>

            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.85rem;font-weight:600;margin-bottom:0.25rem;">
                <span>Assignment Deadline Urgency</span>
                <span>15%</span>
              </div>
              <div class="progress-bar-container">
                <div class="progress-bar-fill" style="width:15%;background:var(--accent-blue);"></div>
              </div>
            </div>

            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.85rem;font-weight:600;margin-bottom:0.25rem;">
                <span>Multi-Quiz Historical Trend</span>
                <span>15%</span>
              </div>
              <div class="progress-bar-container">
                <div class="progress-bar-fill" style="width:15%;background:var(--success);"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- System & Demo Management -->
        <div class="card">
          <h3 class="card-title" style="margin-bottom:0.5rem;">Account & Data Management</h3>
          <p class="card-subtitle" style="margin-bottom:1.25rem;">
            Manage your account session, export study records, or restore default scenario.
          </p>

          <div style="display:flex;gap:1rem;flex-wrap:wrap;">
            <button class="btn-secondary" onclick="SettingsComponent.exportData()">
              📥 Export Study Data (JSON)
            </button>
            <button class="btn-secondary" style="color:var(--danger);border-color:#fecaca;" onclick="window.App.logout()">
              🚪 Log Out
            </button>
            <button class="btn-secondary" style="color:var(--text-muted);" onclick="SettingsComponent.resetDemoData()">
              🔄 Reset Demo Scenario
            </button>
          </div>
        </div>
      </div>
    `;
  }

  static async saveTechniqueSettings() {
    const prefEl = document.getElementById('settings_technique_pref');
    const allowEl = document.getElementById('settings_allow_ai_recommend');
    if (!prefEl) return;

    const technique_preference = prefEl.value;
    const allow_ai_recommend = allowEl ? allowEl.checked : true;

    await ApiService.updateProfile({ technique_preference, allow_ai_recommend });
    await window.state.loadBootstrap();
    await window.state.adaptTimetable(`Technique preference changed to ${technique_preference}`);
    window.App.showToast("Technique preferences saved & timetable adapted!", "success");
    SettingsComponent.render(document.getElementById('view_container'));
  }

  static exportData() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(window.state.data, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `study_planner_export_${new Date().toISOString().substring(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    window.App.showToast("Data exported successfully!", "success");
  }

  static async resetDemoData() {
    if (confirm("Reset application to default rich demo state? All custom sessions will be re-seeded.")) {
      await ApiService.resetDemoData();
      await window.state.loadBootstrap();
      window.App.showToast("Demo data restored successfully!", "success");
      SettingsComponent.render(document.getElementById('view_container'));
    }
  }
}

// Export for browser
window.SettingsComponent = SettingsComponent;
