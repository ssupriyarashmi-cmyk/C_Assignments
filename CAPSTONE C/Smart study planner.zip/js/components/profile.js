/**
 * Study Planner - Student Profile Component
 * Manages student academic details, institution, and the core daily study-time input:
 * "How much time can you study every day?"
 */

class ProfileComponent {
  static render(container) {
    const data = window.state.data;
    const user = data.user || {};
    const courses = data.courses || [];
    const isNewSignup = window.App.isNewUserSignup;

    const hoursVal = user.daily_hours != null ? user.daily_hours : 3.0;

    container.innerHTML = `
      ${isNewSignup ? `
        <div class="auth-onboarding-banner" style="background:linear-gradient(135deg, #ede9fe, #dbeafe);border:1px solid #c7d2fe;border-radius:var(--radius-lg);padding:1.25rem 1.75rem;margin-bottom:1.5rem;display:flex;align-items:center;justify-content:space-between;gap:1.5rem;box-shadow:var(--shadow-sm);">
          <div>
            <div style="font-weight:700;font-size:1.1rem;color:#4338ca;display:flex;align-items:center;gap:0.4rem;">
              <span>🎉 Welcome to Study Planner, ${user.name || 'Student'}!</span>
            </div>
            <p style="font-size:0.85rem;color:#4f46e5;margin-top:4px;line-height:1.4;">
              Your account is created. Review your academic profile and daily study time below to configure your initial study schedule, then continue to your Dashboard.
            </p>
          </div>
          <button class="btn-primary" style="background:#4338ca;white-space:nowrap;padding:0.6rem 1.25rem;" onclick="window.App.isNewUserSignup = false; window.App.navigateTo('dashboard');">
            Skip to Dashboard ➔
          </button>
        </div>
      ` : ''}

      <div style="margin-bottom:1.5rem;">
        <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Student Profile & Study Constraints</h2>
        <p style="font-size:0.85rem;color:var(--text-muted);">
          Set your daily available study time and academic details. The AI planner respects these constraints strictly.
        </p>
      </div>

      <div class="settings-grid">
        <!-- Left: Avatar & Identity -->
        <div class="card profile-card-left">
          <div class="profile-avatar-big">${user.avatar || '👨‍🎓'}</div>
          <div>
            <h3 style="font-size:1.2rem;font-weight:700;color:var(--text-main);">${user.name || 'Student'}</h3>
            <p style="font-size:0.82rem;color:var(--text-muted);">${user.course_program || 'Undergraduate Program'}</p>
            <p style="font-size:0.75rem;color:var(--primary);font-weight:600;margin-top:2px;">${user.institution || 'Apex University'}</p>
            <p style="font-size:0.75rem;color:var(--text-subtle);margin-top:3px;">${user.email || ''}</p>
          </div>

          <div style="width:100%;margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border);text-align:left;">
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;margin-bottom:0.5rem;">
              Enrolled Courses (${courses.length})
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:0.4rem;">
              ${courses.map(c => `<span class="badge" style="background:${c.color}20;color:${c.color};font-weight:700;">${c.name}</span>`).join('')}
            </div>
          </div>

          <!-- Logout Button in Profile Area (Section 4) -->
          <div style="width:100%;margin-top:auto;padding-top:1.25rem;">
            <button type="button" class="btn-secondary" style="width:100%;color:var(--danger);border-color:#fecaca;display:flex;align-items:center;justify-content:center;gap:0.5rem;" onclick="window.App.logout()">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
              <span>Log Out of Account</span>
            </button>
          </div>
        </div>

        <!-- Right: Profile Form & Core Study Time Input -->
        <div class="card">
          <h3 class="card-title" style="margin-bottom:1rem;">Academic Information</h3>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.25rem;">
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <input type="text" id="prof_name" class="form-input" value="${user.name || ''}" />
            </div>

            <div class="form-group">
              <label class="form-label">Academic Year / Semester</label>
              <input type="text" id="prof_year" class="form-input" value="${user.academic_year || ''}" placeholder="e.g. Year 1, Semester 1" />
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.5rem;">
            <div class="form-group">
              <label class="form-label">College / Institution</label>
              <input type="text" id="prof_inst" class="form-input" value="${user.institution || ''}" />
            </div>

            <div class="form-group">
              <label class="form-label">Degree / Program</label>
              <input type="text" id="prof_prog" class="form-input" value="${user.course_program || ''}" />
            </div>
          </div>

          <!-- THE MOST IMPORTANT STUDY-TIME INPUT (Section 5) -->
          <div class="study-time-box">
            <h4>⏱️ How much time can you study every day?</h4>
            <p>
              Instead of manually creating complex schedules, specify your available daily hours.
              The AI dynamically balances and slots your subjects.
            </p>

            <div class="time-slider-wrapper">
              <input type="range" id="prof_hours_slider" class="time-slider" min="1" max="8" step="0.5" value="${hoursVal}"
                oninput="document.getElementById('prof_hours_val').textContent = this.value + ' hrs/day'" />
              <div id="prof_hours_val" class="time-slider-val">${hoursVal} hrs/day</div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-top:1.25rem;">
              <div class="form-group">
                <label class="form-label">Preferred Study Start Time</label>
                <input type="time" id="prof_start" class="form-input" value="${user.preferred_start || '18:00'}" />
              </div>
              <div class="form-group">
                <label class="form-label">Preferred Study End Time</label>
                <input type="time" id="prof_end" class="form-input" value="${user.preferred_end || '21:00'}" />
              </div>
            </div>
          </div>

          <!-- STUDY TECHNIQUE PREFERENCE (Section 8) -->
          <div class="study-time-box" style="margin-top:1.25rem;background:#f5f3ff;border-color:#ddd6fe;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:0.75rem;margin-bottom:0.5rem;">
              <h4 style="color:#5b21b6;margin-bottom:0;">🧠 Study Technique Preference</h4>
              <span class="badge" style="background:#ede9fe;color:#6d28d9;font-weight:700;">Break-Aware</span>
            </div>
            <p style="color:#6d28d9;margin-bottom:1rem;">
              Choose how your study sessions and cognitive breaks are structured:
            </p>

            <div class="form-group" style="margin-bottom:1rem;">
              <label class="form-label" style="font-weight:600;color:#4c1d95;">Primary Study Technique</label>
              <select id="prof_technique" class="form-input" style="background:white;font-weight:600;">
                <option value="automatic" ${user.technique_preference === 'automatic' || !user.technique_preference ? 'selected' : ''}>
                  🤖 Automatic — AI Recommended (Adaptive)
                </option>
                <option value="pomodoro" ${user.technique_preference === 'pomodoro' ? 'selected' : ''}>
                  🍅 Pomodoro (25m study • 5m break)
                </option>
                <option value="focused" ${user.technique_preference === 'focused' ? 'selected' : ''}>
                  🎯 Focused Study (50m study • 10m break)
                </option>
                <option value="deep" ${user.technique_preference === 'deep' ? 'selected' : ''}>
                  🌊 Deep Study (80m study • 15m break)
                </option>
              </select>
            </div>

            <label style="display:flex;align-items:center;gap:0.75rem;padding:0.75rem;background:white;border:1px solid #ddd6fe;border-radius:var(--radius-md);cursor:pointer;">
              <input type="checkbox" id="prof_allow_ai_recommend" ${user.allow_ai_recommend !== false ? 'checked' : ''} style="width:18px;height:18px;accent-color:#7c3aed;" />
              <div>
                <div style="font-weight:700;font-size:0.88rem;color:#4c1d95;">Allow AI to recommend the best technique for each topic</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px;">
                  When enabled, AI automatically selects Pomodoro for high-friction/weak topics, Deep Study for complex concepts, and Focused Study for balanced reviews.
                </div>
              </div>
            </label>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:1rem;margin-top:1.5rem;">
            ${isNewSignup ? `
              <button class="btn-primary" style="padding:0.7rem 1.75rem;font-size:0.95rem;" onclick="ProfileComponent.saveProfile(true)">
                💾 Save & Continue to Dashboard ➔
              </button>
            ` : `
              <button class="btn-primary" onclick="ProfileComponent.saveProfile(false)">
                💾 Save Profile & Rebalance Timetable
              </button>
            `}
          </div>
        </div>
      </div>
    `;
  }

  static async saveProfile(proceedToDashboard = false) {
    const name = document.getElementById('prof_name').value.trim();
    const academic_year = document.getElementById('prof_year').value.trim();
    const institution = document.getElementById('prof_inst').value.trim();
    const course_program = document.getElementById('prof_prog').value.trim();
    const daily_hours = parseFloat(document.getElementById('prof_hours_slider').value);
    const preferred_start = document.getElementById('prof_start').value;
    const preferred_end = document.getElementById('prof_end').value;
    const technique_preference = document.getElementById('prof_technique') ? document.getElementById('prof_technique').value : 'automatic';
    const allow_ai_recommend = document.getElementById('prof_allow_ai_recommend') ? document.getElementById('prof_allow_ai_recommend').checked : true;

    await ApiService.updateProfile({
      name,
      academic_year,
      institution,
      course_program,
      daily_hours,
      preferred_start,
      preferred_end,
      technique_preference,
      allow_ai_recommend
    });

    await window.state.loadBootstrap();
    // Adapt timetable to match new time constraints and technique preferences immediately
    await window.state.adaptTimetable(`Profile updated: ${daily_hours}h/day (${preferred_start} – ${preferred_end}), technique: ${technique_preference}`);

    window.App.updateHeaderUser();

    if (proceedToDashboard || window.App.isNewUserSignup) {
      window.App.isNewUserSignup = false;
      window.App.showToast("Profile configured! Welcome to your Dashboard.", "success");
      window.App.navigateTo('dashboard');
    } else {
      window.App.showToast("Profile saved & study timetable adapted!", "success");
      ProfileComponent.render(document.getElementById('view_container'));
    }
  }
}

// Export for browser
window.ProfileComponent = ProfileComponent;
