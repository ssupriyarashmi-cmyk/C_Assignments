/**
 * Study Planner - Mock Quiz & Test Component
 * Implements Option A (AI-Generated Quiz) & Option B (Student-Provided Quiz)
 * Evaluates performance at the topic level, distinguishes Strong vs Weak areas,
 * and directly triggers the AI Adaptive Timetable feedback loop.
 */

class QuizComponent {
  static activeQuiz = null;
  static userAnswers = {};
  static currentQuestionIdx = 0;
  static timerInterval = null;
  static secondsRemaining = 600; // 10 mins default
  static currentMode = 'select'; // 'select' | 'taking' | 'results' | 'manual_create'
  static lastResults = null;

  static render(container) {
    if (QuizComponent.currentMode === 'taking' && QuizComponent.activeQuiz) {
      QuizComponent.renderActiveQuiz(container);
    } else if (QuizComponent.currentMode === 'results' && QuizComponent.lastResults) {
      QuizComponent.renderResults(container);
    } else if (QuizComponent.currentMode === 'manual_create') {
      QuizComponent.renderManualCreate(container);
    } else {
      QuizComponent.renderSelectMode(container);
    }
  }

  // ==========================================
  // MODE 1: QUIZ SELECT / LAUNCHER (Options A & B)
  // ==========================================
  static renderSelectMode(container) {
    const courses = window.state.data.courses || [];
    const courseOptions = courses.map(c => `<option value="${c.name}">${c.name}</option>`).join('');

    container.innerHTML = `
      <div style="margin-bottom:2rem;">
        <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Mock Quizzes & Diagnostics</h2>
        <p style="font-size:0.85rem;color:var(--text-muted);">
          Take diagnostic tests to measure topic-level mastery. Your results immediately recalibrate your adaptive study timetable.
        </p>
      </div>

      <!-- Mode Cards: Option A vs Option B -->
      <div class="quiz-modes-container">
        <!-- Option A: AI-Generated Quiz -->
        <div class="quiz-mode-card" style="border-color:var(--primary);" onclick="document.getElementById('ai_quiz_panel').scrollIntoView({ behavior:'smooth' })">
          <div style="display:flex;align-items:center;gap:1rem;">
            <div class="quiz-mode-icon">🤖</div>
            <div>
              <span class="brand-badge">OPTION A</span>
              <h3 style="font-size:1.15rem;font-weight:700;color:var(--text-main);margin-top:2px;">AI-Generated Mock Quiz</h3>
            </div>
          </div>
          <p style="font-size:0.85rem;color:var(--text-muted);line-height:1.45;">
            Select your course, specific topics, difficulty, and question count. The AI compiles a structured diagnostic test and evaluates topic weaknesses.
          </p>
          <div style="display:flex;align-items:center;gap:0.4rem;font-size:0.8rem;color:var(--primary);font-weight:700;margin-top:auto;">
            <span>Configure AI Quiz ➔</span>
          </div>
        </div>

        <!-- Option B: Student-Provided Quiz -->
        <div class="quiz-mode-card" onclick="QuizComponent.startManualCreate()">
          <div style="display:flex;align-items:center;gap:1rem;">
            <div class="quiz-mode-icon" style="background:linear-gradient(135deg, #06b6d4, #3b82f6);">✍️</div>
            <div>
              <span class="badge badge-info">OPTION B</span>
              <h3 style="font-size:1.15rem;font-weight:700;color:var(--text-main);margin-top:2px;">Student-Provided Quiz</h3>
            </div>
          </div>
          <p style="font-size:0.85rem;color:var(--text-muted);line-height:1.45;">
            Enter your own custom questions or paste past paper questions with topic tags. Feeds directly into the same performance analytics loop.
          </p>
          <div style="display:flex;align-items:center;gap:0.4rem;font-size:0.8rem;color:var(--accent-blue);font-weight:700;margin-top:auto;">
            <span>Enter Custom Questions ➔</span>
          </div>
        </div>
      </div>

      <!-- Option A Generator Form -->
      <div id="ai_quiz_panel" class="card" style="border:2px solid var(--border-focus);background:linear-gradient(180deg, #ffffff, #faf5ff);">
        <div class="card-header">
          <div class="card-title-group">
            <span style="font-size:1.3rem;">⚡</span>
            <div>
              <h3 class="card-title">Launch AI-Generated Mock Quiz</h3>
              <span class="card-subtitle">Choose subject & topics to test</span>
            </div>
          </div>
          <span class="badge-ai">Instant Grading & Adaptation</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.5rem;">
          <div class="form-group">
            <label class="form-label">Select Subject</label>
            <select id="gen_course" class="form-select" onchange="QuizComponent.updateTopicCheckboxes(this.value)">
              ${courseOptions}
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Difficulty Level</label>
            <select id="gen_difficulty" class="form-select">
              <option value="Easy">Easy (Fundamentals)</option>
              <option value="Medium" selected>Medium (Standard Exam Level)</option>
              <option value="Hard">Hard (Deep Analytical)</option>
            </select>
          </div>
        </div>

        <div class="form-group" style="margin-bottom:1.5rem;">
          <label class="form-label">Select Topics (Include weak areas for targeted diagnostic):</label>
          <div id="gen_topics_wrapper" style="display:flex;flex-wrap:wrap;gap:0.6rem;padding:0.75rem;background:white;border:1px solid var(--border);border-radius:var(--radius-md);">
            <!-- Populated via updateTopicCheckboxes -->
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.5rem;">
          <div class="form-group">
            <label class="form-label">Number of Questions</label>
            <select id="gen_count" class="form-select">
              <option value="5">5 Questions (Quick Check)</option>
              <option value="10" selected>10 Questions (Standard Drill)</option>
              <option value="15">15 Questions (Full Diagnostic)</option>
              <option value="20">20 Questions (Mock Internal Assessment)</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Time Limit</label>
            <select id="gen_timer" class="form-select">
              <option value="300">5 Minutes</option>
              <option value="600" selected>10 Minutes</option>
              <option value="900">15 Minutes</option>
              <option value="1200">20 Minutes</option>
            </select>
          </div>
        </div>

        <div style="display:flex;justify-content:flex-end;gap:1rem;">
          <button class="btn-primary" style="padding:0.75rem 2rem;font-size:0.95rem;" onclick="QuizComponent.generateAndStart()">
            🚀 Start Mock Quiz Now
          </button>
        </div>
      </div>
    `;

    // Initialize checkboxes for the first course
    const firstCourse = courses[0] ? courses[0].name : 'Chemistry';
    QuizComponent.updateTopicCheckboxes(firstCourse);
  }

  static updateTopicCheckboxes(courseName) {
    const wrapper = document.getElementById('gen_topics_wrapper');
    if (!wrapper) return;

    const courses = window.state.data.courses || [];
    const course = courses.find(c => c.name.toLowerCase() === courseName.toLowerCase()) || courses[0];
    const topics = course ? course.topics || [] : [];

    if (topics.length === 0) {
      wrapper.innerHTML = `<span style="font-size:0.8rem;color:var(--text-muted);">No topics registered under ${courseName}.</span>`;
      return;
    }

    wrapper.innerHTML = topics.map((t, idx) => `
      <label style="display:inline-flex;align-items:center;gap:0.4rem;font-size:0.82rem;background:var(--bg-subtle);padding:0.35rem 0.75rem;border-radius:var(--radius-sm);cursor:pointer;">
        <input type="checkbox" name="quiz_topic_sel" value="${t.name}" checked />
        <span>${t.name}</span>
        ${t.mastery_score < 65 ? '<span class="badge badge-danger" style="font-size:0.65rem;">Weak</span>' : ''}
      </label>
    `).join('');
  }

  static generateAndStart() {
    const courseName = document.getElementById('gen_course').value;
    const difficulty = document.getElementById('gen_difficulty').value;
    const count = Number(document.getElementById('gen_count').value);
    const timerSecs = Number(document.getElementById('gen_timer').value);

    const checkedBoxes = Array.from(document.querySelectorAll('input[name="quiz_topic_sel"]:checked'));
    const selectedTopics = checkedBoxes.map(cb => cb.value);

    if (selectedTopics.length === 0) {
      window.App.showToast('Please select at least one topic', 'error');
      return;
    }

    const quiz = QuizEngine.generateQuiz({
      courseName,
      topics: selectedTopics,
      difficulty,
      questionCount: count
    });

    QuizComponent.activeQuiz = quiz;
    QuizComponent.userAnswers = {};
    QuizComponent.currentQuestionIdx = 0;
    QuizComponent.secondsRemaining = timerSecs;
    QuizComponent.currentMode = 'taking';

    // Start timer
    if (QuizComponent.timerInterval) clearInterval(QuizComponent.timerInterval);
    QuizComponent.timerInterval = setInterval(() => {
      QuizComponent.secondsRemaining--;
      const timerEl = document.getElementById('quiz_timer_val');
      if (timerEl) {
        const m = Math.floor(QuizComponent.secondsRemaining / 60);
        const s = QuizComponent.secondsRemaining % 60;
        timerEl.textContent = `${m}:${s < 10 ? '0' : ''}${s}`;
      }
      if (QuizComponent.secondsRemaining <= 0) {
        clearInterval(QuizComponent.timerInterval);
        QuizComponent.submitQuiz();
      }
    }, 1000);

    QuizComponent.render(document.getElementById('view_container'));
    window.App.showToast(`Quiz generated! ${quiz.totalQuestions} questions ready.`, 'info');
  }

  // ==========================================
  // MODE 2: ACTIVE QUIZ TAKING INTERFACE
  // ==========================================
  static renderActiveQuiz(container) {
    const quiz = QuizComponent.activeQuiz;
    const qIdx = QuizComponent.currentQuestionIdx;
    const currentQ = quiz.questions[qIdx];
    const totalQ = quiz.questions.length;
    const selectedAnswer = QuizComponent.userAnswers[qIdx];

    const m = Math.floor(QuizComponent.secondsRemaining / 60);
    const s = QuizComponent.secondsRemaining % 60;
    const timeStr = `${m}:${s < 10 ? '0' : ''}${s}`;

    const optionsHtml = currentQ.options.map((opt, optIdx) => {
      const isSelected = selectedAnswer === optIdx ? 'selected' : '';
      const letters = ['A', 'B', 'C', 'D'];
      return `
        <button class="quiz-option-btn ${isSelected}" onclick="QuizComponent.selectOption(${optIdx})">
          <span class="option-prefix">${letters[optIdx]}</span>
          <span>${opt}</span>
        </button>
      `;
    }).join('');

    // Pagination pill dots
    const dotsHtml = quiz.questions.map((_, i) => {
      const isAns = QuizComponent.userAnswers[i] !== undefined;
      const isCurrent = i === qIdx;
      let bg = '#e2e8f0';
      if (isCurrent) bg = 'var(--primary)';
      else if (isAns) bg = '#a5b4fc';

      return `
        <button onclick="QuizComponent.jumpToQuestion(${i})" style="width:28px;height:28px;border-radius:var(--radius-full);background:${bg};color:${isCurrent ? 'white' : 'var(--text-main)'};font-size:0.75rem;font-weight:700;display:flex;align-items:center;justify-content:center;">
          ${i + 1}
        </button>
      `;
    }).join('');

    container.innerHTML = `
      <div class="quiz-active-view">
        <div class="quiz-runner-header">
          <div>
            <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.25rem;">
              <span class="brand-badge">${quiz.course}</span>
              <span class="question-topic-pill">Topic: ${currentQ.topic}</span>
              <span class="badge badge-neutral">${currentQ.difficulty}</span>
            </div>
            <h3 style="font-size:1.1rem;font-weight:700;color:var(--text-main);">${quiz.title}</h3>
          </div>

          <div style="display:flex;align-items:center;gap:1rem;">
            <div class="quiz-timer-pill">
              <span>⏱️ Time Remaining:</span>
              <span id="quiz_timer_val">${timeStr}</span>
            </div>
            <button class="btn-sm btn-secondary" onclick="if(confirm('Cancel mock quiz? Progress will be discarded.')){ QuizComponent.exitQuiz(); }">
              Exit
            </button>
          </div>
        </div>

        <!-- Question Counter & Breadcrumb -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;">
          <span style="font-size:0.85rem;font-weight:700;color:var(--primary);">Question ${qIdx + 1} of ${totalQ}</span>
          <div style="display:flex;gap:0.35rem;overflow-x:auto;">
            ${dotsHtml}
          </div>
        </div>

        <!-- Question Body -->
        <div class="question-text">
          ${currentQ.question}
        </div>

        <!-- Options List -->
        <div class="quiz-options-list">
          ${optionsHtml}
        </div>

        <!-- Footer Nav -->
        <div class="quiz-footer-nav">
          <button class="btn-secondary" onclick="QuizComponent.prevQuestion()" ${qIdx === 0 ? 'disabled style="opacity:0.5;"' : ''}>
            ← Previous
          </button>

          <div style="display:flex;gap:0.75rem;">
            ${qIdx < totalQ - 1 ? `
              <button class="btn-primary" onclick="QuizComponent.nextQuestion()">
                Next Question →
              </button>
            ` : `
              <button class="btn-success" onclick="QuizComponent.confirmSubmit()">
                ✓ Submit & Analyze Performance
              </button>
            `}
          </div>
        </div>
      </div>
    `;
  }

  static selectOption(optIdx) {
    QuizComponent.userAnswers[QuizComponent.currentQuestionIdx] = optIdx;
    QuizComponent.renderActiveQuiz(document.getElementById('view_container'));
  }

  static prevQuestion() {
    if (QuizComponent.currentQuestionIdx > 0) {
      QuizComponent.currentQuestionIdx--;
      QuizComponent.renderActiveQuiz(document.getElementById('view_container'));
    }
  }

  static nextQuestion() {
    if (QuizComponent.currentQuestionIdx < QuizComponent.activeQuiz.questions.length - 1) {
      QuizComponent.currentQuestionIdx++;
      QuizComponent.renderActiveQuiz(document.getElementById('view_container'));
    }
  }

  static jumpToQuestion(idx) {
    QuizComponent.currentQuestionIdx = idx;
    QuizComponent.renderActiveQuiz(document.getElementById('view_container'));
  }

  static confirmSubmit() {
    const answeredCount = Object.keys(QuizComponent.userAnswers).length;
    const totalQ = QuizComponent.activeQuiz.questions.length;
    if (answeredCount < totalQ) {
      if (!confirm(`You have answered ${answeredCount} of ${totalQ} questions. Submit anyway?`)) {
        return;
      }
    }
    QuizComponent.submitQuiz();
  }

  static async submitQuiz() {
    if (QuizComponent.timerInterval) clearInterval(QuizComponent.timerInterval);

    const quiz = QuizComponent.activeQuiz;
    const results = QuizEngine.evaluateSubmission(quiz, QuizComponent.userAnswers);
    QuizComponent.lastResults = results;
    QuizComponent.currentMode = 'results';

    // Post to state & submit quiz
    const courses = window.state.data.courses || [];
    const courseObj = courses.find(c => c.name.toLowerCase() === (quiz.course || '').toLowerCase()) || courses[0];

    const payload = {
      title: quiz.title,
      course_id: courseObj ? courseObj.id : 1,
      difficulty: quiz.difficulty,
      total_questions: results.totalQuestions,
      score: results.score,
      percentage: results.percentage,
      topic_breakdown: results.topicBreakdown,
      source: 'ai'
    };

    // Submits to state & automatically triggers timetable adaptation
    await window.state.submitQuizResult(payload);

    QuizComponent.render(document.getElementById('view_container'));
    window.App.showToast(`Test evaluated: ${results.percentage}%! AI timetable adapted.`, 'success');
  }

  // ==========================================
  // MODE 3: QUIZ RESULT ANALYSIS (Section 11)
  // ==========================================
  static renderResults(container) {
    const r = QuizComponent.lastResults;
    const breakdown = r.topicBreakdown || {};

    const topicBarsHtml = Object.keys(breakdown).map(tName => {
      const t = breakdown[tName];
      const pct = t.percentage;
      const barColor = pct >= 75 ? 'var(--success)' : (pct < 60 ? 'var(--danger)' : 'var(--warning)');
      const badgeText = pct >= 75 ? 'Strong' : (pct < 60 ? 'Weak Area' : 'Moderate');
      const badgeClass = pct >= 75 ? 'badge-success' : (pct < 60 ? 'badge-danger' : 'badge-warning');

      return `
        <div style="margin-bottom:1rem;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.3rem;">
            <span style="font-weight:700;font-size:0.9rem;color:var(--text-main);">${tName}</span>
            <div style="display:flex;align-items:center;gap:0.5rem;">
              <span class="badge ${badgeClass}">${badgeText}</span>
              <span style="font-size:0.85rem;font-weight:800;color:${barColor};">${pct}%</span>
              <span style="font-size:0.75rem;color:var(--text-muted);">(${t.score}/${t.total})</span>
            </div>
          </div>
          <div class="progress-bar-container">
            <div class="progress-bar-fill" style="width:${pct}%;background:${barColor};"></div>
          </div>
        </div>
      `;
    }).join('');

    const strongListHtml = r.strongAreas.length > 0 ? r.strongAreas.map(a => `
      <div class="area-pill-row">
        <span style="font-weight:600;color:#166534;">${a.topic}</span>
        <span class="badge badge-success">${a.percentage}%</span>
      </div>
    `).join('') : `<p style="font-size:0.8rem;color:var(--text-muted);padding:0.5rem;">No topics reached strong mastery threshold yet.</p>`;

    const weakListHtml = r.weakAreas.length > 0 ? r.weakAreas.map(a => `
      <div class="area-pill-row">
        <span style="font-weight:600;color:#991b1b;">${a.topic}</span>
        <span class="badge badge-danger">${a.percentage}%</span>
      </div>
    `).join('') : `<p style="font-size:0.8rem;color:var(--text-muted);padding:0.5rem;">Great job! No topics flagged as critical weak areas.</p>`;

    // Detailed question review list
    const questionReviewHtml = (r.questionReview || []).map((q, idx) => {
      const statusIcon = q.isCorrect ? '✅' : '❌';
      const letters = ['A', 'B', 'C', 'D'];
      return `
        <div style="background:var(--bg-subtle);border-radius:var(--radius-md);padding:1rem;margin-bottom:0.75rem;border-left:4px solid ${q.isCorrect ? 'var(--success)' : 'var(--danger)'};">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.35rem;">
            <span style="font-size:0.8rem;font-weight:700;color:var(--text-muted);">Q${idx + 1} • ${q.topic}</span>
            <span style="font-size:0.8rem;font-weight:700;">${statusIcon} ${q.isCorrect ? 'Correct' : 'Incorrect'}</span>
          </div>
          <div style="font-size:0.9rem;font-weight:600;color:var(--text-main);margin-bottom:0.5rem;">${q.question}</div>
          <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:0.35rem;">
            Your Answer: <strong>${q.selectedOption !== undefined ? letters[q.selectedOption] + ': ' + q.options[q.selectedOption] : 'Unanswered'}</strong>
            ${!q.isCorrect ? ` | Correct Answer: <strong style="color:var(--success-text);">${letters[q.correctOption]}: ${q.options[q.correctOption]}</strong>` : ''}
          </div>
          <div style="font-size:0.75rem;color:#4c1d95;background:#f5f3ff;padding:0.4rem 0.65rem;border-radius:var(--radius-sm);border:1px solid #ddd6fe;">
            💡 <strong>Explanation:</strong> ${q.explanation}
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div class="quiz-results-container">
        <!-- Top Score Banner -->
        <div class="quiz-score-banner">
          <span class="brand-badge" style="background:rgba(255,255,255,0.2);color:white;border:none;">Quiz Completed!</span>
          <div class="score-big">${r.score} / ${r.totalQuestions}</div>
          <div class="score-pct">${r.percentage}% Overall Score</div>
          <p style="font-size:0.85rem;opacity:0.85;margin-top:0.4rem;">
            Topic-level diagnostic breakdown generated below. Timetable updated automatically.
          </p>
        </div>

        <!-- ACTION BANNER: ADAPTIVE FEEDBACK LOOP HIGHLIGHT -->
        <div class="adapt-action-banner">
          <div class="adapt-action-text">
            <h4>🤖 AI Adaptive Timetable Updated</h4>
            <p>
              The study planner evaluated your topic weak spots (${r.weakAreas.map(w => w.topic).join(', ') || 'rebalanced'}) and dynamically increased their study allocations.
            </p>
          </div>
          <button class="btn-primary" style="background:#4338ca;box-shadow:none;white-space:nowrap;" onclick="window.state.setView('planner')">
            📅 View Updated Timetable ➔
          </button>
        </div>

        <!-- Topic Level Performance Section -->
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Topic-Level Performance Analysis</h3>
              <span class="card-subtitle">Exact breakdown by sub-topic</span>
            </div>
            <span class="badge badge-info">${Object.keys(breakdown).length} Topics Evaluated</span>
          </div>

          <div>
            ${topicBarsHtml}
          </div>
        </div>

        <!-- Strong vs Weak Split Cards -->
        <div class="results-split">
          <div class="areas-card strong-areas-card">
            <div class="areas-card-title">
              <span>🌟 Strong Areas (Mastered)</span>
            </div>
            <div class="area-pills-list">
              ${strongListHtml}
            </div>
          </div>

          <div class="areas-card weak-areas-card">
            <div class="areas-card-title">
              <span>⚠️ Weak Areas (Needs Urgent Focus)</span>
            </div>
            <div class="area-pills-list">
              ${weakListHtml}
            </div>
          </div>
        </div>

        <!-- Question-by-Question Review -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Detailed Question Review & Explanations</h3>
            <button class="btn-sm btn-secondary" onclick="QuizComponent.exitQuiz()">Take Another Quiz</button>
          </div>
          <div>
            ${questionReviewHtml}
          </div>
        </div>
      </div>
    `;
  }

  // ==========================================
  // MODE 4: STUDENT-PROVIDED QUIZ (Option B)
  // ==========================================
  static startManualCreate() {
    QuizComponent.currentMode = 'manual_create';
    QuizComponent.render(document.getElementById('view_container'));
  }

  static renderManualCreate(container) {
    const courses = window.state.data.courses || [];
    const courseOptions = courses.map(c => `<option value="${c.name}">${c.name}</option>`).join('');

    container.innerHTML = `
      <div style="margin-bottom:1.5rem;">
        <button class="btn-sm btn-secondary" onclick="QuizComponent.exitQuiz()" style="margin-bottom:0.75rem;">
          ← Back to Quizzes
        </button>
        <h2 style="font-size:1.35rem;font-weight:700;color:var(--text-main);">Option B — Student-Provided Quiz</h2>
        <p style="font-size:0.85rem;color:var(--text-muted);">
          Enter custom questions from your textbook, homework, or past exam papers. Associate each question with its relevant topic.
        </p>
      </div>

      <div class="card" style="margin-bottom:1.5rem;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.5rem;">
          <div class="form-group">
            <label class="form-label">Quiz Title</label>
            <input type="text" id="manual_title" class="form-input" value="Custom Past Paper Diagnostic" />
          </div>
          <div class="form-group">
            <label class="form-label">Course / Subject</label>
            <select id="manual_course" class="form-select">
              ${courseOptions}
            </select>
          </div>
        </div>

        <div id="manual_questions_list">
          <!-- Dynamic Question Cards -->
          <div class="manual-q-box" data-q-idx="0" style="background:var(--bg-subtle);padding:1.25rem;border-radius:var(--radius-md);margin-bottom:1rem;border:1px solid var(--border);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
              <span style="font-weight:700;font-size:0.9rem;">Question 1</span>
              <div class="form-group" style="width:200px;">
                <input type="text" class="form-input manual-topic" placeholder="Topic (e.g. Chemical Bonding)" value="Chemical Bonding" required />
              </div>
            </div>
            <div class="form-group" style="margin-bottom:0.75rem;">
              <textarea class="form-textarea manual-q-text" rows="2" placeholder="Enter question prompt..." required>Which hybridization state characterizes the central atom in an SF6 molecule?</textarea>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;margin-bottom:0.75rem;">
              <input type="text" class="form-input manual-opt-0" placeholder="Option A" value="sp3" />
              <input type="text" class="form-input manual-opt-1" placeholder="Option B" value="sp3d" />
              <input type="text" class="form-input manual-opt-2" placeholder="Option C" value="sp3d2" />
              <input type="text" class="form-input manual-opt-3" placeholder="Option D" value="dsp2" />
            </div>
            <div style="display:flex;align-items:center;gap:1rem;">
              <label style="font-size:0.8rem;font-weight:600;">Correct Answer Key:</label>
              <select class="form-select manual-correct-idx" style="width:120px;">
                <option value="0">Option A</option>
                <option value="1">Option B</option>
                <option value="2" selected>Option C</option>
                <option value="3">Option D</option>
              </select>
            </div>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:1.5rem;">
          <button class="btn-secondary" onclick="QuizComponent.addManualQuestionCard()">
            + Add Another Question
          </button>
          <button class="btn-primary" onclick="QuizComponent.startManualQuiz()">
            🚀 Start & Take This Quiz
          </button>
        </div>
      </div>
    `;
  }

  static addManualQuestionCard() {
    const list = document.getElementById('manual_questions_list');
    if (!list) return;
    const count = list.querySelectorAll('.manual-q-box').length;

    const div = document.createElement('div');
    div.className = 'manual-q-box';
    div.dataset.qIdx = count;
    div.style = 'background:var(--bg-subtle);padding:1.25rem;border-radius:var(--radius-md);margin-bottom:1rem;border:1px solid var(--border);';
    div.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
        <span style="font-weight:700;font-size:0.9rem;">Question ${count + 1}</span>
        <div class="form-group" style="width:200px;">
          <input type="text" class="form-input manual-topic" placeholder="Topic" value="Thermodynamics" required />
        </div>
      </div>
      <div class="form-group" style="margin-bottom:0.75rem;">
        <textarea class="form-textarea manual-q-text" rows="2" placeholder="Enter question prompt..." required></textarea>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;margin-bottom:0.75rem;">
        <input type="text" class="form-input manual-opt-0" placeholder="Option A" />
        <input type="text" class="form-input manual-opt-1" placeholder="Option B" />
        <input type="text" class="form-input manual-opt-2" placeholder="Option C" />
        <input type="text" class="form-input manual-opt-3" placeholder="Option D" />
      </div>
      <div style="display:flex;align-items:center;gap:1rem;">
        <label style="font-size:0.8rem;font-weight:600;">Correct Answer Key:</label>
        <select class="form-select manual-correct-idx" style="width:120px;">
          <option value="0">Option A</option>
          <option value="1">Option B</option>
          <option value="2">Option C</option>
          <option value="3">Option D</option>
        </select>
      </div>
    `;
    list.appendChild(div);
  }

  static startManualQuiz() {
    const title = document.getElementById('manual_title').value.trim() || 'Custom Student Quiz';
    const course = document.getElementById('manual_course').value;
    const cards = Array.from(document.querySelectorAll('.manual-q-box'));

    const questions = [];
    cards.forEach((card, idx) => {
      const topic = card.querySelector('.manual-topic').value.trim() || 'General';
      const qText = card.querySelector('.manual-q-text').value.trim();
      const opt0 = card.querySelector('.manual-opt-0').value.trim() || 'Option A';
      const opt1 = card.querySelector('.manual-opt-1').value.trim() || 'Option B';
      const opt2 = card.querySelector('.manual-opt-2').value.trim() || 'Option C';
      const opt3 = card.querySelector('.manual-opt-3').value.trim() || 'Option D';
      const correctIdx = Number(card.querySelector('.manual-correct-idx').value);

      if (qText) {
        questions.push({
          id: `man_${idx + 1}_${Date.now()}`,
          course,
          topic,
          difficulty: 'Medium',
          question: qText,
          options: [opt0, opt1, opt2, opt3],
          answerIndex: correctIdx,
          explanation: `Student verified answer key for ${topic}.`
        });
      }
    });

    if (questions.length === 0) {
      window.App.showToast('Please enter at least one question', 'error');
      return;
    }

    const quiz = {
      id: `manual_${Date.now()}`,
      title,
      course,
      difficulty: 'Custom',
      totalQuestions: questions.length,
      questions,
      createdAt: new Date().toISOString()
    };

    QuizComponent.activeQuiz = quiz;
    QuizComponent.userAnswers = {};
    QuizComponent.currentQuestionIdx = 0;
    QuizComponent.secondsRemaining = questions.length * 90; // 1.5 min per Q
    QuizComponent.currentMode = 'taking';

    QuizComponent.render(document.getElementById('view_container'));
    window.App.showToast(`Custom quiz ready! ${questions.length} questions loaded.`, 'success');
  }

  static exitQuiz() {
    if (QuizComponent.timerInterval) clearInterval(QuizComponent.timerInterval);
    QuizComponent.currentMode = 'select';
    QuizComponent.activeQuiz = null;
    QuizComponent.userAnswers = {};
    QuizComponent.render(document.getElementById('view_container'));
  }
}

// Export for browser
window.QuizComponent = QuizComponent;
