/**
 * Study Planner - Authentication Component (Login & Sign Up)
 * Client-side localStorage authentication with route protection and session management.
 */

class AuthComponent {
  static renderLogin(container) {
    container.innerHTML = `
      <div class="auth-wrapper">
        <div class="auth-card">
          <div class="auth-brand">
            <div class="brand-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
              </svg>
            </div>
            <div class="brand-info">
              <h1>Study Planner <span class="brand-badge">AI</span></h1>
            </div>
          </div>

          <div class="auth-header">
            <h2>Welcome Back</h2>
            <p>Enter your credentials to access your adaptive study planner</p>
          </div>

          <div id="auth_error_msg" class="auth-error-box" style="display:none;"></div>

          <form id="login_form" class="auth-form" onsubmit="AuthComponent.handleLoginSubmit(event)">
            <div class="form-group">
              <label class="form-label" for="login_email">Email Address</label>
              <div class="auth-input-wrapper">
                <span class="auth-input-icon">✉️</span>
                <input type="email" id="login_email" class="form-input" placeholder="student@apex.edu" required autocomplete="email" />
              </div>
            </div>

            <div class="form-group">
              <div style="display:flex;justify-content:space-between;align-items:center;">
                <label class="form-label" for="login_password">Password</label>
              </div>
              <div class="auth-input-wrapper">
                <span class="auth-input-icon">🔒</span>
                <input type="password" id="login_password" class="form-input" placeholder="••••••••" required autocomplete="current-password" />
              </div>
            </div>

            <button type="submit" id="login_submit_btn" class="btn-primary auth-submit-btn">
              Login to Study Planner
            </button>
          </form>

          <!-- Quick Demo Access Helper -->
          <div class="auth-demo-box">
            <div class="auth-demo-title">⚡ Quick Demo Access</div>
            <button type="button" class="btn-secondary btn-sm" style="width:100%;" onclick="AuthComponent.fillDemoLogin()">
              Fill Demo: Alex Morgan (alex.morgan@apex.edu / study123)
            </button>
          </div>

          <div class="auth-footer">
            Don't have an account? 
            <a href="#signup" class="auth-link" onclick="event.preventDefault(); window.App.navigateTo('signup');">Sign up</a>
          </div>
        </div>
      </div>
    `;
  }

  static renderSignup(container) {
    container.innerHTML = `
      <div class="auth-wrapper">
        <div class="auth-card">
          <div class="auth-brand">
            <div class="brand-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
              </svg>
            </div>
            <div class="brand-info">
              <h1>Study Planner <span class="brand-badge">AI</span></h1>
            </div>
          </div>

          <div class="auth-header">
            <h2>Create Your Account</h2>
            <p>Start your performance-driven adaptive study journey</p>
          </div>

          <div id="auth_error_msg" class="auth-error-box" style="display:none;"></div>

          <form id="signup_form" class="auth-form" onsubmit="AuthComponent.handleSignupSubmit(event)">
            <div class="form-group">
              <label class="form-label" for="signup_name">Full Name</label>
              <div class="auth-input-wrapper">
                <span class="auth-input-icon">👤</span>
                <input type="text" id="signup_name" class="form-input" placeholder="e.g. Jordan Lee" required autocomplete="name" />
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="signup_email">Email Address</label>
              <div class="auth-input-wrapper">
                <span class="auth-input-icon">✉️</span>
                <input type="email" id="signup_email" class="form-input" placeholder="e.g. jordan.lee@university.edu" required autocomplete="email" />
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="signup_password">Password</label>
              <div class="auth-input-wrapper">
                <span class="auth-input-icon">🔒</span>
                <input type="password" id="signup_password" class="form-input" placeholder="At least 6 characters" minlength="6" required autocomplete="new-password" />
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="signup_confirm_password">Confirm Password</label>
              <div class="auth-input-wrapper">
                <span class="auth-input-icon">🔐</span>
                <input type="password" id="signup_confirm_password" class="form-input" placeholder="Re-enter password" minlength="6" required autocomplete="new-password" />
              </div>
            </div>

            <button type="submit" id="signup_submit_btn" class="btn-primary auth-submit-btn">
              Create Account
            </button>
          </form>

          <div class="auth-footer">
            Already have an account? 
            <a href="#login" class="auth-link" onclick="event.preventDefault(); window.App.navigateTo('login');">Login</a>
          </div>
        </div>
      </div>
    `;
  }

  static fillDemoLogin() {
    const emailEl = document.getElementById('login_email');
    const passEl = document.getElementById('login_password');
    if (emailEl && passEl) {
      emailEl.value = 'alex.morgan@apex.edu';
      passEl.value = 'study123';
      emailEl.focus();
    }
  }

  static showError(message) {
    const errBox = document.getElementById('auth_error_msg');
    if (errBox) {
      errBox.textContent = message;
      errBox.style.display = 'block';
    }
  }

  static hideError() {
    const errBox = document.getElementById('auth_error_msg');
    if (errBox) {
      errBox.style.display = 'none';
      errBox.textContent = '';
    }
  }

  static async handleLoginSubmit(e) {
    e.preventDefault();
    AuthComponent.hideError();

    const email = document.getElementById('login_email').value.trim();
    const password = document.getElementById('login_password').value;

    if (!email || !password) {
      AuthComponent.showError('Please fill in both email and password.');
      return;
    }

    const res = ApiService.loginUser({ email, password });
    if (!res.success) {
      AuthComponent.showError(res.message || 'Invalid email or password. Please try again.');
      return;
    }

    window.App.showToast(`Welcome back, ${res.user.name}!`, 'success');
    
    // Load student's study data into state
    await window.state.loadBootstrap();

    // Take student to their dashboard
    window.App.navigateTo('dashboard');
  }

  static async handleSignupSubmit(e) {
    e.preventDefault();
    AuthComponent.hideError();

    const name = document.getElementById('signup_name').value.trim();
    const email = document.getElementById('signup_email').value.trim();
    const password = document.getElementById('signup_password').value;
    const confirmPassword = document.getElementById('signup_confirm_password').value;

    if (!name || !email || !password || !confirmPassword) {
      AuthComponent.showError('All fields are required.');
      return;
    }

    if (password !== confirmPassword) {
      AuthComponent.showError('Passwords do not match. Please verify and re-enter.');
      return;
    }

    if (password.length < 6) {
      AuthComponent.showError('Password must be at least 6 characters long.');
      return;
    }

    const res = ApiService.registerUser({ name, email, password });
    if (!res.success) {
      AuthComponent.showError(res.message || 'An error occurred during sign up.');
      return;
    }

    window.App.showToast(`Account created for ${name}!`, 'success');

    // Load newly created state
    await window.state.loadBootstrap();

    // User flow: Sign Up → Profile setup → Dashboard
    // Take student to Profile setup first with welcome banner, from which they can review hours and proceed to Dashboard
    window.App.isNewUserSignup = true;
    window.App.navigateTo('profile');
  }
}

// Export for browser
window.AuthComponent = AuthComponent;
