/**
 * Study Planner - Dashboard Component
 * Summarizes the student's current academic state, today's adaptive schedule,
 * today's study sessions with study techniques and break indicators, upcoming events,
 * performance breakdown, and explainable AI insights.
 */

class DashboardComponent {
  static render(container) {
    const data = window.state.data;
    const user = data.user || {};
    const timetable = data.timetable || [];
    const exams = data.exams || [];
    const assignments = data.assignments || [];
    const courses = data.courses || [];
    const insight = data.lastAdaptedInsight || {
      topic: 'Chemical Bonding',
      course: 'Chemistry',
      title: '⚠ Chemical Bonding needs prioritized revision',
      recommendation: 'Your performance increased from 45% to 72% in mock tests. Because your Chemistry Internal Assessment is in 6 days, the timetable allocates 50 min to Chemical Bonding and 40 min to Thermodynamics with structured 10m cognitive rest breaks.',
      trend: 'Improving',
      score: 72
    };

    // Calculate quick metrics
    const totalStudyHours = user.daily_hours || 3.0;
    const upcomingExamsCount = exams.length;
    const pendingAssignmentsCount = assignments.filter(a => a.status !== 'completed').length;
    const weakTopicsTotal = courses.reduce((acc, c) => acc + (c.weak_topics_count || 0), 0);

    // Filter study sessions only for the Study Sessions section (Section 10)
    const studySessionsOnly = timetable.filter(s => !s.is_break);

    // Build today's schedule items (Timeline including breaks)
    const scheduleHtml = timetable.length > 0 ? timetable.map(sess => {
      // Break Item
      if (sess.is_break) {
        return `
          <div class="timeline-slot timeline-break-slot" style="background:#fffbeb;border-left:4px solid #f59e0b;padding:0.75rem 1rem;">
            <div class="slot-time" style="color:#b45309;font-weight:700;">${sess.start_time} – ${sess.end_time}</div>
            <div class="slot-details">
              <div style="display:flex;align-items:center;gap:0.5rem;">
                <span style="font-size:1.1rem;">☕</span>
                <strong style="color:#92400e;font-size:0.9rem;">${sess.title || 'Break Time'}</strong>
                <span class="badge" style="background:#fef3c7;color:#92400e;font-weight:700;">${sess.duration_mins} min</span>
              </div>
              <div style="font-size:0.75rem;color:#b45309;margin-top:2px;">
                ${sess.message || 'Rest your eyes, hydrate, and relax before your next session.'}
              </div>
            </div>
            <div class="slot-actions">
              <button class="btn-sm btn-secondary" style="border-color:#fde68a;color:#92400e;background:white;" onclick="StudyTimerComponent.startDirectBreak({ duration_mins: ${sess.duration_mins} })">
                ☕ Start Break
              </button>
            </div>
          </div>
        `;
      }

      // Study Session Item
      const isCompleted = sess.completed ? 'completed' : '';
      const checkClass = sess.completed ? 'checked' : '';
      const technique = sess.study_technique || 'Focused Study';
      const techIcon = technique.includes('Pomodoro') ? '🍅' : (technique.includes('Deep') ? '🌊' : '🎯');

      const diffTag = sess.change_delta_mins > 0
        ? `<span class="slot-diff-tag diff-plus">+${sess.change_delta_mins}m AI</span>`
        : (sess.change_delta_mins < 0 ? `<span class="slot-diff-tag diff-minus">${sess.change_delta_mins}m AI</span>` : '');

      let completionPill = '';
      if (sess.completion_status === 'Completed') {
        completionPill = `<span class="badge badge-success" style="font-size:0.72rem;">🟢 Completed</span>`;
      } else if (sess.completion_status === 'Partially Completed') {
        completionPill = `<span class="badge badge-warning" style="font-size:0.72rem;">🟡 Partial</span>`;
      } else if (sess.completion_status === 'Not Completed') {
        completionPill = `<span class="badge badge-danger" style="font-size:0.72rem;">🔴 Incomplete</span>`;
      }

      return `
        <div class="timeline-slot ${isCompleted}" data-session-id="${sess.id}" style="border-left-color:${sess.course_color || 'var(--primary)'};">
          <div class="slot-time">${sess.start_time} – ${sess.end_time}</div>
          <div class="slot-details">
            <div class="slot-subject-topic" style="gap:0.45rem;align-items:center;">
              <span class="slot-subject" style="color:${sess.course_color || 'var(--primary)'};">${sess.course_name || 'Study'}</span>
              <span class="slot-topic" style="font-weight:700;">${sess.topic_name || 'General'}</span>
              <span class="badge" style="background:#ede9fe;color:#6d28d9;font-size:0.72rem;font-weight:700;">
                ${techIcon} ${technique}
              </span>
              ${diffTag}
              ${completionPill}
            </div>

            <!-- Goal preview -->
            ${sess.goal ? `
              <div style="font-size:0.78rem;color:var(--text-main);margin-top:0.25rem;">
                🎯 <strong>Goal:</strong> ${sess.goal}
              </div>
            ` : ''}

            ${sess.change_reason ? `<div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px;">💡 ${sess.change_reason}</div>` : ''}
          </div>
          <div class="slot-actions">
            <button class="btn-sm btn-primary" style="white-space:nowrap;padding:0.35rem 0.75rem;" onclick="StudyTimerComponent.openTimer('${sess.id}')">
              ▶ ${sess.completed ? 'Restart' : 'Start'}
            </button>
            <button class="slot-check-btn ${checkClass}" title="Mark completed" onclick="window.state.toggleSessionCompleted('${sess.id}')">
              ${sess.completed ? '✓' : ''}
            </button>
          </div>
        </div>
      `;
    }).join('') : `
      <div style="padding:1.5rem;text-align:center;color:var(--text-muted);background:var(--bg-subtle);border-radius:var(--radius-md);">
        No sessions scheduled for today. <button class="btn-sm btn-primary" onclick="window.state.adaptTimetable('Manual generation')">Generate Timetable</button>
      </div>
    `;

    // Section 10: Dedicated "Today's Study Sessions" Cards
    const studySessionsCardsHtml = studySessionsOnly.map(sess => {
      const technique = sess.study_technique || 'Focused Study';
      const techIcon = technique.includes('Pomodoro') ? '🍅' : (technique.includes('Deep') ? '🌊' : '🎯');

      let statusBadge = `<button class="btn-sm btn-primary" style="padding:0.4rem 0.9rem;" onclick="StudyTimerComponent.openTimer('${sess.id}')">▶ Start Session</button>`;
      if (sess.completed) {
        const text = sess.completion_status || 'Completed';
        const colorClass = text === 'Completed' ? 'badge-success' : (text === 'Partially Completed' ? 'badge-warning' : 'badge-danger');
        statusBadge = `
          <div style="display:flex;align-items:center;gap:0.4rem;">
            <span class="badge ${colorClass}">✓ ${text}</span>
            <button class="btn-sm btn-secondary" onclick="StudyTimerComponent.openTimer('${sess.id}')" title="Restart">↺</button>
          </div>
        `;
      }

      return `
        <div class="dashboard-session-card" style="border-left:4px solid ${sess.course_color || 'var(--primary)'};">
          <div class="dashboard-session-time">
            <span style="font-size:0.95rem;font-weight:800;color:var(--text-main);">${sess.start_time}</span>
            <span style="font-size:0.75rem;color:var(--text-muted);font-weight:600;">${sess.duration_mins} min</span>
          </div>

          <div class="dashboard-session-body">
            <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
              <span style="font-weight:800;font-size:1rem;color:${sess.course_color || 'var(--primary)'};">${sess.course_name}</span>
              <span style="color:var(--text-subtle);">—</span>
              <span style="font-weight:700;color:var(--text-main);">${sess.topic_name}</span>
              <span class="badge" style="background:#ede9fe;color:#6d28d9;font-weight:700;font-size:0.75rem;">
                ${techIcon} ${technique}
              </span>
            </div>

            <div style="font-size:0.8rem;color:var(--text-muted);margin-top:0.3rem;">
              🎯 <strong>Goal:</strong> ${sess.goal || 'Understand core theory and solve 5 questions.'}
            </div>
            
            ${sess.break_duration > 0 ? `
              <div style="font-size:0.75rem;color:#b45309;margin-top:0.25rem;">
                ☕ Followed by a ${sess.break_duration} min rest break
              </div>
            ` : ''}
          </div>

          <div class="dashboard-session-action">
            ${statusBadge}
          </div>
        </div>
      `;
    }).join('');

    // Upcoming events list (Exams & Assignments)
    const combinedEvents = [
      ...exams.map(e => ({
        type: 'exam',
        title: e.title,
        sub: `Topics: ${(e.topics || []).slice(0, 2).join(', ')}`,
        date: new Date(e.exam_date),
        dateStr: e.exam_date,
        priority: e.priority
      })),
      ...assignments.filter(a => a.status !== 'completed').map(a => ({
        type: 'assignment',
        title: a.title,
        sub: `Due: ${a.due_date}`,
        date: new Date(a.due_date),
        dateStr: a.due_date,
        priority: a.priority
      }))
    ].sort((a, b) => a.date - b.date).slice(0, 4);

    const now = new Date();
    const eventsHtml = combinedEvents.length > 0 ? combinedEvents.map(evt => {
      const diffDays = Math.ceil((evt.date - now) / (1000 * 60 * 60 * 24));
      const countdownStr = diffDays <= 0 ? 'Due Today' : (diffDays === 1 ? 'Tomorrow' : `${diffDays} days remaining`);
      const icon = evt.type === 'exam' ? '📝' : '📌';

      return `
        <div class="event-card ${evt.type}">
          <div class="event-info">
            <h4>${icon} ${evt.title}</h4>
            <p>${evt.sub}</p>
          </div>
          <span class="event-countdown">${countdownStr}</span>
        </div>
      `;
    }).join('') : `<p style="color:var(--text-muted);font-size:0.85rem;">No upcoming deadlines scheduled.</p>`;

    // Performance bars for courses
    const perfHtml = courses.map(c => {
      const score = c.average_performance || 70;
      const barColor = score >= 80 ? 'var(--success)' : (score < 65 ? 'var(--danger)' : 'var(--warning)');
      return `
        <div class="perf-item">
          <div class="perf-meta">
            <span>${c.name}</span>
            <span style="color:${barColor};">${score}%</span>
          </div>
          <div class="progress-bar-container">
            <div class="progress-bar-fill" style="width:${score}%;background:${barColor};"></div>
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <!-- Continuous Adaptive Loop USP Banner -->
      <div class="usp-loop-banner">
        <div class="usp-left">
          <h3>Adaptive Study & Break System Active</h3>
          <p>Study Planner balances topic weaknesses with structured Pomodoro, Focused, and Deep study techniques + rest breaks within your available hours.</p>
          <div class="usp-steps">
            <span class="loop-step">1. Plan</span>
            <span class="loop-arrow">➔</span>
            <span class="loop-step" style="background:#ffffff;color:#4f46e5;font-weight:700;">2. Study</span>
            <span class="loop-arrow">➔</span>
            <span class="loop-step" style="background:#fef3c7;color:#92400e;font-weight:700;">3. ☕ Break</span>
            <span class="loop-arrow">➔</span>
            <span class="loop-step">4. Test</span>
            <span class="loop-arrow">➔</span>
            <span class="loop-step">5. Analyze</span>
            <span class="loop-arrow">➔</span>
            <span class="loop-step">6. Adapt</span>
          </div>
        </div>
        <div class="usp-right">
          <button class="btn-secondary" style="background:white;color:#4f46e5;font-weight:700;" onclick="window.state.setView('quiz')">
            ⚡ Take Mock Quiz
          </button>
        </div>
      </div>

      <!-- Quick Metrics Row -->
      <div class="metrics-row">
        <div class="metric-card">
          <div class="metric-icon-box" style="background:var(--primary-light);color:var(--primary);">⏱️</div>
          <div class="metric-content">
            <div class="metric-label">Daily Study Window</div>
            <div class="metric-value">${totalStudyHours} hrs</div>
            <div class="metric-sub" style="color:var(--text-muted);">${user.preferred_start || '18:00'} – ${user.preferred_end || '21:00'}</div>
          </div>
        </div>
        <div class="metric-card">
          <div class="metric-icon-box" style="background:var(--danger-light);color:var(--danger);">⚠️</div>
          <div class="metric-content">
            <div class="metric-label">Weak Topics Flagged</div>
            <div class="metric-value">${weakTopicsTotal}</div>
            <div class="metric-sub attention">Prioritized in timetable</div>
          </div>
        </div>
        <div class="metric-card">
          <div class="metric-icon-box" style="background:var(--secondary-light);color:var(--secondary);">🎯</div>
          <div class="metric-content">
            <div class="metric-label">Upcoming Exams</div>
            <div class="metric-value">${upcomingExamsCount}</div>
            <div class="metric-sub" style="color:var(--primary);">Internal assessment in 6d</div>
          </div>
        </div>
        <div class="metric-card">
          <div class="metric-icon-box" style="background:var(--accent-blue-light);color:var(--accent-blue);">📋</div>
          <div class="metric-content">
            <div class="metric-label">Pending Assignments</div>
            <div class="metric-value">${pendingAssignmentsCount}</div>
            <div class="metric-sub positive">With active alert reminders</div>
          </div>
        </div>
      </div>

      <!-- SECTION 10: TODAY'S STUDY SESSIONS -->
      <div class="card" style="margin-bottom:1.5rem;">
        <div class="card-header">
          <div class="card-title-group">
            <span style="font-size:1.3rem;">🎯</span>
            <div>
              <h3 class="card-title">Today's Study Sessions</h3>
              <span class="card-subtitle">Technique-based study blocks with structured rest intervals</span>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:0.75rem;">
            <span class="badge-ai">Break-Aware Scheduler</span>
            <button class="btn-sm btn-secondary" onclick="window.state.setView('planner')">Full Planner ➔</button>
          </div>
        </div>

        <div class="dashboard-sessions-list" style="display:flex;flex-direction:column;gap:0.85rem;">
          ${studySessionsCardsHtml || '<p style="color:var(--text-muted);font-size:0.85rem;padding:1rem;">No study sessions scheduled.</p>'}
        </div>
      </div>

      <!-- Main Dashboard Grid -->
      <div class="dashboard-grid">
        <!-- Left: Today's Full Schedule Timeline (with Breaks) -->
        <div class="card">
          <div class="card-header">
            <div class="card-title-group">
              <span style="font-size:1.3rem;">📅</span>
              <div>
                <h3 class="card-title">Today's Study & Break Plan</h3>
                <span class="card-subtitle">AI-optimized schedule fitting strictly within available hours</span>
              </div>
            </div>
            <div style="display:flex;gap:0.5rem;">
              <span class="badge-ai">🤖 Adaptive Plan</span>
              <button class="btn-sm btn-secondary" onclick="window.App.openWhyTimetableModal()">
                Why this plan?
              </button>
            </div>
          </div>

          <div class="schedule-timeline">
            ${scheduleHtml}
          </div>
        </div>

        <!-- Right: AI Insight & Events & Performance -->
        <div style="display:flex;flex-direction:column;gap:1.5rem;">
          
          <!-- AI Insight Box -->
          <div class="ai-spotlight-card">
            <div class="ai-spotlight-header">
              <div class="ai-badge-row">
                <div class="ai-icon-pulse">✨</div>
                <span style="font-weight:700;font-size:0.85rem;color:#6b21a8;">AI Study Insight</span>
              </div>
              <span class="badge badge-success">Trend: ${insight.trend || 'Improving'}</span>
            </div>

            <div class="ai-insight-content">
              <div class="ai-insight-title">${insight.title || 'Topic Revision Focus'}</div>
              <p class="ai-insight-text">${insight.recommendation}</p>
              
              <div class="ai-insight-metrics">
                <div>Topic: <strong>${insight.topic || 'Chemical Bonding'}</strong></div>
                <div>Mastery: <strong>${insight.score || 72}%</strong></div>
              </div>
            </div>

            <div style="display:flex;justify-content:flex-end;">
              <button class="btn-sm btn-primary" onclick="window.state.setView('planner')">
                View Adaptive Planner ➔
              </button>
            </div>
          </div>

          <!-- Upcoming Events -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title" style="font-size:1rem;">Upcoming Events</h3>
              <button class="btn-sm btn-secondary" onclick="window.state.setView('exams')">View All</button>
            </div>
            <div class="events-list">
              ${eventsHtml}
            </div>
          </div>

          <!-- Course Performance Summary -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title" style="font-size:1rem;">Performance Summary</h3>
              <button class="btn-sm btn-secondary" onclick="window.state.setView('progress')">Analytics</button>
            </div>
            <div class="perf-list">
              ${perfHtml}
            </div>
          </div>

        </div>
      </div>
    `;
  }
}

// Export for browser
window.DashboardComponent = DashboardComponent;
