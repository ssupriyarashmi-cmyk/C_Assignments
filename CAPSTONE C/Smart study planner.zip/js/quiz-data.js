/**
 * Study Planner - Comprehensive Mock Quiz Question Bank & Quiz Engine
 * Maps every question directly to its Course and Topic for fine-grained performance analytics.
 */

const QUESTION_BANK = [
  // ==========================================
  // CHEMISTRY: Chemical Bonding (Crucial Weak Topic)
  // ==========================================
  {
    id: "chem_cb_1",
    course: "Chemistry",
    topic: "Chemical Bonding",
    difficulty: "Medium",
    question: "Which of the following molecules has a linear molecular geometry according to VSEPR theory?",
    options: ["SO₂", "H₂O", "BeCl₂", "OF₂"],
    answerIndex: 2,
    explanation: "BeCl₂ has two bonding pairs and zero lone pairs around the central Beryllium atom, resulting in a steric number of 2 and a linear geometry (180° bond angle)."
  },
  {
    id: "chem_cb_2",
    course: "Chemistry",
    topic: "Chemical Bonding",
    difficulty: "Medium",
    question: "What is the hybridization of the central sulfur atom in sulfur hexafluoride (SF₆)?",
    options: ["sp³", "dsp³", "sp³d²", "dsp²"],
    answerIndex: 2,
    explanation: "SF₆ has 6 single bonds and zero lone pairs on sulfur. 6 electron domains correspond to sp³d² hybridization with octahedral geometry."
  },
  {
    id: "chem_cb_3",
    course: "Chemistry",
    topic: "Chemical Bonding",
    difficulty: "Hard",
    question: "Which species possesses a permanent dipole moment (is polar)?",
    options: ["CCl₄", "BF₃", "NH₃", "CO₂"],
    answerIndex: 2,
    explanation: "NH₃ has a trigonal pyramidal shape due to the lone pair on nitrogen, causing dipole vectors to add up and form a net dipole moment."
  },
  {
    id: "chem_cb_4",
    course: "Chemistry",
    topic: "Chemical Bonding",
    difficulty: "Easy",
    question: "In an ionic bond between Sodium and Chlorine, which process represents the driving stabilization force?",
    options: [
      "Sharing of valence electrons",
      "Electrostatic attraction within the crystal lattice (Lattice Energy)",
      "Nuclear fusion between atoms",
      "Overlap of 1s orbitals"
    ],
    answerIndex: 1,
    explanation: "Lattice energy released during the condensation of gaseous ions into a crystal lattice provides the thermodynamic stabilization for ionic compounds."
  },
  {
    id: "chem_cb_5",
    course: "Chemistry",
    topic: "Chemical Bonding",
    difficulty: "Hard",
    question: "According to Molecular Orbital Theory, what is the bond order of the O₂ molecule?",
    options: ["1.0", "1.5", "2.0", "2.5"],
    answerIndex: 2,
    explanation: "O₂ has 10 bonding electrons and 6 antibonding electrons: Bond Order = (10 - 6) / 2 = 2.0. It is paramagnetic with 2 unpaired electrons in π* orbitals."
  },

  // ==========================================
  // CHEMISTRY: Thermodynamics (Weak Topic)
  // ==========================================
  {
    id: "chem_th_1",
    course: "Chemistry",
    topic: "Thermodynamics",
    difficulty: "Medium",
    question: "For a process to be spontaneous at all temperatures, what must be the signs of ΔH and ΔS?",
    options: [
      "ΔH > 0 and ΔS > 0",
      "ΔH < 0 and ΔS > 0",
      "ΔH < 0 and ΔS < 0",
      "ΔH > 0 and ΔS < 0"
    ],
    answerIndex: 1,
    explanation: "From ΔG = ΔH - TΔS, if ΔH is negative (exothermic) and ΔS is positive (increasing entropy), ΔG will always remain negative regardless of temperature T."
  },
  {
    id: "chem_th_2",
    course: "Chemistry",
    topic: "Thermodynamics",
    difficulty: "Hard",
    question: "At constant temperature and pressure, a reaction reaches dynamic chemical equilibrium when:",
    options: ["ΔG = 0", "ΔH = 0", "ΔS = 0", "Q = 0"],
    answerIndex: 0,
    explanation: "At chemical equilibrium, the Gibbs free energy of the system is at an absolute minimum, meaning ΔG = 0."
  },
  {
    id: "chem_th_3",
    course: "Chemistry",
    topic: "Thermodynamics",
    difficulty: "Medium",
    question: "Which of the following is a state function rather than a path-dependent function?",
    options: ["Work (w)", "Heat (q)", "Enthalpy (H)", "Mechanical Power"],
    answerIndex: 2,
    explanation: "Enthalpy (H) depends only on the current thermodynamic state of the system, not on the path taken, unlike heat (q) and work (w)."
  },
  {
    id: "chem_th_4",
    course: "Chemistry",
    topic: "Thermodynamics",
    difficulty: "Easy",
    question: "The Second Law of Thermodynamics states that the total entropy of an isolated system always:",
    options: ["Remains constant", "Decreases over time", "Increases over time in spontaneous processes", "Fluctuates sinusoidally"],
    answerIndex: 2,
    explanation: "In any spontaneous process, the total entropy of the universe (system + surroundings) increases: ΔS_total > 0."
  },

  // ==========================================
  // CHEMISTRY: Atomic Structure (Strong Topic)
  // ==========================================
  {
    id: "chem_as_1",
    course: "Chemistry",
    topic: "Atomic Structure",
    difficulty: "Easy",
    question: "What are the allowed values of the magnetic quantum number (m_l) for an orbital with azimuthal quantum number l = 2?",
    options: ["0, 1, 2", "-2, -1, 0, +1, +2", "-1, 0, +1", "1, 2, 3, 4, 5"],
    answerIndex: 1,
    explanation: "The magnetic quantum number m_l ranges from -l to +l in integer steps. For l = 2 (d orbital), m_l can be -2, -1, 0, +1, +2."
  },
  {
    id: "chem_as_2",
    course: "Chemistry",
    topic: "Atomic Structure",
    difficulty: "Medium",
    question: "Which rule states that no two electrons in an atom can have the same set of four quantum numbers?",
    options: ["Hund's Rule", "Pauli Exclusion Principle", "Aufbau Principle", "Heisenberg Uncertainty"],
    answerIndex: 1,
    explanation: "Pauli's exclusion principle forbids two identical fermions from occupying the same quantum state simultaneously."
  },

  // ==========================================
  // CHEMISTRY: Organic Chemistry
  // ==========================================
  {
    id: "chem_oc_1",
    course: "Chemistry",
    topic: "Organic Chemistry",
    difficulty: "Medium",
    question: "Which carbocation is the most thermodynamically stable due to hyperconjugation and inductive effects?",
    options: ["Methyl carbocation", "Primary carbocation", "Secondary carbocation", "Tertiary carbocation"],
    answerIndex: 3,
    explanation: "Tertiary carbocations have three alkyl groups donating electron density through hyperconjugation with 9 α-hydrogens."
  },

  // ==========================================
  // PHYSICS: Mechanics
  // ==========================================
  {
    id: "phys_mech_1",
    course: "Physics",
    topic: "Mechanics",
    difficulty: "Medium",
    question: "A solid cylinder and a thin spherical shell of equal mass and radius roll down an incline without slipping. Which reaches the bottom first?",
    options: [
      "The thin spherical shell",
      "The solid cylinder",
      "Both reach at the exact same time",
      "Depends on the incline angle"
    ],
    answerIndex: 1,
    explanation: "The cylinder has a smaller moment of inertia (I = 1/2 M R² vs 2/3 M R²), meaning less potential energy is converted to rotational kinetic energy and more to linear velocity."
  },
  {
    id: "phys_mech_2",
    course: "Physics",
    topic: "Mechanics",
    difficulty: "Hard",
    question: "When no external torque acts on a rotating system, which physical quantity is strictly conserved?",
    options: ["Kinetic energy", "Angular momentum", "Linear momentum", "Rotational inertia"],
    answerIndex: 1,
    explanation: "Torque is the rate of change of angular momentum (τ = dL/dt). If τ = 0, angular momentum L is conserved."
  },

  // ==========================================
  // PHYSICS: Electromagnetism (Weak Topic)
  // ==========================================
  {
    id: "phys_em_1",
    course: "Physics",
    topic: "Electromagnetism",
    difficulty: "Medium",
    question: "According to Faraday's Law, the induced electromotive force (EMF) in a closed circuit is equal to:",
    options: [
      "The magnetic flux itself",
      "The negative time rate of change of magnetic flux",
      "The electrostatic potential gradient",
      "The current times resistance squared"
    ],
    answerIndex: 1,
    explanation: "EMF = - dΦ_B / dt. The negative sign represents Lenz's Law indicating the induced current opposes the change in flux."
  },
  {
    id: "phys_em_2",
    course: "Physics",
    topic: "Electromagnetism",
    difficulty: "Hard",
    question: "A charged particle moves perpendicular to a uniform magnetic field B with velocity v. What work is done by the magnetic force on the charge?",
    options: ["qvB × distance", "1/2 m v²", "Zero", "qvB / time"],
    answerIndex: 2,
    explanation: "The Lorentz force F = q(v × B) is always strictly perpendicular to the velocity vector v. Since F · v = 0, the magnetic force does zero work."
  },

  // ==========================================
  // MATHEMATICS: Calculus & Linear Algebra
  // ==========================================
  {
    id: "math_calc_1",
    course: "Mathematics",
    topic: "Calculus",
    difficulty: "Medium",
    question: "What is the derivative of f(x) = ln(cos(x)) with respect to x?",
    options: ["sec(x)", "-tan(x)", "cot(x)", "-sin(x)"],
    answerIndex: 1,
    explanation: "By chain rule, d/dx[ln(u)] = (1/u) * u'. Here u = cos(x), u' = -sin(x). Thus, -sin(x)/cos(x) = -tan(x)."
  },
  {
    id: "math_calc_2",
    course: "Mathematics",
    topic: "Calculus",
    difficulty: "Hard",
    question: "What is the evaluation of ∫ x * e^(2x) dx using integration by parts?",
    options: [
      "(1/2) x e^(2x) - (1/4) e^(2x) + C",
      "x e^(2x) - 2 e^(2x) + C",
      "(1/4) x e^(2x) + C",
      "(1/2) e^(2x) + C"
    ],
    answerIndex: 0,
    explanation: "Let u = x, dv = e^(2x) dx => du = dx, v = (1/2)e^(2x). ∫ u dv = uv - ∫ v du = (1/2)x e^(2x) - (1/4)e^(2x) + C."
  },
  {
    id: "math_la_1",
    course: "Mathematics",
    topic: "Linear Algebra",
    difficulty: "Medium",
    question: "If a square matrix A has determinant det(A) = 0, which statement is true?",
    options: [
      "A is invertible",
      "0 is an eigenvalue of A",
      "All columns of A are linearly independent",
      "The rank of A is equal to its dimension n"
    ],
    answerIndex: 1,
    explanation: "det(A) is the product of its eigenvalues. If det(A) = 0, at least one eigenvalue must be 0, and matrix A is singular (non-invertible)."
  },
  {
    id: "math_prob_1",
    course: "Mathematics",
    topic: "Probability & Statistics",
    difficulty: "Medium",
    question: "If events A and B are independent, P(A) = 0.4 and P(B) = 0.5, what is P(A ∪ B)?",
    options: ["0.90", "0.70", "0.20", "0.60"],
    answerIndex: 1,
    explanation: "P(A ∩ B) = P(A)*P(B) = 0.4*0.5 = 0.20. P(A ∪ B) = P(A) + P(B) - P(A ∩ B) = 0.4 + 0.5 - 0.20 = 0.70."
  },

  // ==========================================
  // COMPUTER SCIENCE: Data Structures & Algorithms
  // ==========================================
  {
    id: "cs_ds_1",
    course: "Computer Science",
    topic: "Data Structures",
    difficulty: "Medium",
    question: "In an AVL self-balancing binary search tree, what is the maximum permissible balance factor magnitude for any node?",
    options: ["0", "1", "2", "log(n)"],
    answerIndex: 1,
    explanation: "In an AVL tree, the height difference between the left and right subtrees (balance factor) must be at most ±1 (-1, 0, or 1)."
  },
  {
    id: "cs_algo_1",
    course: "Computer Science",
    topic: "Algorithms",
    difficulty: "Hard",
    question: "What is the worst-case time complexity of QuickSort when a naive first-element pivot selection is used on an already sorted array?",
    options: ["O(n log n)", "O(n)", "O(n²)", "O(2ⁿ)"],
    answerIndex: 2,
    explanation: "If already sorted and the first element is selected, each partition produces unbalanced splits of size 0 and n-1, leading to O(n²) comparisons."
  },
  {
    id: "cs_db_1",
    course: "Computer Science",
    topic: "Database Systems",
    difficulty: "Medium",
    question: "Which ACID property guarantees that all operations within a transaction succeed or all are rolled back?",
    options: ["Consistency", "Isolation", "Durability", "Atomicity"],
    answerIndex: 3,
    explanation: "Atomicity ('all or nothing') ensures that a transaction cannot be partially completed."
  }
];

class QuizEngine {
  /**
   * Generates a curated or dynamic AI mock quiz matching requested topics & count
   */
  static generateQuiz({ courseName, topics = [], difficulty = "Medium", questionCount = 10, title }) {
    // Filter questions
    let candidateQuestions = QUESTION_BANK.filter(q => {
      const matchCourse = !courseName || q.course.toLowerCase() === courseName.toLowerCase();
      const matchTopic = topics.length === 0 || topics.some(t => t.toLowerCase() === q.topic.toLowerCase());
      return matchCourse && matchTopic;
    });

    // If not enough questions in pre-baked bank, dynamically generate realistic topic questions
    if (candidateQuestions.length < questionCount) {
      const needed = questionCount - candidateQuestions.length;
      const targetTopics = topics.length > 0 ? topics : [
        "Chemical Bonding", "Thermodynamics", "Atomic Structure", "Mechanics", "Calculus"
      ];
      
      for (let i = 0; i < needed; i++) {
        const topic = targetTopics[i % targetTopics.length];
        const generatedQ = this.createSyntheticQuestion(courseName || "General", topic, difficulty, i + 1);
        candidateQuestions.push(generatedQ);
      }
    }

    // Shuffle and pick requested count
    const shuffled = [...candidateQuestions].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, questionCount);

    return {
      id: "quiz_" + Date.now(),
      title: title || `${courseName || "Adaptive"} Mock Quiz (${difficulty})`,
      course: courseName,
      difficulty,
      totalQuestions: selected.length,
      questions: selected,
      createdAt: new Date().toISOString()
    };
  }

  /**
   * Generates synthetic conceptual questions if question bank needs more items
   */
  static createSyntheticQuestion(course, topic, difficulty, num) {
    const templates = [
      {
        q: `In the study of ${topic}, what is the primary consequence of increasing system energy or parameter variation?`,
        opts: [
          `Higher reaction coordinate / system equilibrium shift`,
          `Decrease in internal kinetic degrees of freedom`,
          `Immediate transition to degenerate ground state`,
          `Non-linear decay of fundamental frequency`
        ],
        ans: 0,
        exp: `In standard ${topic} formulations, energy perturbation shifts dynamic equilibrium toward higher potential states.`
      },
      {
        q: `Which analytical method is most effective for evaluating boundary conditions in ${topic}?`,
        opts: [
          `Perturbation theory and linear approximation`,
          `Heuristic guesswork without numerical validation`,
          `Direct substitution without checking dimensional consistency`,
          `Infinite recursive expansion without convergence bounds`
        ],
        ans: 0,
        exp: `Linear approximation and perturbation theory provide rigorous convergence for boundary conditions in ${topic}.`
      },
      {
        q: `What is the key governing theorem or principle applied when solving problems in ${topic}?`,
        opts: [
          `Conservation of fundamental physical quantities`,
          `Arbitrary constant variation hypothesis`,
          `Inversion of boundary potentials without symmetry`,
          `Static frame invariance assumption`
        ],
        ans: 0,
        exp: `Fundamental conservation laws form the cornerstone of analysis in ${topic}.`
      }
    ];

    const t = templates[num % templates.length];
    return {
      id: `syn_${topic.replace(/\s+/g, '_')}_${num}`,
      course,
      topic,
      difficulty,
      question: t.q,
      options: t.opts,
      answerIndex: t.ans,
      explanation: t.exp
    };
  }

  /**
   * Evaluates student's answers, calculates topic-level breakdown, and returns full analytics
   */
  static evaluateSubmission(quiz, userAnswers) {
    let correctCount = 0;
    const topicStats = {};
    const questionReview = [];

    quiz.questions.forEach((q, idx) => {
      const selectedOption = userAnswers[idx];
      const isCorrect = selectedOption === q.answerIndex;

      if (isCorrect) correctCount++;

      // Track by topic
      if (!topicStats[q.topic]) {
        topicStats[q.topic] = { total: 0, correct: 0, scorePct: 0 };
      }
      topicStats[q.topic].total++;
      if (isCorrect) topicStats[q.topic].correct++;

      questionReview.push({
        questionId: q.id,
        question: q.question,
        topic: q.topic,
        selectedOption,
        correctOption: q.answerIndex,
        isCorrect,
        explanation: q.explanation,
        options: q.options
      });
    });

    // Compute topic percentages & categorize strong vs weak
    const strongAreas = [];
    const weakAreas = [];
    const topicBreakdown = {};

    Object.keys(topicStats).forEach(tName => {
      const s = topicStats[tName];
      const pct = Math.round((s.correct / s.total) * 100);
      s.scorePct = pct;
      topicBreakdown[tName] = {
        score: s.correct,
        total: s.total,
        percentage: pct
      };

      if (pct >= 75) {
        strongAreas.push({ topic: tName, percentage: pct });
      } else {
        weakAreas.push({ topic: tName, percentage: pct });
      }
    });

    const totalQuestions = quiz.questions.length;
    const overallPercentage = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;

    return {
      quizId: quiz.id,
      title: quiz.title,
      course: quiz.course,
      totalQuestions,
      score: correctCount,
      percentage: overallPercentage,
      topicBreakdown,
      strongAreas,
      weakAreas,
      questionReview,
      completedAt: new Date().toISOString()
    };
  }
}

// Export for browser
window.QUESTION_BANK = QUESTION_BANK;
window.QuizEngine = QuizEngine;
