/**
 * Study Planner - API Service & Hybrid LocalStorage Sync
 * Automatically detects backend availability; falls back to localStorage seamlessly.
 */

class ApiService {
  static BASE_URL = '';
  static isServerAvailable = false;
  static SESSION_KEY = 'study_planner_session';
  static USERS_KEY = 'study_planner_users';

  static DEFAULT_USERS = [
    {
      id: 'user_alex',
      name: 'Alex Morgan',
      email: 'alex.morgan@apex.edu',
      password: 'study123',
      avatar: '👨‍🎓',
      academic_year: 'Year 2, Semester 1',
      course_program: 'B.Sc. Natural & Computer Sciences',
      institution: 'Apex University',
      daily_hours: 3.0,
      preferred_start: '18:00',
      preferred_end: '21:00',
      technique_preference: 'automatic',
      allow_ai_recommend: true
    }
  ];

  static isAuthenticated() {
    return !!this.getCurrentSession();
  }

  static getCurrentSession() {
    const raw = localStorage.getItem(this.SESSION_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  static setCurrentSession(user) {
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(user));
  }

  static clearSession() {
    localStorage.removeItem(this.SESSION_KEY);
  }

  static getUsers() {
    const raw = localStorage.getItem(this.USERS_KEY);
    if (!raw) {
      localStorage.setItem(this.USERS_KEY, JSON.stringify(this.DEFAULT_USERS));
      return [...this.DEFAULT_USERS];
    }
    try {
      const users = JSON.parse(raw);
      if (!Array.isArray(users) || users.length === 0) {
        localStorage.setItem(this.USERS_KEY, JSON.stringify(this.DEFAULT_USERS));
        return [...this.DEFAULT_USERS];
      }
      return users;
    } catch (e) {
      return [...this.DEFAULT_USERS];
    }
  }

  static registerUser({ name, email, password }) {
    const users = this.getUsers();
    const existing = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (existing) {
      return { success: false, message: 'An account with this email address already exists. Please log in.' };
    }

    const newUser = {
      id: 'user_' + Date.now(),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password,
      avatar: '👨‍🎓',
      academic_year: 'Year 1, Semester 1',
      course_program: 'Undergraduate Program',
      institution: 'Apex University',
      daily_hours: 3.0,
      preferred_start: '18:00',
      preferred_end: '21:00',
      technique_preference: 'automatic',
      allow_ai_recommend: true
    };

    users.push(newUser);
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));

    // Initialize user's isolated study data store
    const userSeed = this.getNewUserSeed(newUser);
    localStorage.setItem(`study_planner_store_${newUser.id}`, JSON.stringify(userSeed));

    // Set active session
    this.setCurrentSession(newUser);

    return { success: true, user: newUser };
  }

  static loginUser({ email, password }) {
    const users = this.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());

    if (!user) {
      return { success: false, message: 'No account found with this email. Please check your spelling or sign up.' };
    }

    if (user.password !== password) {
      return { success: false, message: 'Incorrect password. Please verify and try again.' };
    }

    this.setCurrentSession(user);
    return { success: true, user };
  }

  static logoutUser() {
    this.clearSession();
  }

  static async init() {
    // Ensure users table is initialized
    this.getUsers();
  }

  static async getBootstrapData() {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/bootstrap`);
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API request failed, falling back to local store", e);
      }
    }
    return this.getLocalStore();
  }

  static async submitQuiz(quizPayload) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/quizzes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(quizPayload)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API submit failed, using local store", e);
      }
    }

    // LocalStorage fallback handling
    const store = this.getLocalStore();
    const qid = Date.now();
    const newQuiz = {
      id: qid,
      title: quizPayload.title,
      course_id: quizPayload.course_id,
      difficulty: quizPayload.difficulty,
      total_questions: quizPayload.total_questions,
      score: quizPayload.score,
      percentage: Math.round((quizPayload.score / quizPayload.total_questions) * 100),
      completed_at: new Date().toISOString().replace('T', ' ').substring(0, 16),
      topic_breakdown: quizPayload.topic_breakdown,
      source: quizPayload.source || 'ai'
    };
    store.quizzes.unshift(newQuiz);

    // Update topic scores
    const weakTopics = [];
    const strongTopics = [];
    Object.keys(quizPayload.topic_breakdown).forEach(tName => {
      const perf = quizPayload.topic_breakdown[tName];
      const topicObj = store.topics.find(t => t.name.toLowerCase() === tName.toLowerCase() && t.course_id === quizPayload.course_id);
      if (topicObj) {
        const oldScore = topicObj.mastery_score;
        const newScore = Math.round(0.6 * perf.percentage + 0.4 * oldScore);
        topicObj.mastery_score = newScore;
        topicObj.tests_taken = (topicObj.tests_taken || 1) + 1;
        topicObj.status = newScore >= 80 ? 'mastered' : (newScore < 65 ? 'weak' : 'improving');

        store.topic_history.push({
          id: Date.now() + Math.random(),
          topic_id: topicObj.id,
          quiz_id: qid,
          percentage: perf.percentage,
          recorded_at: new Date().toISOString()
        });

        if (newScore < 65) weakTopics.push(tName);
        else strongTopics.push(tName);
      }
    });

    // Add adaptive notification
    store.notifications.unshift({
      id: Date.now(),
      title: `Quiz Evaluated: ${newQuiz.percentage}%`,
      message: `Topic performance analyzed. Weak areas flagged (${weakTopics.join(', ') || 'None'}). AI Timetable re-balanced.`,
      type: 'adaptive',
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 16),
      read: 0,
      link_view: 'planner'
    });

    this.saveLocalStore(store);
    return {
      success: true,
      quiz_id: qid,
      percentage: newQuiz.percentage,
      weak_topics: weakTopics,
      strong_topics: strongTopics
    };
  }

  static async saveTimetableSessions(sessions) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/timetable/save-all`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessions })
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API save failed", e);
      }
    }
    const store = this.getLocalStore();
    store.timetable = sessions;
    this.saveLocalStore(store);
    return { success: true };
  }

  static async updateProfile(profileData) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/profile`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(profileData)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API updateProfile failed", e);
      }
    }
    const store = this.getLocalStore();
    store.user = { ...store.user, ...profileData };
    this.saveLocalStore(store);

    // Also update active session and users list
    const session = this.getCurrentSession();
    if (session) {
      const updatedUser = { ...session, ...profileData };
      this.setCurrentSession(updatedUser);

      const users = this.getUsers().map(u => 
        (u.id === session.id || u.email.toLowerCase() === session.email.toLowerCase()) ? { ...u, ...profileData } : u
      );
      localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
    }

    return { success: true, user: store.user };
  }

  static async addAssignment(asg) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/assignments`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(asg)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API addAssignment failed", e);
      }
    }
    const store = this.getLocalStore();
    const newAsg = {
      id: Date.now(),
      status: 'pending',
      ...asg
    };
    store.assignments.unshift(newAsg);
    store.notifications.unshift({
      id: Date.now() + 1,
      title: `Reminder Set: ${asg.title}`,
      message: `Alert scheduled ${asg.reminder_setting || '24 hours before'} for due date ${asg.due_date}`,
      type: 'assignment',
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 16),
      read: 0,
      link_view: 'assignments'
    });
    this.saveLocalStore(store);
    return { success: true, id: newAsg.id };
  }

  static async updateAssignmentStatus(assignmentId, status) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/assignments/${assignmentId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status })
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API updateAssignmentStatus failed, using local store", e);
      }
    }

    const store = this.getLocalStore();
    if (!store.assignments) store.assignments = [];
    const target = store.assignments.find(a => String(a.id) === String(assignmentId));
    if (target) {
      target.status = status;
      this.saveLocalStore(store);
      return { success: true, assignment: target };
    }
    return { success: false, message: 'Assignment not found' };
  }

  static async deleteAssignment(assignmentId) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/assignments/${assignmentId}`, {
          method: 'DELETE'
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API deleteAssignment failed, using local store", e);
      }
    }

    const store = this.getLocalStore();
    if (store.assignments) {
      store.assignments = store.assignments.filter(a => String(a.id) !== String(assignmentId));
      this.saveLocalStore(store);
      return { success: true };
    }
    return { success: false };
  }

  static async addExam(exam) {
    if (this.isServerAvailable) {
      try {
        const res = await fetch(`${this.BASE_URL}/api/exams`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(exam)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn("API addExam failed", e);
      }
    }
    const store = this.getLocalStore();
    const newExam = {
      id: Date.now(),
      ...exam
    };
    store.exams.unshift(newExam);
    store.notifications.unshift({
      id: Date.now() + 1,
      title: `Exam Scheduled: ${exam.title}`,
      message: `Exam on ${exam.exam_date}. AI Timetable is ramping up revision priority.`,
      type: 'exam',
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 16),
      read: 0,
      link_view: 'planner'
    });
    this.saveLocalStore(store);
    return { success: true, id: newExam.id };
  }

  static async markNotificationsRead() {
    if (this.isServerAvailable) {
      try {
        await fetch(`${this.BASE_URL}/api/notifications/mark-read`, { method: 'POST' });
      } catch (e) {}
    }
    const store = this.getLocalStore();
    store.notifications.forEach(n => n.read = 1);
    this.saveLocalStore(store);
  }

  static async resetDemoData() {
    if (this.isServerAvailable) {
      try {
        await fetch(`${this.BASE_URL}/api/reset-demo`, { method: 'POST' });
      } catch (e) {}
    }
    localStorage.removeItem('study_planner_store');
    return await this.getBootstrapData();
  }

  // ==========================================
  // LocalStorage Fallback Storage Implementation
  // ==========================================
  static getStoreKeyForCurrentUser() {
    const session = this.getCurrentSession();
    if (!session) return 'study_planner_store';
    return `study_planner_store_${session.id || session.email}`;
  }

  static getLocalStore() {
    const session = this.getCurrentSession();
    const userStoreKey = this.getStoreKeyForCurrentUser();

    const raw = localStorage.getItem(userStoreKey);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch (e) {}
    }

    // Check if session is Alex Morgan, also look for legacy 'study_planner_store'
    if (session && (session.email === 'alex.morgan@apex.edu' || session.id === 'user_alex')) {
      const legacyRaw = localStorage.getItem('study_planner_store');
      if (legacyRaw) {
        try {
          const parsed = JSON.parse(legacyRaw);
          localStorage.setItem(userStoreKey, JSON.stringify(parsed));
          return parsed;
        } catch (e) {}
      }
      const defaults = this.getDefaultSeed();
      localStorage.setItem(userStoreKey, JSON.stringify(defaults));
      localStorage.setItem('study_planner_store', JSON.stringify(defaults));
      return defaults;
    }

    // For newly registered students
    if (session) {
      const userSeed = this.getNewUserSeed(session);
      localStorage.setItem(userStoreKey, JSON.stringify(userSeed));
      return userSeed;
    }

    // Fallback if not logged in
    const legacyRaw = localStorage.getItem('study_planner_store');
    if (legacyRaw) {
      try { return JSON.parse(legacyRaw); } catch (e) {}
    }
    const defaults = this.getDefaultSeed();
    return defaults;
  }

  static saveLocalStore(data) {
    const userStoreKey = this.getStoreKeyForCurrentUser();
    localStorage.setItem(userStoreKey, JSON.stringify(data));
    const session = this.getCurrentSession();
    if (!session || session.email === 'alex.morgan@apex.edu') {
      localStorage.setItem('study_planner_store', JSON.stringify(data));
    }
  }

  static getNewUserSeed(user) {
    const now = new Date();
    const fmtDate = (days) => {
      const d = new Date(now.getTime() + days * 86400000);
      return d.toISOString().split('T')[0];
    };

    return {
      user: {
        id: user.id || 2,
        name: user.name || 'New Student',
        email: user.email,
        avatar: '👨‍🎓',
        academic_year: user.academic_year || 'Year 1, Semester 1',
        course_program: user.course_program || 'Undergraduate Degree',
        institution: user.institution || 'Apex University',
        daily_hours: user.daily_hours || 3.0,
        preferred_start: user.preferred_start || '18:00',
        preferred_end: user.preferred_end || '21:00',
        technique_preference: user.technique_preference || 'automatic',
        allow_ai_recommend: user.allow_ai_recommend !== undefined ? user.allow_ai_recommend : true
      },
      courses: [
        {
          id: 1, name: 'Chemistry', code: 'CHEM101', color: '#8B5CF6', icon: 'flask',
          average_performance: 75.0, weak_topics_count: 0, upcoming_tests_count: 1,
          topics: [
            { id: 101, course_id: 1, name: 'Atomic Structure', mastery_score: 75.0, status: 'neutral', tests_taken: 0 },
            { id: 102, course_id: 1, name: 'Chemical Bonding', mastery_score: 75.0, status: 'neutral', tests_taken: 0 },
            { id: 103, course_id: 1, name: 'Thermodynamics', mastery_score: 75.0, status: 'neutral', tests_taken: 0 }
          ]
        },
        {
          id: 2, name: 'Physics', code: 'PHYS101', color: '#3B82F6', icon: 'atom',
          average_performance: 75.0, weak_topics_count: 0, upcoming_tests_count: 0,
          topics: [
            { id: 201, course_id: 2, name: 'Mechanics', mastery_score: 75.0, status: 'neutral', tests_taken: 0 },
            { id: 202, course_id: 2, name: 'Electromagnetism', mastery_score: 75.0, status: 'neutral', tests_taken: 0 }
          ]
        },
        {
          id: 3, name: 'Mathematics', code: 'MATH101', color: '#EC4899', icon: 'sigma',
          average_performance: 75.0, weak_topics_count: 0, upcoming_tests_count: 0,
          topics: [
            { id: 301, course_id: 3, name: 'Calculus', mastery_score: 75.0, status: 'neutral', tests_taken: 0 },
            { id: 302, course_id: 3, name: 'Linear Algebra', mastery_score: 75.0, status: 'neutral', tests_taken: 0 }
          ]
        }
      ],
      topics: [],
      assignments: [
        {
          id: 1001,
          title: 'Introduction & Course Syllabus Review',
          course_id: 1,
          description: 'Review unit topics and lab requirements.',
          due_date: `${fmtDate(4)} 17:00`,
          priority: 'Medium',
          status: 'pending',
          reminder_setting: '24 hours before',
          reminder_time: `${fmtDate(3)} 17:00`
        }
      ],
      exams: [
        {
          id: 2001,
          title: 'Introductory Diagnostic Assessment',
          course_id: 1,
          exam_date: fmtDate(7),
          priority: 'High',
          topics: ['Atomic Structure', 'Chemical Bonding']
        }
      ],
      quizzes: [],
      topic_history: [],
      session_history: [],
      timetable: [
        {
          id: 'sess_new_1',
          day_date: fmtDate(0),
          start_time: '6:00 PM',
          end_time: '6:50 PM',
          duration_mins: 50,
          course_id: 1,
          course_name: 'Chemistry',
          course_color: '#8B5CF6',
          topic_id: 101,
          topic_name: 'Atomic Structure',
          study_technique: 'Focused Study (50m)',
          technique_key: 'focused',
          session_goal: 'Review Bohr model and electron configuration principles.',
          priority: 'Medium',
          ai_rationale: 'Initial baseline study block to establish course foundations.',
          is_adaptive: 0,
          change_delta_mins: 0,
          change_reason: 'Initial baseline session: Welcome to Study Planner.',
          completed: 0,
          is_break: false
        },
        {
          id: 'break_new_1',
          day_date: fmtDate(0),
          start_time: '6:50 PM',
          end_time: '7:00 PM',
          duration_mins: 10,
          is_break: true,
          topic_name: '☕ Cognitive Reset & Hydration',
          break_duration_mins: 10,
          completed: 0
        },
        {
          id: 'sess_new_2',
          day_date: fmtDate(0),
          start_time: '7:00 PM',
          end_time: '7:50 PM',
          duration_mins: 50,
          course_id: 2,
          course_name: 'Physics',
          course_color: '#3B82F6',
          topic_id: 201,
          topic_name: 'Mechanics',
          study_technique: 'Focused Study (50m)',
          technique_key: 'focused',
          session_goal: 'Solve 5 kinematics and Newton equation problems.',
          priority: 'Medium',
          ai_rationale: 'Core practice block scheduled within your daily study hours.',
          is_adaptive: 0,
          change_delta_mins: 0,
          change_reason: 'Initial baseline session.',
          completed: 0,
          is_break: false
        },
        {
          id: 'break_new_2',
          day_date: fmtDate(0),
          start_time: '7:50 PM',
          end_time: '8:00 PM',
          duration_mins: 10,
          is_break: true,
          topic_name: '☕ Eye Relaxation & Stretch',
          break_duration_mins: 10,
          completed: 0
        },
        {
          id: 'sess_new_3',
          day_date: fmtDate(0),
          start_time: '8:00 PM',
          end_time: '8:50 PM',
          duration_mins: 50,
          course_id: 3,
          course_name: 'Mathematics',
          course_color: '#EC4899',
          topic_id: 301,
          topic_name: 'Calculus',
          study_technique: 'Focused Study (50m)',
          technique_key: 'focused',
          session_goal: 'Practice differentiation rules and derivative properties.',
          priority: 'Medium',
          ai_rationale: 'Quantitative analytical block before evening wind-down.',
          is_adaptive: 0,
          change_delta_mins: 0,
          change_reason: 'Initial baseline session.',
          completed: 0,
          is_break: false
        },
        {
          id: 'break_new_3',
          day_date: fmtDate(0),
          start_time: '8:50 PM',
          end_time: '9:00 PM',
          duration_mins: 10,
          is_break: true,
          topic_name: '☕ Wrap-up & Reflection',
          break_duration_mins: 10,
          completed: 0
        }
      ],
      notifications: [
        {
          id: 3001,
          title: 'Welcome to Study Planner!',
          message: `Hello ${user.name}! Your account is active. Take a mock test anytime to trigger adaptive timetable adjustments.`,
          type: 'insight',
          created_at: `${fmtDate(0)} 12:00`,
          read: 0,
          link_view: 'dashboard'
        }
      ]
    };
  }

  static getDefaultSeed() {
    const now = new Date();
    const fmtDate = (days) => {
      const d = new Date(now.getTime() + days * 86400000);
      return d.toISOString().split('T')[0];
    };

    return {
      user: {
        id: 1,
        name: 'Alex Morgan',
        email: 'alex.morgan@apex.edu',
        avatar: '👨‍🎓',
        academic_year: 'Year 2, Semester 1',
        course_program: 'B.Sc. Natural & Computer Sciences',
        institution: 'Apex University',
        daily_hours: 3.0,
        preferred_start: '18:00',
        preferred_end: '21:00',
        technique_preference: 'automatic',
        allow_ai_recommend: true
      },
      courses: [
        {
          id: 1, name: 'Chemistry', code: 'CHEM201', color: '#8B5CF6', icon: 'flask',
          average_performance: 74.2, weak_topics_count: 2, upcoming_tests_count: 1,
          topics: [
            { id: 101, course_id: 1, name: 'Atomic Structure', mastery_score: 90.0, status: 'mastered', tests_taken: 3 },
            { id: 102, course_id: 1, name: 'Chemical Bonding', mastery_score: 72.0, status: 'improving', tests_taken: 3 },
            { id: 103, course_id: 1, name: 'Thermodynamics', mastery_score: 55.0, status: 'weak', tests_taken: 2 },
            { id: 104, course_id: 1, name: 'Organic Chemistry', mastery_score: 80.0, status: 'mastered', tests_taken: 2 }
          ]
        },
        {
          id: 2, name: 'Physics', code: 'PHYS201', color: '#3B82F6', icon: 'atom',
          average_performance: 71.8, weak_topics_count: 1, upcoming_tests_count: 1,
          topics: [
            { id: 201, course_id: 2, name: 'Mechanics', mastery_score: 75.0, status: 'neutral', tests_taken: 2 },
            { id: 202, course_id: 2, name: 'Electromagnetism', mastery_score: 60.0, status: 'weak', tests_taken: 2 },
            { id: 203, course_id: 2, name: 'Optics', mastery_score: 82.0, status: 'mastered', tests_taken: 2 },
            { id: 204, course_id: 2, name: 'Waves & Sound', mastery_score: 70.0, status: 'neutral', tests_taken: 1 }
          ]
        },
        {
          id: 3, name: 'Mathematics', code: 'MATH201', color: '#EC4899', icon: 'sigma',
          average_performance: 82.0, weak_topics_count: 1, upcoming_tests_count: 1,
          topics: [
            { id: 301, course_id: 3, name: 'Calculus', mastery_score: 88.0, status: 'mastered', tests_taken: 3 },
            { id: 302, course_id: 3, name: 'Linear Algebra', mastery_score: 85.0, status: 'mastered', tests_taken: 2 },
            { id: 303, course_id: 3, name: 'Probability & Statistics', mastery_score: 65.0, status: 'weak', tests_taken: 1 },
            { id: 304, course_id: 3, name: 'Trigonometry', mastery_score: 90.0, status: 'mastered', tests_taken: 3 }
          ]
        },
        {
          id: 4, name: 'Computer Science', code: 'CS201', color: '#10B981', icon: 'code',
          average_performance: 79.0, weak_topics_count: 1, upcoming_tests_count: 0,
          topics: [
            { id: 401, course_id: 4, name: 'Data Structures', mastery_score: 82.0, status: 'mastered', tests_taken: 2 },
            { id: 402, course_id: 4, name: 'Algorithms', mastery_score: 68.0, status: 'weak', tests_taken: 2 },
            { id: 403, course_id: 4, name: 'Database Systems', mastery_score: 92.0, status: 'mastered', tests_taken: 3 },
            { id: 404, course_id: 4, name: 'Operating Systems', mastery_score: 74.0, status: 'neutral', tests_taken: 1 }
          ]
        }
      ],
      topics: [],
      assignments: [
        {
          id: 1,
          title: 'Unit 2 Record: Mechanics Lab',
          course_id: 2,
          description: 'Rotational inertia and error analysis report.',
          due_date: `${fmtDate(3)} 17:00`,
          priority: 'High',
          status: 'pending',
          reminder_setting: '24 hours before',
          reminder_time: `${fmtDate(2)} 17:00`
        },
        {
          id: 2,
          title: 'Thermodynamics Problem Set',
          course_id: 1,
          description: 'Enthalpy and Gibbs free energy numericals from Chapter 4.',
          due_date: `${fmtDate(5)} 23:59`,
          priority: 'Medium',
          status: 'pending',
          reminder_setting: '12 hours before',
          reminder_time: `${fmtDate(5)} 11:59`
        },
        {
          id: 3,
          title: 'Binary Search Tree Implementation',
          course_id: 4,
          description: 'Implement AVL self-balancing tree insert and delete routines in Python/C++.',
          due_date: `${fmtDate(8)} 18:00`,
          priority: 'Medium',
          status: 'pending',
          reminder_setting: '2 days before',
          reminder_time: `${fmtDate(6)} 18:00`
        }
      ],
      exams: [
        {
          id: 1,
          title: 'Chemistry Internal Assessment',
          course_id: 1,
          exam_date: fmtDate(6),
          priority: 'High',
          topics: ['Atomic Structure', 'Chemical Bonding', 'Thermodynamics', 'Organic Chemistry']
        },
        {
          id: 2,
          title: 'Mathematics Midterm',
          course_id: 3,
          exam_date: fmtDate(12),
          priority: 'High',
          topics: ['Calculus', 'Linear Algebra', 'Trigonometry']
        },
        {
          id: 3,
          title: 'Physics Unit Test',
          course_id: 2,
          exam_date: fmtDate(18),
          priority: 'Medium',
          topics: ['Mechanics', 'Electromagnetism']
        }
      ],
      quizzes: [
        {
          id: 1,
          title: 'Chemistry Mock Test #3',
          course_id: 1,
          difficulty: 'Medium',
          total_questions: 20,
          score: 14,
          percentage: 70.0,
          completed_at: `${fmtDate(-2)} 18:45`,
          topic_breakdown: {
            'Atomic Structure': { score: 9, total: 10, percentage: 90.0 },
            'Chemical Bonding': { score: 7, total: 10, percentage: 70.0 },
            'Thermodynamics': { score: 5, total: 9, percentage: 55.5 },
            'Organic Chemistry': { score: 8, total: 10, percentage: 80.0 }
          },
          source: 'ai'
        }
      ],
      topic_history: [
        { id: 1, topic_id: 102, quiz_id: 1, percentage: 45.0, recorded_at: '2026-11-01 19:30:00' },
        { id: 2, topic_id: 102, quiz_id: 2, percentage: 58.0, recorded_at: '2026-11-06 20:00:00' },
        { id: 3, topic_id: 102, quiz_id: 3, percentage: 72.0, recorded_at: '2026-11-12 18:45:00' },
        { id: 4, topic_id: 103, quiz_id: 1, percentage: 50.0, recorded_at: '2026-11-02 20:15:00' },
        { id: 5, topic_id: 103, quiz_id: 3, percentage: 55.0, recorded_at: '2026-11-12 18:45:00' }
      ],
      session_history: [
        {
          id: 'hist_1',
          session_id: 'sess_prev_1',
          course_id: 1,
          topic_id: 101,
          topic_name: 'Atomic Structure',
          technique: 'Focused Study (50m)',
          status: 'Completed',
          completed_at: `${fmtDate(-1)} 19:00`
        },
        {
          id: 'hist_2',
          session_id: 'sess_prev_2',
          course_id: 1,
          topic_id: 103,
          topic_name: 'Thermodynamics',
          technique: 'Pomodoro (25m)',
          status: 'Partially Completed',
          completed_at: `${fmtDate(-1)} 20:00`
        }
      ],
      timetable: [
        {
          id: 'sess_1',
          day_date: fmtDate(0),
          start_time: '6:00 PM',
          end_time: '6:50 PM',
          duration_mins: 50,
          course_id: 3,
          course_name: 'Mathematics',
          course_color: '#EC4899',
          topic_id: 304,
          topic_name: 'Trigonometry',
          study_technique: 'Focused Study (50m)',
          technique_key: 'focused',
          session_goal: 'Solve 6 trigonometry transformation problems and verify unit circle identities.',
          priority: 'Medium',
          ai_rationale: 'Solid baseline mastery (90%); targeted focused session to maintain speed for upcoming exam in 12 days.',
          is_adaptive: 1,
          change_delta_mins: -10,
          change_reason: 'Reduced because performance is strong (90%) and exam is 12 days away.',
          completed: 0,
          is_break: false
        },
        {
          id: 'break_1',
          day_date: fmtDate(0),
          start_time: '6:50 PM',
          end_time: '7:00 PM',
          duration_mins: 10,
          is_break: true,
          topic_name: '☕ Cognitive Reset & Hydration',
          break_duration_mins: 10,
          completed: 0
        },
        {
          id: 'sess_2',
          day_date: fmtDate(0),
          start_time: '7:00 PM',
          end_time: '7:50 PM',
          duration_mins: 50,
          course_id: 1,
          course_name: 'Chemistry',
          course_color: '#8B5CF6',
          topic_id: 102,
          topic_name: 'Chemical Bonding',
          study_technique: 'Focused Study (50m)',
          technique_key: 'focused',
          session_goal: 'Understand VSEPR molecular geometry and solve 5 practice questions.',
          priority: 'High',
          ai_rationale: 'Chemical Bonding has an exam in 6 days and past quiz score was 58% (now improving to 72%). Additional focused study allocated.',
          is_adaptive: 1,
          change_delta_mins: 20,
          change_reason: 'Increased: Exam is in 6 days and past quiz score was 58% (now improving to 72%).',
          completed: 0,
          is_break: false
        },
        {
          id: 'break_2',
          day_date: fmtDate(0),
          start_time: '7:50 PM',
          end_time: '8:00 PM',
          duration_mins: 10,
          is_break: true,
          topic_name: '☕ Refresh & Stretch',
          break_duration_mins: 10,
          completed: 0
        },
        {
          id: 'sess_3',
          day_date: fmtDate(0),
          start_time: '8:00 PM',
          end_time: '8:40 PM',
          duration_mins: 40,
          course_id: 1,
          course_name: 'Chemistry',
          course_color: '#8B5CF6',
          topic_id: 103,
          topic_name: 'Thermodynamics',
          study_technique: 'Focused Study (40m)',
          technique_key: 'focused',
          session_goal: 'Master enthalpy calculations and solve 4 Gibbs free energy problems.',
          priority: 'High',
          ai_rationale: 'Lowest recent quiz score (55%) with upcoming assignment due in 5 days.',
          is_adaptive: 1,
          change_delta_mins: 15,
          change_reason: 'Increased: Lowest topic score (55%) with upcoming assignment due in 5 days.',
          completed: 0,
          is_break: false
        },
        {
          id: 'break_3',
          day_date: fmtDate(0),
          start_time: '8:40 PM',
          end_time: '8:50 PM',
          duration_mins: 10,
          is_break: true,
          topic_name: '☕ Short Rest Break',
          break_duration_mins: 10,
          completed: 0
        },
        {
          id: 'sess_4',
          day_date: fmtDate(0),
          start_time: '8:50 PM',
          end_time: '9:00 PM',
          duration_mins: 10,
          course_id: 2,
          course_name: 'Physics',
          course_color: '#3B82F6',
          topic_id: 201,
          topic_name: 'Mechanics',
          study_technique: 'Quick Revision (10m)',
          technique_key: 'revision',
          session_goal: 'Quickly review rotational inertia equations for upcoming Unit 2 lab record.',
          priority: 'Medium',
          ai_rationale: 'Rapid recap session fitted in remaining window before 9:00 PM deadline.',
          is_adaptive: 1,
          change_delta_mins: 0,
          change_reason: 'Adjusted for Physics assignment due in 3 days; Mechanics lab review.',
          completed: 0,
          is_break: false
        }
      ],
      notifications: [
        {
          id: 1,
          title: 'Timetable Adapted by AI',
          message: 'Your study timetable was updated: Chemistry (+30m on Chemical Bonding & Thermodynamics) prioritizing your approaching exam in 6 days.',
          type: 'adaptive',
          created_at: `${fmtDate(0)} 14:30`,
          read: 0,
          link_view: 'planner'
        },
        {
          id: 2,
          title: 'Assignment Reminder',
          message: 'Physics "Unit 2 Record" is due in 3 days. Reminder alert scheduled 24 hours prior.',
          type: 'assignment',
          created_at: `${fmtDate(0)} 10:15`,
          read: 0,
          link_view: 'assignments'
        },
        {
          id: 3,
          title: 'AI Performance Milestone',
          message: 'You have improved by +14% in Chemical Bonding across your last two mock tests! Keep up the momentum.',
          type: 'insight',
          created_at: `${fmtDate(-1)} 19:00`,
          read: 1,
          link_view: 'progress'
        }
      ]
    };
  }
}

// Export for browser
window.ApiService = ApiService;
