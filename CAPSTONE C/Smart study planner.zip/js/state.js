/**
 * Study Planner - Reactive Global State Manager & Event Bus
 */

class AppState {
  constructor() {
    this.data = {
      user: {},
      courses: [],
      topics: [],
      assignments: [],
      exams: [],
      quizzes: [],
      topic_history: [],
      timetable: [],
      initialTimetable: [],
      timetableMode: 'adaptive', // 'adaptive' | 'initial'
      notifications: [],
      activeView: 'dashboard',
      lastAdaptedInsight: null
    };
    this.listeners = {};
  }

  on(event, callback) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (!this.listeners[event]) return;
    this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
  }

  emit(event, payload) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(cb => {
        try {
          cb(payload, this.data);
        } catch (e) {
          console.error(`Error in event listener for ${event}:`, e);
        }
      });
    }
  }

  async loadBootstrap() {
    const raw = await ApiService.getBootstrapData();
    this.data.user = raw.user || {};
    this.data.courses = raw.courses || [];
    this.data.topics = raw.topics || [];
    this.data.assignments = raw.assignments || [];
    this.data.exams = raw.exams || [];
    this.data.quizzes = raw.quizzes || [];
    this.data.topic_history = raw.topic_history || [];
    this.data.session_history = raw.session_history || [];
    this.data.timetable = raw.timetable || [];
    this.data.notifications = raw.notifications || [];

    // Ensure baseline initial timetable exists
    if (!this.data.initialTimetable || this.data.initialTimetable.length === 0) {
      this.data.initialTimetable = AdaptiveEngine.generateInitialTimetable(this.data.courses, this.data.user);
    }

    // Trigger initial state broadcast
    this.emit('state:loaded', this.data);
    this.emit('timetable:updated', this.data.timetable);
    this.emit('notifications:updated', this.data.notifications);
  }

  setView(viewName) {
    if (this.data.activeView === viewName) return;
    this.data.activeView = viewName;
    this.emit('view:changed', viewName);
  }

  async adaptTimetable(explicitReason = "") {
    // Run AI Adaptive Calculation with Break System & Session History
    const result = AdaptiveEngine.generateAdaptiveTimetable({
      courses: this.data.courses,
      exams: this.data.exams,
      assignments: this.data.assignments,
      topicHistory: this.data.topic_history,
      sessionHistory: this.data.session_history || [],
      userProfile: this.data.user
    });

    this.data.timetable = result.sessions;
    this.data.lastAdaptedInsight = result.insights[0] || null;
    this.data.timetableMode = 'adaptive';

    // Persist to server / storage
    await ApiService.saveTimetableSessions(result.sessions);

    // Broadcast update
    this.emit('timetable:updated', {
      sessions: this.data.timetable,
      diffs: result.changeDiffs,
      insights: result.insights,
      reason: explicitReason
    });

    return result;
  }

  async recordSessionCompletion(sessionId, completionStatus) {
    const sess = this.data.timetable.find(s => s.id === sessionId);
    if (sess) {
      sess.completed = completionStatus === 'Not Completed' ? 0 : 1;
      sess.completion_status = completionStatus;
    }

    if (!this.data.session_history) this.data.session_history = [];
    this.data.session_history.push({
      session_id: sessionId,
      topic_id: sess ? sess.topic_id : null,
      topic_name: sess ? sess.topic_name : null,
      course_id: sess ? sess.course_id : null,
      completion_status: completionStatus,
      recorded_at: new Date().toISOString()
    });

    await ApiService.saveTimetableSessions(this.data.timetable);
    const store = ApiService.getLocalStore();
    store.session_history = this.data.session_history;
    store.timetable = this.data.timetable;
    ApiService.saveLocalStore(store);

    this.emit('timetable:updated', { sessions: this.data.timetable });
  }

  async submitQuizResult(quizResult) {
    const apiRes = await ApiService.submitQuiz(quizResult);

    // Refresh state from updated storage
    await this.loadBootstrap();

    // Trigger automatic adaptive timetable update!
    const adaptRes = await this.adaptTimetable("Updated automatically following mock quiz evaluation.");

    this.emit('quiz:submitted', {
      quizResult,
      apiRes,
      adaptRes
    });

    return { apiRes, adaptRes };
  }

  async toggleSessionCompleted(sessionId) {
    const sess = this.data.timetable.find(s => s.id === sessionId);
    if (sess) {
      sess.completed = sess.completed ? 0 : 1;
      await ApiService.saveTimetableSessions(this.data.timetable);
      this.emit('timetable:updated', { sessions: this.data.timetable });
    }
  }

  async toggleAssignmentCompleted(assignmentId) {
    if (!this.data.assignments) this.data.assignments = [];
    const asg = this.data.assignments.find(a => String(a.id) === String(assignmentId));
    if (asg) {
      const nextStatus = asg.status === 'completed' ? 'pending' : 'completed';
      asg.status = nextStatus;

      // 1. Sync through ApiService (server and localStorage)
      await ApiService.updateAssignmentStatus(assignmentId, nextStatus);

      // 2. Also ensure local store has latest assignments
      const store = ApiService.getLocalStore();
      if (!store.assignments) store.assignments = [];
      const stored = store.assignments.find(a => String(a.id) === String(assignmentId));
      if (stored) {
        stored.status = nextStatus;
      } else {
        store.assignments = this.data.assignments;
      }
      ApiService.saveLocalStore(store);

      // 3. Recalculate adaptive timetable since assignment deadline urgency has changed
      await this.adaptTimetable(`Assignment "${asg.title}" marked as ${nextStatus}`);

      // 4. Emit event so subscribers re-render views & update badges
      this.emit('assignments:updated', {
        assignmentId,
        status: nextStatus,
        assignments: this.data.assignments
      });

      if (window.App && typeof window.App.showToast === 'function') {
        window.App.showToast(nextStatus === 'completed' ? `✓ "${asg.title}" marked complete!` : `"${asg.title}" marked as pending.`, 'success');
      }

      return asg;
    } else {
      console.warn(`Assignment ID ${assignmentId} not found in state.`);
      return null;
    }
  }

  async markAllNotificationsRead() {
    await ApiService.markNotificationsRead();
    this.data.notifications.forEach(n => n.read = 1);
    this.emit('notifications:updated', this.data.notifications);
  }

  getUnreadNotificationsCount() {
    return this.data.notifications.filter(n => !n.read).length;
  }
}

// Global instance
window.state = new AppState();
