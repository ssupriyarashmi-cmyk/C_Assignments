/**
 * Study Planner - Main Application Controller
 * Manages view routing, modals, notifications drawer, and global event coordination.
 */

class App {
  static currentView = 'dashboard';
  static isNewUserSignup = false;

  static init() {
    console.log("Initializing AI-Powered Adaptive Study Planner...");

    // Setup Navigation Listeners
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const view = item.dataset.view;
        if (view) {
          App.navigateTo(view);
          // Close mobile menu if open
          document.querySelector('.sidebar').classList.remove('mobile-open');
        }
      });
    });

    // Mobile Hamburger Toggle
    const menuBtn = document.getElementById('mobile_menu_btn');
    if (menuBtn) {
      menuBtn.addEventListener('click', () => {
        document.querySelector('.sidebar').classList.toggle('mobile-open');
      });
    }

    // Notification Drawer Toggle
    const notifBtn = document.getElementById('notif_bell_btn');
    const notifDrawer = document.getElementById('notif_drawer');
    if (notifBtn && notifDrawer) {
      notifBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        notifDrawer.classList.toggle('active');
        if (notifDrawer.classList.contains('active')) {
          App.renderNotifications();
        }
      });

      document.addEventListener('click', (e) => {
        if (!notifDrawer.contains(e.target) && !notifBtn.contains(e.target)) {
          notifDrawer.classList.remove('active');
        }
      });
    }

    // Reactive State Subscriptions
    window.state.on('state:loaded', () => {
      App.updateHeaderUser();
      App.updateBadges();
      App.renderCurrentView();
    });

    window.state.on('view:changed', (view) => {
      App.navigateTo(view, false);
    });

    window.state.on('timetable:updated', () => {
      App.updateBadges();
      if (App.currentView === 'dashboard' || App.currentView === 'planner') {
        App.renderCurrentView();
      }
    });

    window.state.on('notifications:updated', () => {
      App.updateBadges();
      App.renderNotifications();
    });

    window.state.on('assignments:updated', () => {
      App.updateBadges();
      if (App.currentView === 'assignments' || App.currentView === 'dashboard') {
        App.renderCurrentView();
      }
    });

    // Check Authentication & Initialize
    ApiService.init().then(async () => {
      if (ApiService.isAuthenticated()) {
        await window.state.loadBootstrap();
        const hash = window.location.hash.replace('#', '');
        const targetView = (hash && hash !== 'login' && hash !== 'signup') ? hash : 'dashboard';
        App.navigateTo(targetView);
      } else {
        const hash = window.location.hash.replace('#', '');
        if (hash === 'signup') {
          App.navigateTo('signup');
        } else {
          App.navigateTo('login');
        }
      }
    });
  }

  static logout() {
    ApiService.logoutUser();
    App.isNewUserSignup = false;
    App.showToast("You have been logged out.", "info");
    App.navigateTo('login');
  }

  static navigateTo(viewName, updateState = true) {
    // Route Protection (Section 5)
    const isAuth = ApiService.isAuthenticated();

    if (!isAuth) {
      if (viewName !== 'login' && viewName !== 'signup') {
        viewName = 'login';
      }
    } else {
      if (viewName === 'login' || viewName === 'signup') {
        viewName = 'dashboard';
      }
    }

    App.currentView = viewName;
    if (updateState) window.state.data.activeView = viewName;

    const appRoot = document.getElementById('app_root') || document.querySelector('.app-container');
    const isAuthView = (viewName === 'login' || viewName === 'signup');

    if (appRoot) {
      appRoot.classList.toggle('auth-mode', isAuthView);
    }

    if (!isAuthView) {
      if (window.location.hash !== '#' + viewName) {
        try {
          window.location.hash = viewName;
        } catch (e) {}
      }

      // Update active nav links
      document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.view === viewName);
      });

      // Update Header Titles
      const titles = {
        dashboard: { title: 'Academic Overview', sub: "AI-Powered Adaptive Learning & Timetable System" },
        courses: { title: 'Courses & Topics', sub: 'Topic-level mastery directory' },
        planner: { title: 'Study Planner & Timetable', sub: 'Adaptive schedule updated by your quiz performance' },
        assignments: { title: 'Coursework & Assignments', sub: 'Deadlines with automated pre-submission alerts' },
        exams: { title: 'Upcoming Tests & Exams', sub: 'Targeted countdowns driving adaptive timetable weights' },
        quiz: { title: 'Mock Tests & Diagnostics', sub: 'Topic-level quizzes feeding the adaptation feedback loop' },
        progress: { title: 'Progress & Retention Analytics', sub: 'Multi-quiz mastery trajectories over time' },
        profile: { title: 'Student Profile & Study Hours', sub: 'Define available daily study time constraints' },
        settings: { title: 'Preferences & Settings', sub: 'Notification thresholds & engine parameters' }
      };

      const header = titles[viewName] || { title: 'Study Planner', sub: '' };
      const titleEl = document.getElementById('header_page_title');
      const subEl = document.getElementById('header_page_sub');
      if (titleEl) titleEl.textContent = header.title;
      if (subEl) subEl.textContent = header.sub;
    }

    App.renderCurrentView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  static renderCurrentView() {
    const container = document.getElementById('view_container');
    if (!container) return;

    switch (App.currentView) {
      case 'login':
        AuthComponent.renderLogin(container);
        break;
      case 'signup':
        AuthComponent.renderSignup(container);
        break;
      case 'dashboard':
        DashboardComponent.render(container);
        break;
      case 'courses':
        CoursesComponent.render(container);
        break;
      case 'planner':
        PlannerComponent.render(container);
        break;
      case 'assignments':
        AssignmentsComponent.render(container);
        break;
      case 'exams':
        ExamsComponent.render(container);
        break;
      case 'quiz':
        QuizComponent.render(container);
        break;
      case 'progress':
        ProgressComponent.render(container);
        break;
      case 'profile':
        ProfileComponent.render(container);
        break;
      case 'settings':
        SettingsComponent.render(container);
        break;
      default:
        DashboardComponent.render(container);
    }
  }

  static updateHeaderUser() {
    const user = window.state.data.user || {};
    const avatarEl = document.getElementById('user_avatar_box');
    const nameEl = document.getElementById('user_name_box');
    const roleEl = document.getElementById('user_role_box');
    const timeEl = document.getElementById('header_study_time');

    if (avatarEl) avatarEl.textContent = user.avatar || '👨‍🎓';
    if (nameEl) nameEl.textContent = user.name || 'Alex Morgan';
    if (roleEl) roleEl.textContent = user.academic_year || 'Year 2';
    if (timeEl) timeEl.textContent = `${user.daily_hours || 3} hrs/day (${user.preferred_start || '18:00'}–${user.preferred_end || '21:00'})`;
  }

  static updateBadges() {
    const data = window.state.data;
    const unread = window.state.getUnreadNotificationsCount();
    const notifDot = document.getElementById('notif_dot');
    if (notifDot) notifDot.style.display = unread > 0 ? 'block' : 'none';

    // Pending assignments count badge in sidebar
    const pendingAsgs = (data.assignments || []).filter(a => a.status !== 'completed').length;
    const asgBadge = document.getElementById('sidebar_asg_badge');
    if (asgBadge) asgBadge.textContent = pendingAsgs;

    // Upcoming exams count badge in sidebar
    const examsCount = (data.exams || []).length;
    const examBadge = document.getElementById('sidebar_exam_badge');
    if (examBadge) examBadge.textContent = examsCount;
  }

  static renderNotifications() {
    const notifListEl = document.getElementById('notif_list_content');
    if (!notifListEl) return;

    const notifs = window.state.data.notifications || [];
    if (notifs.length === 0) {
      notifListEl.innerHTML = `<div style="padding:1.5rem;text-align:center;color:var(--text-muted);font-size:0.85rem;">No notifications right now.</div>`;
      return;
    }

    notifListEl.innerHTML = notifs.map(n => {
      const unreadClass = !n.read ? 'unread' : '';
      let icon = '🔔';
      let iconClass = 'notif-icon-insight';
      if (n.type === 'adaptive') { icon = '🤖'; iconClass = 'notif-icon-adaptive'; }
      else if (n.type === 'assignment') { icon = '📌'; iconClass = 'notif-icon-assignment'; }
      else if (n.type === 'exam') { icon = '📝'; iconClass = 'notif-icon-exam'; }

      return `
        <div class="notif-item ${unreadClass}" onclick="App.handleNotifClick('${n.link_view || 'dashboard'}')">
          <div class="notif-icon-box ${iconClass}">${icon}</div>
          <div class="notif-content">
            <div class="notif-title">${n.title}</div>
            <div class="notif-msg">${n.message}</div>
            <div class="notif-time">${n.created_at || 'Just now'}</div>
          </div>
        </div>
      `;
    }).join('');
  }

  static handleNotifClick(view) {
    document.getElementById('notif_drawer').classList.remove('active');
    App.navigateTo(view);
  }

  // ==========================================
  // "WHY DID MY TIMETABLE CHANGE?" MODAL (Section 13, 14, 24)
  // ==========================================
  static openWhyTimetableModal() {
    App.showModal({
      title: '🔍 Why did my timetable change?',
      body: `
        <div style="display:flex;flex-direction:column;gap:1.25rem;">
          <div style="background:#faf5ff;border:1px solid #e9d5ff;padding:1rem 1.25rem;border-radius:var(--radius-md);">
            <div style="font-weight:700;color:#581c87;font-size:0.95rem;margin-bottom:0.25rem;">
              Transparent AI Decision Engine
            </div>
            <p style="font-size:0.82rem;color:var(--text-main);line-height:1.45;">
              The system does not arbitrarily alter your timetable. Every minute is mathematically calculated from your
              <strong>topic performance, upcoming exams, assignment deadlines, and historical trends</strong>.
            </p>
          </div>

          <!-- Specific Explanations for Current Adjustments -->
          <div>
            <h4 style="font-size:0.9rem;font-weight:700;margin-bottom:0.6rem;color:var(--text-main);">Current Adjustments Breakdown:</h4>
            
            <!-- Chemistry Increase -->
            <div style="background:var(--bg-subtle);border-left:4px solid #8b5cf6;padding:0.75rem 1rem;border-radius:var(--radius-sm);margin-bottom:0.65rem;">
              <div style="font-weight:700;font-size:0.88rem;color:#6d28d9;display:flex;justify-content:space-between;">
                <span>Chemistry: Chemical Bonding & Thermodynamics</span>
                <span class="badge diff-plus">+30 min total</span>
              </div>
              <p style="font-size:0.8rem;color:var(--text-muted);margin-top:0.25rem;">
                <strong>Reason:</strong> Your Chemistry Internal Assessment is approaching in <strong>6 days</strong>. Past mock quiz scores revealed weak retention in <strong>Chemical Bonding (45% initial)</strong> and <strong>Thermodynamics (55%)</strong>. Allocating +30 min ensures targeted concept recovery before exam day.
              </p>
            </div>

            <!-- Mathematics Reduction -->
            <div style="background:var(--bg-subtle);border-left:4px solid #ec4899;padding:0.75rem 1rem;border-radius:var(--radius-sm);margin-bottom:0.65rem;">
              <div style="font-weight:700;font-size:0.88rem;color:#be185d;display:flex;justify-content:space-between;">
                <span>Mathematics: Trigonometry & Calculus</span>
                <span class="badge diff-minus">-15 min</span>
              </div>
              <p style="font-size:0.8rem;color:var(--text-muted);margin-top:0.25rem;">
                <strong>Reason:</strong> Your recent test score is <strong>90% (mastered)</strong> and your Math Midterm is <strong>12 days away</strong>. The AI temporarily reduces this slot by 15 min to give urgent priority to Chemistry while maintaining steady recall.
              </p>
            </div>

            <!-- Physics Allocation -->
            <div style="background:var(--bg-subtle);border-left:4px solid #3b82f6;padding:0.75rem 1rem;border-radius:var(--radius-sm);">
              <div style="font-weight:700;font-size:0.88rem;color:#1d4ed8;display:flex;justify-content:space-between;">
                <span>Physics: Mechanics Lab Review</span>
                <span class="badge" style="background:#eff6ff;color:#1d4ed8;">Balanced (45 min)</span>
              </div>
              <p style="font-size:0.8rem;color:var(--text-muted);margin-top:0.25rem;">
                <strong>Reason:</strong> "Unit 2 Record: Mechanics Lab" assignment submission deadline is in <strong>3 days</strong>.
              </p>
            </div>
          </div>

          <!-- Section 14 Checklist of Factors -->
          <div style="background:white;border:1px solid var(--border);padding:1rem;border-radius:var(--radius-md);">
            <div style="font-size:0.8rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;margin-bottom:0.5rem;">
              The 7 Factors Governing Your Schedule:
            </div>
            <ul style="font-size:0.78rem;color:var(--text-muted);line-height:1.6;padding-left:1.25rem;">
              <li><strong>1. Quiz Performance:</strong> Latest topic scores.</li>
              <li><strong>2. Topic-Level Weakness:</strong> Direct prioritization of struggling concepts.</li>
              <li><strong>3. Previous Performance Trend:</strong> Identifies if you are improving or repeatedly stuck.</li>
              <li><strong>4. Exam Proximity:</strong> Exponential ramp-up as exam day approaches.</li>
              <li><strong>5. Assignment Deadlines:</strong> Coursework submissions due within 72 hours.</li>
              <li><strong>6. Test Importance:</strong> High priority exams receive stronger weight.</li>
              <li><strong>7. Available Daily Study Hours:</strong> Strict hard cap matching your entered study time.</li>
            </ul>
          </div>
        </div>
      `,
      confirmText: 'Understood'
    });
  }

  // ==========================================
  // MODAL MANAGER
  // ==========================================
  static showModal({ title, body, confirmText = 'Save', onConfirm = null }) {
    const overlay = document.getElementById('global_modal_overlay');
    const titleEl = document.getElementById('modal_title');
    const bodyEl = document.getElementById('modal_body');
    const confirmBtn = document.getElementById('modal_confirm_btn');

    titleEl.textContent = title;
    bodyEl.innerHTML = body;
    confirmBtn.textContent = confirmText;

    confirmBtn.onclick = async () => {
      if (onConfirm) {
        await onConfirm();
      }
      App.closeModal();
    };

    overlay.classList.add('active');
  }

  static closeModal() {
    const overlay = document.getElementById('global_modal_overlay');
    if (overlay) overlay.classList.remove('active');
  }

  // ==========================================
  // TOAST MANAGER
  // ==========================================
  static showToast(message, type = 'info') {
    const container = document.getElementById('toast_container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    else if (type === 'error') icon = '❌';

    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  static startQuizForCourse(courseName, topics = []) {
    App.navigateTo('quiz');
    setTimeout(() => {
      const courseSelect = document.getElementById('gen_course');
      if (courseSelect) {
        courseSelect.value = courseName;
        QuizComponent.updateTopicCheckboxes(courseName);
      }
    }, 100);
  }
}

// Global Export
window.App = App;

// Bootstrap on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
