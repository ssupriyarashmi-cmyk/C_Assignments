/**
 * Study Planner - Pure Interactive SVG Chart Engine
 * Fully self-contained with zero external dependencies.
 */

class SVGCharts {
  /**
   * Renders a smooth multi-point trend line chart
   * @param {HTMLElement|string} target - Container element or ID
   * @param {Array} points - Array of { label: "Test 1", value: 45, date: "Nov 1" }
   * @param {Object} options - Custom title, colors, dimensions
   */
  static renderTrendChart(target, points = [], options = {}) {
    const el = typeof target === 'string' ? document.getElementById(target) : target;
    if (!el) return;

    if (!points || points.length === 0) {
      el.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--text-muted);font-size:0.88rem;">
          No quiz history available yet. Take a mock test to track your trend!
        </div>
      `;
      return;
    }

    const width = options.width || el.clientWidth || 540;
    const height = options.height || 240;
    const padLeft = 45;
    const padRight = 30;
    const padTop = 25;
    const padBottom = 40;

    const chartW = width - padLeft - padRight;
    const chartH = height - padTop - padBottom;

    const lineColor = options.lineColor || '#8b5cf6';
    const gradientStart = options.gradientStart || 'rgba(139, 92, 246, 0.35)';
    const gradientEnd = options.gradientEnd || 'rgba(139, 92, 246, 0.0)';

    // Compute coordinate mapping
    const minVal = 0;
    const maxVal = 100;

    const getX = (index) => {
      if (points.length === 1) return padLeft + chartW / 2;
      return padLeft + (index / (points.length - 1)) * chartW;
    };

    const getY = (val) => {
      const clamped = Math.max(0, Math.min(100, val));
      return padTop + chartH - (clamped / 100) * chartH;
    };

    // Build SVG path string
    const coords = points.map((p, idx) => ({ x: getX(idx), y: getY(p.value), ...p }));
    const pathD = coords.map((c, idx) => (idx === 0 ? `M ${c.x} ${c.y}` : `L ${c.x} ${c.y}`)).join(' ');
    
    // Area fill path
    const areaD = `${pathD} L ${coords[coords.length - 1].x} ${padTop + chartH} L ${coords[0].x} ${padTop + chartH} Z`;

    // Horizontal grid lines: 0%, 25%, 50%, 75%, 100%
    const gridY = [0, 25, 50, 75, 100];
    const gridLinesSvg = gridY.map(val => {
      const y = getY(val);
      return `
        <line x1="${padLeft}" y1="${y}" x2="${width - padRight}" y2="${y}" stroke="#e2e8f0" stroke-dasharray="3,3" stroke-width="1" />
        <text x="${padLeft - 8}" y="${y + 4}" fill="#94a3b8" font-size="10" text-anchor="end" font-weight="500">${val}%</text>
      `;
    }).join('');

    // Dots and labels
    const dotsSvg = coords.map((c) => `
      <g class="chart-point-group" style="cursor:pointer;">
        <circle cx="${c.x}" cy="${c.y}" r="5" fill="#ffffff" stroke="${lineColor}" stroke-width="3" />
        <circle cx="${c.x}" cy="${c.y}" r="9" fill="transparent" />
        <text x="${c.x}" y="${c.y - 12}" fill="#4c1d95" font-size="11" font-weight="700" text-anchor="middle">${c.value}%</text>
        <text x="${c.x}" y="${padTop + chartH + 20}" fill="#64748b" font-size="11" font-weight="600" text-anchor="middle">${c.label || ''}</text>
      </g>
    `).join('');

    const gradId = `grad_${Math.random().toString(36).substring(2, 9)}`;

    el.innerHTML = `
      <svg viewBox="0 0 ${width} ${height}" style="width:100%;height:100%;overflow:visible;">
        <defs>
          <linearGradient id="${gradId}" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="${gradientStart}" />
            <stop offset="100%" stop-color="${gradientEnd}" />
          </linearGradient>
        </defs>

        <!-- Grid Lines & Axis -->
        ${gridLinesSvg}

        <!-- Benchmark 70% Mastery Line -->
        <line x1="${padLeft}" y1="${getY(70)}" x2="${width - padRight}" y2="${getY(70)}" stroke="#10b981" stroke-dasharray="4,4" stroke-width="1.5" opacity="0.6" />
        <text x="${width - padRight - 5}" y="${getY(70) - 5}" fill="#059669" font-size="9" font-weight="600" text-anchor="end">Mastery Benchmark (70%)</text>

        <!-- Area Fill -->
        <path d="${areaD}" fill="url(#${gradId})" />

        <!-- Line Stroke -->
        <path d="${pathD}" fill="none" stroke="${lineColor}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />

        <!-- Data Point Dots -->
        ${dotsSvg}
      </svg>
    `;
  }

  /**
   * Renders a circular radial progress donut
   */
  static renderDonutProgress(target, percentage, label = "", color = "#6366f1") {
    const el = typeof target === 'string' ? document.getElementById(target) : target;
    if (!el) return;

    const size = 110;
    const strokeWidth = 10;
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (Math.min(100, Math.max(0, percentage)) / 100) * circumference;

    el.innerHTML = `
      <div style="position:relative;width:${size}px;height:${size}px;display:flex;align-items:center;justify-content:center;">
        <svg width="${size}" height="${size}" style="transform:rotate(-90deg);">
          <circle cx="${size/2}" cy="${size/2}" r="${radius}" stroke="#f1f5f9" stroke-width="${strokeWidth}" fill="transparent" />
          <circle cx="${size/2}" cy="${size/2}" r="${radius}" stroke="${color}" stroke-width="${strokeWidth}" fill="transparent"
            stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" stroke-linecap="round"
            style="transition:stroke-dashoffset 0.8s ease;" />
        </svg>
        <div style="position:absolute;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
          <span style="font-size:1.35rem;font-weight:800;color:var(--text-main);line-height:1;">${percentage}%</span>
          ${label ? `<span style="font-size:0.68rem;color:var(--text-muted);margin-top:2px;font-weight:600;">${label}</span>` : ''}
        </div>
      </div>
    `;
  }
}

// Export for browser
window.SVGCharts = SVGCharts;
