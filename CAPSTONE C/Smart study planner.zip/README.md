# 🎓 AI-Powered Smart Study Planner with Teacher Dashboard

> **A comprehensive, intelligent educational web application featuring synchronized Student and Teacher portals, secure Gmail SMTP email verification, forgot password recovery, topic-level quiz analytics, AI-powered practice testing, personalized study recommendations, and automatic adaptive timetable generation.**

---

## 🌟 Application Architecture & Tech Stack

- **Backend**: Python Flask (`app.py`, blueprint-modular architecture)
- **Database**: Shared SQLite relational database (`instance/studyplanner.db`)
- **Authentication & Security**: PBKDF2/SHA-256 password hashing, 6-digit cryptographic OTPs with 5-minute expiry, rate limiting, and role-based access control
- **Email Delivery**: Gmail SMTP with TLS encryption via standard Python `smtplib` and `email.mime`
- **Frontend**: Clean, responsive HTML5, CSS3 (soft lavender, blue & white palette), vanilla JavaScript with password visibility toggles
- **Data Visualizations**: Chart.js for student mastery radar, score distributions, and topic trajectory charts
- **File Management**: Python Flask secure file uploads (`static/uploads/`) for lecture slides, PDFs, notes, and references

---

## 🚀 Quick Start Guide

### 1. Configure Gmail SMTP (Email Verification & Password Reset)
Create a `.env` file in the project root by copying the provided `.env.example`:
```bash
copy .env.example .env
```
Open `.env` and configure your Gmail address and **Google App Password**:
```ini
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-16-character-app-password
MAIL_DEFAULT_SENDER=your-email@gmail.com
```

> [!IMPORTANT]
> **How to Generate a Gmail App Password:**
> 1. Go to your [Google Account](https://myaccount.google.com/) and select **Security**.
> 2. Ensure **2-Step Verification** is turned ON.
> 3. Go to [Google App Passwords](https://myaccount.google.com/apppasswords).
> 4. Enter an app name (e.g. `SmartStudyPlanner`) and click **Create**.
> 5. Copy the generated 16-character password into `MAIL_PASSWORD` in your `.env` file.
> *(Never use your standard personal Gmail password).*

### 2. Run the Web Application
```bash
python app.py
```
Open your web browser and navigate to:
```text
http://127.0.0.1:5000/
```

### 3. Preload Realistic Demo Data (Idempotent)
To populate the database with realistic sample subjects, topics, study handouts, assignments, quizzes, and student attempt histories:
```bash
python seed_demo_data.py
```
*(This script is strictly idempotent: running it multiple times will never create duplicate records).*

### 4. Run the Automated Test Suite
To execute the comprehensive automated test suite (51 test cases across 8 categories using a dedicated, isolated test database):
```bash
python tests/test_suite.py
```
Or via standard unittest discovery:
```bash
python -m unittest discover tests
```

---

## 🔐 Authentication, Email Verification & Security

### 1. Robust Login Validation
- Rejects nonexistent emails with: `"No account found with this email. Please register first."`
- Rejects incorrect passwords with: `"Incorrect password. Please try again."`
- Blocks unverified accounts from logging in, redirecting to the OTP verification screen.
- Enforces strict role validation between Students and Teachers.
- Never creates accounts automatically during login.

### 2. Gmail Email Verification (Registration)
- Validates institutional and personal email formatting via regex.
- Rejects duplicate email registrations.
- Generates a secure, cryptographically random 6-digit numerical OTP.
- Hashes OTPs before storing them in SQLite (`verification_otp_hash`).
- Enforces a **5-minute expiration window** and a maximum of 5 failed attempts.
- Provides a **Resend OTP** action with a **60-second cooldown timer**.
- Activates the account (`is_verified = 1`) only upon successful code verification.

### 3. Forgot Password & Recovery
- Accessible directly from the **"Forgot Password?"** link on the login page.
- Generates a time-limited (15-minute) 6-digit reset code sent to the registered address.
- Hashes reset codes before database storage.
- Rate-limited with a 60-second cooldown to prevent spam.
- Updates the user password hash securely upon valid verification and immediately invalidates the reset token.

### 4. Password Visibility Toggle
- Integrated into all password inputs across Login, Student Registration, Teacher Registration, and Reset Password pages with an eye toggle (`👁️` / `🙈`).

---

## 🔑 Preloaded Demo Credentials

| Role | Email | Password | Status | Details |
| :--- | :--- | :--- | :--- | :--- |
| **Teacher** | `teacher@studyglow.com` | `Teacher@123` | Active & Verified | Prof. Sarah Jenkins, Dept. of Computer Science & Engineering |
| **Student** | `student@studyglow.com` | `Student@123` | Active & Verified | Alex Rivera, 2nd Year B.Tech CSE (Roll: `CSE-2026-042`) |

---

## 📚 Enrolled Subjects & Course Codes

Students can enrol in classes by entering either the Subject Code or the Enrolment Code:

| Subject Code | Subject Name | Enrolment Code | Preloaded Topics |
| :--- | :--- | :--- | :--- |
| **PPS101** | Programming for Problem Solving | `PPS-0101` | Variables, Conditionals, Loops, Arrays, Functions, Pointers |
| **MAT102** | Engineering Mathematics | `MAT-0102` | Matrices, Differential Calculus, Integration, Vector Calculus, Differential Equations, Laplace Transforms |
| **PHY103** | Engineering Physics | `PHY-0103` | Quantum Mechanics, Wave Optics, Laser Technology, Fiber Optics, Semiconductor Physics, Dielectrics |
| **AIML104** | Artificial Intelligence & Machine Learning | `AIML-0104` | Search Algorithms, Knowledge Representation, Classical ML, Neural Networks, Computer Vision, NLP |
| **DEC105** | Digital Electronics | `DEC-0105` | Number Systems, Boolean Algebra, Logic Gates, Combinational Circuits, Sequential Circuits, Memory & PLDs |
| **CSA0207** | Operating Systems & Core CS | *(Generated)* | Kernel Architectures, CPU Scheduling, Virtual Memory |

---

## 🧪 Comprehensive Automated Test Results

The test suite executes against an isolated SQLite test database (`instance/test_studyplanner.db`), ensuring production records and preloaded demo data remain completely intact.

```text
================================================================================
TEST REPORT TABLE (SECTION 12 MANDATORY FORMAT):
================================================================================
| Test Category                    | Total Tests | Passed | Failed |
|----------------------------------|-------------|--------|--------|
| Application startup              | 7           | 7      | 0      |
| Quiz generation and evaluation   | 7           | 7      | 0      |
| Topic analysis                   | 6           | 6      | 0      |
| Adaptive timetable               | 9           | 9      | 0      |
| Teacher dashboard                | 3           | 3      | 0      |
| Authentication & Security        | 13          | 13     | 0      |
| Existing feature regression      | 5           | 5      | 0      |
| End-to-end integration           | 1           | 1      | 0      |
| TOTAL                            | 51          | 51     | 0      |
================================================================================
```

### Breakdown of Authentication & Security Tests (13 Test Cases):
1. **Login with registered email and correct password**: Authenticates user, establishes session, redirects to dashboard.
2. **Login with registered email and incorrect password**: Rejects login, returns `"Incorrect password. Please try again."`, no session created.
3. **Login with nonexistent email**: Rejects login, returns `"No account found with this email. Please register first."`, no session created.
4. **Register with existing email**: Rejects duplicate registration with `"An account with this email address already exists. Please sign in instead."`.
5. **Register with new email and verify using correct OTP**: Creates pending unverified account (`is_verified = 0`), verifies with 6-digit OTP, activates account (`is_verified = 1`), and permits subsequent login.
6. **Attempt verification with incorrect OTP**: Rejects invalid OTP, increments failed attempt counter, leaves account unverified.
7. **Attempt verification with expired OTP**: Detects expired OTP (>5 mins), rejects with expiration notice, leaves account unverified.
8. **Attempt login before email verification**: Blocks unverified account from accessing session, redirects to `/verify-otp`.
9. **Request password reset for registered email**: Generates secure 6-digit reset code, stores hash in database, sets 15-minute expiration.
10. **Attempt password reset with invalid or expired token**: Rejects invalid codes and expired tokens with clear error messages.
11. **Reset password successfully and login with new password**: Updates password hash, invalidates reset token, verifies new password login succeeds and old password fails.
12. **Check student and teacher role permissions**: Cross-role access denied (students cannot open `/teacher/dashboard`, teachers cannot open `/student/dashboard`, guests redirected to `/login`).
13. **Confirm existing accounts, courses, enrolments and quiz history remain intact**: Verifies all 7 production users in `instance/studyplanner.db` remain verified (`is_verified = 1`) and all historical academic data is preserved.

---

## 📂 Project Directory Structure

```text
Antigravity/
├── app.py                      # Flask application factory and main entry point
├── config.py                   # Configuration settings, .env loader & Gmail SMTP parameters
├── .env.example                # Template for Gmail SMTP credentials and App Password
├── compat.py                   # Lightweight Flask compatibility & testing framework layer
├── database.py                 # SQLite schema initialization, safe migrations & connection factory
├── email_service.py            # Gmail SMTP delivery service, TLS connection & HTML templates
├── models.py                   # Relational data access models (User, Subject, Topic, Material, Quiz, Timetable)
├── ai_quiz.py                  # AI quiz generator, algorithmic question builder & topic question bank
├── ai_analysis.py              # Performance analysis engine, topic mastery & trend detection algorithms
├── ai_recommendations.py       # Personalized study recommendation engine linking teacher resources
├── adaptive_timetable.py       # Adaptive timetable engine, priority calculator & schedule rebalancing
├── seed_demo_data.py           # Idempotent demo environment seeder (preloads subjects, materials, attempts)
├── tests/
│   └── test_suite.py           # Comprehensive automated test suite (51 test cases, 100% pass rate)
├── instance/
│   └── studyplanner.db         # Shared SQLite database
├── routes/
│   ├── auth.py                 # Authentication, email verification, forgot password & logout routes
│   ├── student.py              # Student dashboard, subject enrolment and learning analytics
│   ├── teacher.py              # Teacher dashboard, subject creation and class analytics
│   ├── materials.py            # Study material uploads, downloads and resource viewing
│   ├── assignments.py          # Assignment distribution, submissions and completion checkoffs
│   ├── quizzes.py              # Teacher quiz creation, AI quiz generation and evaluation
│   └── timetable.py            # Study timetable viewing, custom sessions and AI adaptation
├── static/
│   ├── css/
│   │   └── style.css           # Soft lavender/blue responsive styling, cards and password toggles
│   ├── js/
│   │   ├── main.js             # Navigation toggles, modal dialogs, AJAX enrolment & password toggles
│   │   └── charts.js           # Chart.js integration for score history and topic radar
│   └── uploads/                # Lecture handouts, PDFs and study guides
└── templates/
    ├── base.html               # Shared master layout with role-aware sidebar navigation
    ├── index.html              # Modern educational platform landing page
    ├── auth/                   # Login, student/teacher registration, OTP verification, forgot/reset password
    ├── student/                # Dashboard, analytics, quizzes, quiz result and timetable templates
    └── teacher/                # Dashboard, performance overview and student detail drilldown templates
```
