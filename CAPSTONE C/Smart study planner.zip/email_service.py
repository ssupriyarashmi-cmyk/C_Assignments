"""
Email Service for Smart Study Planner
Provides Gmail SMTP email delivery for:
- 6-digit registration verification OTPs
- 6-digit password reset verification codes

Configured via environment variables / .env:
MAIL_SERVER, MAIL_PORT, MAIL_USE_TLS, MAIL_USERNAME, MAIL_PASSWORD, MAIL_DEFAULT_SENDER
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import Config

# In-memory outbox for testing and debugging
outbox = []

def is_email_configured():
    """Checks whether valid Gmail SMTP credentials have been provided."""
    return bool(Config.MAIL_USERNAME and Config.MAIL_PASSWORD)

def verify_smtp_credentials(username=None, password=None, server_host=None, port=None, use_tls=True):
    """
    Verifies that the provided or configured Gmail SMTP credentials can authenticate.
    Returns: (success: bool, message: str)
    """
    user = (username if username is not None else Config.MAIL_USERNAME).strip()
    pwd = (password if password is not None else Config.MAIL_PASSWORD).strip().replace(' ', '')
    host = (server_host if server_host is not None else Config.MAIL_SERVER).strip()
    p = port if port is not None else Config.MAIL_PORT

    if not user or not pwd:
        return False, "Gmail username and App Password cannot be empty."

    try:
        if p == 465:
            server = smtplib.SMTP_SSL(host, p, timeout=15)
        else:
            server = smtplib.SMTP(host, p, timeout=15)
            if use_tls:
                server.starttls()
        server.login(user, pwd)
        server.quit()
        return True, "Gmail SMTP authentication successful! Credentials are valid."
    except smtplib.SMTPAuthenticationError:
        return False, (
            "Gmail SMTP authentication failed (535 5.7.8). "
            "Please ensure you are using a 16-character Google App Password (not your normal Gmail password). "
            "Generate one at: https://myaccount.google.com/apppasswords"
        )
    except Exception as e:
        return False, f"Failed to connect to {host}:{p} - {str(e)}"

def send_email(to_email, subject, html_content, text_content=None):
    """
    Sends an email using Gmail SMTP with TLS.
    Returns: (success: bool, error_message: str or None)
    """
    # In test mode or when mock enabled, store in outbox without network connection
    if getattr(Config, 'TESTING', False):
        outbox.append({
            'to': to_email,
            'subject': subject,
            'html': html_content,
            'text': text_content or html_content
        })
        return True, None

    if not is_email_configured():
        return False, (
            "Gmail SMTP is not configured. Please set MAIL_USERNAME and MAIL_PASSWORD "
            "(Gmail App Password) in your environment variables or .env file."
        )

    sender = Config.MAIL_DEFAULT_SENDER or Config.MAIL_USERNAME
    to_email = to_email.strip()
    username = Config.MAIL_USERNAME.strip()
    password = Config.MAIL_PASSWORD.replace(" ", "").strip()

    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = f"Smart Study Planner <{sender}>"
    msg['To'] = to_email

    if text_content:
        part1 = MIMEText(text_content, 'plain', 'utf-8')
        msg.attach(part1)

    part2 = MIMEText(html_content, 'html', 'utf-8')
    msg.attach(part2)

    try:
        if Config.MAIL_PORT == 465:
            server = smtplib.SMTP_SSL(Config.MAIL_SERVER, 465, timeout=15)
        else:
            server = smtplib.SMTP(Config.MAIL_SERVER, Config.MAIL_PORT, timeout=15)
            if Config.MAIL_USE_TLS:
                server.starttls()
        server.login(username, password)
        server.send_message(msg)
        server.quit()
        return True, None
    except smtplib.SMTPAuthenticationError:
        return False, (
            "Gmail SMTP authentication failed. Please verify your Gmail address and 16-character App Password. "
            "Note: Google requires a Gmail App Password, not your standard login password."
        )
    except Exception as e:
        return False, f"Failed to send email via Gmail SMTP: {str(e)}"

def send_verification_otp(to_email, user_name, otp_code):
    """Sends a 6-digit email verification OTP."""
    subject = "🎓 [Study Planner] Verify Your Email Address"
    text_content = (
        f"Hello {user_name},\n\n"
        f"Your verification code is: {otp_code}\n\n"
        f"This code will expire in 5 minutes.\n"
        f"If you did not register for Smart Study Planner, please ignore this email."
    )
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #F8FAFC; margin: 0; padding: 20px; }}
            .container {{ max-width: 520px; margin: 0 auto; background: #FFFFFF; border-radius: 16px; border: 1px solid #E2E8F0; padding: 36px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }}
            .brand {{ text-align: center; margin-bottom: 24px; }}
            .brand-badge {{ display: inline-block; width: 48px; height: 48px; line-height: 48px; font-size: 24px; background: #EEF2FF; border-radius: 12px; margin-bottom: 8px; }}
            .brand h2 {{ margin: 0; color: #1E293B; font-size: 22px; font-weight: 800; }}
            .content {{ color: #475569; font-size: 15px; line-height: 1.6; text-align: center; }}
            .otp-box {{ background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%); border: 2px dashed #6366F1; border-radius: 12px; padding: 20px; margin: 28px 0; text-align: center; }}
            .otp-code {{ font-family: 'Courier New', Courier, monospace; font-size: 34px; font-weight: 800; letter-spacing: 8px; color: #4338CA; margin: 0; }}
            .expiry-note {{ font-size: 13px; color: #64748B; margin-top: 10px; }}
            .footer {{ border-top: 1px solid #E2E8F0; margin-top: 32px; padding-top: 20px; font-size: 12px; color: #94A3B8; text-align: center; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="brand">
                <div class="brand-badge">🎓</div>
                <h2>Smart Study Planner</h2>
            </div>
            <div class="content">
                <p>Hello <strong>{user_name}</strong>,</p>
                <p>Thank you for signing up. Please verify your email address to activate your account and start your personalized study journey.</p>
                
                <div class="otp-box">
                    <div class="otp-code">{otp_code}</div>
                    <div class="expiry-note">⏱️ Valid for <strong>5 minutes</strong> only</div>
                </div>

                <p style="font-size: 13px; color: #64748B;">Enter this six-digit verification code in the Study Planner portal to complete registration.</p>
            </div>
            <div class="footer">
                If you did not create an account on Smart Study Planner, you can safely ignore this email.<br>
                &copy; 2026 Smart Study Planner. All rights reserved.
            </div>
        </div>
    </body>
    </html>
    """
    return send_email(to_email, subject, html_content, text_content)

def send_password_reset_otp(to_email, user_name, reset_code):
    """Sends a 6-digit password reset verification code."""
    subject = "🔐 [Study Planner] Password Reset Verification Code"
    text_content = (
        f"Hello {user_name},\n\n"
        f"We received a request to reset your Smart Study Planner password.\n"
        f"Your reset verification code is: {reset_code}\n\n"
        f"This code will expire in 15 minutes.\n"
        f"If you did not request a password reset, please ignore this email. Your password will remain unchanged."
    )
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #F8FAFC; margin: 0; padding: 20px; }}
            .container {{ max-width: 520px; margin: 0 auto; background: #FFFFFF; border-radius: 16px; border: 1px solid #E2E8F0; padding: 36px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }}
            .brand {{ text-align: center; margin-bottom: 24px; }}
            .brand-badge {{ display: inline-block; width: 48px; height: 48px; line-height: 48px; font-size: 24px; background: #FEF3C7; border-radius: 12px; margin-bottom: 8px; }}
            .brand h2 {{ margin: 0; color: #1E293B; font-size: 22px; font-weight: 800; }}
            .content {{ color: #475569; font-size: 15px; line-height: 1.6; text-align: center; }}
            .otp-box {{ background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border: 2px dashed #F59E0B; border-radius: 12px; padding: 20px; margin: 28px 0; text-align: center; }}
            .otp-code {{ font-family: 'Courier New', Courier, monospace; font-size: 34px; font-weight: 800; letter-spacing: 8px; color: #92400E; margin: 0; }}
            .expiry-note {{ font-size: 13px; color: #78350F; margin-top: 10px; }}
            .footer {{ border-top: 1px solid #E2E8F0; margin-top: 32px; padding-top: 20px; font-size: 12px; color: #94A3B8; text-align: center; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="brand">
                <div class="brand-badge">🔐</div>
                <h2>Password Reset Request</h2>
            </div>
            <div class="content">
                <p>Hello <strong>{user_name}</strong>,</p>
                <p>We received a request to reset your Smart Study Planner password. Use the verification code below to set your new password:</p>
                
                <div class="otp-box">
                    <div class="otp-code">{reset_code}</div>
                    <div class="expiry-note">⏱️ Valid for <strong>15 minutes</strong> only</div>
                </div>

                <p style="font-size: 13px; color: #64748B;">Enter this verification code along with your new password to complete the reset process.</p>
            </div>
            <div class="footer">
                If you did not request a password reset, no further action is required. Your password remains safe.<br>
                &copy; 2026 Smart Study Planner. All rights reserved.
            </div>
        </div>
    </body>
    </html>
    """
    return send_email(to_email, subject, html_content, text_content)
