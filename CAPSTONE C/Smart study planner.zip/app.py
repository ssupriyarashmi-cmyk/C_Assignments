import os
from compat import Flask, render_template, session, redirect, url_for
from config import Config
from database import init_db

# Import blueprints
from routes.auth import auth_bp
from routes.student import student_bp
from routes.teacher import teacher_bp
from routes.materials import materials_bp
from routes.assignments import assignments_bp
from routes.quizzes import quizzes_bp
from routes.timetable import timetable_bp

def create_app():
    # Ensure database tables exist
    init_db()

    app = Flask(__name__, template_folder='templates', static_folder='static')
    app.config['SECRET_KEY'] = Config.SECRET_KEY
    app.config['UPLOAD_FOLDER'] = Config.UPLOAD_FOLDER
    app.config['MAX_CONTENT_LENGTH'] = Config.MAX_CONTENT_LENGTH

    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(teacher_bp)
    app.register_blueprint(materials_bp)
    app.register_blueprint(assignments_bp)
    app.register_blueprint(quizzes_bp)
    app.register_blueprint(timetable_bp)

    from email_service import is_email_configured
    @app.context_processor
    def inject_globals():
        return {
            'email_configured': is_email_configured()
        }

    @app.route('/')
    def index():
        if 'user_id' in session:
            if session.get('role') == 'teacher':
                return redirect(url_for('teacher.dashboard'))
            return redirect(url_for('student.dashboard'))
        return render_template('index.html')

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='127.0.0.1', port=port, debug=True)
