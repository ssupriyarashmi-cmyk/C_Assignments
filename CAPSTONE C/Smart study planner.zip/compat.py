"""
Compatibility module:
If Flask, Werkzeug, and Jinja2 are installed in the Python environment,
this module imports and exports them directly.
If not yet installed, it provides a lightweight, fully functional WSGI/HTTP
server and template engine using pure Python standard library modules.
"""

import os
import sys
import re
import json
import sqlite3
import hashlib
import secrets
import mimetypes
from datetime import datetime
from urllib.parse import parse_qs, urlparse, unquote

try:
    import flask
    import werkzeug.security
    import werkzeug.utils
    from flask import (
        Flask as RealFlask,
        Blueprint as RealBlueprint,
        render_template as real_render_template,
        request as real_request,
        redirect as real_redirect,
        url_for as real_url_for,
        session as real_session,
        flash as real_flash,
        get_flashed_messages as real_get_flashed_messages,
        jsonify as real_jsonify,
        send_from_directory as real_send_from_directory,
        abort as real_abort,
        g as real_g
    )
    from werkzeug.security import generate_password_hash, check_password_hash
    from werkzeug.utils import secure_filename

    Flask = RealFlask
    Blueprint = RealBlueprint
    render_template = real_render_template
    request = real_request
    redirect = real_redirect
    url_for = real_url_for
    session = real_session
    flash = real_flash
    get_flashed_messages = real_get_flashed_messages
    jsonify = real_jsonify
    send_from_directory = real_send_from_directory
    abort = real_abort
    g = real_g
    HAS_FLASK = True

except ImportError:
    HAS_FLASK = False
    import http.server
    import http.cookies
    import urllib.parse
    import io

    # Password hashing using standard library hashlib
    def generate_password_hash(password, method='pbkdf2:sha256', salt_length=16):
        salt = secrets.token_hex(salt_length // 2)
        key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
        return f"pbkdf2:sha256:100000${salt}${key.hex()}"

    def check_password_hash(pwhash, password):
        try:
            if not pwhash or '$' not in pwhash:
                return False
            parts = pwhash.split('$')
            if len(parts) == 3:
                _, salt, key_hex = parts
                test_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
                return secrets.compare_digest(test_key.hex(), key_hex)
            elif len(parts) == 2:
                salt, key_hex = parts
                test_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
                return secrets.compare_digest(test_key.hex(), key_hex)
            return False
        except Exception:
            return False

    def secure_filename(filename):
        filename = re.sub(r'[^a-zA-Z0-9_.-]', '_', filename)
        return filename.strip('._') or 'upload_file'

    # Global request/session context storage for single-threaded or thread-local execution
    import threading
    _context_local = threading.local()

    class RequestFile:
        def __init__(self, filename, content_bytes):
            self.filename = filename
            self._content = content_bytes

        def save(self, destination):
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            with open(destination, 'wb') as f:
                f.write(self._content)

        def read(self):
            return self._content

    class FormDict(dict):
        def __init__(self, raw_dict=None):
            super().__init__()
            self._raw = {}
            if raw_dict:
                for k, v in raw_dict.items():
                    if isinstance(v, list):
                        self._raw[k] = list(v)
                        self[k] = v[0] if v else ''
                    else:
                        self._raw[k] = [v]
                        self[k] = v

        def getlist(self, key):
            return list(self._raw.get(key, []))

    class RequestWrapper:
        def __init__(self, method='GET', path='/', query_params=None, form_data=None, files_data=None, cookies=None, headers=None, json_data=None):
            self.method = method
            self.path = path
            self.args = FormDict(query_params or {})
            self.form = FormDict(form_data or {})
            self.files = files_data or {}
            self.cookies = cookies or {}
            self.headers = headers or {}
            self.json = json_data or {}
            self.endpoint = None

        def get_json(self, force=False):
            return self.json or {}

        @property
        def is_json(self):
            ct = self.headers.get('Content-Type', '') if hasattr(self.headers, 'get') else ''
            return 'application/json' in ct

        @property
        def referrer(self):
            if hasattr(self.headers, 'get'):
                return self.headers.get('Referer') or self.headers.get('referrer')
            return None

    class ContextProxy:
        def __getattr__(self, name):
            req = getattr(_context_local, 'request', None)
            if req is None:
                raise RuntimeError("Working outside of request context.")
            return getattr(req, name)

    request = ContextProxy()

    class SessionDict(dict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.modified = False

        def __setitem__(self, key, value):
            super().__setitem__(key, value)
            self.modified = True

        def pop(self, key, default=None):
            self.modified = True
            return super().pop(key, default)

        def clear(self):
            self.modified = True
            super().clear()

    class SessionProxy:
        def _get_current_session(self):
            sess = getattr(_context_local, 'session', None)
            if sess is None:
                sess = SessionDict()
                _context_local.session = sess
            return sess

        def __getitem__(self, key):
            return self._get_current_session()[key]

        def __setitem__(self, key, value):
            self._get_current_session()[key] = value

        def __contains__(self, key):
            return key in self._get_current_session()

        def get(self, key, default=None):
            return self._get_current_session().get(key, default)

        def pop(self, key, default=None):
            return self._get_current_session().pop(key, default)

        def clear(self):
            self._get_current_session().clear()

        def items(self):
            return self._get_current_session().items()

        def keys(self):
            return self._get_current_session().keys()

    session = SessionProxy()

    class GProxy:
        def __getattr__(self, name):
            g_dict = getattr(_context_local, 'g', None)
            if g_dict is None:
                g_dict = {}
                _context_local.g = g_dict
            return g_dict.get(name)

        def __setattr__(self, name, value):
            if not hasattr(_context_local, 'g') or _context_local.g is None:
                _context_local.g = {}
            _context_local.g[name] = value

    g = GProxy()

    _sessions_store = {}  # session_id -> dict

    def flash(message, category='info'):
        flashes = session.get('_flashes', [])
        flashes.append((category, message))
        session['_flashes'] = flashes

    def get_flashed_messages(with_categories=False):
        flashes = session.get('_flashes')
        if flashes is not None:
            flashes = session.pop('_flashes', [])
            setattr(_context_local, '_cached_flashes', list(flashes))
        else:
            flashes = getattr(_context_local, '_cached_flashes', [])
        if with_categories:
            return list(flashes)
        return [msg for cat, msg in flashes]

    class ResponseRedirect:
        def __init__(self, location, status_code=302):
            self.location = location
            self.status_code = status_code
            self.code = status_code

    def redirect(location):
        return ResponseRedirect(location)

    def abort(code):
        raise HTTPException(code)

    class HTTPException(Exception):
        def __init__(self, code, message=""):
            self.code = code
            self.message = message

    class JsonResponse:
        def __init__(self, data, status_code=200):
            self.data = data
            self.status_code = status_code
            self.content_type = 'application/json'

    def jsonify(*args, **kwargs):
        if args:
            data = args[0]
        else:
            data = kwargs
        return JsonResponse(data)

    class FileResponse:
        def __init__(self, filepath, filename=None, as_attachment=False):
            self.filepath = filepath
            self.filename = filename or os.path.basename(filepath)
            self.as_attachment = as_attachment

    def send_from_directory(directory, path, as_attachment=False):
        full_path = os.path.join(directory, path)
        if not os.path.exists(full_path):
            raise HTTPException(404, "File not found")
        return FileResponse(full_path, filename=path, as_attachment=as_attachment)

    # Simple Jinja-like template engine supporting extends, blocks, for, if, and variables
    def parse_and_render_template(template_str, template_dir, context):
        # 1. Handle {% extends "..." %}
        extends_match = re.search(r'\{%\s*extends\s+["\']([^"\']+)["\']\s*%\}', template_str)
        if extends_match:
            base_filename = extends_match.group(1)
            base_path = os.path.join(template_dir, base_filename)
            with open(base_path, 'r', encoding='utf-8') as f:
                base_str = f.read()

            # Extract blocks from child
            blocks = {}
            for block_match in re.finditer(r'\{%\s*block\s+(\w+)\s*%\}(.*?)\{%\s*endblock\s*(?:\1)?\s*%\}', template_str, re.DOTALL):
                blocks[block_match.group(1)] = block_match.group(2)

            # Replace blocks in base template
            def replace_block(m):
                bname = m.group(1)
                default_content = m.group(2)
                return blocks.get(bname, default_content)

            combined_str = re.sub(r'\{%\s*block\s+(\w+)\s*%\}(.*?)\{%\s*endblock\s*(?:\1)?\s*%\}', replace_block, base_str, flags=re.DOTALL)
        else:
            combined_str = template_str

        # Render expressions and control structures
        return render_string(combined_str, context)

    def eval_expr(expr, context):
        expr = expr.strip()
        if not expr:
            return ""

        # Check for filter like | length
        if '|' in expr:
            parts = expr.split('|', 1)
            val = eval_expr(parts[0], context)
            filt = parts[1].strip()
            if filt == 'length' or filt.startswith('length'):
                try:
                    return len(val)
                except Exception:
                    return 0
            elif filt.startswith('default('):
                def_val = filt[8:-1].strip(' "\'')
                return val if val else def_val
            elif filt.startswith('round'):
                try:
                    return round(float(val), 1)
                except Exception:
                    return val
            return val

        # Handle boolean / ternary / logic
        try:
            # Safe evaluation in context
            # Support dot notation: e.g. user.name -> user['name'] or getattr
            return eval(expr, {"__builtins__": None, "len": len, "str": str, "int": int, "float": float, "round": round, "max": max, "min": min}, SafeContext(context))
        except Exception:
            return ""

    class SafeContext(dict):
        def __init__(self, data):
            super().__init__(data)

        def __getitem__(self, key):
            if key in self:
                val = super().__getitem__(key)
                return self._wrap(val)
            return ""

        def _wrap(self, val):
            if isinstance(val, dict):
                return SafeDict(val)
            elif isinstance(val, sqlite3.Row):
                return SafeDict(dict(val))
            elif isinstance(val, list):
                return [self._wrap(x) for x in val]
            return val

    class SafeDict(dict):
        def __getattr__(self, name):
            if name in self:
                val = self[name]
                if isinstance(val, dict):
                    return SafeDict(val)
                elif isinstance(val, sqlite3.Row):
                    return SafeDict(dict(val))
                return val
            return ""

    def render_string(template_str, context):
        # We will tokenize and parse if/for blocks
        tokens = re.split(r'(\{%.*?%\}|\{\{.*?\}\})', template_str, flags=re.DOTALL)
        
        ctx = SafeContext(context)
        # Helper standard variables inside templates
        ctx['get_flashed_messages'] = get_flashed_messages
        ctx['session'] = session
        ctx['url_for'] = url_for
        ctx['request'] = request

        output = []
        i = 0
        n = len(tokens)

        def process_block(start_idx, end_tag_names):
            idx = start_idx
            res = []
            while idx < n:
                token = tokens[idx]
                if not token:
                    idx += 1
                    continue
                if token.startswith('{%'):
                    tag_content = token[2:-2].strip()
                    parts = tag_content.split()
                    tag_name = parts[0] if parts else ''

                    if tag_name in end_tag_names:
                        return "".join(res), idx, tag_name, parts

                    if tag_name == 'if':
                        # Find matching endif/else
                        cond_expr = " ".join(parts[1:])
                        cond_met = False
                        try:
                            cond_val = eval_expr(cond_expr, ctx)
                            cond_met = bool(cond_val)
                        except Exception:
                            cond_met = False

                        active_render = cond_met
                        has_rendered = cond_met

                        sub_idx = idx + 1
                        while sub_idx < n:
                            block_res, next_idx, end_tag, end_parts = process_block(sub_idx, ['endif', 'elif', 'else'])
                            if active_render:
                                res.append(block_res)
                            
                            if end_tag == 'endif':
                                idx = next_idx
                                break
                            elif end_tag == 'elif':
                                sub_idx = next_idx + 1
                                elif_expr = " ".join(end_parts[1:])
                                if not has_rendered:
                                    try:
                                        elif_val = eval_expr(elif_expr, ctx)
                                        if bool(elif_val):
                                            active_render = True
                                            has_rendered = True
                                        else:
                                            active_render = False
                                    except Exception:
                                        active_render = False
                                else:
                                    active_render = False
                            elif end_tag == 'else':
                                sub_idx = next_idx + 1
                                if not has_rendered:
                                    active_render = True
                                    has_rendered = True
                                else:
                                    active_render = False
                        idx += 1
                        continue

                    elif tag_name == 'for':
                        # {% for item in items %} or {% for k, v in items %}
                        match_for = re.match(r'for\s+(.+?)\s+in\s+(.+)', tag_content)
                        if match_for:
                            var_names = [v.strip() for v in match_for.group(1).split(',')]
                            iter_expr = match_for.group(2).strip()
                            try:
                                iterable = eval_expr(iter_expr, ctx)
                                if iterable is None:
                                    iterable = []
                            except Exception:
                                iterable = []

                            # Collect inner tokens until endfor
                            loop_tokens = []
                            depth = 1
                            search_idx = idx + 1
                            while search_idx < n:
                                t = tokens[search_idx]
                                if t.startswith('{%'):
                                    tc = t[2:-2].strip()
                                    if tc.startswith('for '):
                                        depth += 1
                                    elif tc.startswith('endfor'):
                                        depth -= 1
                                        if depth == 0:
                                            break
                                loop_tokens.append(t)
                                search_idx += 1

                            idx = search_idx

                            # Render loop iterations
                            for loop_idx, item in enumerate(iterable):
                                loop_ctx = dict(ctx)
                                loop_ctx['loop'] = {
                                    'index': loop_idx + 1,
                                    'index0': loop_idx,
                                    'first': loop_idx == 0,
                                    'last': loop_idx == len(iterable) - 1 if hasattr(iterable, '__len__') else False,
                                    'length': len(iterable) if hasattr(iterable, '__len__') else 0
                                }
                                if len(var_names) == 1:
                                    loop_ctx[var_names[0]] = item
                                elif len(var_names) == 2 and isinstance(item, (list, tuple)):
                                    loop_ctx[var_names[0]] = item[0]
                                    loop_ctx[var_names[1]] = item[1]

                                rendered_iter = render_string("".join(loop_tokens), loop_ctx)
                                res.append(rendered_iter)

                        idx += 1
                        continue

                    elif tag_name == 'set':
                        # {% set var = expr %}
                        match_set = re.match(r'set\s+([a-zA-Z_]\w*)\s*=\s*(.+)', tag_content)
                        if match_set:
                            var_name = match_set.group(1).strip()
                            expr_str = match_set.group(2).strip()
                            try:
                                ctx[var_name] = eval_expr(expr_str, ctx)
                            except Exception:
                                ctx[var_name] = None
                        idx += 1
                        continue

                elif token.startswith('{{'):
                    expr = token[2:-2].strip()
                    val = eval_expr(expr, ctx)
                    res.append(str(val) if val is not None else "")
                else:
                    res.append(token)
                idx += 1

            return "".join(res), idx, None, None

        full_rendered, _, _, _ = process_block(0, [])
        return full_rendered

    def render_template(template_name, **context):
        template_dir = getattr(_app_instance, 'template_folder', 'templates')
        filepath = os.path.join(template_dir, template_name)
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Template {template_name} not found at {filepath}")

        # Merge context processors
        if _app_instance and hasattr(_app_instance, 'context_processors'):
            for cp in _app_instance.context_processors:
                try:
                    cp_data = cp()
                    if isinstance(cp_data, dict):
                        for k, v in cp_data.items():
                            if k not in context:
                                context[k] = v
                except Exception:
                    pass

        with open(filepath, 'r', encoding='utf-8') as f:
            template_str = f.read()
        return parse_and_render_template(template_str, template_dir, context)

    # URL routing and Blueprint support
    _url_map = {}  # endpoint -> (rule, func, methods, bp_prefix)

    def url_for(endpoint, **values):
        if endpoint == 'static':
            filename = values.get('filename', '')
            return f"/static/{filename}"
        
        entry = _url_map.get(endpoint)
        if entry:
            rule = entry['rule']
            # substitute <param>
            for k, v in values.items():
                rule = rule.replace(f"<{k}>", str(v)).replace(f"<int:{k}>", str(v))
            return rule
        return f"/{endpoint}"

    class Blueprint:
        def __init__(self, name, import_name, url_prefix=None):
            self.name = name
            self.import_name = import_name
            self.url_prefix = url_prefix or ""
            self.routes = []

        def route(self, rule, methods=None):
            if methods is None:
                methods = ['GET']
            def decorator(f):
                self.routes.append({
                    'rule': rule,
                    'func': f,
                    'methods': [m.upper() for m in methods],
                    'endpoint': f.__name__
                })
                return f
            return decorator

    _app_instance = None

    class Flask:
        def __init__(self, import_name, template_folder='templates', static_folder='static'):
            global _app_instance
            _app_instance = self
            self.import_name = import_name
            self.template_folder = template_folder
            self.static_folder = static_folder
            self.config = {}
            self.blueprints = []
            self.routes = []
            self.before_request_funcs = []
            self.context_processors = []

        def register_blueprint(self, bp, url_prefix=None):
            prefix = url_prefix if url_prefix is not None else bp.url_prefix
            self.blueprints.append((bp, prefix))
            for r in bp.routes:
                full_rule = prefix.rstrip('/') + '/' + r['rule'].lstrip('/')
                if full_rule == '':
                    full_rule = '/'
                endpoint = f"{bp.name}.{r['endpoint']}"
                _url_map[endpoint] = {
                    'rule': full_rule,
                    'func': r['func'],
                    'methods': r['methods'],
                    'bp_prefix': prefix
                }

        def route(self, rule, methods=None):
            if methods is None:
                methods = ['GET']
            def decorator(f):
                endpoint = f.__name__
                _url_map[endpoint] = {
                    'rule': rule,
                    'func': f,
                    'methods': [m.upper() for m in methods],
                    'bp_prefix': ''
                }
                self.routes.append(_url_map[endpoint])
                return f
            return decorator

        def before_request(self, f):
            self.before_request_funcs.append(f)
            return f

        def context_processor(self, f):
            self.context_processors.append(f)
            return f

        def match_route(self, path, method):
            for endpoint, r in _url_map.items():
                rule = r['rule']
                # Convert rule to regex
                regex_pattern = '^' + re.sub(r'<int:(\w+)>', r'(?P<\1>\\d+)', re.sub(r'<(\w+)>', r'(?P<\1>[^/]+)', rule)) + '$'
                match = re.match(regex_pattern, path)
                if match:
                    if method not in r['methods']:
                        return None, None, 405
                    params = match.groupdict()
                    # convert int params
                    for k in params:
                        if f"<int:{k}>" in rule:
                            params[k] = int(params[k])
                    return endpoint, params, 200
            return None, None, 404

        def test_client(self):
            return TestClient(self)

        def run(self, host='127.0.0.1', port=5000, debug=True):
            app = self
            print(f" * Serving Study Planner on http://{host}:{port}/")

            class CustomHandler(http.server.BaseHTTPRequestHandler):
                def do_GET(self):
                    self.handle_request('GET')

                def do_POST(self):
                    self.handle_request('POST')

                def handle_request(self, method):
                    parsed_url = urlparse(self.path)
                    path = parsed_url.path
                    query_params = {k: v[0] if len(v) == 1 else v for k, v in parse_qs(parsed_url.query).items()}

                    # Static file serving
                    if path.startswith('/static/'):
                        rel_path = path[8:]
                        file_path = os.path.join(app.static_folder, rel_path)
                        if os.path.isfile(file_path):
                            mime, _ = mimetypes.guess_type(file_path)
                            self.send_response(200)
                            self.send_header('Content-Type', mime or 'application/octet-stream')
                            self.end_headers()
                            with open(file_path, 'rb') as f:
                                self.wfile.write(f.read())
                            return
                        else:
                            self.send_error(404, "Static file not found")
                            return

                    # Parse Cookies & Session
                    cookies = {}
                    if 'Cookie' in self.headers:
                        c = http.cookies.SimpleCookie(self.headers['Cookie'])
                        for key, morsel in c.items():
                            cookies[key] = morsel.value

                    session_id = cookies.get('session_id')
                    if not session_id or session_id not in _sessions_store:
                        session_id = secrets.token_hex(16)
                        _sessions_store[session_id] = SessionDict()

                    sess = _sessions_store[session_id]

                    # Parse POST form and files
                    form_data = {}
                    files_data = {}
                    json_data = {}

                    if method == 'POST':
                        content_type = self.headers.get('Content-Type', '')
                        content_length = int(self.headers.get('Content-Length', 0))
                        body_bytes = self.rfile.read(content_length)

                        if 'multipart/form-data' in content_type:
                            # Parse multipart data
                            boundary = content_type.split('boundary=')[-1].strip()
                            parts = body_bytes.split(b'--' + boundary.encode('utf-8'))
                            for part in parts:
                                if not part or part == b'--\r\n' or part == b'--':
                                    continue
                                if b'\r\n\r\n' in part:
                                    headers_part, body_part = part.split(b'\r\n\r\n', 1)
                                    # strip trailing \r\n
                                    if body_part.endswith(b'\r\n'):
                                        body_part = body_part[:-2]
                                    headers_text = headers_part.decode('latin1', errors='ignore')
                                    cd_match = re.search(r'Content-Disposition:\s*form-data;\s*name="([^"]+)"(?:;\s*filename="([^"]*)")?', headers_text, re.I)
                                    if cd_match:
                                        name = cd_match.group(1)
                                        filename = cd_match.group(2)
                                        if filename is not None:
                                            if filename:
                                                files_data[name] = RequestFile(filename, body_part)
                                        else:
                                            form_data[name] = body_part.decode('utf-8', errors='ignore')
                        elif 'application/json' in content_type:
                            try:
                                json_data = json.loads(body_bytes.decode('utf-8', errors='ignore'))
                            except Exception:
                                json_data = {}
                        else:
                            # Standard urlencoded
                            body_str = body_bytes.decode('utf-8', errors='ignore')
                            parsed_form = parse_qs(body_str)
                            form_data = parsed_form

                    # Setup Context
                    req_obj = RequestWrapper(
                        method=method,
                        path=path,
                        query_params=query_params,
                        form_data=form_data,
                        files_data=files_data,
                        cookies=cookies,
                        headers=self.headers,
                        json_data=json_data
                    )
                    _context_local.request = req_obj
                    _context_local.session = sess
                    _context_local.g = {}

                    # Match Route
                    endpoint, params, status_code = app.match_route(path, method)
                    if status_code == 404:
                        self.send_response(404)
                        self.send_header('Content-Type', 'text/html; charset=utf-8')
                        self.end_headers()
                        self.wfile.write(b"<h1>404 Not Found</h1><p>The requested URL was not found on the server.</p>")
                        return
                    if status_code == 405:
                        self.send_response(405)
                        self.send_header('Content-Type', 'text/html; charset=utf-8')
                        self.end_headers()
                        self.wfile.write(b"<h1>405 Method Not Allowed</h1>")
                        return

                    req_obj.endpoint = endpoint
                    r_entry = _url_map[endpoint]
                    handler_func = r_entry['func']

                    try:
                        # Before request hooks
                        for br_func in app.before_request_funcs:
                            br_res = br_func()
                            if br_res is not None:
                                self.send_handled_response(br_res, session_id)
                                return

                        # Call route handler
                        result = handler_func(**params)
                        self.send_handled_response(result, session_id)

                    except HTTPException as he:
                        self.send_response(he.code)
                        self.send_header('Content-Type', 'text/html; charset=utf-8')
                        self.end_headers()
                        self.wfile.write(f"<h1>{he.code} Error</h1><p>{he.message}</p>".encode('utf-8'))
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        self.send_response(500)
                        self.send_header('Content-Type', 'text/html; charset=utf-8')
                        self.end_headers()
                        self.wfile.write(f"<h1>500 Internal Server Error</h1><pre>{e}</pre>".encode('utf-8'))

                def send_handled_response(self, result, session_id):
                    cookie_header = f"session_id={session_id}; Path=/; HttpOnly"

                    if isinstance(result, tuple):
                        res_obj, code = result[0], result[1]
                        if isinstance(res_obj, JsonResponse):
                            res_obj.status_code = code
                            result = res_obj
                        elif isinstance(res_obj, ResponseRedirect):
                            res_obj.status_code = code
                            result = res_obj

                    if isinstance(result, ResponseRedirect):
                        self.send_response(result.status_code)
                        self.send_header('Location', result.location)
                        self.send_header('Set-Cookie', cookie_header)
                        self.end_headers()
                        return

                    if isinstance(result, JsonResponse):
                        content = json.dumps(result.data).encode('utf-8')
                        self.send_response(result.status_code)
                        self.send_header('Content-Type', 'application/json; charset=utf-8')
                        self.send_header('Content-Length', str(len(content)))
                        self.send_header('Set-Cookie', cookie_header)
                        self.end_headers()
                        self.wfile.write(content)
                        return

                    if isinstance(result, FileResponse):
                        mime, _ = mimetypes.guess_type(result.filepath)
                        self.send_response(200)
                        self.send_header('Content-Type', mime or 'application/octet-stream')
                        if result.as_attachment:
                            self.send_header('Content-Disposition', f'attachment; filename="{result.filename}"')
                        self.send_header('Set-Cookie', cookie_header)
                        self.end_headers()
                        with open(result.filepath, 'rb') as f:
                            self.wfile.write(f.read())
                        return

                    if isinstance(result, tuple):
                        content_str, code = result[0], result[1]
                    else:
                        content_str, code = result, 200

                    content_bytes = str(content_str).encode('utf-8')
                    self.send_response(code)
                    self.send_header('Content-Type', 'text/html; charset=utf-8')
                    self.send_header('Content-Length', str(len(content_bytes)))
                    self.send_header('Set-Cookie', cookie_header)
                    self.end_headers()
                    self.wfile.write(content_bytes)

            server_address = (host, port)
            httpd = http.server.ThreadingHTTPServer(server_address, CustomHandler)
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                httpd.server_close()

    class TestResponse:
        def __init__(self, status_code, data, headers=None):
            self.status_code = status_code
            self.data = data if isinstance(data, bytes) else str(data).encode('utf-8')
            self.headers = headers or {}

        @property
        def text(self):
            return self.data.decode('utf-8', errors='ignore')

        def get_json(self):
            try:
                return json.loads(self.text)
            except Exception:
                return None

    class TestClient:
        def __init__(self, app):
            self.app = app
            self.session_id = secrets.token_hex(16)
            self.session = SessionDict()
            _sessions_store[self.session_id] = self.session

        def get(self, path, **kwargs):
            return self.open(path, method='GET', **kwargs)

        def post(self, path, **kwargs):
            return self.open(path, method='POST', **kwargs)

        def open(self, path, method='GET', data=None, json=None, headers=None, follow_redirects=True):
            parsed = urlparse(path)
            req_path = parsed.path
            query_params = {k: v[0] if len(v) == 1 else v for k, v in parse_qs(parsed.query).items()}
            
            req_headers = dict(headers or {})
            form_data = FormDict()
            files_data = {}
            json_data = {}

            if json is not None:
                json_data = json
                req_headers['Content-Type'] = 'application/json'
            elif data is not None:
                if isinstance(data, dict):
                    d = {}
                    for k, v in data.items():
                        if isinstance(v, list):
                            d[k] = [str(x) for x in v]
                        elif isinstance(v, RequestFile):
                            files_data[k] = v
                        else:
                            d[k] = [str(v)]
                    form_data = FormDict(d)

            req_obj = RequestWrapper(
                method=method.upper(),
                path=req_path,
                query_params=query_params,
                form_data=form_data,
                files_data=files_data,
                cookies={'session_id': self.session_id},
                headers=req_headers,
                json_data=json_data
            )

            _context_local.request = req_obj
            _context_local.session = self.session
            _context_local.g = {}

            endpoint, params, status_code = self.app.match_route(req_path, method.upper())
            if status_code != 200:
                return TestResponse(status_code, f"Error {status_code}")

            req_obj.endpoint = endpoint
            r_entry = _url_map[endpoint]
            handler_func = r_entry['func']

            try:
                for br_func in self.app.before_request_funcs:
                    br_res = br_func()
                    if br_res is not None:
                        return self._convert_res(br_res, follow_redirects)

                result = handler_func(**params)
                return self._convert_res(result, follow_redirects)
            except HTTPException as he:
                return TestResponse(he.code, b"HTTP Exception")

        def _convert_res(self, res, follow_redirects):
            if isinstance(res, ResponseRedirect):
                if follow_redirects:
                    return self.open(res.location, method='GET', follow_redirects=True)
                return TestResponse(res.status_code, b"", {'Location': res.location})
            if isinstance(res, JsonResponse):
                return TestResponse(res.status_code, json.dumps(res.data).encode('utf-8'), {'Content-Type': 'application/json'})
            if isinstance(res, tuple):
                body, code = res[0], res[1]
                if isinstance(body, JsonResponse):
                    return TestResponse(code, json.dumps(body.data).encode('utf-8'), {'Content-Type': 'application/json'})
                return TestResponse(code, str(body).encode('utf-8'))
            return TestResponse(200, str(res).encode('utf-8'), {'Content-Type': 'text/html'})
