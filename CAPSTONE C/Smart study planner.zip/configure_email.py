"""
Gmail SMTP Configuration & Verification Tool for Smart Study Planner

Usage:
  Interactive configuration:
    python configure_email.py

  Direct configuration with arguments:
    python configure_email.py --email your-email@gmail.com --password "abcd efgh ijkl mnop"

  Check current configuration status:
    python configure_email.py --check

  Send a live test verification email:
    python configure_email.py --test-send recipient@gmail.com
"""

import os
import sys
import re
import argparse
from config import Config, BASE_DIR, load_env
from email_service import verify_smtp_credentials, send_email, is_email_configured

ENV_PATH = os.path.join(BASE_DIR, '.env')

def save_env_config(email, password, server="smtp.gmail.com", port=587, use_tls=True):
    """Writes or updates .env with the given SMTP credentials."""
    clean_password = password.strip().replace(" ", "")
    clean_email = email.strip()

    # Read existing lines if .env exists
    existing_lines = []
    keys_written = set()

    if os.path.exists(ENV_PATH):
        try:
            with open(ENV_PATH, 'r', encoding='utf-8-sig') as f:
                existing_lines = f.readlines()
        except Exception:
            existing_lines = []

    new_lines = []
    new_values = {
        'MAIL_SERVER': server,
        'MAIL_PORT': str(port),
        'MAIL_USE_TLS': 'true' if use_tls else 'false',
        'MAIL_USERNAME': clean_email,
        'MAIL_PASSWORD': clean_password,
        'MAIL_DEFAULT_SENDER': clean_email,
    }

    # Ensure SECRET_KEY is preserved or added
    secret_found = False
    for line in existing_lines:
        line_clean = line.strip()
        if not line_clean or line_clean.startswith('#') or '=' not in line_clean:
            new_lines.append(line)
            continue
        key = line_clean.split('=', 1)[0].strip()
        if key == 'SECRET_KEY':
            secret_found = True
            new_lines.append(line)
        elif key in new_values:
            new_lines.append(f"{key}={new_values[key]}\n")
            keys_written.add(key)
        else:
            new_lines.append(line)

    if not secret_found:
        new_lines.insert(0, f"SECRET_KEY={os.environ.get('SECRET_KEY', 'smart-study-planner-secret-key-2026')}\n")

    for k, v in new_values.items():
        if k not in keys_written:
            new_lines.append(f"{k}={v}\n")

    with open(ENV_PATH, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)

    # Force reload into current process
    load_env(force=True)

def print_setup_instructions():
    print("""
================================================================================
HOW TO GET A 16-CHARACTER GMAIL APP PASSWORD:
================================================================================
1. Open your Google Account: https://myaccount.google.com/
2. Go to 'Security' on the left menu.
3. Make sure '2-Step Verification' is turned ON.
4. Go to 'App passwords': https://myaccount.google.com/apppasswords
5. Enter an app name (e.g. 'SmartStudyPlanner') and click 'Create'.
6. Google will display a 16-letter password (e.g., 'abcd efgh ijkl mnop').
7. Copy and use that 16-character code as your MAIL_PASSWORD.
   (Note: Do NOT use your regular Gmail sign-in password!)
================================================================================
""")

def run_check():
    load_env(force=True)
    user = Config.MAIL_USERNAME
    pwd = Config.MAIL_PASSWORD
    print("=" * 70)
    print("CHECKING GMAIL SMTP CONFIGURATION STATUS")
    print("=" * 70)
    print(f"  • .env File:       {'[FOUND] ' + ENV_PATH if os.path.exists(ENV_PATH) else '[MISSING] (.env not created yet)'}")
    print(f"  • SMTP Server:     {Config.MAIL_SERVER}:{Config.MAIL_PORT} (TLS: {Config.MAIL_USE_TLS})")
    print(f"  • Gmail Address:   {user if user else '[NOT SET]'}")
    print(f"  • App Password:    {'*' * len(pwd) if pwd else '[NOT SET]'}")
    print("=" * 70)

    if not user or not pwd:
        print("\n[!] STATUS: Gmail SMTP is NOT configured.")
        print("    Email verification and forgot-password emails cannot be sent yet.")
        print_setup_instructions()
        print("To configure, run:\n    python configure_email.py --email your@gmail.com --password \"xxxx xxxx xxxx xxxx\"")
        return False

    print("\nTesting live connection to smtp.gmail.com:587...")
    ok, msg = verify_smtp_credentials()
    if ok:
        print(f"[✓] SUCCESS: {msg}")
        print("    Gmail SMTP is configured correctly and ready to send OTP emails!")
        return True
    else:
        print(f"[X] ERROR: {msg}")
        print_setup_instructions()
        return False

def main():
    parser = argparse.ArgumentParser(description="Configure and test Gmail SMTP for Smart Study Planner")
    parser.add_argument("--check", action="store_true", help="Check current SMTP configuration status")
    parser.add_argument("--email", type=str, help="Your full Gmail address")
    parser.add_argument("--password", type=str, help="Your 16-character Google App Password")
    parser.add_argument("--test-send", type=str, help="Send a test OTP email to this recipient address")
    args = parser.parse_args()

    if args.check:
        success = run_check()
        sys.exit(0 if success else 1)

    if args.test_send:
        recipient = args.test_send.strip()
        print(f"Sending test email to: {recipient}...")
        ok, err = send_email(
            to_email=recipient,
            subject="🎓 [Study Planner] SMTP Verification Test Email",
            html_content="<h2>It works!</h2><p>Your Smart Study Planner Gmail SMTP is configured properly.</p>",
            text_content="It works! Your Smart Study Planner Gmail SMTP is configured properly."
        )
        if ok:
            print("[✓] Test email sent successfully! Please check your inbox (and spam folder).")
            sys.exit(0)
        else:
            print(f"[X] Failed to send test email: {err}")
            sys.exit(1)

    if args.email and args.password:
        email = args.email.strip()
        password = args.password.strip().replace(" ", "")

        print(f"Verifying credentials for {email}...")
        ok, msg = verify_smtp_credentials(username=email, password=password)
        if not ok:
            print(f"[X] Authentication test failed: {msg}")
            print_setup_instructions()
            sys.exit(1)

        save_env_config(email, password)
        print(f"[✓] SUCCESS: {msg}")
        print(f"[✓] Credentials saved to: {ENV_PATH}")
        print("    You can now run 'python app.py' and register with live email verification!")
        sys.exit(0)

    # Interactive mode
    print("=" * 70)
    print("SMART STUDY PLANNER - GMAIL SMTP CONFIGURATION ASSISTANT")
    print("=" * 70)
    print("This utility helps you connect your Gmail account to send real OTP codes.")
    
    # Check if stdin is available
    if not sys.stdin.isatty():
        run_check()
        sys.exit(0)

    print_setup_instructions()

    try:
        email = input("Enter your Gmail address (e.g. name@gmail.com): ").strip()
        if not email or '@' not in email:
            print("[X] Invalid email address.")
            sys.exit(1)

        password = input("Enter your 16-character Google App Password: ").strip().replace(" ", "")
        if len(password) < 16:
            print("[!] Note: Google App Passwords are 16 characters long.")

        print("\nVerifying credentials with Gmail SMTP server...")
        ok, msg = verify_smtp_credentials(username=email, password=password)
        if not ok:
            print(f"[X] Authentication test failed: {msg}")
            sys.exit(1)

        save_env_config(email, password)
        print(f"\n[✓] SUCCESS: {msg}")
        print(f"[✓] Credentials saved to {ENV_PATH}")
        print("    Gmail SMTP is now ready!")
    except KeyboardInterrupt:
        print("\nConfiguration cancelled.")
        sys.exit(1)

if __name__ == '__main__':
    main()
