import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
_last_env_mtime = 0

def _parse_env_line(line):
    line = line.strip()
    if not line or line.startswith('#') or '=' not in line:
        return None, None
    k, v = line.split('=', 1)
    k = k.strip()
    v = v.strip()
    if len(v) >= 2 and ((v[0] == '"' and v[-1] == '"') or (v[0] == "'" and v[-1] == "'")):
        v = v[1:-1]
    elif '#' in v:
        v = v.split('#', 1)[0].strip()
    return k, v

def load_env(filepath=None, force=False):
    """
    Safely loads .env file into os.environ.
    Uses 'utf-8-sig' to automatically handle Windows UTF-8 BOM.
    """
    global _last_env_mtime
    if filepath is None:
        filepath = os.path.join(BASE_DIR, '.env')
    if not os.path.isfile(filepath):
        return {}
    try:
        current_mtime = os.path.getmtime(filepath)
        if not force and current_mtime == _last_env_mtime:
            return {}
        _last_env_mtime = current_mtime
        loaded = {}
        with open(filepath, 'r', encoding='utf-8-sig') as f:
            for line in f:
                k, v = _parse_env_line(line)
                if k:
                    loaded[k] = v
                    os.environ[k] = v
        return loaded
    except Exception:
        return {}

# Initial load
load_env(force=True)

class ConfigMeta(type):
    """Metaclass that provides dynamically re-evaluated properties for Config."""
    @property
    def MAIL_SERVER(cls):
        load_env()
        return os.environ.get('MAIL_SERVER', 'smtp.gmail.com').strip()

    @property
    def MAIL_PORT(cls):
        load_env()
        try:
            return int(os.environ.get('MAIL_PORT', 587))
        except Exception:
            return 587

    @property
    def MAIL_USE_TLS(cls):
        load_env()
        return os.environ.get('MAIL_USE_TLS', 'true').lower() in ('true', '1', 't', 'yes')

    @property
    def MAIL_USERNAME(cls):
        load_env()
        return os.environ.get('MAIL_USERNAME', '').strip()

    @property
    def MAIL_PASSWORD(cls):
        load_env()
        # Automatically strip spaces from Google App Passwords
        return os.environ.get('MAIL_PASSWORD', '').strip().replace(' ', '')

    @property
    def MAIL_DEFAULT_SENDER(cls):
        load_env()
        return os.environ.get('MAIL_DEFAULT_SENDER', '').strip() or cls.MAIL_USERNAME

    @property
    def TESTING(cls):
        return getattr(cls, '_testing_mode', False) or os.environ.get('TESTING', 'false').lower() in ('true', '1', 't', 'yes')

    @TESTING.setter
    def TESTING(cls, val):
        cls._testing_mode = bool(val)

class Config(metaclass=ConfigMeta):
    _testing_mode = False
    SECRET_KEY = os.environ.get('SECRET_KEY', 'smart-study-planner-secret-key-2026')
    DATABASE = os.path.join(BASE_DIR, 'instance', 'studyplanner.db')
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload size
    ALLOWED_EXTENSIONS = {'pdf', 'ppt', 'pptx', 'doc', 'docx', 'txt', 'png', 'jpg', 'jpeg'}
