"""
Integration and Flow Test Suite for Teacher Dashboard & Shared Classroom System
Covers all 16 required test scenarios:
1. Teacher registration and login
2. Student registration and login
3. Teacher creates classroom with unique code (e.g. PYAI27K)
4. Student joins classroom with valid code (case/space-insensitive)
5. Student joins classroom with invalid code
6. Student already enrolled prevention
7. Teacher posts announcement
8. Student views announcement
9. Teacher uploads study material
10. Teacher creates manual quiz
11. Teacher generates AI quiz (MUST NOT auto-publish: is_published == 0)
12. Teacher reviews, edits, and publishes AI quiz (is_published == 1)
13. Student takes classroom quiz and submits answers
14. Shared performance updates topic mastery and adapts timetable
15. Teacher views students needing attention (low score / overdue signals)
16. Teacher views classroom reports and analytics
"""

import os
import sys
import unittest
from datetime import datetime, timedelta

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from config import Config
TEST_DB_PATH = os.path.join(BASE_DIR, 'instance', 'test_studyplanner.db')
Config.DATABASE = TEST_DB_PATH
Config.TESTING = True

from database import init_db, get_db
from models import (
    UserModel, SubjectModel, TopicModel, MaterialModel,
    AssignmentModel, QuizModel, TimetableModel, StatsModel, AnnouncementModel
)
from ai_quiz import AIQuizEngine
from ai_analysis import PerformanceAnalyzer
from app import create_app

def setup_clean_db():
    if os.path.exists(TEST_DB_PATH):
        try:
            os.remove(TEST_DB_PATH)
        except Exception:
            pass
    init_db()

class TestTeacherAndClassroomSystem(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        setup_clean_db()
        cls.app = create_app()

    def setUp(self):
        self.client = self.app.test_client()

    def test_01_teacher_registration_and_login(self):
        """Test 1: Teacher registers, logs in, and accesses Teacher Dashboard."""
        tch_id, err = UserModel.create_user(
            role='teacher',
            name='Prof. Alan Turing',
            email='turing@cs.edu',
            password='Password@123',
            identifier='FAC-1001',
            department='Computer Science',
            subjects_handled='Artificial Intelligence'
        )
        self.assertIsNone(err)
        self.assertIsNotNone(tch_id)

        # Login
        res = self.client.post('/login', data={
            'email': 'turing@cs.edu',
            'password': 'Password@123',
            'role': 'teacher'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(self.client.session.get('user_id'), tch_id)
        self.assertEqual(self.client.session.get('role'), 'teacher')
        self.assertIn("Faculty Control Center", res.text)

    def test_02_student_registration_and_login(self):
        """Test 2: Student registers, logs in, and accesses Student Dashboard."""
        stu_id, err = UserModel.create_user(
            role='student',
            name='Ada Lovelace',
            email='ada@cs.edu',
            password='Password@123',
            identifier='ROLL-2026',
            department='Computer Science',
            year_of_study='2nd Year',
            semester='Semester 3'
        )
        self.assertIsNone(err)
        self.assertIsNotNone(stu_id)

        # Login
        res = self.client.post('/login', data={
            'email': 'ada@cs.edu',
            'password': 'Password@123',
            'role': 'student'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(self.client.session.get('user_id'), stu_id)
        self.assertEqual(self.client.session.get('role'), 'student')
        self.assertIn("Dashboard", res.text)

    def test_03_teacher_creates_classroom(self):
        """Test 3: Teacher creates a classroom and system generates a unique Class Code."""
        # Login teacher
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        
        res = self.client.post('/teacher/classrooms/create', data={
            'name': 'Python Programming & AI 2026',
            'code': 'PYAI101',
            'academic_year': '2nd Year',
            'department': 'Computer Science',
            'description': 'Core programming and intelligent systems concepts.'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("Classroom 'Python Programming & AI 2026' created successfully", res.text)

        # Check in DB
        subject = SubjectModel.get_by_code('PYAI101')
        self.assertIsNotNone(subject)
        self.assertEqual(subject['name'], 'Python Programming & AI 2026')
        self.assertEqual(subject['academic_year'], '2nd Year')
        self.assertTrue(len(subject['enrolment_code']) >= 5)
        # Store for subsequent tests
        TestTeacherAndClassroomSystem.classroom_id = subject['id']
        TestTeacherAndClassroomSystem.class_code = subject['enrolment_code']

    def test_04_student_joins_classroom_valid_code(self):
        """Test 4: Student enters valid class code (case-insensitive & space-tolerant) and joins."""
        self.client.post('/login', data={'email': 'ada@cs.edu', 'password': 'Password@123', 'role': 'student'})

        # Test case-insensitivity and extra whitespace
        code_input = f"  {self.class_code.lower()}  "
        res = self.client.post('/student/classrooms/join', data={
            'enrolment_code': code_input
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("Successfully enrolled", res.text)

        # Verify enrolled in DB
        stu = UserModel.get_by_email('ada@cs.edu')
        self.assertTrue(SubjectModel.is_student_enrolled(stu['id'], self.classroom_id))

        # Classroom appears in My Classrooms
        classrooms_res = self.client.get('/student/classrooms')
        self.assertEqual(classrooms_res.status_code, 200)
        self.assertIn("Python Programming & AI 2026", classrooms_res.text)

    def test_05_student_joins_classroom_invalid_code(self):
        """Test 5: Student enters non-existent class code -> clear error message."""
        self.client.post('/login', data={'email': 'ada@cs.edu', 'password': 'Password@123', 'role': 'student'})
        res = self.client.post('/student/classrooms/join', data={
            'enrolment_code': 'NONEXISTENT999'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("No class found with this code", res.text)

    def test_06_student_already_enrolled(self):
        """Test 6: Student attempts to re-enter code for already-joined class -> friendly message."""
        self.client.post('/login', data={'email': 'ada@cs.edu', 'password': 'Password@123', 'role': 'student'})
        res = self.client.post('/student/classrooms/join', data={
            'enrolment_code': self.class_code
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("already enrolled", res.text)

    def test_07_teacher_posts_announcement(self):
        """Test 7: Teacher posts an announcement to the classroom."""
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        res = self.client.post('/teacher/announcements/create', data={
            'subject_id': self.classroom_id,
            'title': 'Welcome to Python & AI Course',
            'message': 'Please review the lecture notes on Variables and Functions before Friday.'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("Welcome to Python & AI Course", res.text)

        announcements = AnnouncementModel.get_by_subject(self.classroom_id)
        self.assertEqual(len(announcements), 1)
        self.assertEqual(announcements[0]['title'], 'Welcome to Python & AI Course')

    def test_08_student_views_announcement(self):
        """Test 8: Student views announcements in classroom view."""
        self.client.post('/login', data={'email': 'ada@cs.edu', 'password': 'Password@123', 'role': 'student'})
        res = self.client.get(f'/student/classrooms/{self.classroom_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn("Welcome to Python & AI Course", res.text)
        self.assertIn("Variables and Functions", res.text)

    def test_09_teacher_uploads_material(self):
        """Test 9: Teacher adds study material with topic tagging."""
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        res = self.client.post('/materials/teacher/upload', data={
            'subject_id': self.classroom_id,
            'title': 'Introduction to Control Structures',
            'topic': 'Control Flow',
            'material_type': 'link',
            'external_link': 'https://docs.python.org/3/tutorial/controlflow.html',
            'description': 'Official documentation on if statements and loops.'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        materials = MaterialModel.get_by_subject(self.classroom_id)
        self.assertEqual(len(materials), 1)
        self.assertEqual(materials[0]['title'], 'Introduction to Control Structures')
        self.assertEqual(materials[0]['topic'], 'Control Flow')

    def test_10_teacher_creates_manual_quiz(self):
        """Test 10: Teacher creates a manual quiz with questions and explanation."""
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        
        # Create quiz shell
        res = self.client.post('/quizzes/teacher/create', data={
            'subject_id': self.classroom_id,
            'title': 'Conditionals & Loops Diagnostic',
            'topic': 'Control Flow',
            'duration_minutes': '20',
            'description': 'Assessing if-else statements and while loops.'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Get created quiz
        quizzes = QuizModel.get_by_subject(self.classroom_id)
        manual_quiz = [q for q in quizzes if q['title'] == 'Conditionals & Loops Diagnostic'][0]

        # Add question
        res_q = self.client.post(f'/quizzes/teacher/{manual_quiz["id"]}/questions', data={
            'question_text': 'What keyword in Python is used to exit a loop early?',
            'topic': 'Control Flow',
            'option_a': 'exit',
            'option_b': 'break',
            'option_c': 'return',
            'option_d': 'stop',
            'correct_option': 'B',
            'explanation': 'The break statement terminates the nearest enclosing loop.'
        }, follow_redirects=True)
        self.assertEqual(res_q.status_code, 200)

        questions = QuizModel.get_questions(manual_quiz['id'])
        self.assertEqual(len(questions), 1)
        self.assertEqual(questions[0]['correct_option'], 'B')

    def test_11_teacher_generates_ai_quiz_must_not_auto_publish(self):
        """Test 11: Teacher generates AI quiz -> MUST NOT auto-publish (is_published == 0)."""
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        
        res = self.client.post('/quizzes/teacher/generate-ai', data={
            'subject_id': self.classroom_id,
            'topic': 'Arrays and Pointers',
            'difficulty': 'Medium',
            'question_count': '3',
            'title': 'Data Structures: Arrays Diagnostic'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn("Draft mode", res.text)

        # CRITICAL VERIFICATION: Quiz must have is_published == 0
        conn = get_db()
        quiz_row = conn.execute("SELECT * FROM quizzes WHERE title = 'Data Structures: Arrays Diagnostic'").fetchone()
        conn.close()

        self.assertIsNotNone(quiz_row)
        self.assertEqual(quiz_row['is_published'], 0, "AI Quiz must be created as Draft (is_published == 0)!")
        
        # Verify 3 questions generated
        questions = QuizModel.get_questions(quiz_row['id'])
        self.assertEqual(len(questions), 3)
        TestTeacherAndClassroomSystem.ai_quiz_id = quiz_row['id']
        TestTeacherAndClassroomSystem.ai_question_id = questions[0]['id']

    def test_12_teacher_reviews_and_publishes_ai_quiz(self):
        """Test 12: Teacher reviews generated questions, edits a question, and publishes."""
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        
        # Review page
        res = self.client.get(f'/quizzes/teacher/{self.ai_quiz_id}/questions')
        self.assertEqual(res.status_code, 200)
        self.assertIn("Draft Review Mode", res.text)

        # Edit question
        edit_res = self.client.post(f'/quizzes/teacher/{self.ai_quiz_id}/questions/{self.ai_question_id}/edit', data={
            'question_text': 'Edited: What is the indexing complexity in a contiguous Array?',
            'option_a': 'O(1)',
            'option_b': 'O(n)',
            'option_c': 'O(log n)',
            'option_d': 'O(n^2)',
            'correct_option': 'A',
            'explanation': 'Contiguous memory allows direct index address calculation in constant time.',
            'difficulty': 'Easy'
        }, follow_redirects=True)
        self.assertEqual(edit_res.status_code, 200)

        # Publish quiz
        pub_res = self.client.post(f'/quizzes/teacher/{self.ai_quiz_id}/publish', follow_redirects=True)
        self.assertEqual(pub_res.status_code, 200)
        self.assertIn("published", pub_res.text.lower())

        # Verify in DB
        quiz = QuizModel.get_by_id(self.ai_quiz_id)
        self.assertEqual(quiz['is_published'], 1)

    def test_13_student_takes_classroom_quiz(self):
        """Test 13: Student takes published classroom quiz and submits answers."""
        self.client.post('/login', data={'email': 'ada@cs.edu', 'password': 'Password@123', 'role': 'student'})
        
        # Open take quiz page
        take_res = self.client.get(f'/quizzes/student/take/{self.ai_quiz_id}')
        self.assertEqual(take_res.status_code, 200)

        # Submit answers: answering question 1 with 'A' (correct) and others with 'B'
        questions = QuizModel.get_questions(self.ai_quiz_id)
        form_data = {f"q_{q['id']}": q['correct_option'] for q in questions}  # Answer 100% correct
        
        sub_res = self.client.post(f'/quizzes/student/submit/{self.ai_quiz_id}', data=form_data, follow_redirects=True)
        self.assertEqual(sub_res.status_code, 200)
        self.assertIn("100.0%", sub_res.text)

    def test_14_shared_performance_and_adaptive_timetable(self):
        """Test 14: Shared performance data updates topic mastery, personal timetable, and teacher analytics."""
        stu = UserModel.get_by_email('ada@cs.edu')
        analysis = PerformanceAnalyzer.analyze_student(stu['id'])
        self.assertTrue(analysis['has_data'])
        self.assertEqual(analysis['overall_average'], 100.0)

        # Teacher views student performance and class analytics
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        perf_res = self.client.get(f'/teacher/performance/{stu["id"]}')
        self.assertEqual(perf_res.status_code, 200)
        self.assertIn("Ada Lovelace", perf_res.text)
        self.assertIn("100.0%", perf_res.text)

    def test_15_teacher_students_needing_attention(self):
        """Test 15: Student with low quiz score or overdue assignment triggers attention signal."""
        # Create a struggling student
        struggling_id, _ = UserModel.create_user(
            role='student',
            name='Struggling Student',
            email='struggle@cs.edu',
            password='Password@123',
            identifier='ROLL-FAIL',
            department='Computer Science'
        )
        SubjectModel.enroll_student(struggling_id, self.class_code)

        # Create an assignment with past due date (overdue)
        AssignmentModel.create_assignment(
            subject_id=self.classroom_id,
            teacher_id=SubjectModel.get_by_id(self.classroom_id)['teacher_id'],
            title='Overdue Laboratory 1',
            topic='Control Flow',
            description='Due yesterday',
            due_date='2020-01-01',
            priority='High'
        )

        # Student takes quiz and scores 0% (answering wrong option)
        questions = QuizModel.get_questions(self.ai_quiz_id)
        wrong_answers = {str(q['id']): 'D' if q['correct_option'] != 'D' else 'C' for q in questions}
        QuizModel.evaluate_and_record_attempt(self.ai_quiz_id, struggling_id, wrong_answers)

        # Teacher checks students needing attention
        tch = UserModel.get_by_email('turing@cs.edu')
        attention_list = StatsModel.get_students_needing_attention(tch['id'])
        self.assertTrue(len(attention_list) >= 1)
        
        struggle_entry = [a for a in attention_list if a['student_id'] == struggling_id]
        self.assertTrue(len(struggle_entry) == 1)
        self.assertEqual(struggle_entry[0]['badge'], 'danger')
        self.assertIn("Low Quiz Average", struggle_entry[0]['primary_reason'])

    def test_16_teacher_reports_page(self):
        """Test 16: Teacher accesses comprehensive reports page with topic mastery & score brackets."""
        self.client.post('/login', data={'email': 'turing@cs.edu', 'password': 'Password@123', 'role': 'teacher'})
        res = self.client.get('/teacher/reports')
        self.assertEqual(res.status_code, 200)
        self.assertIn("Classroom Academic Reports", res.text)
        self.assertIn("Classroom Performance Comparison", res.text)
        self.assertIn("Score Distribution Brackets", res.text)
        self.assertIn("Topic Mastery Breakdown", res.text)

    def test_17_student_daily_timetable_presentation(self):
        """Test 17: Verify daily-based timetable presentation without weekly explanations table."""
        stu = UserModel.get_by_email('ada@cs.edu')
        self.client.post('/login', data={'email': 'ada@cs.edu', 'password': 'Password@123', 'role': 'student'})

        # Generate a balanced timetable with study slots and breaks
        TimetableModel.generate_timetable_schedule(stu['id'], [self.classroom_id], daily_hours=2.5)

        # Access timetable page
        res = self.client.get('/timetable/student')
        self.assertEqual(res.status_code, 200)

        # 1. Verify weekly explanation table and its headers are removed
        self.assertNotIn("Previous Weekly Time", res.text)
        self.assertNotIn("New Weekly Time", res.text)
        self.assertNotIn("Delta", res.text)
        self.assertNotIn("Explanation for Change", res.text)

        # 2. Verify daily schedule section and required headers are present
        self.assertIn("Daily Study Schedule", res.text)
        self.assertIn("Time & Duration", res.text)
        self.assertIn("Subject & Topic", res.text)
        self.assertIn("Study Date / Day", res.text)
        self.assertIn("Study Status", res.text)

        # 3. Verify session fields: duration, start/end time, subject, topic
        sessions = TimetableModel.get_student_sessions(stu['id'])
        self.assertTrue(len(sessions) > 0)
        study_sess = [s for s in sessions if s['session_type'] == 'study'][0]
        self.assertIn(study_sess['subject_name'], res.text)
        self.assertIn(study_sess['topic'], res.text)

        # 4. Verify study status displays (Pending or Completed)
        self.assertTrue("Pending" in res.text or "Completed" in res.text)

        # 5. Verify session completion toggle works
        toggle_res = self.client.post(f'/timetable/student/session/{study_sess["id"]}/toggle')
        self.assertEqual(toggle_res.status_code, 200)
        self.assertIn("Completed", toggle_res.text)

        # 6. Verify Re-optimize Schedule functionality
        adapt_res = self.client.post('/timetable/student/adapt')
        self.assertEqual(adapt_res.status_code, 200)
        self.assertIn("AI Timetable v", adapt_res.text)

if __name__ == '__main__':
    unittest.main()
