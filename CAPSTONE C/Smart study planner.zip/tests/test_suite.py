"""
Automated Test Suite for Smart Study Planner
Covers all mandatory test requirements from Prompt 2 Section 11:
- Application startup tests (Tests 1-7)
- Quiz system test cases (Test Cases 1-7)
- Topic analysis test cases (Test Cases 8-13)
- Adaptive timetable test cases (Test Cases 14-22)
- Teacher dashboard test cases (Test Cases 23-25)
- Existing feature regression tests (Prompt 1 regression + CSA0207 enrolment)
- Final end-to-end integration test (16-step teacher/student workflow)

Uses a dedicated isolated SQLite test database to ensure existing production
and seeded demo data remain completely unaffected.
"""

import os
import sys
import unittest
from datetime import datetime, timedelta

# Ensure root directory is in sys.path
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from config import Config

# Point to dedicated test database
TEST_DB_PATH = os.path.join(BASE_DIR, 'instance', 'test_studyplanner.db')
Config.DATABASE = TEST_DB_PATH
Config.TESTING = True

from database import init_db, get_db
from email_service import outbox
from models import (
    UserModel, SubjectModel, TopicModel, MaterialModel, 
    AssignmentModel, QuizModel, TimetableModel, StatsModel
)
from ai_quiz import (
    AIQuizEngine, generate_topic_questions, 
    create_ai_practice_quiz, TOPIC_QUESTION_BANK
)
from ai_analysis import PerformanceAnalyzer
from ai_recommendations import RecommendationEngine
from adaptive_timetable import AdaptiveTimetableEngine
from compat import check_password_hash
from app import create_app


def setup_clean_test_db():
    """Initializes a fresh, clean test database."""
    if os.path.exists(TEST_DB_PATH):
        try:
            os.remove(TEST_DB_PATH)
        except Exception:
            pass
    init_db()


class TestApplicationStartup(unittest.TestCase):
    """Prompt 2 Section 11.A: Application startup tests (Tests 1-7)"""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.app = create_app()
        cls.client = cls.app.test_client()

    def test_01_flask_application_startup(self):
        """Test 1: Flask application starts without errors."""
        self.assertIsNotNone(self.app, "Flask application instance failed to initialize.")

    def test_02_all_python_modules_import(self):
        """Test 2: All required Python modules import successfully."""
        import database
        import models
        import ai_quiz
        import ai_analysis
        import ai_recommendations
        import adaptive_timetable
        import compat
        import config
        import seed_demo_data
        self.assertTrue(hasattr(ai_quiz, 'create_ai_practice_quiz'))
        self.assertTrue(hasattr(ai_analysis, 'PerformanceAnalyzer'))
        self.assertTrue(hasattr(adaptive_timetable, 'AdaptiveTimetableEngine'))
        self.assertTrue(hasattr(ai_recommendations, 'RecommendationEngine'))

    def test_03_database_connection(self):
        """Test 3: Database connection works with row factory and foreign keys."""
        conn = get_db()
        self.assertIsNotNone(conn)
        cursor = conn.cursor()
        fk_check = cursor.execute("PRAGMA foreign_keys;").fetchone()[0]
        self.assertEqual(fk_check, 1, "Foreign key constraints are not enabled.")
        conn.close()

    def test_04_database_migrations_and_tables(self):
        """Test 4: Database schema and tables execute successfully."""
        conn = get_db()
        tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        conn.close()
        required_tables = [
            'users', 'subjects', 'enrolments', 'study_materials', 'assignments',
            'assignment_submissions', 'quizzes', 'quiz_questions', 'quiz_attempts',
            'quiz_attempt_answers', 'timetables', 'timetable_sessions',
            'topics', 'timetable_versions', 'timetable_adaptations', 'study_recommendations'
        ]
        for t in required_tables:
            self.assertIn(t, tables, f"Mandatory table '{t}' is missing from schema.")

    def test_05_required_routes_registered(self):
        """Test 5: All required application routes are registered."""
        rule_map = [r['rule'] for r in self.app.routes]
        for bp, _ in self.app.blueprints:
            for r in bp.routes:
                prefix = bp.url_prefix.rstrip('/')
                rule_map.append(f"{prefix}/{r['rule'].lstrip('/')}")
        
        # Verify key endpoints
        expected_endpoints = ['/', '/login', '/logout', '/student/dashboard', '/teacher/dashboard']
        for ep in expected_endpoints:
            endpoint_match, _, _ = self.app.match_route(ep, 'GET')
            self.assertIsNotNone(endpoint_match, f"Route {ep} is not properly mapped.")

    def test_06_student_and_teacher_login(self):
        """Test 6: Student and teacher login authentication works."""
        # Create student and teacher
        stu_id, _ = UserModel.create_user(
            role='student', name='Startup Stu', email='start_stu@test.com',
            password='Password123', identifier='STU-001', department='CSE'
        )
        tch_id, _ = UserModel.create_user(
            role='teacher', name='Startup Prof', email='start_tch@test.com',
            password='Password123', identifier='TCH-001', department='CSE'
        )
        # Test student login
        c_stu = self.app.test_client()
        res_stu = c_stu.post('/login', data={'email': 'start_stu@test.com', 'password': 'Password123', 'role': 'student'})
        self.assertEqual(c_stu.session.get('user_id'), stu_id)
        self.assertEqual(c_stu.session.get('role'), 'student')

        # Test teacher login
        c_tch = self.app.test_client()
        res_tch = c_tch.post('/login', data={'email': 'start_tch@test.com', 'password': 'Password123', 'role': 'teacher'})
        self.assertEqual(c_tch.session.get('user_id'), tch_id)
        self.assertEqual(c_tch.session.get('role'), 'teacher')

    def test_07_existing_dashboard_pages_load(self):
        """Test 7: Existing dashboard pages load successfully (HTTP 200)."""
        # Load student dashboard
        c_stu = self.app.test_client()
        c_stu.post('/login', data={'email': 'start_stu@test.com', 'password': 'Password123', 'role': 'student'})
        res_stu = c_stu.get('/student/dashboard')
        self.assertEqual(res_stu.status_code, 200)
        self.assertIn("Study Planner", res_stu.text)

        # Load teacher dashboard
        c_tch = self.app.test_client()
        c_tch.post('/login', data={'email': 'start_tch@test.com', 'password': 'Password123', 'role': 'teacher'})
        res_tch = c_tch.get('/teacher/dashboard')
        self.assertEqual(res_tch.status_code, 200)
        self.assertIn("Teacher Dashboard", res_tch.text)


class TestQuizSystem(unittest.TestCase):
    """Prompt 2 Section 11.B: Quiz system test cases (Test Cases 1-7)"""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.app = create_app()
        cls.teacher_id, _ = UserModel.create_user(
            'teacher', 'Quiz Prof', 'quiz_prof@test.com', 'Pass@123', 'TCH-Q', 'Computer Science'
        )
        cls.student_id, _ = UserModel.create_user(
            'student', 'Quiz Stu', 'quiz_stu@test.com', 'Pass@123', 'STU-Q', 'Computer Science'
        )
        cls.subject_id, cls.code = SubjectModel.create_subject(
            cls.teacher_id, 'CS101', 'Programming in Python', 'Computer Science', 'Core programming concepts'
        )
        SubjectModel.enroll_student(cls.student_id, cls.code)

    def test_case_01_generate_quiz_subject_topic(self):
        """Test Case 1: Generate a quiz for a selected subject and topic with 4 options and correct answer."""
        questions = generate_topic_questions("Programming in Python", "Loops", 3, "Medium")
        self.assertGreaterEqual(len(questions), 3)
        for q in questions:
            self.assertIn('question', q)
            self.assertIn('options', q)
            self.assertIn('A', q['options'])
            self.assertIn('B', q['options'])
            self.assertIn('C', q['options'])
            self.assertIn('D', q['options'])
            self.assertIn(q['correct'], ['A', 'B', 'C', 'D'])

    def test_case_02_generate_quiz_difficulties(self):
        """Test Case 2: Generate quizzes at Easy, Medium and Hard difficulty."""
        q_easy = AIQuizEngine.generate_questions("Semiconductor Physics", difficulty="Easy", count=2)
        q_med = AIQuizEngine.generate_questions("Semiconductor Physics", difficulty="Medium", count=2)
        q_hard = AIQuizEngine.generate_questions("Semiconductor Physics", difficulty="Hard", count=2)
        self.assertGreater(len(q_easy), 0)
        self.assertGreater(len(q_med), 0)
        self.assertGreater(len(q_hard), 0)

    def test_case_03_submit_quiz_all_correct(self):
        """Test Case 3: Submit a quiz with all correct answers -> Score is 100%."""
        quiz_id = QuizModel.create_quiz(self.subject_id, self.teacher_id, 'Perfect Quiz', 'Loops', 'All correct test', 10)
        q1_id = QuizModel.add_question(quiz_id, 'Loops', 'Q1?', 'A', 'B', 'C', 'D', 'A', 'Exp', 'Medium')
        q2_id = QuizModel.add_question(quiz_id, 'Loops', 'Q2?', 'A', 'B', 'C', 'D', 'C', 'Exp', 'Medium')

        answers = {str(q1_id): 'A', str(q2_id): 'C'}
        result, err = QuizModel.evaluate_and_record_attempt(quiz_id, self.student_id, answers, time_taken_seconds=90)
        self.assertIsNone(err)
        self.assertEqual(result['score_percentage'], 100.0)
        self.assertEqual(result['correct_answers'], 2)
        self.assertEqual(result['total_questions'], 2)

    def test_case_04_submit_quiz_all_incorrect(self):
        """Test Case 4: Submit a quiz with all incorrect answers -> Score is 0%."""
        quiz_id = QuizModel.create_quiz(self.subject_id, self.teacher_id, 'Zero Quiz', 'Loops', 'All wrong test', 10)
        q1_id = QuizModel.add_question(quiz_id, 'Loops', 'Q1?', 'A', 'B', 'C', 'D', 'A', 'Exp', 'Medium')
        q2_id = QuizModel.add_question(quiz_id, 'Loops', 'Q2?', 'A', 'B', 'C', 'D', 'C', 'Exp', 'Medium')

        answers = {str(q1_id): 'B', str(q2_id): 'D'}
        result, err = QuizModel.evaluate_and_record_attempt(quiz_id, self.student_id, answers, time_taken_seconds=60)
        self.assertIsNone(err)
        self.assertEqual(result['score_percentage'], 0.0)
        self.assertEqual(result['correct_answers'], 0)

    def test_case_05_submit_quiz_mixed_answers(self):
        """Test Case 5: Submit a quiz with mixed correct and incorrect answers -> Correct score and percentage."""
        quiz_id = QuizModel.create_quiz(self.subject_id, self.teacher_id, 'Mixed Quiz', 'Loops', 'Half right test', 10)
        q1_id = QuizModel.add_question(quiz_id, 'Loops', 'Q1?', 'A', 'B', 'C', 'D', 'A', 'Exp', 'Medium')
        q2_id = QuizModel.add_question(quiz_id, 'Loops', 'Q2?', 'A', 'B', 'C', 'D', 'C', 'Exp', 'Medium')

        answers = {str(q1_id): 'A', str(q2_id): 'B'} # 1 right, 1 wrong
        result, err = QuizModel.evaluate_and_record_attempt(quiz_id, self.student_id, answers, time_taken_seconds=75)
        self.assertIsNone(err)
        self.assertEqual(result['score_percentage'], 50.0)
        self.assertEqual(result['correct_answers'], 1)
        self.assertEqual(result['total_questions'], 2)

    def test_case_06_submit_invalid_quiz_request(self):
        """Test Case 6: Submit an incomplete or invalid quiz request -> Proper validation and error message."""
        # Non-existent quiz
        result, err = QuizModel.evaluate_and_record_attempt(99999, self.student_id, {})
        self.assertIsNone(result)
        self.assertIn("Quiz not found", str(err))

        # API validation test for AI quiz creation with missing fields
        client = self.app.test_client()
        client.post('/login', data={'email': 'quiz_stu@test.com', 'password': 'Pass@123', 'role': 'student'})
        res = client.post('/quizzes/student/generate-ai', json={})
        self.assertEqual(res.status_code, 400)
        self.assertIn("error", res.get_json())

    def test_case_07_quiz_attempts_and_answers_saved_sqlite(self):
        """Test Case 7: Check whether quiz attempts and individual answers are saved in SQLite."""
        quiz_id = QuizModel.create_quiz(self.subject_id, self.teacher_id, 'Storage Quiz', 'Loops', 'Save verification', 10)
        q1_id = QuizModel.add_question(quiz_id, 'Loops', 'Q_Save?', 'A', 'B', 'C', 'D', 'B', 'Exp', 'Medium')
        
        result, _ = QuizModel.evaluate_and_record_attempt(quiz_id, self.student_id, {str(q1_id): 'B'}, time_taken_seconds=42)
        attempt_id = result['attempt_id']

        conn = get_db()
        attempt_row = conn.execute("SELECT * FROM quiz_attempts WHERE id = ?", (attempt_id,)).fetchone()
        ans_rows = conn.execute("SELECT * FROM quiz_attempt_answers WHERE attempt_id = ?", (attempt_id,)).fetchall()
        conn.close()

        self.assertIsNotNone(attempt_row)
        self.assertEqual(attempt_row['score_percentage'], 100.0)
        self.assertEqual(attempt_row['time_taken_seconds'], 42)
        self.assertEqual(len(ans_rows), 1)
        self.assertEqual(ans_rows[0]['selected_option'], 'B')
        self.assertEqual(ans_rows[0]['is_correct'], 1)


class TestTopicAnalysis(unittest.TestCase):
    """Prompt 2 Section 11.C: Topic analysis test cases (Test Cases 8-13)"""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.teacher_id, _ = UserModel.create_user('teacher', 'Analytics Prof', 'an_prof@test.com', 'P@123', 'T-AN', 'Science')
        cls.student_id, _ = UserModel.create_user('student', 'Analytics Stu', 'an_stu@test.com', 'P@123', 'S-AN', 'Science')
        cls.subject_id, cls.code = SubjectModel.create_subject(cls.teacher_id, 'SCI101', 'Physical Sciences', 'Science', 'Physics')
        SubjectModel.enroll_student(cls.student_id, cls.code)

    def _simulate_quiz_attempt(self, topic, score_pct, minutes_ago=0):
        """Helper to inject an attempt with specific topic and accuracy."""
        quiz_id = QuizModel.create_quiz(self.subject_id, self.teacher_id, f'Quiz on {topic}', topic, 'desc', 10)
        # Add 10 questions
        q_ids = []
        for i in range(10):
            qid = QuizModel.add_question(quiz_id, topic, f"Q{i}?", "A", "B", "C", "D", "A", "exp", "Medium")
            q_ids.append(qid)
        
        # Decide how many to answer correctly
        correct_count = int(round((score_pct / 100.0) * 10))
        answers = {}
        for i, qid in enumerate(q_ids):
            answers[str(qid)] = 'A' if i < correct_count else 'B'

        result, _ = QuizModel.evaluate_and_record_attempt(quiz_id, self.student_id, answers)
        return result

    def test_case_08_strong_topic_classification(self):
        """Test Case 8: Student scores 90% in a topic -> classified as Strong (>=80%)."""
        self._simulate_quiz_attempt("Newtonian Mechanics", 90.0)
        analysis = PerformanceAnalyzer.analyze_student(self.student_id)
        strong_names = [t['topic'] for t in analysis['strong_topics']]
        self.assertIn("Newtonian Mechanics", strong_names)

    def test_case_09_weak_topic_classification(self):
        """Test Case 9: Student scores 35% in a topic -> classified as Weak (<60%)."""
        self._simulate_quiz_attempt("Thermodynamics", 35.0)
        analysis = PerformanceAnalyzer.analyze_student(self.student_id)
        weak_names = [t['topic'] for t in analysis['weak_topics']]
        self.assertIn("Thermodynamics", weak_names)

    def test_case_10_improving_trend_detected(self):
        """Test Case 10: Scores improve across 3 attempts: 35%, 50%, 70% -> Improving trend detected."""
        self._simulate_quiz_attempt("Optics", 35.0)
        self._simulate_quiz_attempt("Optics", 50.0)
        self._simulate_quiz_attempt("Optics", 70.0)
        analysis = PerformanceAnalyzer.analyze_student(self.student_id)
        improving_topics = {t['topic']: t for t in analysis['improving_topics']}
        self.assertIn("Optics", improving_topics)
        self.assertGreaterEqual(improving_topics['Optics']['delta'], 20.0)
        self.assertEqual(improving_topics['Optics']['trend'], 'Improving')

    def test_case_11_declining_trend_detected(self):
        """Test Case 11: Scores decline across 3 attempts: 90%, 65%, 40% -> Declining trend detected."""
        self._simulate_quiz_attempt("Electromagnetism", 90.0)
        self._simulate_quiz_attempt("Electromagnetism", 65.0)
        self._simulate_quiz_attempt("Electromagnetism", 40.0)
        analysis = PerformanceAnalyzer.analyze_student(self.student_id)
        declining_topics = {t['topic']: t for t in analysis['declining_topics']}
        self.assertIn("Electromagnetism", declining_topics)
        self.assertEqual(declining_topics['Electromagnetism']['delta'], -50.0)

    def test_case_12_single_attempt_no_unsupported_trend(self):
        """Test Case 12: Student has only one quiz attempt -> system avoids unsupported trend conclusions."""
        self._simulate_quiz_attempt("Wave Theory", 75.0)
        analysis = PerformanceAnalyzer.analyze_student(self.student_id)
        wave_topic = next((t for t in analysis['all_topics'] if t['topic'] == 'Wave Theory'), None)
        self.assertIsNotNone(wave_topic)
        self.assertEqual(wave_topic['trend'], "Insufficient History")
        # Should not be in improving or declining lists
        self.assertNotIn("Wave Theory", [t['topic'] for t in analysis['improving_topics']])
        self.assertNotIn("Wave Theory", [t['topic'] for t in analysis['declining_topics']])

    def test_case_13_no_quiz_history(self):
        """Test Case 13: Student has no quiz history -> dashboard loads without errors."""
        fresh_stu_id, _ = UserModel.create_user('student', 'No History Stu', 'nohistory@test.com', 'P@123', 'S-NH', 'Science')
        analysis = PerformanceAnalyzer.analyze_student(fresh_stu_id)
        self.assertFalse(analysis['has_data'])
        self.assertEqual(len(analysis['all_topics']), 0)
        self.assertEqual(analysis['total_attempts'], 0)


class TestAdaptiveTimetable(unittest.TestCase):
    """Prompt 2 Section 11.D: Adaptive timetable test cases (Test Cases 14-22)"""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.teacher_id, _ = UserModel.create_user('teacher', 'TT Prof', 'tt_prof@test.com', 'Pass@123', 'T-TT', 'Engineering')
        cls.student_id, _ = UserModel.create_user('student', 'TT Stu', 'tt_stu@test.com', 'Pass@123', 'S-TT', 'Engineering')
        
        # Create subjects
        cls.chem_id, cls.chem_code = SubjectModel.create_subject(cls.teacher_id, 'CHEM101', 'Chemistry', 'Engineering', 'Chemical reactions')
        cls.math_id, cls.math_code = SubjectModel.create_subject(cls.teacher_id, 'MATH101', 'Mathematics', 'Engineering', 'Calculus and Linear Algebra')
        SubjectModel.enroll_student(cls.student_id, cls.chem_code)
        SubjectModel.enroll_student(cls.student_id, cls.math_code)

    def test_case_14_daily_study_hours_constraint(self):
        """Test Case 14: Generate a basic timetable for 3 daily study hours -> total time does not exceed available time."""
        gen_ok, msg = TimetableModel.generate_timetable_schedule(
            self.student_id, [self.chem_id, self.math_id], daily_hours=3.0, start_time_str="18:00"
        )
        self.assertTrue(gen_ok)
        sessions = TimetableModel.get_student_sessions(self.student_id)
        study_sessions = [s for s in sessions if s['session_type'] == 'study']
        
        # 3 hours daily * 7 days = max 21 study hours total across week
        total_study_minutes = sum(s['duration_minutes'] for s in study_sessions)
        max_allowed_minutes = 3.0 * 60 * 7
        self.assertLessEqual(total_study_minutes, max_allowed_minutes)

    def test_case_15_poor_performance_priority_increase(self):
        """Test Case 15: Student performs poorly in Chemistry -> Chemistry receives higher study priority."""
        # Inject poor Chemistry score (30%)
        q_id = QuizModel.create_quiz(self.chem_id, self.teacher_id, 'Chem Quiz', 'Thermodynamics', 'desc', 10)
        q1 = QuizModel.add_question(q_id, 'Thermodynamics', 'Q?', 'A', 'B', 'C', 'D', 'A', 'exp', 'Medium')
        QuizModel.evaluate_and_record_attempt(q_id, self.student_id, {str(q1): 'B'}) # 0%

        priorities = AdaptiveTimetableEngine.calculate_topic_priorities(self.student_id)
        chem_p = [p['priority_score'] for p in priorities.values() if p['subject_name'] == 'Chemistry']
        self.assertTrue(any(score >= 6.0 for score in chem_p))

    def test_case_16_consistent_performance_revision_preserved(self):
        """Test Case 16: Consistently performing well in Mathematics reduces priority reasonably without removing it."""
        # Inject high Math scores (95%)
        for i in range(2):
            q_id = QuizModel.create_quiz(self.math_id, self.teacher_id, f'Math Quiz {i}', 'Calculus', 'desc', 10)
            q1 = QuizModel.add_question(q_id, 'Calculus', 'Q?', 'A', 'B', 'C', 'D', 'A', 'exp', 'Medium')
            QuizModel.evaluate_and_record_attempt(q_id, self.student_id, {str(q1): 'A'}) # 100%

        priorities = AdaptiveTimetableEngine.calculate_topic_priorities(self.student_id)
        math_p = [p['priority_score'] for p in priorities.values() if p['subject_name'] == 'Mathematics']
        self.assertTrue(all(score >= 1.0 for score in math_p), "Math priority should remain >= 1.0 (never removed).")

    def test_case_17_improving_topic_priority_adjusted(self):
        """Test Case 17: Student improves in previously weak topic -> priority is adjusted accordingly."""
        # Simulate improvement in Chemistry
        q_id = QuizModel.create_quiz(self.chem_id, self.teacher_id, 'Chem Re-test', 'Thermodynamics', 'desc', 10)
        q1 = QuizModel.add_question(q_id, 'Thermodynamics', 'Q?', 'A', 'B', 'C', 'D', 'A', 'exp', 'Medium')
        QuizModel.evaluate_and_record_attempt(q_id, self.student_id, {str(q1): 'A'}) # 100% now

        priorities = AdaptiveTimetableEngine.calculate_topic_priorities(self.student_id)
        thermo = priorities.get('Thermodynamics')
        if thermo:
            # Check reasons reflect update or moderated priority
            self.assertIn('Thermodynamics', priorities)

    def test_case_18_upcoming_examination_priority_boost(self):
        """Test Case 18: Upcoming examination gives preparation appropriate priority boost."""
        conn = get_db()
        exam_target = (datetime.now() + timedelta(days=5)).strftime("%Y-%m-%d")
        conn.execute("UPDATE timetables SET exam_date = ? WHERE student_id = ?", (exam_target, self.student_id))
        conn.commit()
        conn.close()

        priorities = AdaptiveTimetableEngine.calculate_topic_priorities(self.student_id)
        exam_boosted = any(any("exam" in r.lower() for r in p['reasons']) for p in priorities.values())
        self.assertTrue(exam_boosted, "Expected upcoming exam boost in topic priorities.")

    def test_case_19_approaching_assignment_deadline(self):
        """Test Case 19: Approaching assignment deadline accounts for priority schedule."""
        due_soon = (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d")
        AssignmentModel.create_assignment(self.math_id, self.teacher_id, 'Urgent Math Set', 'Calculus', 'desc', due_soon)
        
        priorities = AdaptiveTimetableEngine.calculate_topic_priorities(self.student_id)
        assign_boosted = any(any("assignment" in r.lower() for r in p['reasons']) for p in priorities.values())
        self.assertTrue(assign_boosted, "Expected approaching assignment deadline priority boost.")

    def test_case_20_study_sessions_and_breaks_structure(self):
        """Test Case 20: Sessions do not overlap, breaks are preserved, daily hours respected."""
        adapt_ok, _, adapt_res = AdaptiveTimetableEngine.adapt_timetable(self.student_id, "Test adaptive schedule")
        self.assertTrue(adapt_ok)
        
        sessions = TimetableModel.get_student_sessions(self.student_id)
        # Verify 50m study blocks followed by 10m breaks
        study_blocks = [s for s in sessions if s['session_type'] == 'study']
        break_blocks = [s for s in sessions if s['session_type'] == 'break']
        self.assertGreater(len(study_blocks), 0)
        self.assertGreater(len(break_blocks), 0)
        self.assertTrue(all(s['duration_minutes'] == 50 for s in study_blocks))
        self.assertTrue(all(b['duration_minutes'] == 10 for b in break_blocks))

    def test_case_21_version_retention_after_adaptation(self):
        """Test Case 21: Revised timetable is saved, previous timetable version remains available."""
        # Perform 2 adaptations
        AdaptiveTimetableEngine.adapt_timetable(self.student_id, "Adaptation 1")
        AdaptiveTimetableEngine.adapt_timetable(self.student_id, "Adaptation 2")

        history = TimetableModel.get_version_history(self.student_id)
        self.assertGreaterEqual(len(history), 2)
        version_numbers = [v['version_number'] for v in history]
        self.assertIn(1, version_numbers)
        self.assertIn(2, version_numbers)

    def test_case_22_independent_student_adaptations(self):
        """Test Case 22: Two students attempt same quiz with different scores -> adapt independently."""
        stu2_id, _ = UserModel.create_user('student', 'Student Two', 'stu2@test.com', 'Pass@123', 'S-002', 'Engineering')
        SubjectModel.enroll_student(stu2_id, self.chem_code)
        
        # Student 1 scored 0% earlier in Chemistry, Student 2 scores 100%
        q_id = QuizModel.create_quiz(self.chem_id, self.teacher_id, 'Shared Quiz', 'Organic Chemistry', 'desc', 10)
        q1 = QuizModel.add_question(q_id, 'Organic Chemistry', 'Q?', 'A', 'B', 'C', 'D', 'A', 'exp', 'Medium')
        QuizModel.evaluate_and_record_attempt(q_id, stu2_id, {str(q1): 'A'})

        p1 = AdaptiveTimetableEngine.calculate_topic_priorities(self.student_id)
        p2 = AdaptiveTimetableEngine.calculate_topic_priorities(stu2_id)
        self.assertNotEqual(p1, p2, "Two students with different scores should have independent priorities.")


class TestTeacherDashboard(unittest.TestCase):
    """Prompt 2 Section 11.E: Teacher dashboard test cases (Test Cases 23-25)"""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.app = create_app()
        cls.teacher_id, _ = UserModel.create_user('teacher', 'Prof Harrison', 'teach_h@test.com', 'Pass@123', 'FAC-01', 'Physics')
        cls.unrelated_teacher_id, _ = UserModel.create_user('teacher', 'Prof Unrelated', 'teach_un@test.com', 'Pass@123', 'FAC-02', 'Arts')
        cls.student_id, _ = UserModel.create_user('student', 'Alice Walker', 'alice@test.com', 'Pass@123', 'STU-100', 'Physics')
        
        cls.subject_id, cls.code = SubjectModel.create_subject(cls.teacher_id, 'PHY201', 'Classical Mechanics', 'Physics', 'Mechanics syllabus')
        SubjectModel.enroll_student(cls.student_id, cls.code)

        # Student takes a quiz
        q_id = QuizModel.create_quiz(cls.subject_id, cls.teacher_id, 'Dynamics Test', 'Kinematics', 'desc', 15)
        q1 = QuizModel.add_question(q_id, 'Kinematics', 'Q1?', 'A', 'B', 'C', 'D', 'A', 'exp', 'Easy')
        QuizModel.evaluate_and_record_attempt(q_id, cls.student_id, {str(q1): 'A'})

    def test_case_23_enrolled_student_performance_view(self):
        """Test Case 23: Teacher opens enrolled student's performance page -> records & charts displayed."""
        client = self.app.test_client()
        client.post('/login', data={'email': 'teach_h@test.com', 'password': 'Pass@123', 'role': 'teacher'})
        res = client.get(f'/teacher/performance/{self.student_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn("Alice Walker", res.text)
        self.assertIn("Kinematics", res.text)

    def test_case_24_unauthorized_student_access_denied(self):
        """Test Case 24: Teacher attempts to access unrelated student's private information -> access denied."""
        client = self.app.test_client()
        # Login as unrelated teacher
        client.post('/login', data={'email': 'teach_un@test.com', 'password': 'Pass@123', 'role': 'teacher'})
        res = client.get(f'/teacher/performance/{self.student_id}', follow_redirects=False)
        # Should redirect away with 302 and flash error
        self.assertIn(res.status_code, [302, 403])
        self.assertEqual(res.headers.get('Location'), '/teacher/performance')

    def test_case_25_class_level_performance_analytics(self):
        """Test Case 25: View class-level performance -> Class average & commonly weak topics calculated."""
        analytics = PerformanceAnalyzer.analyze_teacher_class(self.teacher_id, self.subject_id)
        self.assertEqual(analytics['enrolled_count'], 1)
        self.assertEqual(analytics['class_average'], 100.0)
        self.assertIn('Kinematics', [t['topic'] for t in analytics['challenging_topics']])


class TestExistingFeatureRegression(unittest.TestCase):
    """Prompt 2 Section 11.F: Existing feature regression tests (Prompt 1 regression + CSA0207 enrolment)"""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.app = create_app()

    def test_regression_01_user_registration_and_login(self):
        """Regression 1: Student & Teacher registration and login."""
        stu_id, err1 = UserModel.create_user('student', 'Reg Stu', 'reg_stu@test.com', 'Pass@123', 'STU-REG', 'CSE')
        tch_id, err2 = UserModel.create_user('teacher', 'Reg Tch', 'reg_tch@test.com', 'Pass@123', 'TCH-REG', 'CSE')
        self.assertIsNone(err1)
        self.assertIsNone(err2)

        client = self.app.test_client()
        res_stu = client.post('/login', data={'email': 'reg_stu@test.com', 'password': 'Pass@123', 'role': 'student'})
        self.assertEqual(client.session.get('user_id'), stu_id)

    def test_regression_02_student_enrolment_csa0207(self):
        """Regression 2: Verify student enrolment using subject code 'CSA0207' and generated enrolment code."""
        tch_id, _ = UserModel.create_user('teacher', 'Class Teacher', 'csa_tch@test.com', 'Pass@123', 'TCH-CSA', 'IT')
        stu_id, _ = UserModel.create_user('student', 'Class Student', 'csa_stu@test.com', 'Pass@123', 'STU-CSA', 'IT')
        
        # Teacher creates subject with code CSA0207
        subj_id, code = SubjectModel.create_subject(tch_id, 'CSA0207', 'Operating Systems', 'IT', 'Kernel concepts')
        
        # Student enrols using the exact code 'CSA0207'
        success, msg = SubjectModel.enroll_student(stu_id, 'CSA0207')
        self.assertTrue(success)
        self.assertEqual(msg, "Successfully enrolled in the class!")
        
        # Check duplicate enrolment
        dup_success, dup_msg = SubjectModel.enroll_student(stu_id, 'CSA0207')
        self.assertFalse(dup_success)
        self.assertEqual(dup_msg, "You are already enrolled in this class.")

        # Check invalid code
        inv_success, inv_msg = SubjectModel.enroll_student(stu_id, 'INVALID999')
        self.assertFalse(inv_success)
        self.assertEqual(inv_msg, "No class found with this code.")

        # Verify enrolled student list on teacher side
        enrolled_list = SubjectModel.get_enrolled_students(subj_id)
        self.assertTrue(any(s['id'] == stu_id for s in enrolled_list))

    def test_regression_03_materials_and_assignments(self):
        """Regression 3: Material uploads, student access, assignment creation & completion toggle."""
        tch_id, _ = UserModel.create_user('teacher', 'Mat Prof', 'mat_prof@test.com', 'Pass@123', 'T-MAT', 'ECE')
        stu_id, _ = UserModel.create_user('student', 'Mat Stu', 'mat_stu@test.com', 'Pass@123', 'S-MAT', 'ECE')
        s_id, code = SubjectModel.create_subject(tch_id, 'ECE101', 'Signals', 'ECE', 'Signals')
        SubjectModel.enroll_student(stu_id, code)

        # Upload material
        m_id = MaterialModel.create_material(s_id, tch_id, 'Signals Handout', 'Fourier', 'desc', 'link', external_link='https://example.com')
        mats = MaterialModel.get_student_materials(stu_id)
        self.assertTrue(any(m['id'] == m_id for m in mats))

        # Assignment
        a_id = AssignmentModel.create_assignment(s_id, tch_id, 'Homework 1', 'Fourier', 'desc', '2026-12-31')
        assigns = AssignmentModel.get_student_assignments(stu_id)
        self.assertTrue(any(a['id'] == a_id and not a['is_completed'] for a in assigns))

        # Mark completed
        AssignmentModel.toggle_student_completion(a_id, stu_id, mark_completed=True)
        assigns_after = AssignmentModel.get_student_assignments(stu_id)
        self.assertTrue(any(a['id'] == a_id and a['is_completed'] for a in assigns_after))

    def test_regression_04_teacher_quiz_and_student_attempt(self):
        """Regression 4: Teacher-created quiz, student submission, and score storage."""
        tch_id, _ = UserModel.create_user('teacher', 'Qz Prof', 'qz_prof@test.com', 'Pass@123', 'T-QZ', 'CSE')
        stu_id, _ = UserModel.create_user('student', 'Qz Stu', 'qz_stu@test.com', 'Pass@123', 'S-QZ', 'CSE')
        s_id, code = SubjectModel.create_subject(tch_id, 'CSE202', 'Networks', 'CSE', 'Networking')
        SubjectModel.enroll_student(stu_id, code)

        q_id = QuizModel.create_quiz(s_id, tch_id, 'OSI Model Quiz', 'OSI Layers', 'desc', 10)
        q1 = QuizModel.add_question(q_id, 'OSI Layers', 'How many layers?', '5', '6', '7', '8', 'C', '7 layers', 'Easy')
        
        res, _ = QuizModel.evaluate_and_record_attempt(q_id, stu_id, {str(q1): 'C'})
        self.assertEqual(res['score_percentage'], 100.0)

    def test_regression_05_basic_timetable_and_session_toggle(self):
        """Regression 5: Basic timetable generation and session completion toggle."""
        stu_id, _ = UserModel.create_user('student', 'TT Reg Stu', 'tt_reg@test.com', 'Pass@123', 'S-TTR', 'CSE')
        tch_id, _ = UserModel.create_user('teacher', 'TT Reg Tch', 'tt_tch@test.com', 'Pass@123', 'T-TTR', 'CSE')
        s_id, code = SubjectModel.create_subject(tch_id, 'CSE301', 'Databases', 'CSE', 'SQL')
        SubjectModel.enroll_student(stu_id, code)

        gen_ok, _ = TimetableModel.generate_timetable_schedule(stu_id, [s_id], daily_hours=2.0)
        self.assertTrue(gen_ok)
        sessions = TimetableModel.get_student_sessions(stu_id)
        study_sess = [s for s in sessions if s['session_type'] == 'study'][0]

        TimetableModel.toggle_session_completed(study_sess['id'], stu_id)
        updated = [s for s in TimetableModel.get_student_sessions(stu_id) if s['id'] == study_sess['id']][0]
        self.assertEqual(updated['is_completed'], 1)


class TestEndToEndIntegration(unittest.TestCase):
    """Prompt 2 Section 11.G: Complete 16-step end-to-end integration test."""

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.app = create_app()

    def test_complete_16_step_teacher_student_workflow(self):
        """
        Executes complete integration sequence 1-16:
        1. Teacher logs in.
        2. Teacher creates a subject.
        3. Student enrols in that subject.
        4. Teacher uploads study material.
        5. Student accesses the material.
        6. Teacher creates an assignment.
        7. Student views and completes the assignment.
        8. Teacher creates a quiz with questions from multiple topics.
        9. Student attempts the quiz.
        10. System evaluates and stores the results.
        11. System analyzes topic-wise performance.
        12. System identifies weak and strong topics.
        13. System generates personalized recommendations.
        14. System automatically adapts the student's timetable.
        15. Student views the revised timetable.
        16. Teacher views the student's updated performance analytics.
        """
        # Step 1: Teacher logs in
        teacher_id, _ = UserModel.create_user(
            'teacher', 'Prof. Alan Turing', 'turing@ai.edu', 'Enigma@1940', 'FAC-CS-007', 'Computer Science'
        )
        student_id, _ = UserModel.create_user(
            'student', 'Ada Lovelace', 'ada@ai.edu', 'Analytical@1843', 'STU-CS-001', 'Computer Science'
        )

        teacher_client = self.app.test_client()
        res_tlogin = teacher_client.post('/login', data={'email': 'turing@ai.edu', 'password': 'Enigma@1940', 'role': 'teacher'})
        self.assertEqual(teacher_client.session.get('user_id'), teacher_id)

        # Step 2: Teacher creates a subject
        subject_id, enrol_code = SubjectModel.create_subject(
            teacher_id, 'CS501', 'Artificial Intelligence', 'Computer Science', 'Foundations of AI'
        )
        self.assertIsNotNone(subject_id)

        # Step 3: Student enrols in that subject
        student_client = self.app.test_client()
        student_client.post('/login', data={'email': 'ada@ai.edu', 'password': 'Analytical@1843', 'role': 'student'})
        self.assertEqual(student_client.session.get('user_id'), student_id)
        
        enrolled, msg = SubjectModel.enroll_student(student_id, enrol_code)
        self.assertTrue(enrolled)

        # Step 4: Teacher uploads study material
        mat_id = MaterialModel.create_material(
            subject_id, teacher_id, 'A* Search Algorithms Guide', 'Search Algorithms',
            'Heuristic graph search lecture', 'link', external_link='https://example.edu/astar'
        )
        self.assertIsNotNone(mat_id)

        # Step 5: Student accesses the material
        student_materials = MaterialModel.get_student_materials(student_id)
        self.assertTrue(any(m['id'] == mat_id for m in student_materials))

        # Step 6: Teacher creates an assignment
        due_date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
        assign_id = AssignmentModel.create_assignment(
            subject_id, teacher_id, 'Implement Minimax with Alpha-Beta', 'Game Playing',
            'Adversarial search programming set', due_date
        )
        self.assertIsNotNone(assign_id)

        # Step 7: Student views and completes the assignment
        student_assigns = AssignmentModel.get_student_assignments(student_id)
        target_a = next(a for a in student_assigns if a['id'] == assign_id)
        self.assertFalse(target_a['is_completed'])
        AssignmentModel.toggle_student_completion(assign_id, student_id, mark_completed=True)
        updated_a = next(a for a in AssignmentModel.get_student_assignments(student_id) if a['id'] == assign_id)
        self.assertTrue(updated_a['is_completed'])

        # Step 8: Teacher creates a quiz with questions from multiple topics
        quiz_id = QuizModel.create_quiz(
            subject_id, teacher_id, 'AI Comprehensive Assessment', 'AI Core', 'Midterm quiz', 20
        )
        # Topic 1: Search Algorithms (Student will answer correctly -> Strong)
        q1 = QuizModel.add_question(
            quiz_id, 'Search Algorithms', 'What is admissible heuristic?',
            'Never overestimates', 'Always overestimates', 'Zero cost', 'Negative cost', 'A', 'Admissibility', 'Medium'
        )
        # Topic 2: Neural Networks (Student will answer incorrectly -> Weak)
        q2 = QuizModel.add_question(
            quiz_id, 'Neural Networks', 'What solves vanishing gradient?',
            'ReLU', 'Sigmoid', 'Step function', 'Linear', 'A', 'ReLU has constant gradient', 'Medium'
        )

        # Step 9: Student attempts the quiz
        # Submit: q1 correct ('A'), q2 wrong ('B')
        answers = {str(q1): 'A', str(q2): 'B'}
        
        # Step 10: System evaluates and stores the results
        eval_res, err = QuizModel.evaluate_and_record_attempt(quiz_id, student_id, answers, time_taken_seconds=300)
        self.assertIsNone(err)
        self.assertEqual(eval_res['score_percentage'], 50.0)

        # Step 11: System analyzes topic-wise performance
        analysis = PerformanceAnalyzer.analyze_student(student_id)
        self.assertTrue(analysis['has_data'])

        # Step 12: System identifies weak and strong topics
        strong_names = [t['topic'] for t in analysis['strong_topics']]
        weak_names = [t['topic'] for t in analysis['weak_topics']]
        self.assertIn('Search Algorithms', strong_names)
        self.assertIn('Neural Networks', weak_names)

        # Step 13: System generates personalized recommendations
        recs = RecommendationEngine.get_latest_recommendations(student_id)
        self.assertGreater(len(recs), 0)
        self.assertTrue(any('Neural Networks' in r['topic'] or 'Search' in r['topic'] for r in recs))

        # Step 14: System automatically adapts the student's timetable
        adapt_ok, msg, adapt_res = AdaptiveTimetableEngine.adapt_timetable(student_id, "Post-assessment dynamic adjustment")
        self.assertTrue(adapt_ok)

        # Step 15: Student views the revised timetable
        res_tt = student_client.get('/timetable/student')
        self.assertEqual(res_tt.status_code, 200)
        self.assertIn("My Study Timetable", res_tt.text)

        # Step 16: Teacher views the student's updated performance analytics
        res_tview = teacher_client.get(f'/teacher/performance/{student_id}')
        self.assertEqual(res_tview.status_code, 200)
        self.assertIn("Ada Lovelace", res_tview.text)
        self.assertIn("Search Algorithms", res_tview.text)
        self.assertIn("Neural Networks", res_tview.text)


class TestAuthenticationAndSecurity(unittest.TestCase):
    """
    Mandatory Tests for Authentication, Email Verification & Forgot Password:
    1. Login with a registered email and correct password.
    2. Login with a registered email and incorrect password.
    3. Login with a nonexistent email.
    4. Register with an existing email.
    5. Register with a new email and verify using the correct OTP.
    6. Attempt verification with an incorrect OTP.
    7. Attempt verification with an expired OTP.
    8. Attempt login before email verification.
    9. Request a password reset for a registered email.
    10. Attempt password reset with an invalid or expired token.
    11. Reset the password successfully and log in using the new password.
    12. Check student and teacher role permissions.
    13. Confirm existing accounts, courses, enrolments and quiz history remain intact.
    """

    @classmethod
    def setUpClass(cls):
        setup_clean_test_db()
        cls.app = create_app()
        # Seed a verified test student and verified test teacher
        cls.student_id, _ = UserModel.create_user(
            'student', 'Auth Verified Student', 'auth_stu@test.com', 'CorrectPass@123',
            'STU-AUTH-01', 'Computer Science', is_verified=1
        )
        cls.teacher_id, _ = UserModel.create_user(
            'teacher', 'Auth Verified Teacher', 'auth_tch@test.com', 'TeacherPass@123',
            'TCH-AUTH-01', 'Computer Science', is_verified=1
        )

    def setUp(self):
        outbox.clear()

    def test_01_login_registered_email_correct_password(self):
        """1. Login with a registered email and correct password -> success, sets session."""
        client = self.app.test_client()
        res = client.post('/login', data={
            'email': 'auth_stu@test.com',
            'password': 'CorrectPass@123',
            'role': 'student'
        })
        self.assertEqual(res.status_code, 200)
        self.assertEqual(client.session.get('user_id'), self.student_id)
        self.assertEqual(client.session.get('role'), 'student')
        self.assertIn("Student Dashboard", res.text)

    def test_02_login_registered_email_incorrect_password(self):
        """2. Login with a registered email and incorrect password -> rejected, 'Incorrect password. Please try again.'"""
        client = self.app.test_client()
        res = client.post('/login', data={
            'email': 'auth_stu@test.com',
            'password': 'WrongPassword123',
            'role': 'student'
        })
        self.assertIsNone(client.session.get('user_id'), "Session must not be established on incorrect password.")
        self.assertIn("Incorrect password. Please try again.", res.text)

    def test_03_login_nonexistent_email(self):
        """3. Login with a nonexistent email -> rejected, 'No account found with this email. Please register first.'"""
        client = self.app.test_client()
        res = client.post('/login', data={
            'email': 'does_not_exist_999@test.com',
            'password': 'AnyPassword123',
            'role': 'student'
        })
        self.assertIsNone(client.session.get('user_id'), "Session must not be established for nonexistent email.")
        self.assertIn("No account found with this email. Please register first.", res.text)

    def test_04_register_existing_email(self):
        """4. Register with an existing email -> rejected with error, no duplicate account created."""
        client = self.app.test_client()
        res = client.post('/register/student', data={
            'name': 'Duplicate Attempt',
            'email': 'auth_stu@test.com',
            'password': 'NewPassword123',
            'confirm_password': 'NewPassword123',
            'student_id': 'DUP-001',
            'department': 'Computer Science',
            'year_of_study': '2nd Year',
            'semester': 'Semester 3'
        })
        self.assertIn("An account with this email address already exists", res.text)
        
        # Verify no duplicate row in DB
        conn = get_db()
        count = conn.execute("SELECT COUNT(*) FROM users WHERE email = 'auth_stu@test.com'").fetchone()[0]
        conn.close()
        self.assertEqual(count, 1)

    def test_05_register_new_email_and_verify_correct_otp(self):
        """5. Register with a new email and verify using the correct OTP -> activates account."""
        client = self.app.test_client()
        res_reg = client.post('/register/student', data={
            'name': 'New Student Alex',
            'email': 'new_alex@test.com',
            'password': 'SecurePass@123',
            'confirm_password': 'SecurePass@123',
            'student_id': 'STU-ALEX-01',
            'department': 'Information Technology',
            'year_of_study': '1st Year',
            'semester': 'Semester 1'
        })
        # Verify user is created with is_verified = 0
        new_user = UserModel.get_by_email('new_alex@test.com')
        self.assertIsNotNone(new_user)
        self.assertEqual(new_user['is_verified'], 0, "Newly registered user must initially be unverified.")
        self.assertIsNotNone(new_user['verification_otp_hash'])

        # An email must have been sent
        self.assertGreaterEqual(len(outbox), 1)
        self.assertEqual(outbox[-1]['to'], 'new_alex@test.com')

        # Retrieve the generated OTP from outbox text or regenerate test OTP
        test_otp = UserModel.set_verification_otp(new_user['id'], otp_code="654321")
        
        # Verify using correct OTP
        res_verify = client.post('/verify-otp', data={'otp': '654321', 'user_id': new_user['id']})
        
        # User must now be active (is_verified = 1)
        updated_user = UserModel.get_by_id(new_user['id'])
        self.assertEqual(updated_user['is_verified'], 1)
        self.assertIsNone(updated_user['verification_otp_hash'])

        # Now login should succeed
        login_res = client.post('/login', data={
            'email': 'new_alex@test.com',
            'password': 'SecurePass@123',
            'role': 'student'
        })
        self.assertEqual(client.session.get('user_id'), new_user['id'])

    def test_06_verify_incorrect_otp(self):
        """6. Attempt verification with an incorrect OTP -> rejected, user remains unverified."""
        # Create unverified user
        unver_id, _ = UserModel.create_user(
            'student', 'Unverified Student', 'unver_fail@test.com', 'Pass@123',
            'STU-UNV-01', 'CSE', is_verified=0
        )
        UserModel.set_verification_otp(unver_id, otp_code="123456")

        client = self.app.test_client()
        client.session['unverified_user_id'] = unver_id
        res = client.post('/verify-otp', data={'otp': '999999', 'user_id': unver_id})
        
        self.assertIn("Invalid verification code", res.text)
        user = UserModel.get_by_id(unver_id)
        self.assertEqual(user['is_verified'], 0)
        self.assertGreaterEqual(user['otp_attempts'], 1)

    def test_07_verify_expired_otp(self):
        """7. Attempt verification with an expired OTP -> rejected with expiration error."""
        unver_id, _ = UserModel.create_user(
            'student', 'Expired OTP Student', 'expired_otp@test.com', 'Pass@123',
            'STU-EXP-01', 'CSE', is_verified=0
        )
        UserModel.set_verification_otp(unver_id, otp_code="123456")

        # Manually alter expiry to past
        conn = get_db()
        past_time = (datetime.now() - timedelta(minutes=10)).strftime('%Y-%m-%d %H:%M:%S')
        conn.execute("UPDATE users SET otp_expires_at = ? WHERE id = ?", (past_time, unver_id))
        conn.commit()
        conn.close()

        client = self.app.test_client()
        client.session['unverified_user_id'] = unver_id
        res = client.post('/verify-otp', data={'otp': '123456', 'user_id': unver_id})

        self.assertIn("Verification code has expired", res.text)
        user = UserModel.get_by_id(unver_id)
        self.assertEqual(user['is_verified'], 0)

    def test_08_login_before_email_verification(self):
        """8. Attempt login before email verification -> rejected, redirected to OTP verification."""
        unver_id, _ = UserModel.create_user(
            'student', 'Pending Verify Student', 'pending_ver@test.com', 'Pass@123',
            'STU-PV-01', 'CSE', is_verified=0
        )
        UserModel.set_verification_otp(unver_id, otp_code="112233")

        client = self.app.test_client()
        res = client.post('/login', data={
            'email': 'pending_ver@test.com',
            'password': 'Pass@123',
            'role': 'student'
        }, follow_redirects=True)

        self.assertIsNone(client.session.get('user_id'), "Unverified user must not be given active session.")
        self.assertIn("verify", res.text.lower())

    def test_09_request_password_reset_registered_email(self):
        """9. Request a password reset for a registered email -> sends reset code."""
        client = self.app.test_client()
        res = client.post('/forgot-password', data={'email': 'auth_stu@test.com'}, follow_redirects=True)
        
        self.assertEqual(res.status_code, 200)
        self.assertGreaterEqual(len(outbox), 1)
        self.assertEqual(outbox[-1]['to'], 'auth_stu@test.com')

        user = UserModel.get_by_email('auth_stu@test.com')
        self.assertIsNotNone(user['reset_token_hash'])
        self.assertIsNotNone(user['reset_expires_at'])

    def test_10_password_reset_invalid_or_expired_token(self):
        """10. Attempt password reset with an invalid or expired token -> rejected with error."""
        user = UserModel.get_by_email('auth_stu@test.com')
        UserModel.set_password_reset_otp('auth_stu@test.com', reset_code="888888")

        client = self.app.test_client()

        # Invalid token
        res_invalid = client.post('/reset-password', data={
            'email': 'auth_stu@test.com',
            'code': '000000',
            'password': 'NewPassword@123',
            'confirm_password': 'NewPassword@123'
        })
        self.assertIn("Invalid reset verification code", res_invalid.text)

        # Expired token
        conn = get_db()
        past_time = (datetime.now() - timedelta(minutes=20)).strftime('%Y-%m-%d %H:%M:%S')
        conn.execute("UPDATE users SET reset_expires_at = ? WHERE email = ?", (past_time, 'auth_stu@test.com'))
        conn.commit()
        conn.close()

        res_expired = client.post('/reset-password', data={
            'email': 'auth_stu@test.com',
            'code': '888888',
            'password': 'NewPassword@123',
            'confirm_password': 'NewPassword@123'
        })
        self.assertIn("expired", res_expired.text.lower())

    def test_11_reset_password_successfully_and_login_new_password(self):
        """11. Reset password successfully and log in using the new password."""
        UserModel.set_password_reset_otp('auth_stu@test.com', reset_code="334455")

        client = self.app.test_client()
        res_reset = client.post('/reset-password', data={
            'email': 'auth_stu@test.com',
            'code': '334455',
            'password': 'BrandNewPassword@2026',
            'confirm_password': 'BrandNewPassword@2026'
        }, follow_redirects=True)

        self.assertEqual(res_reset.status_code, 200)

        # Old password must now fail
        res_old = client.post('/login', data={
            'email': 'auth_stu@test.com',
            'password': 'CorrectPass@123',
            'role': 'student'
        })
        self.assertIn("Incorrect password. Please try again.", res_old.text)
        self.assertIsNone(client.session.get('user_id'))

        # New password must succeed
        res_new = client.post('/login', data={
            'email': 'auth_stu@test.com',
            'password': 'BrandNewPassword@2026',
            'role': 'student'
        })
        self.assertEqual(client.session.get('user_id'), self.student_id)

    def test_12_role_permissions_enforcement(self):
        """12. Check student and teacher role permissions -> cross-role access prevented."""
        # Student cannot access teacher dashboard
        stu_client = self.app.test_client()
        stu_client.session['user_id'] = self.student_id
        stu_client.session['role'] = 'student'
        res_t = stu_client.get('/teacher/dashboard', follow_redirects=False)
        self.assertIn(res_t.status_code, [302, 403])

        # Teacher cannot access student dashboard
        tch_client = self.app.test_client()
        tch_client.session['user_id'] = self.teacher_id
        tch_client.session['role'] = 'teacher'
        res_s = tch_client.get('/student/dashboard', follow_redirects=False)
        self.assertIn(res_s.status_code, [302, 403])

        # Unauthenticated cannot access dashboards
        guest_client = self.app.test_client()
        res_g1 = guest_client.get('/student/dashboard', follow_redirects=False)
        res_g2 = guest_client.get('/teacher/dashboard', follow_redirects=False)
        self.assertIn(res_g1.status_code, [302, 401])
        self.assertIn(res_g2.status_code, [302, 401])

    def test_13_existing_accounts_and_data_intact(self):
        """13. Confirm existing production accounts, courses, enrolments and quiz history remain intact."""
        prod_db_path = os.path.join(BASE_DIR, 'instance', 'studyplanner.db')
        self.assertTrue(os.path.exists(prod_db_path), "Production database must exist.")
        
        import sqlite3
        conn = sqlite3.connect(prod_db_path)
        c = conn.cursor()

        # Check existing accounts
        users = c.execute("SELECT email, role, is_verified FROM users").fetchall()
        user_emails = [u[0] for u in users]
        
        # Verify demo accounts are present and verified
        self.assertIn('teacher@studyglow.com', user_emails)
        self.assertIn('student@studyglow.com', user_emails)
        for u in users:
            self.assertEqual(u[2], 1, f"Pre-existing user {u[0]} must be verified.")

        # Check existing courses, enrolments, quizzes
        subjects_count = c.execute("SELECT COUNT(*) FROM subjects").fetchone()[0]
        enrolments_count = c.execute("SELECT COUNT(*) FROM enrolments").fetchone()[0]
        quizzes_count = c.execute("SELECT COUNT(*) FROM quizzes").fetchone()[0]
        attempts_count = c.execute("SELECT COUNT(*) FROM quiz_attempts").fetchone()[0]

        self.assertGreater(subjects_count, 0)
        self.assertGreater(enrolments_count, 0)
        self.assertGreater(quizzes_count, 0)
        self.assertGreater(attempts_count, 0)
        conn.close()


def run_all_tests():
    """Custom runner that runs all test suites and generates the mandatory test report."""
    test_categories = [
        ("Application startup", TestApplicationStartup),
        ("Quiz generation and evaluation", TestQuizSystem),
        ("Topic analysis", TestTopicAnalysis),
        ("Adaptive timetable", TestAdaptiveTimetable),
        ("Teacher dashboard", TestTeacherDashboard),
        ("Authentication & Security", TestAuthenticationAndSecurity),
        ("Existing feature regression", TestExistingFeatureRegression),
        ("End-to-end integration", TestEndToEndIntegration),
    ]

    report = []
    total_all = 0
    passed_all = 0
    failed_all = 0

    print("=" * 80)
    print("STARTING SMART STUDY PLANNER COMPREHENSIVE AUTOMATED TEST SUITE")
    print(f"Isolated Test Database: {TEST_DB_PATH}")
    print("=" * 80)

    for cat_name, test_class in test_categories:
        suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
        runner = unittest.TextTestRunner(verbosity=1, stream=open(os.devnull, 'w'))
        result = runner.run(suite)

        cat_total = result.testsRun
        cat_failed = len(result.failures) + len(result.errors)
        cat_passed = cat_total - cat_failed

        report.append({
            'category': cat_name,
            'total': cat_total,
            'passed': cat_passed,
            'failed': cat_failed,
            'errors': result.failures + result.errors
        })

        total_all += cat_total
        passed_all += cat_passed
        failed_all += cat_failed

        status_str = "PASS" if cat_failed == 0 else "FAIL"
        print(f"[{status_str}] {cat_name:<35} | Total: {cat_total:>2} | Passed: {cat_passed:>2} | Failed: {cat_failed:>2}")
        if cat_failed > 0:
            for err in result.failures + result.errors:
                print(f"    ERROR in {err[0]}: {err[1]}")

    print("=" * 80)
    print("TEST REPORT TABLE (SECTION 12 MANDATORY FORMAT):")
    print("=" * 80)
    print(f"| {'Test Category':<32} | {'Total Tests':<11} | {'Passed':<6} | {'Failed':<6} |")
    print(f"|{'-' * 34}|{'-' * 13}|{'-' * 8}|{'-' * 8}|")
    for r in report:
        print(f"| {r['category']:<32} | {r['total']:<11} | {r['passed']:<6} | {r['failed']:<6} |")
    print(f"| {'TOTAL':<32} | {total_all:<11} | {passed_all:<6} | {failed_all:<6} |")
    print("=" * 80)

    # Clean up test database
    if os.path.exists(TEST_DB_PATH):
        try:
            os.remove(TEST_DB_PATH)
        except Exception:
            pass

    return failed_all == 0


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
